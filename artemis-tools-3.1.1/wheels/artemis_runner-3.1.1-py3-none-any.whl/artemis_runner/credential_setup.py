"""Module for setting up and validating Artemis credentials."""

import os
import sys
from pathlib import Path
from typing import Optional

import typer
from dotenv import dotenv_values
from evoml_services.clients.thanos.client import ThanosClient, ThanosSettings

from artemis_runner import custom_env_setup
from artemis_runner.envs import Environment, get_env


def validate_credentials(username: str, password: str, environment: Environment = Environment.production) -> bool:
    """
    Validate credentials by attempting to authenticate with Thanos service.

    Returns True if credentials are valid, False otherwise.
    Exits immediately on rate limit (429) errors.
    """
    try:
        # Get environment configuration
        env_config = get_env(environment)

        # Set up authentication environment variables
        os.environ["THANOS_USERNAME"] = username
        os.environ["THANOS_PASSWORD"] = password

        # Update environment with Thanos settings
        for key, value in env_config.items():
            if key.startswith("THANOS_"):
                os.environ[key] = str(value)

        # Create Thanos client and test authentication
        thanos_settings = ThanosSettings.with_env_prefix("thanos")
        thanos_client = ThanosClient(thanos_settings)

        # Try to get user info - this will validate credentials
        try:
            user_info = thanos_client.get("/users/me")
            # If we got user info, credentials are valid
            return True
        except Exception as e:
            error_msg = str(e)

            # Check for rate limit error
            if "429" in error_msg or "too many requests" in error_msg.lower():
                typer.echo("\n❌ Too many login attempts. You've hit the rate limit.", err=True)
                typer.echo("Please wait a few minutes before trying again.", err=True)
                typer.echo("This usually happens after multiple failed login attempts.", err=True)
                sys.exit(1)

            # Check if it's an authentication error
            elif (
                "400" in error_msg
                or "invalid_grant" in error_msg
                or "401" in error_msg
                or "unauthorized" in error_msg.lower()
                or "credentials" in error_msg.lower()
            ):
                return False

            # Other errors we'll treat as connection issues
            raise

    except Exception as e:
        # For connection errors, exit with error message
        typer.echo(f"Error: Could not connect to Artemis services: {e}", err=True)
        typer.echo("Please check your internet connection and environment settings.", err=True)
        sys.exit(1)


def ensure_credentials_exist_for_start_worker(
    runner_name: str, environment: Environment, delete_task_output: bool
) -> None:
    """
    Ensure .env.credentials exists for start_worker.

    Flow:
    0. If environment is custom and .env.custom doesn't exist: run custom setup
    1. Load credentials from .env.credentials (if exists)
    2. Load credentials from environment (takes precedence)
    3. Validate credentials
    4. Prompt for credentials if not provided or invalid (max 3 attempts)
    5. Save to .env.credentials
    """
    # Step 0: Handle custom environment setup
    if environment == Environment.custom:
        env_custom_path = Path(".env.custom")
        if not env_custom_path.exists():
            try:
                custom_env_setup.run_custom_env_setup()
            except KeyboardInterrupt:
                typer.echo("\n\nSetup cancelled by user.", err=True)
                sys.exit(1)
            except Exception as e:
                typer.echo(f"\n\n❌ Custom environment setup failed: {e}", err=True)
                sys.exit(1)

    credentials_path = Path(".env.credentials")

    # Step 1: Load credentials from .env.credentials
    file_creds = {}
    if credentials_path.exists():
        file_creds = dotenv_values(credentials_path)

    # Step 2: Load credentials from environment (with fallback to file)
    username = os.environ.get("ARTEMIS_USERNAME")
    password = os.environ.get("ARTEMIS_PASSWORD")

    if not username:
        username = file_creds.get("ARTEMIS_USERNAME")
        # Treat placeholder as missing
        if username == "<your artemis email address>":
            username = None

    if not password:
        password = file_creds.get("ARTEMIS_PASSWORD")
        if password == "<your artemis password>":
            password = None

    # Track sources for messaging
    username_from_env = bool(os.environ.get("ARTEMIS_USERNAME"))
    password_from_env = bool(os.environ.get("ARTEMIS_PASSWORD"))

    # Step 3: Validate credentials (if both present)
    credentials_valid = False
    if username and password:
        source = "environment variables" if (username_from_env and password_from_env) else ".env.credentials file"
        typer.echo(f"\n🔍 Validating credentials from {source}...")
        credentials_valid = validate_credentials(username, password, environment)

        if credentials_valid:
            typer.echo("✅ Credentials validated successfully!")
        else:
            typer.echo(f"❌ Invalid credentials from {source}.", err=True)

            # Can't retry if from env vars
            if username_from_env or password_from_env:
                typer.echo("Please check your environment variables ARTEMIS_USERNAME and ARTEMIS_PASSWORD.", err=True)
                sys.exit(1)

            # Reset for prompting
            username = None
            password = None

    # Step 4: Prompt for credentials if needed
    if not credentials_valid:
        _display_setup_header(environment)

        max_attempts = 3
        for attempt in range(max_attempts):
            username = typer.prompt("Artemis login email")
            password = typer.prompt("Artemis login password", hide_input=True)

            typer.echo("\n🔍 Validating credentials...")
            credentials_valid = validate_credentials(username, password, environment)

            if credentials_valid:
                typer.echo("✅ Credentials validated successfully!\n")
                break
            else:
                typer.echo("❌ Invalid credentials.", err=True)
                if attempt < max_attempts - 1:
                    typer.echo(f"Please try again ({attempt + 2}/{max_attempts} attempts).\n", err=True)
                else:
                    typer.echo("Maximum login attempts reached.", err=True)
                    sys.exit(1)

    # Step 5: Save to .env.credentials (once)
    # Use placeholders for env var credentials
    save_username = "<your artemis email address>" if username_from_env else username
    save_password = "<your artemis password>" if password_from_env else password

    _write_credentials_file(
        username=save_username,
        password=save_password,
        runner_name=runner_name,
        environment=environment,
        delete_task_output=delete_task_output,
    )

    typer.echo("💾 Saved credentials to .env.credentials")

    # Notify credential sources
    _notify_credential_sources(username_from_env, password_from_env, runner_name)


def _display_setup_header(environment: Environment) -> None:
    """Display setup header with connection information."""
    typer.echo("\n🔧 Artemis Credentials Setup")
    typer.echo("=" * 40)
    typer.echo("Setting up credentials for the Artemis Runner.\n")

    env_config = get_env(environment)
    thanos_host = env_config.get("THANOS_HOST", "artemis.turintech.ai")
    thanos_https = env_config.get("THANOS_HTTPS", "True").lower() == "true"
    protocol = "https" if thanos_https else "http"

    typer.echo(f"🌐 Connecting to: {protocol}://{thanos_host}")
    if environment != Environment.production:
        typer.echo(f"🌍 Environment: {environment.value}")
    typer.echo()


def _write_credentials_file(
    username: str, password: str, runner_name: str, environment: Environment, delete_task_output: bool
) -> None:
    """Write credentials to .env.credentials file."""
    credentials_path = Path(".env.credentials")
    with open(credentials_path, "w") as f:
        f.write(f'ARTEMIS_USERNAME="{username}"\n')
        f.write(f'ARTEMIS_PASSWORD="{password}"\n')
        f.write(f'ARTEMIS_RUNNER_NAME="{runner_name}"\n')
        f.write(f'ARTEMIS_ENVIRONMENT="{environment.value}"\n')
        f.write(f'ARTEMIS_DELETE_TASK_OUTPUT="{str(delete_task_output).lower()}"\n')


def _notify_credential_sources(
    username_from_env: Optional[str], password_from_env: Optional[str], runner_name: str
) -> None:
    """Notify user where credentials are being sourced from."""
    typer.echo("\n🔐 Credential Sources:")

    if username_from_env:
        typer.echo(f"  Username: Environment variable (ARTEMIS_USERNAME)")
    else:
        typer.echo(f"  Username: .env.credentials file")

    if password_from_env:
        typer.echo(f"  Password: Environment variable (ARTEMIS_PASSWORD)")
    else:
        typer.echo(f"  Password: .env.credentials file")

    typer.echo(f"  Runner name: CLI argument ({runner_name})")
    typer.echo()
