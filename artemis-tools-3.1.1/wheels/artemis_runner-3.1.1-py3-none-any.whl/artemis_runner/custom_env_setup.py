"""Module for setting up custom environment configurations."""

import sys
from pathlib import Path
from typing import TypedDict
from urllib.parse import urlparse

import typer


class ParsedUrl(TypedDict):
    """Structure for parsed URL components."""

    protocol: str
    host: str
    port: int


class CustomEnvInputs(TypedDict):
    """Structure for custom environment setup inputs."""

    protocol: str
    host: str
    port: int


# Static credentials for custom environment
RUNNER_CLIENT_ID = "runner-client-id"
RUNNER_CLIENT_SECRET = "PFK1w1dTwsE3tsoLd9WxJsHy3adlA"

# Service-specific URL path postfixes
SERVICE_POSTFIXES = {
    "THANOS": "/turintech-thanos/api",
    "THOR": "/turintech-thor/api",
    "FALCON": "/turintech-falcon/api",
    "VISION": "/turintech-vision/api",
    "LOKI": "/turintech-loki",  # Note: no /api suffix
}


def generate_service_configs(protocol: str, host: str, port: int) -> dict[str, str]:
    """
    Generate configuration for all 5 Artemis microservices from parsed URL components.

    Takes parsed URL components and produces a dictionary with all required
    configuration keys for THANOS, THOR, FALCON, VISION, and LOKI services.

    Args:
        protocol: Either "https" or "http"
        host: Hostname or IP address
        port: Port number (as integer)

    Returns:
        Dictionary containing 25+ configuration keys:
        - For each service: HOST, PORT, POSTFIX, HTTPS, READ_TIMEOUT
        - Additional: LOKI_CONNECT_TIMEOUT

    Example:
        >>> generate_service_configs("https", "myserver.com", 443)
        {
            "THANOS_HOST": "myserver.com",
            "THANOS_PORT": "443",
            "THANOS_POSTFIX": "/turintech-thanos/api",
            "THANOS_HTTPS": "True",
            "THANOS_READ_TIMEOUT": "120",
            ...
        }
    """
    config = {}

    # Convert protocol to HTTPS boolean string
    https_value = "True" if protocol == "https" else "False"
    # Convert port to string
    port_str = str(port)

    # Generate configuration for each service
    for service_name, postfix in SERVICE_POSTFIXES.items():
        # Core service connection parameters
        config[f"{service_name}_HOST"] = host
        config[f"{service_name}_PORT"] = port_str
        config[f"{service_name}_POSTFIX"] = postfix
        config[f"{service_name}_HTTPS"] = https_value

        # Timeout configuration (all services have read timeout)
        config[f"{service_name}_READ_TIMEOUT"] = "120"

    # LOKI-specific additional timeout
    config["LOKI_CONNECT_TIMEOUT"] = "10"

    return config


def prompt_custom_env_inputs() -> CustomEnvInputs:
    """
    Collect custom environment setup inputs interactively.

    Prompts user for base URL (uses parse_base_url for validation and parsing).

    Returns:
        Dictionary containing:
        - protocol: str ("https" or "http")
        - host: str (hostname or IP)
        - port: int (explicit or default)

    Raises:
        ValueError: If URL parsing fails or inputs are invalid
        KeyboardInterrupt: If user cancels (Ctrl+C)
    """
    # Display introductory message
    typer.echo("\n🔧 Custom Artemis Deployment Setup")
    typer.echo("=" * 40)
    typer.echo("Setting up connection to your custom Artemis deployment...\n")

    # Display accepted URL formats
    typer.echo("Accepted URL formats:")
    typer.echo("  - https://myserver.com")
    typer.echo("  - http://localhost:8080")
    typer.echo("  - myserver.com\n")

    # Prompt for base URL and parse it
    base_url = typer.prompt("Enter the base URL for your custom Artemis deployment (e.g., https://myserver.com)")
    parsed_url = parse_base_url(base_url)

    # Display parsed URL confirmation
    protocol = parsed_url["protocol"]
    host = parsed_url["host"]
    port = parsed_url["port"]

    # Show default port info if using standard ports
    port_display = f":{port}" if (protocol == "https" and port != 443) or (protocol == "http" and port != 80) else ""

    typer.echo(f"\n✓ Parsed URL: {protocol}://{host}{port_display}")
    typer.echo(f"✓ Service endpoints will use: {protocol}://{host}{port_display}/turintech-[service]\n")

    # Return complete dictionary
    return {
        "protocol": protocol,
        "host": host,
        "port": port,
    }


def parse_base_url(url: str) -> ParsedUrl:
    """
    Parse a base URL string into structured components (protocol, host, port).

    Supports multiple input formats:
    - Full URLs: https://myserver.com, http://localhost:8080
    - Bare hostnames: myserver.com, localhost, 192.168.1.100
    - With/without trailing slashes
    - Explicit or implicit ports

    Args:
        url: The URL string to parse (can include or omit protocol)

    Returns:
        Dictionary with keys:
        - protocol: str ("https" or "http")
        - host: str (hostname or IP address)
        - port: int (explicit or default: 443 for HTTPS, 80 for HTTP)

    Raises:
        ValueError: If the URL is invalid or host is empty
    """
    if not url or not url.strip():
        raise ValueError("URL cannot be empty")

    url = url.strip()

    # Check if URL has a protocol scheme
    has_scheme = "://" in url

    if not has_scheme:
        # No protocol specified - prompt user for HTTPS preference
        use_https = typer.confirm("Use HTTPS?", default=True)
        protocol = "https" if use_https else "http"
        # Prepend protocol for parsing
        url = f"{protocol}://{url}"

    # Parse the URL
    parsed = urlparse(url)

    # Extract protocol
    protocol = parsed.scheme.lower()
    if protocol not in ("http", "https"):
        raise ValueError(f"Invalid protocol: {protocol}. Must be 'http' or 'https'")

    # Extract host (hostname or IP)
    host = parsed.hostname
    if not host:
        raise ValueError("Invalid URL: host is empty or could not be parsed")

    # Extract port or use defaults (urllib.parse validates port range automatically)
    if parsed.port is not None:
        port = parsed.port
    else:
        # Use default ports based on protocol
        port = 443 if protocol == "https" else 80

    return {
        "protocol": protocol,
        "host": host,
        "port": port,
    }


def write_env_custom_file(service_configs: dict[str, str], client_id: str, client_secret: str) -> None:
    """
    Generate and write a complete .env.custom configuration file.

    Creates a .env.custom file in the current working directory with all required
    configuration for the 5 Artemis microservices (THANOS, THOR, FALCON, VISION, LOKI).

    Args:
        service_configs: Dictionary containing parsed URL components for all services.
                        Expected keys: SERVICE_HOST, SERVICE_PORT, SERVICE_POSTFIX,
                        SERVICE_HTTPS, SERVICE_READ_TIMEOUT for each service.
        client_id: CLIENT_ID for Thanos authentication
        client_secret: CLIENT_SECRET for Thanos authentication

    Raises:
        OSError: If file cannot be written (permission denied, disk full, etc.)

    Example:
        >>> service_configs = generate_service_configs("https", "myserver.com", 443)
        >>> write_env_custom_file(service_configs, "my_client_id", "my_secret")
        # Creates .env.custom with all 5 service configurations
    """
    try:
        # Build the file content with proper formatting
        content = f"""#########  THANOS  ###########
THANOS_CLIENT_ID={client_id}
THANOS_CLIENT_SECRET={client_secret}
THANOS_GRANT_TYPE=password
THANOS_HOST={service_configs["THANOS_HOST"]}
THANOS_PORT={service_configs["THANOS_PORT"]}
THANOS_POSTFIX={service_configs["THANOS_POSTFIX"]}
THANOS_HTTPS={service_configs["THANOS_HTTPS"]}
THANOS_READ_TIMEOUT={service_configs["THANOS_READ_TIMEOUT"]}

#########  THOR  ###########
THOR_HTTPS={service_configs["THOR_HTTPS"]}
THOR_HOST={service_configs["THOR_HOST"]}
THOR_PORT={service_configs["THOR_PORT"]}
THOR_POSTFIX={service_configs["THOR_POSTFIX"]}
THOR_READ_TIMEOUT={service_configs["THOR_READ_TIMEOUT"]}

#########  FALCON  ###########
FALCON_HTTPS={service_configs["FALCON_HTTPS"]}
FALCON_HOST={service_configs["FALCON_HOST"]}
FALCON_PORT={service_configs["FALCON_PORT"]}
FALCON_POSTFIX={service_configs["FALCON_POSTFIX"]}
FALCON_READ_TIMEOUT={service_configs["FALCON_READ_TIMEOUT"]}

#########  VISION  ###########
VISION_HTTPS={service_configs["VISION_HTTPS"]}
VISION_HOST={service_configs["VISION_HOST"]}
VISION_PORT={service_configs["VISION_PORT"]}
VISION_POSTFIX={service_configs["VISION_POSTFIX"]}
VISION_READ_TIMEOUT={service_configs["VISION_READ_TIMEOUT"]}

######### LOKI ##########
LOKI_HTTPS={service_configs["LOKI_HTTPS"]}
LOKI_HOST={service_configs["LOKI_HOST"]}
LOKI_PORT={service_configs["LOKI_PORT"]}
LOKI_POSTFIX={service_configs["LOKI_POSTFIX"]}
LOKI_READ_TIMEOUT={service_configs["LOKI_READ_TIMEOUT"]}
LOKI_CONNECT_TIMEOUT={service_configs["LOKI_CONNECT_TIMEOUT"]}

"""

        # Write to .env.custom in current working directory
        env_file_path = Path(".env.custom")
        env_file_path.write_text(content, encoding="utf-8")

    except PermissionError:
        typer.echo("\n❌ Permission denied: Cannot write .env.custom file.", err=True)
        typer.echo("Please check file permissions in the current directory.", err=True)
        raise
    except OSError as e:
        typer.echo(f"\n❌ Failed to write .env.custom file: {e}", err=True)
        typer.echo("Please check disk space and directory permissions.", err=True)
        raise


def run_custom_env_setup() -> None:
    """
    Orchestrate the complete custom environment setup process.

    This is the main entry point for creating a .env.custom file. It:
    1. Prompts user for base URL
    2. Generates service configurations and writes .env.custom file

    Note: Configuration will be validated when the worker starts.

    Raises:
        OSError: If file cannot be written
        KeyboardInterrupt: If user cancels with Ctrl+C (handled gracefully)
    """
    try:
        # Get all inputs from user
        inputs = prompt_custom_env_inputs()

        # Generate service configurations
        service_configs = generate_service_configs(
            protocol=inputs["protocol"],
            host=inputs["host"],
            port=inputs["port"],
        )

        # Write the .env.custom file
        write_env_custom_file(
            service_configs=service_configs,
            client_id=RUNNER_CLIENT_ID,
            client_secret=RUNNER_CLIENT_SECRET,
        )

        typer.echo("\n✅ Successfully created .env.custom file!")
        typer.echo("ℹ️  Configuration will be validated when you start the worker.\n")

    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        typer.echo("\n\nSetup cancelled by user.", err=True)
        sys.exit(0)
