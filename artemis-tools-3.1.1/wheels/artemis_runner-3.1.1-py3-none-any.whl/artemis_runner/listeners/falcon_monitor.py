from uuid import UUID

from artemis_client.falcon.client import FalconClient, FalconSettings
from falcon_models import LogAdditionRequest
from turing_task_manager.monitor import TaskMonitor
from turing_task_manager.worker import BaseWorker


class FalconTaskMonitor(TaskMonitor):
    """
    Extends the folder monitor, but provides the specific behavior to handle
    files created by a task specific executable and also defines behaviour
    for reading logs and sending them through loki.
    """

    falcon_client: FalconClient
    log_group_id: UUID

    def __init__(self, worker: "BaseWorker", folder: str, *args, **kwargs):
        super().__init__(worker, folder, *args, **kwargs)
        falcon_settings = FalconSettings.with_env_prefix("falcon")
        self.falcon_client = FalconClient(falcon_settings)
        self.log_group_id = self.falcon_client.get_process(self.worker.process_id).log_id

    def send_logs(self, force: bool = False):
        """Sends the new logs generated if there are more then the set threshold
        or if we are at the end of the executable run and empties the logs
        buffer
        """

        if force or len(self.logs_buffer) >= self.logs_threshold:
            for l in self.logs_buffer:
                self.falcon_client.post_log(self.log_group_id, LogAdditionRequest(**l.dict()))
            self.logs_buffer = []
