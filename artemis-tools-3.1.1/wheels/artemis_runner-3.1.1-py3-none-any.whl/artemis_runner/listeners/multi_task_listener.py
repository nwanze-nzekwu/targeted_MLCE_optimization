import atexit
import time

from ..utils.logging import configure_logging, SensitiveFilter

# Ensure logging is properly configured with SensitiveFilter
configure_logging()

from artemis_client.base_auth import ArtemisApiAddress

from ..resilient_client import ArtemisResilientClient
from .falcon_monitor import FalconTaskMonitor
from .ttm_listener import (
    DEPENDENCY_REGEX,
    HEARTBEAT_INTERVAL,
    AbstractListener,
    BaseWorker,
    GPUtil,
    Optional,
    Path,
    PathLike,
    Popen,
    Process,
    RepeatingTimer,
    StoppableThread,
    Type,
    Union,
    WorkerConfig,
    get_cpu_count,
    get_memory_bytes,
    log,
    logger,
    logging,
    os,
    pkg_resources,
    psutil,
    run_heartbeat,
    socket,
)
logger.addFilter(SensitiveFilter())


class LokiSettings(ArtemisApiAddress):
    pass


class MultiTaskListener(AbstractListener):

    folder_monitor = FalconTaskMonitor

    def __init__(
        self,
        rootdir: str,
        worker_class: Type[BaseWorker],
        *task_types: PathLike,
        labels=None,
        **kwargs,
    ):
        # Copy of AbstractListener __init__, minus the assert on worker_class
        self.worker_class = worker_class
        self.rootdir: Path = Path(rootdir)
        self.labels = labels or []

        self.task_types: tuple[str, ...] = task_types

        self.process: Optional[Union[Popen, Process]] = None
        self.monitor: Optional[StoppableThread] = None

        # Instantiate the worker API infos (note: same info as notification)
        loki_settings = LokiSettings.with_env_prefix("loki")
        self.loki_client = ArtemisResilientClient(worker_class.loki_client_class(loki_settings))
        # The manual retry logic because we need really coordinated retries, and for some reason hyx doesn't do that
        # Get the queue names with explicit retries
        task_queues = []
        max_retry_attempts = 5
        retry_delay = 1  # seconds

        for task in self.task_types:
            queue_name = None
            retry_count = 0
            last_error = None

            while queue_name is None and retry_count < max_retry_attempts:
                try:
                    queue_name = self.loki_client.get_queue_name(task)
                    if queue_name is None:
                        raise ValueError(f"get_queue_name returned None for {task}")
                except Exception as e:
                    last_error = e
                    retry_count += 1
                    if retry_count < max_retry_attempts:
                        logger.warning(
                            f"Failed to get queue name for {task} (attempt {retry_count}/{max_retry_attempts}): {str(e)}. Retrying in {retry_delay}s..."
                        )
                        time.sleep(retry_delay)
                    else:
                        logger.error(
                            f"Failed to get queue name for {task} after {max_retry_attempts} attempts: {str(e)}"
                        )

            # If we still don't have a queue name after all retries, raise an exception
            if queue_name is None:
                raise RuntimeError(
                    f"Could not retrieve queue name for {task} after {max_retry_attempts} attempts. Last error: {str(last_error)}"
                )

            task_queues.append({"type": task, "queue": queue_name})
            logger.debug(f"Successfully retrieved queue name for {task}: {queue_name}")

        self.queues = [pair["queue"] for pair in task_queues]
        self.current_queue = self.queues[0]

        # Get the worker's config from the environment
        worker_config = WorkerConfig()

        # Information about the machine
        cpus_info: Union[list, tuple] = psutil.cpu_freq(percpu=True)
        cpu_count = get_cpu_count()
        if not isinstance(cpus_info, list):
            cpus_info = [cpus_info]
        if len(cpus_info) > cpu_count:
            cpus_info = cpus_info[:cpu_count]
        try:
            gpus_info = GPUtil.getGPUs()
        except BaseException:
            gpus_info = []

        # Register worker with explicit retries
        # Same here, registration needs to be reliable that's why we do it manually
        max_register_attempts = 5
        register_retry_delay = 2  # seconds
        registration_attempt = 0
        last_reg_error = None

        registration_data = {
            "clusterId": worker_config.cluster_id,
            "workers": task_queues,
            "hostname": socket.gethostname(),
            "databaseUrl": worker_config.thanos_host,
            "rabbitmqUrl": worker_config.rabbitmq_host,
            "sentryEnabled": worker_config.sentry_enabled,
            "cpus": {
                "count": cpu_count,
                "frequencies": [{"minHz": freq.min, "maxHz": freq.max} for freq in cpus_info],
            },
            "gpus": [
                {
                    "id": gpu.id,
                    "name": gpu.name,
                    "memoryInBytes": gpu.memoryTotal,
                    "driver": gpu.driver,
                }
                for gpu in gpus_info
            ],
            "memoryInBytes": get_memory_bytes(),
            "labels": self.labels,
            "version": os.environ.get("VERSION"),
            "commit": os.environ.get("COMMIT_HASH"),
            "codeDependencies": [
                {
                    "name": package.key,
                    "version": package.version,
                }
                for package in pkg_resources.working_set
                if DEPENDENCY_REGEX.match(package.key)
            ],
        }

        registered = None
        while registered is None and registration_attempt < max_register_attempts:
            try:
                logger.info(
                    f"Attempting to register worker (attempt {registration_attempt + 1}/{max_register_attempts})..."
                )
                registered = self.loki_client.register_worker(registration_data)
                logger.info(f"Worker registration successful: {registered.id}")
            except Exception as e:
                last_reg_error = e
                registration_attempt += 1
                if registration_attempt < max_register_attempts:
                    logger.warning(
                        f"Worker registration failed (attempt {registration_attempt}/{max_register_attempts}): {str(e)}. Retrying in {register_retry_delay}s..."
                    )
                    time.sleep(register_retry_delay)
                else:
                    logger.error(f"Worker registration failed after {max_register_attempts} attempts: {str(e)}")

        if registered is None:
            raise RuntimeError(
                f"Failed to register worker after {max_register_attempts} attempts. Last error: {str(last_reg_error)}"
            )

        self.worker_id = registered.id
        self.cluster_id = registered.clusterId

        self.heartbeat_loop = RepeatingTimer(
            run_heartbeat,
            worker_id=self.worker_id,
            loki_client=self.loki_client,
            interval=HEARTBEAT_INTERVAL,
        )

        # Add the worker_id and cluster_id to the context
        log.add_context(
            logging.getLogger(),
            worker_id=self.worker_id,
            cluster_id=self.cluster_id,
            queue=self.queues[0],
            task_type=self.task_types[0],
            env_tag=os.environ.get("ENV_TAG"),
            commit_hash=os.environ.get("COMMIT_HASH"),
        )

        # Log startup informations
        logging.getLogger(__name__).info("worker -- start")
        registered.cpus.frequencies = registered.cpus.frequencies[:1]
        logger.debug("Worker configuration:\n%s", registered.json(indent=2))

    def _cleanup_worker(self):
        """Cleanup handler to unregister the worker when the process exits."""
        if hasattr(self, "worker_id") and self.worker_id:
            try:
                logger.debug(f"Unregistering worker {self.worker_id} during process exit")
                self.loki_client.unregister_worker(self.worker_id)
                logger.debug(f"Successfully unregistered worker {self.worker_id}")
            except Exception as e:
                logger.debug(f"Failed to unregister worker {self.worker_id} during process exit: {str(e)}")
