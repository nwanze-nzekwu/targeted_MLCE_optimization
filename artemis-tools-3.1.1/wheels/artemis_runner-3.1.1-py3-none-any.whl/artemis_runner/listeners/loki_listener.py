import atexit
import logging
import socket
import sys
from dataclasses import dataclass
from typing import Optional

from artemis_client.auth.loki_client import AuthLokiClient
from httpx import HTTPStatusError
from turing_task_manager.clients.core.client import authenticated
from turing_task_manager.clients.loki.models import WorkerStatus
from turing_task_manager.kombu import MQAction

from ..resilient_client import ArtemisResilientClient
from .multi_task_listener import LokiSettings, MultiTaskListener
from ..utils.logging import SensitiveFilter

logger = logging.getLogger(__name__)
logger.addFilter(SensitiveFilter())


@dataclass
class Message:
    body: dict


class ExternalLokiClient(AuthLokiClient):
    """
    Loki client used to fetch tasks outside of the internal deployment network.
    Uses the /dequeue endpoint to fetch tasks instead of rabbitmq.
    """

    @authenticated
    def dequeue(self, task_type: str, timeout: int = 5) -> Message:
        """
        Dequeue a task from the queue.
        :param task_type: The type of task to dequeue.
        :param timeout: The timeout for the dequeue operation.
        :return: The dequeued task.
        """
        response = self.post(f"/tasks/{task_type}/dequeue?timeout={timeout}")
        return Message(response)


class LokiListener(MultiTaskListener):
    def __init__(self, rootdir: str, worker_class, *task_types, labels=None, **kwargs):
        super().__init__(rootdir, worker_class, *task_types, labels=labels, **kwargs)

    def listen(self):
        settings = LokiSettings.with_env_prefix("loki")
        poll_timeout = 5
        settings.read_timeout = poll_timeout + 5

        # Log connection settings for debugging
        logger.info(f"Connecting to Loki service at {settings.host}:{settings.port}")

        # Test the connection before proceeding
        self._test_connection(settings.host, settings.port)

        loki = ArtemisResilientClient(ExternalLokiClient(settings))

        try:
            self.heartbeat_loop.start()
            logger.info(f"Polling for tasks on [{' '.join(self.task_types)}] with timeout {poll_timeout}s")
            self.set_worker_status("ready")
            while True:
                for task_type in self.task_types:
                    try:
                        # TODO: need to merge PR adding timeout query param to dequeue endpoint
                        # for now, it is internally hardcoded to 5s
                        message = loki.dequeue(task_type, timeout=poll_timeout)
                        if message:  # Only process if we got a task
                            self.run(message)
                    except HTTPStatusError as e:
                        # The resilient client will handle retries for all errors except 404 "no task found"
                        if e.response.status_code == 404 and e.response.json().get("detail") == "no task found":
                            continue
                        # For other HTTP errors, log but don't exit - the circuit breaker will handle it
                        logger.error(f"HTTP Error fetching task: {e}")
                    except Exception as e:
                        # For unexpected errors, we may still want to exit
                        logger.critical(f"Critical error in task polling loop: {e}")
                        self._cleanup_worker()
                        sys.exit(1)
                    except KeyboardInterrupt:
                        logger.info("KeyboardInterrupt received, stopping the runner.")
                        self._cleanup_worker()
                        sys.exit(0)
        finally:
            self.heartbeat_loop.stop()

    def _test_connection(self, host, port):
        """Test the TCP connection to the service before proceeding."""
        try:
            # Create a socket object
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)

            # Connect to the server
            result = s.connect_ex((host, port))

            if result == 0:
                logger.info(f"Successfully connected to {host}:{port}")
            else:
                logger.warning(f"Connection to {host}:{port} failed with error code {result}")
                logger.warning("Service might not be available. Will attempt to continue anyway.")

            # Close the socket
            s.close()
        except Exception as e:
            logger.warning(f"Error testing connection to {host}:{port}: {e}")
            logger.warning("Will attempt to continue despite connection test failure.")

    def _cleanup_worker(self):
        """Cleanup handler to set worker status to unreachable when the process exits."""
        if hasattr(self, "worker_id") and self.worker_id:
            try:
                logger.debug(f"Setting worker {self.worker_id} status to unreachable during process exit")
                # use clean loki client to avoid circuit breaker
                settings = LokiSettings.with_env_prefix("loki")
                loki = ExternalLokiClient(settings)
                loki.set_worker_status(self.worker_id, WorkerStatus.unreachable)
                logger.debug(f"Successfully set worker {self.worker_id} status to unreachable")
            except Exception as e:
                logger.debug(
                    f"Failed to set worker {self.worker_id} status to unreachable during process exit: {str(e)}"
                )

    def run(self, message: Message) -> Optional[MQAction]:
        """The main method of the worker class, listening and processing tasks
        as long as tasks are provided by the worker's :func:`listen` method.

        Returns True to ACK and False to NACK
        """
        body = message.body
        generic_queued_task = self.json_to_task(body)
        self._set_logging_context(generic_queued_task)

        logger.info("received task:\n%s", generic_queued_task.json(indent=2))

        # -------------------- acknowledge the task ? -------------------- #
        logger.info("consuming the task: \x1b[32m✓\x1b[0m")

        # ----------------------- process the task ----------------------- #
        status, handler = self.process_task(generic_queued_task)

        # ------------------------- logging -------------------------- #
        log_method = logger.info if handler.ready else logger.debug

        # outcome
        if not handler.ready:
            outcome = "not ready"
        elif handler.failed:
            outcome = "\x1b[31m✗ failure\x1b[0m"
        elif handler.already_completed:
            outcome = "\x1b[33m⚠ already completed\x1b[0m"
        elif handler.already_running:
            outcome = "\x1b[33m⚠ already running\x1b[0m"
        else:
            outcome = "\x1b[32m✓ success\x1b[0m"

        # requeue
        if handler.requeued:
            requeue = "⟳ re-queue"
        elif handler.failed:
            requeue = "\x1b[1m✗ dropped\x1b[0m"
        else:
            requeue = "\x1b[32m✓ consumed\x1b[0m"
        log_method("%s - %s", outcome, requeue)

        # ---------------------------------------------------------------- #
        self._drop_logging_context()

        # Finally, set the worker to ready again
        # Note: the task is finished, so no need to communicate the process id
        # or task id
        self.set_worker_status("ready")

        if handler.requeued:
            return MQAction.REQUEUE
        return None
