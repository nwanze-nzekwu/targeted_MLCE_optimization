import inspect
import logging
import time
from typing import Any, Callable, Optional

from hyx.sync_circuit_breaker.api import consecutive_breaker
from hyx.sync_circuit_breaker.exceptions import BreakerFailing
from hyx.sync_circuit_breaker.managers import ConsecutiveCircuitBreaker
from hyx.sync_circuit_breaker.states import BreakerState, FailingState
from hyx.sync_circuit_breaker.typing import DelayT, ExceptionsT, FuncT
from hyx.sync_retry import RetryListener, jitters, retry
from hyx.sync_retry.backoffs import expo
from hyx.sync_retry.counters import Counter, create_counter
from hyx.sync_retry.exceptions import AttemptsExceeded
from hyx.sync_retry.manager import RetryManager
from turing_task_manager.clients import HttpException, LokiClient

# Import the configure_logging function instead of just the filter
from artemis_runner.utils.logging import configure_logging, SensitiveFilter

# Ensure logging is configured
configure_logging()

# Get the logger without adding a filter - it will inherit from root logger
logger = logging.getLogger(__name__)
logger.addFilter(SensitiveFilter())

"""
Sorry for the overengineering, hyx is such a mess
"""

class AuthException(HttpException):
    code: int = 401
    message: str = "user credentials are invalid"


class LokiRetryListener(RetryListener):
    """
    A custom RetryListener that logs the retry attempts and backoff times.
    """

    def on_retry(
        self,
        manager: RetryManager,
        exception: Exception,
        attempt: Counter,
        backoff: float,
    ) -> None:
        logger.debug(
            f"Retrying {manager.name} due to {exception}. Attempt {attempt} with backoff {backoff:.2f}s."
        )
        super().on_retry(manager, exception, attempt, backoff)


class LokiRetryManager(RetryManager):
    """
    A custom RetryManager that aborts retries immediately when a raised exception has a status_code of 404
    and the error detail is "no task found".
    """

    def __call__(self, func: "FuncT") -> any:
        counter = create_counter(self._attempts)
        backoff_generator = iter(self._backoff)

        try:
            while bool(counter):
                try:
                    if self._limiter is not None:
                        self._limiter.take()

                    result = func()
                    self._event_dispatcher.on_success(self, counter)
                    return result
                except self._exceptions as e:
                    # Check if this is the specific error we want to abort on.
                    if hasattr(e, 'response') and e.response.json().get("detail") == "no task found":
                        # Immediately signal that all attempts are exhausted and abort without retrying.
                        self._event_dispatcher.on_attempts_exceeded(self)
                        raise e  # Abort retries immediately.

                    # Check for authentication errors
                    if hasattr(e, 'response') and e.response.status_code == 400:
                        error_message = e.response.json().get("message", "")
                        if "user credentials are invalid" in error_message:
                            # Raise AuthException instead of retrying
                            raise AuthException(response=e.response)

                    # For all other errors, continue with the normal retry logic.
                    counter += 1
                    backoff = next(backoff_generator)
                    self._event_dispatcher.on_retry(self, e, counter, backoff)
                    time.sleep(backoff)

        except AttemptsExceeded:
            self._event_dispatcher.on_attempts_exceeded(self)
            raise


class WaitingCircuitBreaker(ConsecutiveCircuitBreaker):
    """An enhanced CircuitBreaker that automatically waits when in the failing state
    instead of raising BreakerFailing exceptions."""

    def __init__(
        self,
        name: str,
        exceptions: ExceptionsT,
        failure_threshold: int,
        recovery_time_secs: DelayT,
        recovery_threshold: int,
        event_dispatcher: "BreakerListener",
        wait_log_callback: Optional[Callable[[str], None]] = None,
    ) -> None:
        """
        Initialize a WaitingCircuitBreaker.

        Args:
            name: Name of the circuit breaker
            exceptions: Exceptions to consider as failures
            failure_threshold: Number of consecutive failures to trip the breaker
            recovery_time_secs: Time in seconds to wait in the failing state
            recovery_threshold: Number of consecutive successes to reset the breaker
            event_dispatcher: Event dispatcher for circuit breaker events
            wait_log_callback: Optional callback to log waiting status
        """
        super().__init__(
            name,
            exceptions,
            failure_threshold,
            recovery_time_secs,
            recovery_threshold,
            event_dispatcher,
        )
        self._wait_log_callback = wait_log_callback or logger.debug
        self._last_wait_log = 0
        # Store last failing call information
        self._last_failing_func = None
        self._last_failing_args = None
        self._last_failing_kwargs = None

    @property
    def state(self) -> BreakerState:
        return super().state

    def _transit_state(self, new_state: BreakerState) -> None:
        return super()._transit_state(new_state)

    def acquire(self) -> None:
        return super().acquire()

    def release(self, exception: Optional[BaseException]) -> None:
        return super().release(exception)

    def __call__(self, func: FuncT) -> Any:
        """Execute a function with the circuit breaker, automatically waiting if in failing state."""
        # This will track the most recent call
        call_tracker = {"args": None, "kwargs": None}

        def capture_func_call(*args, **kwargs):
            # Update the tracker with the current call
            call_tracker["args"] = args
            call_tracker["kwargs"] = kwargs
            return func(*args, **kwargs)

        # Create a wrapper function that captures the call details
        wrapped_func = capture_func_call

        try:
            # Attempt to transition state before executing the function.
            self._transit_state(self._state.before_execution())
        except BreakerFailing:
            # In failing state, handle via waiting.
            return self._handle_failing_state(wrapped_func)

        @retry(
            on=(Exception),
            attempts=3,
            backoff=expo(max_delay_secs=3, jitter=jitters.full),
            retry_manager=LokiRetryManager,
            listeners=(LokiRetryListener(),),
        )
        def call_func():
            # The actual function call.
            return wrapped_func()

        try:
            try:
                result = call_func()
                self._transit_state(self._state.on_success())
                return result
            except AuthException as e:
                # Propagate auth exceptions immediately without retry
                logger.warning("Authentication error detected, not retrying")
                raise e
            except AttemptsExceeded:
                # Explicitly handle AttemptsExceeded from the retry mechanism
                # Store the failing function for later retry
                self._last_failing_func = func
                self._last_failing_args = call_tracker["args"]
                self._last_failing_kwargs = call_tracker["kwargs"]

                self._transit_state(self._state.on_exception())
                return None
            except self._context.exceptions as e:
                # Handle special case if error detail is "no task found"
                if (
                    hasattr(e, "response")
                    and e.response.json().get("detail") == "no task found"
                ):
                    return None

                # Store the failing function for later retry
                self._last_failing_func = func
                self._last_failing_args = call_tracker["args"]
                self._last_failing_kwargs = call_tracker["kwargs"]

                self._transit_state(self._state.on_exception())
                raise e
        except AuthException as e:
            # Ensure auth exceptions propagate upward
            raise e
        except Exception as e:
            # Catch any other unexpected exceptions
            # Transit state and inform listeners
            self._transit_state(self._state.on_exception())

            # Store the failing function for later retry in case of unexpected errors
            self._last_failing_func = func
            self._last_failing_args = call_tracker["args"]
            self._last_failing_kwargs = call_tracker["kwargs"]

            # Re-raise the exception
            raise e

    def _handle_failing_state(self, func: FuncT) -> Any:
        """Handle execution when in failing state by waiting for recovery time."""
        if isinstance(self._state, FailingState):
            remaining = self._state.remain
            if remaining:
                current_time = time.time()
                if current_time - self._last_wait_log >= 5:
                    self._wait_log_callback(
                        f"Circuit breaker in failing state. Waiting {remaining.total_seconds():.1f}s for recovery..."
                    )
                    self._last_wait_log = current_time

                # Wait until recovery time
                time.sleep(remaining.total_seconds())

                # Now we should be able to transition to recovering state
                try:
                    self._transit_state(
                        self._state.before_execution()
                    )  # This should now move to recovering
                    self._wait_log_callback(
                        "Circuit breaker recovered, attempting operation"
                    )

                    # Check if we have a stored failing function to retry
                    if self._last_failing_func and (
                        self._last_failing_args is not None
                        or self._last_failing_kwargs is not None
                    ):
                        self._wait_log_callback("Retrying last failing call")

                        # Log some details about the call being retried
                        func_name = getattr(
                            self._last_failing_func,
                            "__name__",
                            str(self._last_failing_func),
                        )
                        args_summary = str(self._last_failing_args)[:100] + (
                            "..." if len(str(self._last_failing_args)) > 100 else ""
                        )
                        kwargs_summary = str(self._last_failing_kwargs)[:100] + (
                            "..." if len(str(self._last_failing_kwargs)) > 100 else ""
                        )

                        self._wait_log_callback(
                            f"Retrying previous call to {func_name} with args: {args_summary}, kwargs: {kwargs_summary}"
                        )

                        # Instead of using the provided func, use the stored one with its arguments
                        @retry(
                            on=(Exception),
                            attempts=3,
                            backoff=expo(max_delay_secs=3, jitter=jitters.full),
                            retry_manager=LokiRetryManager,
                            listeners=(LokiRetryListener(),),
                        )
                        def call_last_failing_func():
                            # Call the last failing function with its original arguments
                            args = self._last_failing_args or ()
                            kwargs = self._last_failing_kwargs or {}
                            return self._last_failing_func(*args, **kwargs)

                        # Try the operation now that we're in recovering state
                        try:
                            try:
                                result = call_last_failing_func()
                                self._transit_state(self._state.on_success())
                                # Clear the stored call information after successful execution
                                self._last_failing_func = None
                                self._last_failing_args = None
                                self._last_failing_kwargs = None
                                return result
                            except AttemptsExceeded:
                                # Explicitly handle AttemptsExceeded from the retry mechanism
                                self._wait_log_callback(
                                    "Max retry attempts exceeded when retrying failing call"
                                )
                                self._transit_state(self._state.on_exception())
                                return None
                            except AuthException as e:
                                # Propagate auth exceptions immediately without retry
                                self._wait_log_callback(
                                    "Authentication error detected, not retrying"
                                )
                                raise e
                            except self._context.exceptions as e:
                                if (
                                    hasattr(e, "response")
                                    and e.response.json().get("detail")
                                    == "no task found"
                                ):
                                    return None
                                self._transit_state(self._state.on_exception())
                                raise e
                        except AuthException as e:
                            # Ensure auth exceptions are propagated upward
                            raise e
                        except Exception as e:
                            # Catch-all for any other unexpected exceptions
                            self._wait_log_callback(
                                f"Unexpected error during recovery retry: {str(e)}"
                            )
                            self._transit_state(self._state.on_exception())
                            return None
                    else:
                        # If no stored failing function, proceed with normal execution
                        @retry(
                            on=(Exception),
                            attempts=3,
                            backoff=expo(max_delay_secs=3, jitter=jitters.full),
                            retry_manager=LokiRetryManager,
                            listeners=(LokiRetryListener(),),
                        )
                        def call_func():
                            # This is the actual function call
                            return func()

                        # Try the operation now that we're in recovering state
                        try:
                            try:
                                result = call_func()
                                self._transit_state(self._state.on_success())
                                return result
                            except AttemptsExceeded:
                                # Explicitly handle AttemptsExceeded from the retry mechanism
                                self._wait_log_callback(
                                    "Max retry attempts exceeded when executing in recovering state"
                                )
                                self._transit_state(self._state.on_exception())
                                return None
                            except AuthException as e:
                                # Propagate auth exceptions immediately without retry
                                self._wait_log_callback(
                                    "Authentication error detected, not retrying"
                                )
                                raise e
                            except self._context.exceptions as e:
                                if (
                                    hasattr(e, "response")
                                    and e.response.json().get("detail")
                                    == "no task found"
                                ):
                                    return None
                                self._transit_state(self._state.on_exception())
                                raise e
                        except AuthException as e:
                            raise e
                        except Exception as e:
                            # Catch-all for any other unexpected exceptions
                            self._wait_log_callback(
                                f"Unexpected error during recovery: {str(e)}"
                            )
                            self._transit_state(self._state.on_exception())
                            return None
                except BreakerFailing:
                    # This shouldn't happen after waiting, but handle it just in case
                    self._wait_log_callback(
                        "Circuit breaker still failing after waiting backing off"
                    )
                    return None

        return None  # Default fallback return


circuitbreaker = consecutive_breaker(
    name="artemis_client_breaker",
    exceptions=(
        Exception,
        HttpException,
        AttemptsExceeded,
    ),
    failure_threshold=1,
    recovery_time_secs=30,
    recovery_threshold=1,
    manager=WaitingCircuitBreaker,
)


class ArtemisResilientClient:
    # Share a single circuit breaker instance across all client instances
    _shared_circuit_breaker = circuitbreaker

    def __init__(self, loki_client: LokiClient):
        self.loki_client = loki_client
        self.circuit_breaker = self._shared_circuit_breaker

    def __getattr__(self, attr_name):
        attr = getattr(self.loki_client, attr_name)

        if callable(attr) and inspect.ismethod(attr):

            @self.circuit_breaker
            def wrapped(*args, **kwargs):
                try:
                    return attr(*args, **kwargs)
                except AuthException as e:
                    # Let authentication errors propagate up without retrying
                    logger.error(f"Authentication failed: {e}")
                    raise e

            return wrapped
        else:
            return attr
