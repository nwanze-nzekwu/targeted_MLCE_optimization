from enum import StrEnum
from pathlib import Path

from dotenv import dotenv_values


class Environment(StrEnum):
    """Enum hosting allowed values for Artemis' environments."""

    develop = "develop"
    staging = "staging"
    production = "production"
    custom = "custom"


DEVELOP = dict(
    THANOS_CLIENT_ID="nWeQlNSX4s",
    THANOS_CLIENT_SECRET="ajyMwmOxoEh4ryWdR0cqa178amexKXvS",
    THANOS_GRANT_TYPE="password",
    THANOS_HOST="dev.artemis.turintech.ai",
    THANOS_PORT="80",
    THANOS_POSTFIX="/turintech-thanos/api",
    THANOS_HTTPS="False",
    THANOS_READ_TIMEOUT="120",
    THOR_HTTPS="False",
    THOR_HOST="dev.artemis.turintech.ai",
    THOR_PORT="80",
    THOR_POSTFIX="/turintech-thor/api",
    THOR_READ_TIMEOUT="120",
    FALCON_HTTPS="False",
    FALCON_HOST="dev.artemis.turintech.ai",
    FALCON_PORT="80",
    FALCON_POSTFIX="/turintech-falcon/api",
    FALCON_READ_TIMEOUT="120",
    VISION_HTTPS="False",
    VISION_HOST="dev.artemis.turintech.ai",
    VISION_PORT="80",
    VISION_POSTFIX="/turintech-vision/api",
    VISION_READ_TIMEOUT="120",
    LOKI_HTTPS="False",
    LOKI_HOST="dev.artemis.turintech.ai",
    LOKI_PORT="80",
    LOKI_POSTFIX="/turintech-loki",
    LOKI_READ_TIMEOUT="120",
    LOKI_CONNECT_TIMEOUT="10",
)

STAGING = dict(
    THANOS_CLIENT_ID="RwNvyV",
    THANOS_CLIENT_SECRET="kMgmHgrKlE",
    THANOS_GRANT_TYPE="password",
    THANOS_HOST="staging.artemis.turintech.ai",
    THANOS_PORT="443",
    THANOS_POSTFIX="/turintech-thanos/api",
    THANOS_HTTPS="True",
    THANOS_READ_TIMEOUT="120",
    THOR_HTTPS="True",
    THOR_HOST="staging.artemis.turintech.ai",
    THOR_PORT="443",
    THOR_POSTFIX="/turintech-thor/api",
    THOR_READ_TIMEOUT="120",
    FALCON_HTTPS="True",
    FALCON_HOST="staging.artemis.turintech.ai",
    FALCON_PORT="443",
    FALCON_POSTFIX="/turintech-falcon/api",
    FALCON_READ_TIMEOUT="120",
    VISION_HTTPS="True",
    VISION_HOST="staging.artemis.turintech.ai",
    VISION_PORT="443",
    VISION_POSTFIX="/turintech-vision/api",
    VISION_READ_TIMEOUT="120",
    LOKI_HTTPS="True",
    LOKI_HOST="staging.artemis.turintech.ai",
    LOKI_PORT="443",
    LOKI_POSTFIX="/turintech-loki",
    LOKI_READ_TIMEOUT="120",
    LOKI_CONNECT_TIMEOUT="10",
)

PRODUCTION = dict(
    THANOS_CLIENT_ID="gfwRjq",
    THANOS_CLIENT_SECRET="xwJMpspatz",
    THANOS_GRANT_TYPE="password",
    THANOS_HOST="artemis.turintech.ai",
    THANOS_PORT="443",
    THANOS_POSTFIX="/turintech-thanos/api",
    THANOS_READ_TIMEOUT="120",
    THANOS_HTTPS="True",
    THOR_HTTPS="True",
    THOR_HOST="artemis.turintech.ai",
    THOR_PORT="443",
    THOR_POSTFIX="/turintech-thor/api",
    THOR_READ_TIMEOUT="120",
    FALCON_HTTPS="True",
    FALCON_HOST="artemis.turintech.ai",
    FALCON_PORT="443",
    FALCON_POSTFIX="/turintech-falcon/api",
    FALCON_READ_TIMEOUT="120",
    VISION_HTTPS="True",
    VISION_HOST="artemis.turintech.ai",
    VISION_PORT="443",
    VISION_POSTFIX="/turintech-vision/api",
    VISION_READ_TIMEOUT="120",
    LOKI_HTTPS="True",
    LOKI_HOST="artemis.turintech.ai",
    LOKI_PORT="443",
    LOKI_POSTFIX="/turintech-loki",
    LOKI_READ_TIMEOUT="120",
    LOKI_CONNECT_TIMEOUT="10",
)


def get_env(env: Environment) -> dict:
    if env == Environment.develop:
        return DEVELOP
    elif env == Environment.staging:
        return STAGING
    elif env == Environment.production:
        return PRODUCTION
    elif env == Environment.custom:
        if not Path(".env.custom").exists():
            raise FileNotFoundError(".env.custom file not found in working directory.")
        return dotenv_values(".env.custom")
