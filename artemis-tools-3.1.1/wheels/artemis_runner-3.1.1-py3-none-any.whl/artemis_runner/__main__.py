import os
# Add git management env var for GitPython to avoid errors BEFORE any import.
os.environ["GIT_PYTHON_REFRESH"]="quiet"
from artemis_runner.cli import create_app
from artemis_runner.worker import ArtemisRunner


def main():
    os.environ["ARTEMIS_OUTPUT_MODE"] = "api"
    app = create_app(ArtemisRunner(), ArtemisRunner.task_types())
    app()


if __name__ == "__main__":
    main()
