import atexit
import logging
import os
import re
import sys
from enum import Enum, StrEnum
from pathlib import Path
from typing import Annotated, Optional

import typer
from dotenv import dotenv_values, load_dotenv
from turing_task_manager.main import log_start
from typer import Option, Typer

from artemis_runner.credential_setup import ensure_credentials_exist_for_start_worker
from artemis_runner.envs import Environment, get_env
from artemis_runner.listeners.loki_listener import LokiListener
from artemis_runner.utils.logging import SensitiveFilter, configure_logging


def validate_runner_name_callback(runner_name: str) -> str:
    """
    Validate runner name using the same regex as Loki service.

    Raises ValueError if runner name is invalid.
    """
    # Regex pattern used by Loki: only alphanumeric characters, hyphens, and underscores
    pattern = r"^[a-zA-Z0-9-_]+$"
    if not re.match(pattern, runner_name):
        raise typer.BadParameter(
            "Invalid runner name. Runner names can only contain:\n"
            "  - Letters (a-z, A-Z)\n"
            "  - Numbers (0-9)\n"
            "  - Hyphens (-) and underscores (_)"
        )
    return runner_name


class DeploymentType(StrEnum):
    """Deployment type for the worker."""

    SAAS = "SAAS"
    ON_PREM = "ON-PREM"

    @classmethod
    def from_environment(cls, environment: Environment) -> "DeploymentType":
        """Determine deployment type from environment."""
        if environment in [Environment.staging, Environment.production]:
            return cls.SAAS
        else:
            return cls.ON_PREM


def set_internal_env_vars():
    # needed for now as task-manager won't start without them
    # see /turing_task_manager/utils/config.py::WorkerConfig
    os.environ["RABBITMQ_HOST"] = "localhost"
    # needed to prevent json logs in worker
    os.environ["ENV_TAG"] = "develop"
    # default cluster id for all workers connecting to loki
    os.environ["CLUSTER_ID"] = "artemis-runner"
    os.environ["PYTHONUTF8"] = "1"

    if sys.platform == "win32":
        os.environ["PYTHONIOENCODING"] = "UTF-8"


def restore_env(original_env: dict):
    """Restores environment variables with previous content after worker execution."""
    os.environ.clear()
    os.environ.update(original_env)


def get_artemis_runner_version():
    """Get the version of artemis-runner."""
    from artemis_runner import __version__

    return __version__


def start(worker_class, runner_ids, worker_output_root, labels):
    """Starts the worker process."""
    configure_logging()
    log_start()

    # Log the artemis-runner version
    version = get_artemis_runner_version()
    logging.getLogger(__name__).debug(f"Starting artemis-runner version {version}")

    listener = LokiListener(worker_output_root, worker_class, *runner_ids, labels=labels)
    listener.listen()


def authenticate_with_artemis():
    """Authenticate with Artemis platform and return user info."""
    from evoml_services.clients.thanos.client import ThanosClient, ThanosSettings

    typer.echo("Authenticating with Artemis platform...")
    try:
        thanos_settings = ThanosSettings.with_env_prefix("thanos")
        thanos_client = ThanosClient(thanos_settings)
        user_info = thanos_client.get("/users/me")
        user_id = user_info["_id"]
        typer.echo(f"✓ Successfully authenticated as {user_info.get('email', 'user')}")
        return user_id
    except Exception as e:
        filtered_error = SensitiveFilter.filter_msg(str(e))
        typer.echo(f"✗ Authentication failed: {filtered_error}", err=True)
        typer.echo("Please check your credentials and network connection.", err=True)
        raise typer.Exit(code=1)


def create_app(worker_class, task_types):
    app = Typer()

    def load_credentials():
        return dotenv_values(f".env.credentials")

    def default_environment():
        """Obtains the system environment to target."""
        credentials = load_credentials()
        environment = credentials.get("ARTEMIS_ENVIRONMENT", Environment.production)
        environment = os.environ.get("ARTEMIS_ENVIRONMENT", environment)
        return environment

    def default_runner_name():
        """Obtains the system environment to target."""
        credentials = load_credentials()
        runner_name = credentials.get("ARTEMIS_RUNNER_NAME", None)
        runner_name = None if runner_name == "<your runner name>" else runner_name
        runner_name = os.environ.get("ARTEMIS_RUNNER_NAME", runner_name)
        if runner_name is None:
            runner_name = typer.prompt("Runner Name")
        return runner_name

    def default_delete_task_output():
        """Obtains the delete task output setting."""
        credentials = load_credentials()
        delete_output = credentials.get("ARTEMIS_DELETE_TASK_OUTPUT", None)
        delete_output = os.environ.get("ARTEMIS_DELETE_TASK_OUTPUT", delete_output)
        if delete_output is None:
            typer.echo("\n⚠️  Warning: Preserving task output can fill your disk over time.")
            typer.echo("You'll need to manually clean the output directory if you choose 'n'.\n")
            return typer.confirm("Delete task output after completion? (recommended)", default=True)

        # delete_output is guaranteed to be a string here
        lower_value = delete_output.lower()
        if lower_value == "true":
            return True
        elif lower_value == "false":
            return False
        else:
            raise typer.BadParameter(f"'{delete_output}' is not a valid boolean.")

    RunnerTask = StrEnum("RunnerTask", {task_type: task_type for task_type in task_types})

    @app.command()
    def start_worker(
        runner_name: Annotated[
            str,
            Option(
                default_factory=default_runner_name,
                show_default=False,
                envvar="ARTEMIS_RUNNER_NAME",
                help="Unique identifier of runner",
                callback=validate_runner_name_callback,
            ),
        ],
        environment: Annotated[
            Environment,
            Option(
                default_factory=default_environment,
                show_default=Environment.production,
                envvar="ARTEMIS_ENVIRONMENT",
                help="Environment to connect to",
            ),
        ],
        delete_task_output: Annotated[
            bool,
            Option(
                default_factory=default_delete_task_output,
                show_default="true",
                envvar="ARTEMIS_DELETE_TASK_OUTPUT",
                help="Delete task output after completion",
            ),
        ],
        runner_tasks: Annotated[
            list[RunnerTask],
            Option(envvar="ARTEMIS_RUNNER_TASKS", help="List of tasks to run"),
        ] = list(RunnerTask),
        worker_output_root: Annotated[
            str,
            Option(
                envvar="ARTEMIS_WORKER_OUTPUT_ROOT",
                help="Directory to download worker input/output",
            ),
        ] = ".artemis",
        log_level: Annotated[
            str,
            Option(
                envvar="LOG_LEVEL",
                help="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)",
            ),
        ] = "INFO",
        ssl_verify: Annotated[
            str,
            Option(
                envvar="ARTEMIS_SSL_VERIFY",
                help="Bool or path to CA_BUNDLE file",
            ),
        ] = "true",
    ):
        # Ensure credentials exist before doing anything else
        os.environ["THANOS_SSL_VERIFY"] = ssl_verify
        ensure_credentials_exist_for_start_worker(runner_name, environment, delete_task_output)

        original_env = os.environ.copy()
        atexit.register(restore_env, original_env)

        set_internal_env_vars()

        # Set logging level in environment
        os.environ["LOG_LEVEL"] = log_level

        credentials = load_credentials()

        username = credentials.get("ARTEMIS_USERNAME", None)
        username = None if username == "<your artemis email address>" else username
        username = os.environ.get("ARTEMIS_USERNAME", username)

        password = credentials.get("ARTEMIS_PASSWORD", None)
        password = None if password == "<your artemis password>" else password
        password = os.environ.get("ARTEMIS_PASSWORD", password)

        environment_config = get_env(environment)

        environment_config["THANOS_USERNAME"] = username
        environment_config["THANOS_PASSWORD"] = password

        ssl_verify = str(ssl_verify)
        environment_config["THANOS_SSL_VERIFY"] = ssl_verify
        environment_config["THOR_SSL_VERIFY"] = ssl_verify
        environment_config["FALCON_SSL_VERIFY"] = ssl_verify
        environment_config["VISION_SSL_VERIFY"] = ssl_verify
        environment_config["LOKI_SSL_VERIFY"] = ssl_verify

        # increase default artemisopt ram limit to 8GB (default is 3GB)
        environment_config["ARTEMIS_RAM_LIMIT_MB"] = os.environ.get("ARTEMIS_RAM_LIMIT_MB", "8192")

        # delete mutated projects after evaluating
        environment_config["ARTEMIS_DELETE_MUTATED"] = os.environ.get("ARTEMIS_DELETE_MUTATED", "true")

        # set TTM_PRESERVE_OUTPUT based on delete_task_output flag (inverted logic)
        environment_config["TTM_PRESERVE_OUTPUT"] = "false" if delete_task_output else "true"

        environment_config["ARTEMIS_RUNNER_NAME"] = runner_name

        os.environ.update(environment_config)

        # Verify authentication with Artemis platform
        user_id = authenticate_with_artemis()

        deployment_type = DeploymentType.from_environment(environment)
        runner_ids = [f"{task}-{runner_name}-{user_id}" for task in runner_tasks]

        # Construct labels for worker registration
        labels = [
            {"name": "userId", "value": user_id},
            {"name": "runnerName", "value": runner_name},
            {"name": "component", "value": "artemis-runner"},
            {"name": "deploymentType", "value": deployment_type},
        ]

        if not os.path.exists(worker_output_root):
            os.makedirs(worker_output_root)

        start(worker_class, runner_ids, worker_output_root, labels)

    return app
