import logging
import os
import re
import sys
import traceback
from typing import Optional


_SENSITIVE_KEYS = [
    "password",
    "client_secret",
    "THANOS_CLIENT_SECRET",
    "THANOS_PASSWORD",
    "ARTEMIS_PASSWORD",
]

# Pattern for key=value or key:value in regular logs
_PATTERN = re.compile(
    rf'(?i)\b(?:{"|".join(_SENSITIVE_KEYS)})\b\s*[=:]\s*([^,\s\)\}}]+)'
)

# Additional patterns for dictionary-style formats often seen in tracebacks
_DICT_PATTERNS = [
    re.compile(rf"(?i)['\"]({key})['\"]:\s*['\"]([^'\"]+)['\"]")
    for key in _SENSITIVE_KEYS
]

class SensitiveFilter(logging.Filter):
    """
    Masks any of these keys (case‑insensitive) in log records:
      - password
      - client_secret
      - THANOS_CLIENT_SECRET
      - THANOS_PASSWORD
      - ARTEMIS_PASSWORD
    by replacing their values with '***'.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()

        filtered = self.filter_msg(msg)

        # override the record so all handlers see only the redacted text
        record.msg = filtered
        record.args = ()
        return True

    @staticmethod
    def filter_msg(msg):
        filtered = _PATTERN.sub(lambda m: f"{m.group(0).split('=')[0]}=***", msg)
        # Also handle dictionary-style formats
        for pattern in _DICT_PATTERNS:
            filtered = pattern.sub(r"'\1': '***'", filtered)
        return filtered


def custom_excepthook(exc_type, exc_value, exc_tb):
    """
    Custom exception hook that filters sensitive information from tracebacks
    before logging them.
    """
    # Get the root logger
    logger = logging.getLogger()
    
    # First create a formatted traceback string
    tb_text = ''.join(traceback.format_exception(exc_type, exc_value, exc_tb))
    
    # Apply filtering manually to the traceback
    for pattern in SensitiveFilter._DICT_PATTERNS:
        tb_text = pattern.sub(r"'\1': '***'", tb_text)
    
    # Apply the key=value pattern as well
    tb_text = SensitiveFilter._PATTERN.sub(lambda m: f"{m.group(0).split('=')[0]}=***", tb_text)
    
    # Log the pre-filtered traceback 
    logger.error("Uncaught exception:\n%s", tb_text)


def configure_logging(level: Optional[str] = None) -> None:
    # determine level
    level_str = level or os.getenv("LOG_LEVEL", "INFO")
    numeric_level = getattr(logging, level_str.upper(), logging.INFO)

    root = logging.getLogger()
    root.setLevel(numeric_level)

    # add our filter just once
    if not any(isinstance(f, SensitiveFilter) for f in root.filters):
        root.addFilter(SensitiveFilter())

    # install the exception hook
    sys.excepthook = custom_excepthook

    # quiet noisy libraries
    logging.getLogger("amqp").setLevel(logging.WARNING)
    logging.getLogger("kombu").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.ERROR)

    # collect detailed ARTEMIS runner logs at DEBUG, but only show them if root is DEBUG
    logging.getLogger("artemis_runner.listeners.multi_task_listener").setLevel(logging.DEBUG)
