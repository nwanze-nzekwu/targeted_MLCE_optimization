class MSLexError(ValueError):
    """Class for mslex errors"""
