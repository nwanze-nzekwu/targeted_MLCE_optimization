from typing import Callable, Dict, List, Optional, Type, Union, TypeVar

# Forward references
class BreakerListener:
    """Listener for circuit breaker events."""
    
    def on_working(self, context, current_state, next_state):
        """Called when transitioning to the working state."""
        pass
    
    def on_recovering(self, context, current_state, next_state):
        """Called when transitioning to the recovering state."""
        pass
    
    def on_failing(self, context, current_state, next_state):
        """Called when transitioning to the failing state."""
        pass
    
    def on_success(self, context, state):
        """Called when an operation succeeds."""
        pass


# Type for listener or factory
BreakerListenerT = TypeVar('BreakerListenerT', bound=BreakerListener)


class ListenerRegistry:
    """Registry for circuit breaker listeners."""
    
    def __init__(self):
        self._listeners: List[Union[BreakerListener, Callable[..., BreakerListener]]] = []
    
    def register(self, listener: Union[BreakerListener, Callable[..., BreakerListener]]) -> None:
        """Register a listener."""
        self._listeners.append(listener)
    
    def create_listeners(self) -> List[BreakerListener]:
        """Create listener instances from registered listeners and factories."""
        result = []
        for listener in self._listeners:
            if callable(listener) and not isinstance(listener, BreakerListener):
                result.append(listener())
            else:
                result.append(listener)
        return result


# Global registry for circuit breaker listeners
_BREAKER_LISTENERS = ListenerRegistry()


class EventDispatcher:
    """Dispatches events to registered listeners."""
    
    def __init__(self, listeners=None, registry=None):
        self._listeners = listeners or []
        self._registry = registry
        self._component = None
    
    def set_component(self, component):
        """Set the component this dispatcher is associated with."""
        self._component = component
    
    @property
    def as_listener(self) -> BreakerListener:
        """Return this dispatcher as a listener."""
        return _EventDispatcherListener(self)
    
    def _get_listeners(self):
        """Get all listeners from both direct listeners and registry."""
        result = list(self._listeners)
        if self._registry:
            result.extend(self._registry.create_listeners())
        return result
    
    def dispatch(self, event_name, *args, **kwargs):
        """Dispatch an event to all listeners."""
        for listener in self._get_listeners():
            method = getattr(listener, event_name, None)
            if method and callable(method):
                method(*args, **kwargs)


class _EventDispatcherListener(BreakerListener):
    """Adapter that exposes the event dispatcher as a listener."""
    
    def __init__(self, dispatcher):
        self._dispatcher = dispatcher
    
    def on_working(self, context, current_state, next_state):
        self._dispatcher.dispatch("on_working", context, current_state, next_state)
    
    def on_recovering(self, context, current_state, next_state):
        self._dispatcher.dispatch("on_recovering", context, current_state, next_state)
    
    def on_failing(self, context, current_state, next_state):
        self._dispatcher.dispatch("on_failing", context, current_state, next_state)
    
    def on_success(self, context, state):
        self._dispatcher.dispatch("on_success", context, state)


def register_breaker_listener(listener: Union[BreakerListener, Callable[..., BreakerListener]]):
    """
    Register a listener that will listen to all circuit breaker components
    """
    global _BREAKER_LISTENERS
    _BREAKER_LISTENERS.register(listener)


def get_default_name():
    """Generate a default name for circuit breakers."""
    import uuid
    return f"circuit_breaker_{uuid.uuid4().hex[:8]}"