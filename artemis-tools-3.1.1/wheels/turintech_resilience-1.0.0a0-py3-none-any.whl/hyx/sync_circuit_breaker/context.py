import dataclasses
from typing import Optional, TYPE_CHECKING

from .typing import DelayT, ExceptionsT

if TYPE_CHECKING:
    from .events import BreakerListener


@dataclasses.dataclass
class BreakerContext:
    """Context for circuit breaker operations."""
    
    breaker_name: Optional[str]
    exceptions: ExceptionsT
    failure_threshold: int
    recovery_time_secs: DelayT
    recovery_threshold: int
    event_dispatcher: 'BreakerListener'  # Forward reference