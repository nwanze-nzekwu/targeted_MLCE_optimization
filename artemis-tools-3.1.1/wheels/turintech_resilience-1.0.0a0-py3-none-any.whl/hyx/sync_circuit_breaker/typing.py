from typing import Any, Callable, TypeVar, Union

# Type for delay in seconds
DelayT = Union[int, float]

# Type for function that can be wrapped
FuncT = TypeVar("FuncT", bound=Callable[..., Any])

# Type for exceptions
ExceptionsT = Union[type[Exception], tuple[type[Exception], ...]]