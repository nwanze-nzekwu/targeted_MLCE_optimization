class CircuitBreakerError(Exception):
    """Base exception class for circuit breaker errors."""


class BreakerFailing(CircuitBreakerError):
    """
    Occurs when you try to execute actions that were identified as failing by the circuit breaker
    """