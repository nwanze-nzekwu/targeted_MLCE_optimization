from typing import Any, Optional

from .context import BreakerContext
from .states import BreakerState, WorkingState
from .typing import ExceptionsT, FuncT


class ConsecutiveCircuitBreaker:
    """
    Watch for consecutive exceptions that exceed a given threshold
    """
    
    __slots__ = ("_context", "_name", "_state")
    
    def __init__(
        self,
        name: str,
        exceptions: ExceptionsT,
        failure_threshold: int,
        recovery_time_secs: float,
        recovery_threshold: int,
        event_dispatcher: Any,  # BreakerListener
    ) -> None:
        self._name = name
        
        self._context = BreakerContext(
            breaker_name=name,
            exceptions=exceptions,
            failure_threshold=failure_threshold,
            recovery_time_secs=recovery_time_secs,
            recovery_threshold=recovery_threshold,
            event_dispatcher=event_dispatcher,
        )
        
        self._state: BreakerState = WorkingState(self._context)
    
    @property
    def state(self) -> BreakerState:
        """Get the current state of the circuit breaker."""
        return self._state
    
    def _transit_state(self, new_state: BreakerState) -> None:
        """Change the current state of the circuit breaker."""
        self._state = new_state
    
    def acquire(self) -> None:
        """Acquire the circuit breaker before execution."""
        self._transit_state(self._state.before_execution())
    
    def release(self, exception: Optional[BaseException]) -> None:
        """Release the circuit breaker after execution."""
        if exception and isinstance(exception, self._context.exceptions):
            self._transit_state(self._state.on_exception())
            raise exception
        
        self._transit_state(self._state.on_success())
    
    def __call__(self, func: FuncT) -> Any:
        """Execute a function with the circuit breaker."""
        self._transit_state(self._state.before_execution())
        
        try:
            result = func()
            
            self._transit_state(self._state.on_success())
            
            return result
        except self._context.exceptions as e:
            self._transit_state(self._state.on_exception())
            # breaker is not hiding the error like retry or fallback
            raise e