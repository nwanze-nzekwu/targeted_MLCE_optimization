from typing import TYPE_CHECKING, Protocol, Union

from hyx.events import ListenerFactoryT, ListenerRegistry

if TYPE_CHECKING:
    from hyx.bulkhead.manager import BulkheadManager

_BULKHEAD_LISTENERS: ListenerRegistry["BulkheadManager", "BulkheadListener"] = ListenerRegistry()


class BulkheadListener(Protocol):
    async def on_bulkhead_full(self, bulkhead: "BulkheadManager") -> None:
        ...


def register_bulkhead_listener(listener: Union[BulkheadListener, ListenerFactoryT]) -> None:
    """
    Register a listener that will listen to all fallback components in the system.
    """
    global _BULKHEAD_LISTENERS  # pylint: disable=W0602

    _BULKHEAD_LISTENERS.register(listener)
