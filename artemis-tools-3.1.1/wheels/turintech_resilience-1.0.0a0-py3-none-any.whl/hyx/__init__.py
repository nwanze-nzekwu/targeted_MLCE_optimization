"""
Lightweight fault tolerance primitives for your modern Python microservices.
"""
