from typing import Union

DelayT = Union[float, int]
