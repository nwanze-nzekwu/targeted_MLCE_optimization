class HyxError(Exception):
    """The base Hyx error.

    Useful to catch all kinds of Hyx errors at once

    """
