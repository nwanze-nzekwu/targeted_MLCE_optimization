import time
from typing import Any, Optional

from hyx.ratelimit.buckets import TokenBucket
from hyx.sync_retry.backoffs import create_backoff
from hyx.sync_retry.counters import create_counter
from hyx.sync_retry.events import RetryListener
from hyx.sync_retry.exceptions import AttemptsExceeded
from hyx.sync_retry.typing import AttemptsT, BackoffsT
from hyx.typing import ExceptionsT, FuncT
from hyx.sync_events import get_default_name


class RetryManager:
    __slots__ = (
        "_name",
        "_exceptions",
        "_attempts",
        "_backoff",
        "_waiter",
        "_event_dispatcher",
        "_limiter",
    )

    def __init__(
        self,
        name: str,
        exceptions: ExceptionsT,
        attempts: AttemptsT,
        backoff: BackoffsT,
        event_dispatcher: Optional[RetryListener] = None,
        limiter: Optional[TokenBucket] = None,
    ) -> None:
        self._name = name
        self._exceptions = exceptions
        self._attempts = attempts
        self._backoff = create_backoff(backoff)
        self._event_dispatcher = event_dispatcher
        self._limiter = limiter

    @property
    def name(self) -> str:
        return self._name

    @property
    def exceptions(self) -> ExceptionsT:
        return self._exceptions

    @property
    def attempts(self) -> AttemptsT:
        return self._attempts

    @property
    def backoff(self) -> Any:
        return self._backoff

    @property
    def event_dispatcher(self) -> Optional[RetryListener]:
        return self._event_dispatcher

    @property
    def limiter(self) -> Optional[TokenBucket]:
        return self._limiter

    def __call__(self, func: FuncT) -> Any:
        counter = create_counter(self._attempts)
        backoff_generator = iter(self._backoff)

        try:
            while bool(counter):
                try:
                    if self._limiter is not None:
                        self._limiter.take_sync()

                    result = func()

                    if self._event_dispatcher:
                        self._event_dispatcher.on_success(self, counter)

                    return result
                except self._exceptions as e:
                    counter += 1
                    backoff = next(backoff_generator)

                    if self._event_dispatcher:
                        self._event_dispatcher.on_retry(self, e, counter, backoff)
                    time.sleep(backoff)

        except AttemptsExceeded:
            if self._event_dispatcher:
                self._event_dispatcher.on_attempts_exceeded(self)
            raise
