from collections.abc import Iterator
from typing import Optional

from hyx.sync_retry.exceptions import AttemptsExceeded


class Counter:
    """Counter implementation used to track retry attempts."""

    def __init__(self, max_value: Optional[int] = None) -> None:
        self._value = 0
        self._max_value = max_value

    def __bool__(self) -> bool:
        """Check if counter is not exceeding the maximum value."""
        if self._max_value is None:
            return True

        if self._value < self._max_value:
            return True

        raise AttemptsExceeded()

    def __iadd__(self, value: int) -> "Counter":
        """Increment counter value."""
        self._value += value
        return self

    def __int__(self) -> int:
        """Returns the current value of the counter."""
        return self._value


class InfiniteCounter(Counter):
    """Infinite Counter implementation."""

    def __bool__(self) -> bool:
        """Always return True."""
        return True


def create_counter(value: Optional[int] = None) -> Counter:
    """Create a counter with a specified maximum value."""
    if value is None:
        return InfiniteCounter()

    return Counter(value) 