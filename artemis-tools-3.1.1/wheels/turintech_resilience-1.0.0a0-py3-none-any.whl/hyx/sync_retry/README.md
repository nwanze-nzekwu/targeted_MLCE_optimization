# Synchronous Retry

This package provides a synchronous implementation of the retry pattern, similar to the async retry pattern but without using asyncio.

## Usage

```python
from hyx.sync_retry import retry

@retry(attempts=3, backoff=0.5)
def my_function():
    # your code here
    pass
``` 