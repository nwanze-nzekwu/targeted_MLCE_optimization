from typing import TYPE_CHECKING, Protocol, Union

from hyx.sync_events import ListenerFactoryT, ListenerRegistry

if TYPE_CHECKING:
    from hyx.sync_retry.counters import Counter
    from hyx.sync_retry.manager import RetryManager


class RetryListener(Protocol):
    """Retry Listener Protocol."""

    def on_retry(self, retry: "RetryManager", exception: Exception, counter: "Counter", backoff: float) -> None:
        """Called when retry occurs."""

    def on_success(self, retry: "RetryManager", counter: "Counter") -> None:
        """Called when retry succeeds."""

    def on_attempts_exceeded(self, retry: "RetryManager") -> None:
        """Called when all attempts are exceeded."""


_RETRY_LISTENERS: ListenerRegistry["RetryManager", RetryListener] = ListenerRegistry()


def register_retry_listener(listener: Union[RetryListener, ListenerFactoryT]) -> None:
    """
    Register a listener that will dispatch on all retry components in the system.
    """
    global _RETRY_LISTENERS

    _RETRY_LISTENERS.register(listener)
