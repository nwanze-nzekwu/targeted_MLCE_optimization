"""Tests for sync_retry package."""
import time

from hyx.sync_retry import retry


def test_sync_retry():
    """Test that sync_retry works correctly."""
    attempt_count = 0

    @retry(attempts=3, backoff=0.1)
    def function_to_retry():
        nonlocal attempt_count
        attempt_count += 1
        if attempt_count < 3:
            raise ValueError("Intentional error")
        return "success"

    # Should retry 2 times and succeed on the 3rd attempt
    result = function_to_retry()
    assert result == "success"
    assert attempt_count == 3


def test_sync_retry_with_listener():
    """Test that sync_retry works with listeners."""
    attempt_count = 0
    retry_events = []

    class TestListener:
        def on_retry(self, retry, exception, counter, backoff):
            retry_events.append(("retry", int(counter)))

        def on_success(self, retry, counter):
            retry_events.append(("success", int(counter)))

        def on_attempts_exceeded(self, retry):
            retry_events.append(("exceeded",))

    @retry(attempts=3, backoff=0.1, listeners=[TestListener()])
    def function_to_retry():
        nonlocal attempt_count
        attempt_count += 1
        if attempt_count < 3:
            raise ValueError("Intentional error")
        return "success"

    # Should retry 2 times and succeed on the 3rd attempt
    result = function_to_retry()
    assert result == "success"
    assert attempt_count == 3
    assert retry_events == [("retry", 1), ("retry", 2), ("success", 2)]


if __name__ == "__main__":
    test_sync_retry()
    test_sync_retry_with_listener()
    print("All tests passed!") 