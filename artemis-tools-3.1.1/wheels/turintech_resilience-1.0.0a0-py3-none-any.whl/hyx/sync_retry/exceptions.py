from hyx.exceptions import HyxError


class AttemptsExceeded(HyxError):
    """Exception raised when all retry attempts are exceeded.""" 