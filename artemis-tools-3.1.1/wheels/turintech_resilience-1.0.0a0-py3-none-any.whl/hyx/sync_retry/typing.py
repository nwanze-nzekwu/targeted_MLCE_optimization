from typing import List, Optional, Union

AttemptsT = Optional[int]
BackoffsT = Union[float, List[float]]
BucketRetryT = int 