import traceback
import weakref
from typing import Callable, Generic, List, Optional, Protocol, Sequence, TypeVar, Union, cast, runtime_checkable

ComponentT = TypeVar("ComponentT")
ListenerT = TypeVar("ListenerT")

_EVENT_MANAGER: Optional["EventManager"] = None


class EventManager:
    """
    Keeps track of currently active listeners in a synchronous way.
    """

    __slots__ = ("_listeners",)

    def __init__(self) -> None:
        self._listeners: weakref.WeakSet = weakref.WeakSet()

    def add(self, listener: Callable) -> None:
        self._listeners.add(listener)

    def wait_for_tasks(self) -> None:
        """Synchronous version - does nothing since there's no async tasks to wait for"""
        pass

    def cancel_tasks(self) -> None:
        """
        Synchronous version - clears all listeners
        """
        self._listeners.clear()


def set_event_manager(event_manager: EventManager) -> None:
    # TODO: Do we need any locking?
    global _EVENT_MANAGER

    if _EVENT_MANAGER:
        # TODO: Log this when the logging part is figured out
        # logger.warning("Overriding of current EventManager is not allowed")
        return

    _EVENT_MANAGER = event_manager


@runtime_checkable
class ListenerFactoryT(Protocol):
    def __call__(self, component: ComponentT) -> ListenerT:
        ...


class ListenerRegistry(Generic[ComponentT, ListenerT]):
    """
    A listener registry that helps to register component-wide listeners.
    """

    __slots__ = ("_listeners",)

    def __init__(self) -> None:
        self._listeners: List[Union[ListenerT, ListenerFactoryT]] = []

    @property
    def listeners(self) -> List[Union[ListenerT, ListenerFactoryT]]:
        return self._listeners

    def register(self, listener: Union[ListenerT, ListenerFactoryT]) -> None:
        self._listeners.append(listener)


class EventDispatcher(Generic[ComponentT, ListenerT]):
    """
    Dispatches specific sets of listeners that correspond to the specific component on events.
    Synchronous version.
    """

    __slots__ = (
        "_event_manager",
        "_local_listeners",
        "_global_listener_registry",
        "_component",
        "_listeners_inited",
        "_inited_listeners",
    )

    def __init__(
        self,
        local_listeners: Optional[Sequence[Union[ListenerT, ListenerFactoryT]]] = None,
        global_listener_registry: Optional[ListenerRegistry] = None,
        event_manager: Optional["EventManager"] = None,
    ) -> None:
        self._event_manager = event_manager if event_manager else _EVENT_MANAGER

        self._local_listeners = local_listeners or []
        self._global_listener_registry = global_listener_registry

        self._component: Optional[ComponentT] = None
        self._inited_listeners: Optional[List[ListenerT]] = None

    @property
    def as_listener(self) -> ListenerT:
        return cast(ListenerT, self)

    def set_component(self, component: ComponentT) -> None:
        self._component = component

    def __getattr__(self, event_handler_name: str) -> Callable:
        """
        Dispatch listeners on events in a synchronous way.
        """

        def handle_event(*args, **kwargs) -> None:
            if not self._get_or_init_listeners():
                return

            self.execute_listeners(
                event_handler_name,
                *args,
                **kwargs,
            )

            if self._event_manager:
                self._event_manager.add(lambda: None)  # Add a placeholder since we don't have real tasks

        return handle_event

    def execute_listeners(self, event_handler_name: str, *args, **kwargs) -> None:
        """
        Execute all relevant listeners sequentially.
        """
        listeners = self._get_or_init_listeners()

        if not listeners:
            return

        for listener in listeners:
            if hasattr(listener, event_handler_name):
                getattr(listener, event_handler_name)(*args, **kwargs)

    def _get_or_init_listeners(self) -> List[ListenerT]:
        if self._inited_listeners is not None:
            return self._inited_listeners

        assert self._component is not None, "Component has not been assigned to event dispatcher"

        self._inited_listeners = []

        global_listeners = self._global_listener_registry.listeners if self._global_listener_registry else []

        for listeners in [self._local_listeners, global_listeners]:
            for listener in listeners:
                if isinstance(listener, ListenerFactoryT):
                    # factory
                    self._inited_listeners.append(listener(self._component))
                    continue

                # singletons
                self._inited_listeners.append(listener)

        return self._inited_listeners


def get_default_name(func: Optional[Callable] = None) -> str:
    """
    Get the default name of the component based on code context where it's being used.
    """
    if func:
        # we have function when we are in the decorator mode
        try:
            return func.__qualname__
        except AttributeError:
            return func.__name__

    # this is more for context managers
    stack = traceback.extract_stack(limit=3)

    return stack[0].name 