# hyx.timeout

Timeout or time limiter is a component that makes sure that some code is not executing more than a given amount of time.

## Acknowledgement

- (aio-libs/async-timeout)[https://github.com/aio-libs/async-timeout]
- (michalc/aiotimeout)[https://github.com/michalc/aiotimeout]
