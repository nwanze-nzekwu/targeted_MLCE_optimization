import logging

logger = logging.getLogger("hyx.timeout")
