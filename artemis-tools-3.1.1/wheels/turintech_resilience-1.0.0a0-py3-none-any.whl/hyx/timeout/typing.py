from typing import Union

DurationT = Union[int, float]
