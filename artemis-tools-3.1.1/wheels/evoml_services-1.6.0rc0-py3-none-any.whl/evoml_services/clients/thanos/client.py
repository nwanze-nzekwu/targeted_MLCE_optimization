"""Module implementing an API client for Thanos API. This is only a wrapper on
top of the API, defining authentication and the models. It only takes as input
models valid for the API.

Some API models have an equivalent backend concept that might be stored
differently. To make the conversion between those, see the `@TODO` class that
uses this client with composition.
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import Optional, List, TypeVar, Iterable, Callable, Any
from functools import lru_cache
import logging

# Dependencies
from pydantic.v1 import parse_obj_as

from turing_task_manager.clients import (
    JsonClient,
    ApiAddress,
    authenticated,
    RetryConfiguration,
)
from evoml_api_models import (
    ConvertedGraph,
    LossFunction,
    MlTask,
    Objective,
    Pipeline,
)

# Module
from ..utils.urls import indices_query
from . import models as api  # Namespacing API version of existing models

# api.Report, api.FinalReport, api.Preprocessed, api.Pipeline, api.ConvertedGraph

from .models import (  # Models unique to API, no namespace needed
    OList,
    Dataset,
    DatasetId,
    GraphId,
    JWTToken,
    ListData,
    LoginForm,
    LokiProcessId,
    LokiTaskIds,
    LossFunctionId,
    Pagination,
    TrialId,
)

# ────────────────────────────────── utils ─────────────────────────────────── #
logger = logging.getLogger("thanos")


T = TypeVar("T")  # pylint: disable=C0103


def unique_by_key(iterable: Iterable[T], key: Callable[[T], Any]):
    """Given an iterable of item and a function that gives a key to an item,
    create a unique list by removing all items with duplicate keys.
    """
    # see https://stackoverflow.com/a/10024750
    keys = set()
    return [keys.add(key(item)) or item for item in iterable if key(item) not in keys]


# ──────────────────────────────────────────────────────────────────────────── #
class ThanosSettings(ApiAddress, LoginForm):
    """Thanos settings, including user and token authentication"""


DATA = "optimization-data"


class ThanosClient(JsonClient):  # pylint: disable=R0904
    """Client for Thanos Backend API"""

    USE_HTTPS = False
    LOGGER = logger
    AUTH_RETRY = RetryConfiguration(tries=2, delay=1.0)

    SELECT_INVERSION_MIN_SIZE = 200

    settings: ThanosSettings
    token: Optional[JWTToken]

    def __init__(self, settings: ThanosSettings):
        super().__init__(settings)
        self.token = None

    # ──────────────────────────── authentication ──────────────────────────── #
    def authenticate(self):
        """Authenticate to Thanos Backend API and caches the access_token"""
        self.token = JWTToken.parse_obj(
            self.post(
                "/auth/login",
                json=LoginForm.parse_obj(self.settings),
            )
        )
        self.session.headers.update({"Authorization": f"Bearer {self.token.access_token}"})

    def is_authenticated(self) -> bool:
        return self.token is not None

    # -------------------------------- utils --------------------------------- #
    @staticmethod
    def check_index(dataset: Dataset, index: int):
        """Checks that an index is valid for a given dataset id, raises an
        IndexError if it's out of range"""
        columns_count = dataset.metadata.columnsCount
        if not 0 <= index < columns_count:
            raise IndexError(f"Index {index} is invalid for dataset {dataset.id}" f" with {columns_count} columns")

    # ─────────────────────────────── datasets ─────────────────────────────── #
    @authenticated
    @lru_cache(maxsize=5)
    def get_dataset(self, dataset_id: DatasetId) -> Dataset:
        """Retrieves the dataset model associated to a unique Dataset Id"""
        return Dataset.parse_obj(self.get(f"/datasets/{dataset_id}"))

    @authenticated
    def delete_dataset(self, dataset_id: DatasetId):
        """Deletes a dataset by id"""
        self.delete(f"/datasets/{dataset_id}")

    # ──────────────────────────── columns infos ───────────────────────────── #
    def _indices_query(self, query: str, indices: Optional[List[int]], n_cols: Optional[int] = None) -> Optional[str]:
        """Shortens the URL for the column selection query in Thanos'
        `/datasets/{id}/columns-info` endpoint.

        See `clients.utils.urls.indices_query` for more information.
        """
        # Implementation detail: the indices query is based on the property of
        # unselecting columns of indices i & j with `-i,-j`. Thanos supports
        # a slightly different version where the request is `!=` to exclude
        # vs. `=` to include.
        converted = indices_query(indices, n_cols, self.SELECT_INVERSION_MIN_SIZE)
        if converted is None:
            return None

        if min(converted) >= 0:  # Positive
            return query + "=" + ",".join(map(str, converted))
        return query + "!=" + ",".join(map(str, -converted))

    @authenticated
    def get_columns_info(self, dataset_id: DatasetId, indexes: OList[int] = None) -> List[api.ColumnInfo]:
        """Retrieves a list of selected column information for a given dataset.

        Args:
            dataset_id:
                Unique id of a Thanos Dataset.
            indexes (Optional[List[int]]):
                A subset of column indexes. If not provided (None), selects all
                available columns. If provided, only downloads the given
                indexes.

        Raises:
            IndexError: if any index is invalid

        Returns:
            columns_info (List[api.ColumnInfo]):
                A list of information for each selected column.
        """
        # To know the number of items we want, we need the size of the dataset
        dataset = self.get_dataset(dataset_id)
        cols_count = dataset.metadata.columnsCount

        if indexes is not None and not all([0 <= index < cols_count for index in indexes]):
            raise IndexError(f"{indexes} contains invalid indexes, dataset has {cols_count} columns")

        cols_query = self._indices_query("columnIndex", indexes, cols_count)
        query = f"?{cols_query}" if cols_query is not None else ""
        return (
            Pagination[api.ColumnInfo]
            .parse_obj(
                self.get(
                    f"/datasets/{dataset_id}/columns-info{query}",
                    params={"perPage": cols_count},
                )
            )
            .docs
        )

    @authenticated
    def get_single_column_info(self, dataset_id: DatasetId, index: int) -> api.ColumnInfo:
        """Retrieves the columns infos for a given dataset id"""
        # To know if the index is valid, we need the size of the dataset
        dataset = self.get_dataset(dataset_id)
        self.check_index(dataset, index)
        return api.ColumnInfo.parse_obj(self.get(f"/datasets/{dataset_id}/columns-info/{index}"))

    @authenticated
    def set_columns_info(self, dataset_id: DatasetId, columns_info: List[api.ColumnInfo]):
        """Sets (creates/updates) the columns-info of a dataset, by id"""
        self.patch(
            f"/datasets/{dataset_id}/columns-info",
            json=ListData[api.ColumnInfo](data=columns_info),
        )

    # ----------------------------- preprocessed ----------------------------- #
    @authenticated
    def get_preprocessed(self, trial_id: TrialId) -> api.Preprocessed:
        """Retrieves the abstract model of a preprocessed file, including
        test & train files, statistics, metadata, ..."""
        return api.Preprocessed.parse_obj(self.get(f"/trials/{trial_id}/preprocessed-file"))

    @authenticated
    def post_preprocessed(self, trial_id: TrialId, preprocessed: api.Preprocessed):
        """Creates the abstract model of a preprocessed file, including test
        & train files, statistics, metadata, ...
        """
        self.put(
            f"/trials/{trial_id}/preprocessed-file",
            json=preprocessed,
        )

    # -------------------------------- graphs -------------------------------- #
    @authenticated
    def post_graph(self, graph: ConvertedGraph) -> api.ConvertedGraph:
        """Registers a graph in Thanos API's database. Returns an almost
        identical model, containing an id field.
        """
        return api.ConvertedGraph.parse_obj(self.post("/graphs", json=graph))

    @authenticated
    def get_graph(self, graph_id: GraphId) -> api.ConvertedGraph:
        """Gets a graph by id"""
        return api.ConvertedGraph.parse_obj(self.get(f"/graphs/{graph_id}"))

    # ---------------------------- loss functions ---------------------------- #
    @authenticated
    def get_loss_functions(
        self, *loss_function_ids: LossFunctionId, ml_task: MlTask = MlTask.classification
    ) -> List[LossFunction]:
        """Retrieves loss functions by ids, or by ml task if no ids are given."""
        by_task = len(loss_function_ids) == 0
        if by_task:
            return (
                Pagination[LossFunction].parse_obj(self.get("/loss-functions", params={"mlTask": ml_task})).docs[:1]
            )  # limit to 1 entry when fetching without id
        return (
            Pagination[LossFunction].parse_obj(self.get("/loss-functions", params={"_id": set(loss_function_ids)})).docs
        )

    @authenticated
    def get_loss_function(self, loss_function_id: LossFunctionId) -> LossFunction:
        """Retrieves a single loss functions by id."""
        return LossFunction.parse_obj(self.get(f"/loss-functions/{loss_function_id}"))
