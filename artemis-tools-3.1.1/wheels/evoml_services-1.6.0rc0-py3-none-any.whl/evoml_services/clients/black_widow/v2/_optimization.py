"""
HTTP Client handling methods for the subset of Black Widow's endpoints dealing with Optimization, Models & Metrics
"""

# ───────────────────────────────────────────────────── imports ────────────────────────────────────────────────────── #
from evoml_services.clients.black_widow.models.types import OptId, ModelId
from evoml_services.clients.black_widow.v2._base import BaseBlackWidowClient
from evoml_services.clients.black_widow.v2.models.optimization import OptimizationModelReport, PipelineFinalReport

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                           specifies all modules that shall be loaded and imported into the                           #
#                                current namespace when we use 'from package import *'                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #

__all_ = ["OptimizationClient"]


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                Client implementation                                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class OptimizationClient(BaseBlackWidowClient):
    """This is a client implementation for Black Widow Data API. This client is
    interacting with Black Widow's `Model Optimization v2` concept.

    This is mainly to allow contextualisation of endpoints and avoid needing to
    prefix every method with the concept it applies to.
    """

    OPT_V2_PATH = "/v2/optimizations"

    # --------------------------------------------------------------------------------------------------

    def get_optimization_model_report(self, optimization_id: OptId, model_id: ModelId) -> OptimizationModelReport:
        """Retrieve the advanced information about a single model considered as a potential solution to the optimisation
        problem.

        Args:
            optimization_id (OptId): Unique ID of a trial execution.
            model_id (ModelId): Unique ID a machine learning model created by an specific trial configuration.

        Returns:
            data (OptimizationModelReport): The advanced information about a single model considered as a potential
                solution.
        """
        response = self.get(f"{self.OPT_V2_PATH}/{optimization_id}/models/{model_id}/report")
        return OptimizationModelReport(**response)

    def get_pipeline_final_report(self, optimization_id: OptId, model_id: ModelId) -> PipelineFinalReport:
        """Returns the final report of a model optimization.

        Args:
            optimization_id (OptId): Unique ID of a trial execution.
            model_id (ModelId): Unique ID a machine learning model created by an specific trial configuration.

        Returns:
            data (PipelineFinalReport): The final model report of a pipeline model optimization.
        """
        response = self.get(f"{self.OPT_V2_PATH}/{optimization_id}/models/{model_id}/pipeline/report")
        return PipelineFinalReport(**response)
