"""
HTTP Client handling methods for the subset of Black Widow's endpoints dealing with Optimization, Models & Metrics
"""

# ───────────────────────────────────────────────────── imports ────────────────────────────────────────────────────── #
from evoml_services.clients.black_widow.base import BlackWidowSettings
from evoml_services.clients.base.base_client import BaseClient

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                           specifies all modules that shall be loaded and imported into the                           #
#                                current namespace when we use 'from package import *'                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #

__all_ = ["OptimizationClient"]


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                Client implementation                                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class BaseBlackWidowClient(BaseClient):
    """This is a client implementation for Black Widow Data API.
    This client is interacting with Black Widow as a whole (not specific to any concept)
    """

    def __init__(self, settings: BlackWidowSettings):
        super().__init__(settings, retries=5)
