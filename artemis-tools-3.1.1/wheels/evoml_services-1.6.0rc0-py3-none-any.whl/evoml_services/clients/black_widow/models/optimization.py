from __future__ import annotations

import io
from typing import List, Optional
from enum import Enum

from pydantic.v1 import Field, BaseModel

from .types import FengId, OptId, ModelId


# --------------------------------- metrics ---------------------------------- #
class MetricDirection(str, Enum):
    ASCENDING = "asc"
    DESCENDING = "desc"


class MetricDefinition(BaseModel):
    name: str
    slug: str
    order: MetricDirection
    sourceCode: Optional[str] = None


# ------------------------------- optimization ------------------------------- #
class Status(str, Enum):
    DEFINED = "defined"
    FAILED = "failed"
    COMPLETED = "completed"
    RUNNING = "running"


class MlTask(str, Enum):
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
    FORECASTING = "forecasting"


class OptimizationSpace(BaseModel): ...


# --------------------------- optimization config ---------------------------- #
class OversampleStrategy(str, Enum):
    NONE = "none"
    AUTO = "auto"
    SINGLE_INSTANCE = "single-instance"
    SMOTE = "smote"
    BORDERLINE_SMOTE = "borderline-smote"
    RAMDOM_OVERSAMPLING = "random-oversampling"
    ADAPTIVE_SYNTHETIC_SAMPLING = "adasyn"
    SVM_SMOTE = "svm-smote"
    SMOTE_TOMEK = "smote-tomek"


class ValidationMethod(str, Enum):
    """Enumeration of the supported validation methods.

    This links 1 ↔ 1 with a model defining parameters (options) for each of this
    enumeration's members.
    """

    cross_validation = "cross-validation"
    holdout = "holdout"
    sliding_window = "sliding-window"
    expanding_window = "expanding-window"
    forecast_holdout = "forecast-holdout"

    value: str  # To avoid LSP warnings in the methods

    def get_option_field(self) -> str:
        """Each enum member has a corresponding option field (where you expect
        to find the config for this method)
        """
        # Convert the current value from 'kebab-case' to 'camelCase'
        words = self.value.split("-")
        camelcase = words[0] + "".join(map(str.capitalize, words[1:]))
        return f"{camelcase}Options"


class CrossValidationOptions(BaseModel):
    """Individual parameters for the 'cross-validation' method"""

    folds: int = Field(5, ge=2, le=10)
    keepOrder: bool = False


class HoldoutOptions(BaseModel):
    """Individual parameters for the 'holdout' method"""

    size: float = Field(0.01, ge=0.01, le=0.5)
    keepOrder: bool = False


class SlidingWindowOptions(BaseModel):
    """Individual parameters for the 'sliding-window' method"""

    horizon: Optional[int] = Field(None, ge=1)
    gap: int = Field(0, ge=0)
    trainWindowLength: Optional[int] = Field(None, ge=1)
    slideLength: Optional[int] = Field(None, ge=1)


class ExpandingWindowOptions(BaseModel):
    """Individual parameters for the 'expanding-window' method"""

    horizon: Optional[int] = Field(None, ge=1)
    gap: int = Field(0, ge=0)
    initialTrainWindowLength: Optional[int] = Field(None, ge=1)
    expansionLength: Optional[int] = Field(None, ge=1)


class ForecastHoldoutOptions(BaseModel):
    """Individual parameters for the 'forecasting-holdout' method"""

    size: float
    gap: int = Field(0, ge=0)


class ValidationMethodOptions(BaseModel):
    method: ValidationMethod = ValidationMethod.cross_validation
    crossValidationOptions: Optional[CrossValidationOptions]
    holdoutOptions: Optional[HoldoutOptions]
    slidingWindowOptions: Optional[SlidingWindowOptions]
    expandingWindowOptions: Optional[ExpandingWindowOptions]
    forecastHoldoutOptions: Optional[ForecastHoldoutOptions]


class ModelDefinition(BaseModel):
    name: str
    parameterSpace: dict
    metadata: dict


class OptimizationConfig(BaseModel):
    datasetId: str
    datasetName: str
    trialId: str
    trialName: str
    labelMapping: Optional[List[str]]
    futureCovariates: List[str] = []
    timeSeries: bool
    labelColumn: str
    indexColumnIndex: Optional[int]
    labelColumnIndex: int
    positiveClass: Optional[str]
    mlTask: MlTask
    objectives: List[str]
    filterBudget: int
    tuningBudget: int
    includeGreenMetrics: bool
    optimizer_name: str
    thread_count: int
    class_count: int
    oversamplingStrategy: OversampleStrategy
    oversamplingRatio: float
    scorers: Optional[dict] = None
    customScorers: Optional[dict] = None
    validationMethodOptions: ValidationMethodOptions
    seed: int


ThanosTrialOptions = dict  # Thanos Trial Options, costly to sync & define


class OptimizationCreate(BaseModel):
    options: ThanosTrialOptions  # Thanos Trial Options
    featureEngineeringId: FengId
    space: OptimizationSpace = OptimizationSpace()


class Optimization(BaseModel):
    featureEngineeringId: FengId
    status: Status
    options: ThanosTrialOptions  # Thanos Trial Options


class ModelArtifactDetails(BaseModel):
    optimisation_id: OptId
    model_id: ModelId
    artifact_binary: io.BytesIO
    metaml_version: str
    metaml_extras: List[str]

    class Config:
        arbitrary_types_allowed = True
