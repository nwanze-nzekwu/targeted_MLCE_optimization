"""Models unique to the different clients, specifically for the data models
where the API communicates elements as Thor `file_id`, but the HTTP client
handles coomunicating with Thor to provide usable in-memory objects.
"""

from typing import List, NamedTuple, Optional

import pandas as pd

from .types import OptId, FengId


# ------------------------------- optimization ------------------------------- #
class ValidationSlice(NamedTuple):
    train_index: List[int]
    test_index: List[int]


# --------------------------- preprocessor actions --------------------------- #
class SplitTransform(NamedTuple):
    """Dataframes output obtained by splitting and preprocessing a file"""

    train: pd.DataFrame
    test: Optional[pd.DataFrame]


class SplitFilesIndices(NamedTuple):
    """Dataframes output obtained by splitting a file"""

    train: pd.Index
    test: Optional[pd.Index]
    drop_train: Optional[pd.Index]
    drop_test: Optional[pd.Index]


# ---------------------------------- legacy ---------------------------------- #
class TrialMapping(NamedTuple):
    optimization_id: OptId
    # feng_id: FengId
