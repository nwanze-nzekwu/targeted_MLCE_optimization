from __future__ import annotations
from typing import List, Optional, Any
from enum import Enum

from pydantic.v1 import Field, BaseModel

from .optimization import Status


# ---------------------------------------------------------------------------- #
class ProductionStageName(str, Enum):
    TUNING = "tuning"
    FILTERING = "filtering"
    STACKING = "stacking"
    VOTING = "voting"


class ProductionStage(BaseModel):
    name: ProductionStageName
    index: int


class EvaluationStep(str, Enum):
    TRAIN = "train"
    VALIDATION = "validation"
    TEST = "test"


class OutputType(str, Enum):
    PREDICTIONS = "predictions"
    PROBABILITIES = "probabilities"
    FEATUREIMPORTANCE = "featureImportance"


class ModelParameter(BaseModel):
    name: str
    value: Any


class ModelInitialization(BaseModel):
    id: str
    startedAt: str
    productionStage: ProductionStage
    name: str = Field(..., alias="mlModelName")
    parameters: List[ModelParameter]
    preprocessorId: str
    ramInBytes: int
    gpus: int
    cpus: int


class ModelOutput(BaseModel):
    fileId: str
    outputType: OutputType
    evaluationStep: EvaluationStep
    validationFold: Optional[int] = None


class MetricValues(BaseModel):
    slug: str
    evaluationStep: EvaluationStep
    values: List[float]
    validationFold: Optional[int] = None


class ModelEvaluationResult(BaseModel):
    outputs: List[ModelOutput]
    metrics: List[MetricValues]


class EnsembleType(str, Enum):
    """Type of ensemble models"""

    NONE = "none"
    FOREST = "forest"
    OTHER = "other"
    # Values for future implementations
    # ---------------------------------
    # BOOSTING = "boosting"
    # STACKING = "stacking"


class ModelFamily(str, Enum):
    """Family of ML model"""

    LINEAR = "linear"
    TREE = "tree"
    OTHER = "other"
    # Values for future implementations
    # ---------------------------------
    # KERNEL = "kernel"
    # NEURAL = "neural"
    # NEIGHBOUR = "neighbour"
    # BAYESIAN = "bayesian"


class ModelProperties(BaseModel):
    """Properties (what a model can do) of a Machine Learning model"""

    probabilities: bool
    featureImportances: bool
    ensembleType: EnsembleType
    family: ModelFamily


class Model(BaseModel):
    """Summary of a model when getting information about a model_id"""

    id: str = Field(..., alias="_id")
    productionStage: ProductionStage
    name: str = Field(..., alias="mlModelName")
    parameters: List[ModelParameter]
    preprocessorId: str
    properties: ModelProperties
    status: Status
    gpus: int
    cpus: int
    ramInBytes: int


class StatusContainer(BaseModel):
    """Container for status change payloads"""

    status: Status


class ClosureReason(str, Enum):
    """Enumeration of the possible reasons for a model to be closed"""

    FINISHED = "finished"
    EXCEPTION = "exception"
    CANCELLATION = "cancellation"


class ClosureInfo(BaseModel):
    """Details about why a model was closed"""

    closureReason: ClosureReason = ClosureReason.FINISHED
    closureMessage: Optional[str] = None


# ---------------------------------Loki Data---------------------------------- #
class TrialDataset(BaseModel):
    datasetId: str
    columnIndex: int
    trialId: str


class LokiData(BaseModel):
    loki_data_retrieval: TrialDataset = Field(..., alias="data_retrieval")
    loki_task_id: str = Field(..., alias="task_id")
    loki_process_id: str = Field(..., alias="process_id")
