from typing import Dict, Optional, List

from pydantic.v1 import BaseModel

from evoml_services.clients.thanos.models import FinalReport
import evoml_api_models as backend  # Backend models

from .types import FileId
from .optimization import MlTask

PipelineId = str


class TrialDataset(BaseModel):
    """Thanos information to uniquely identify a trial + original dataset"""

    datasetId: str
    columnIndex: int
    trialId: str


# ------------------------------- final report ------------------------------- #
class ThanosMetricValues(BaseModel):
    values: List[float]
    min: float
    max: float
    average: float
    median: float


class ThanosModelReport(FinalReport):
    """A mutated form of final.json to fit with thanos interface requirements"""

    mlTask: MlTask
    metrics: Dict[str, backend.PipelineMetrics]
    # ----------------------------------
    pipelineId: PipelineId  # replaces 'pipeline'
    # ----------------------------------
    # Deployment information/files
    pipelineZipFileId: Optional[FileId]
    pipelineHandlerFileId: Optional[FileId]
    predictionCsvFileId: Optional[FileId]
    # ----------------------------------
