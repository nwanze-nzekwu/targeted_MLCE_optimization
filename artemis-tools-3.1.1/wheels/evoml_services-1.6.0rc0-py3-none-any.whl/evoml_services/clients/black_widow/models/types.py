from typing import TypeVar, List, Dict

from evoml_api_models import Objective, PipelineMetrics

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                           specifies all modules that shall be loaded and imported into the                           #
#                                current namespace when we use 'from package import *'                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #

__all_ = [
    "FileId",
    "DatasetFileId",
    "IndicesFileId",
    "GraphId",
    "FengId",
    "PreprocessorId",
    "OptId",
    "ModelId",
    "ResourceUri",
    "ReportObjectivesType",
    "ObjectivesScoreType",
    "ReportMetricsType",
]

# ------------------------------- type aliases ------------------------------- #
FileId = str
DatasetFileId = str
IndicesFileId = str
GraphId = str
FengId = str
PreprocessorId = str
OptId = str
ModelId = str
ResourceUri = str

ReportObjectivesType = List[Objective]
ObjectivesScoreType = Dict[str, float]
ReportMetricsType = Dict[str, PipelineMetrics]
