from typing import Optional, List

from pydantic.v1 import Field, BaseModel

from .types import FileId, DatasetFileId, IndicesFileId


# ─────────────────────────── feature engineering ──────────────────────────── #
class FengMetadata(BaseModel):
    """Metadata for a Feature Engineering"""

    # @TODO: Typing is kept to a minimal here as it is somewhat tricky.
    labelMappings: Optional[list] = Field(None)


class FeatureEngineering(BaseModel):
    id: str = Field(..., alias="_id")
    targetColumnIndex: int
    metadata: Optional[FengMetadata]
    datasetFileId: DatasetFileId
    testFileId: Optional[DatasetFileId] = None


class FengSpace(BaseModel):
    """Search space for feature engineering. Every preprocessor created for
    this problem will be a different point in this research space
    """

    # → Doesn't really exist yet
    # Note: also it is probably mixed with Loki config (exp. the models)


class FengProblemDefinition(BaseModel):
    """Defines the space and options for the feature engineering process"""

    # → PreprocessorOptions from Loki
    options: dict
    space: FengSpace
    datasetFileId: FileId = None
    targetColumnIndex: int = Field(..., ge=0)


class FengCreate(FengProblemDefinition):
    """Feature Engineering Problem Definition adding some top level concepts
    required to instanciate feature engineering
    """

    datasetFileId: DatasetFileId
