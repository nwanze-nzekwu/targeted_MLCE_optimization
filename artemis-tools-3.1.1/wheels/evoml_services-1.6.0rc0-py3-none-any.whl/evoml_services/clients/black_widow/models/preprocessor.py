from typing import Optional

from pydantic.v1 import BaseModel, Field

from .optimization import Status
from .types import FileId, DatasetFileId, IndicesFileId


# ------------------------------- preprocessor ------------------------------- #
class PreprocessorParameters(BaseModel):
    """Specific parameters for a given preprocessor"""


class PreprocessorCreate(BaseModel):
    """Minimum known state of a preprocessor, required to register one as
    potential solution to this problem
    """

    parameters: PreprocessorParameters
    name: str = Field(..., example="RoBERTa-5-feature")
    preprocessorId: str


class PreprocessorReport(BaseModel):
    # @TODO: this should be shared using probably evoml_models
    ...


class Preprocessor(PreprocessorCreate):
    status: Status


# ------------------------------- file actions ------------------------------- #
class SplitTransformFileIds(BaseModel):
    """API response for /.../preprocessors/.../split-transform"""

    trainFileId: DatasetFileId
    testFileId: DatasetFileId


class FileIndicesIds(BaseModel):
    fileId: FileId
    indicesFileId: IndicesFileId


class SplitFileIds(BaseModel):
    """API response for /.../preprocessors/.../split"""

    train: FileIndicesIds
    test: Optional[FileIndicesIds]
    drop_train: Optional[FileIndicesIds]
    drop_test: Optional[FileIndicesIds]
