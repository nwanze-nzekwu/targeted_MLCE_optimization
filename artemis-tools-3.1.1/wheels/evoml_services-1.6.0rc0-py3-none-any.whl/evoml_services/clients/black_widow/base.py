"""Base client for Black Widow"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from __future__ import annotations

import time
from typing import BinaryIO, Sequence
from enum import Enum
import logging
import json

# Dependencies
from requests import Response
import numpy as np
import pandas as pd
import turing_task_manager.clients.core as clients
from turing_task_manager.clients import HttpException
from turing_task_manager.clients.core.utils import response_json
from turing_task_manager.clients.core.types import Json

# Module
from evoml_services.clients.thor import ThorClient, DatasetFileId
from .models.types import IndicesFileId


# ──────────────────────────────────────────────────────────────────────────── #


class BlackWidowSettings(clients.ApiAddress):
    """Settings for Black Widow Data API"""


# ------------------------------ generic client ------------------------------ #
class BaseBlackWidowClient(clients.JsonClient):
    """This is a client implementation for Black Widow Data API. This client is
    interacting with Black Widow as a whole (not specific to any concept)
    """

    LOGGER = logging.getLogger("black_widow")
    USE_HTTPS = False

    def __init__(self, settings: BlackWidowSettings, thor_client: ThorClient):
        super().__init__(settings)
        self.LOGGER.setLevel(settings.log_level.value)
        self.thor_client = thor_client

    # ---------------------------- authentication ---------------------------- #
    def authenticate(self):
        """No authentication for Black Widow Data API yet"""

    def is_authenticated(self) -> bool:
        return True

    # ------------------------------- logging -------------------------------- #
    def request(self, path: str, method: clients.HTTPMethod, **kwargs) -> Response:
        # Log the path & body of the request
        self.LOGGER.debug(
            "Calling: [%s] %s\nJSON: %s\nQuery Params: %s",
            method,
            self.settings.get_adress(),
            json.dumps(kwargs.get("json", {}), indent=2),
            json.dumps(kwargs.get("params", {}), indent=2),
        )
        # Catch and log the exception before raising
        try:
            return super().request(path, method, **kwargs)
        except clients.HttpException as exc:
            self.LOGGER.debug("Response:\n\tCode: %s\n\tMessage: %s", exc.code, exc.message)
            raise exc

    # -------------------------------- utils --------------------------------- #
    # Note: could be on the primary client, but we need Thor and I don't want to
    # force Thor on the primary client
    def file_id_to_indices(self, indices_file_id: DatasetFileId) -> np.array:
        """Converts an indicesFileId (file id of a dataset with a single column
        named 'indices') to a numpy array
        """
        indices_df = self.thor_client.download_dataframe(indices_file_id)
        indices_series: pd.Series = indices_df.iloc[:, 0]
        return indices_series.to_numpy()

    def indices_to_file_id(self, indices: Sequence[int]) -> IndicesFileId:
        """Converts indices (numpy array or list of integers) to an indices file
        id in Thor
        """
        indices_df = pd.DataFrame({"indices": indices})
        return self.thor_client.upload_dataframe(indices_df).id

    # ----------------------------- Retry on 500 ----------------------------- #
    def get(self, path: str, **kwargs) -> Json:
        """
        Overriding the base get method to support retries in the event of 500
        series errors
        """
        MAX_ATTEMPTS = 5
        retry_flag = True
        attempt_count = 0
        while retry_flag:
            attempt_count += 1
            try:
                raw_response = self.request(path, method="get", **kwargs)
                retry_flag = False
            except HttpException as err:
                if err.code == 500:
                    retry_flag = attempt_count < MAX_ATTEMPTS
                    self.LOGGER.info(f"Request to {path} retrying due to 500 series response")
                    time.sleep(0.1)

                if not retry_flag or err.code != 500:
                    raise err

        json_response = response_json(raw_response)
        return json_response

    # ---------------------------- instantiation ----------------------------- #
    @classmethod
    def from_client(cls, client: BaseBlackWidowClient):
        return cls(client.settings, client.thor_client)
