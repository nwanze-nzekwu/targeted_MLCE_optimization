"""Implements an HTTP client for Black Widow Data API"""

# ───────────────────────────────────────────────────── imports ────────────────────────────────────────────────────── #
from evoml_services.clients.black_widow.feature_engineering import FeatureEngineeringClient
from evoml_services.clients.black_widow.optimization import OptimizationClient

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                           specifies all modules that shall be loaded and imported into the                           #
#                                current namespace when we use 'from package import *'                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #

__all_ = ["BlackWidowClient"]


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                Client implementation                                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class BlackWidowClient(FeatureEngineeringClient, OptimizationClient):
    """Aggregates the Optimization and FeatureEngineering clients"""
