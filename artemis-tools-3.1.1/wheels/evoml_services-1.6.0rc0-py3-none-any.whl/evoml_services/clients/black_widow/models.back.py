from __future__ import annotations
from typing import List, Optional, Any, TypeVar, Dict
from enum import Enum
from typing_extensions import NamedTuple

import pandas as pd
from pydantic.v1 import Field, BaseModel, root_validator, StrictInt, validator
from evoml_api_models import (
    Pipeline,
    DetectedType,
    ColumnDefaultTrialOptions,
    ColumnStatistics,
    ColumnTag,
    ColumnAnomalies,
    BaseTypes,
)

# ------------------------------- type aliases ------------------------------- #
FileId = TypeVar("FileId", bound=str)
DatasetFileId = TypeVar("DatasetFileId", bound=str)
IndicesFileId = TypeVar("IndicesFileId", bound=str)
GraphId = TypeVar("GraphId", bound=str)
FengId = TypeVar("FengId", bound=str)
PreprocessorId = TypeVar("PreprocessorId", bound=str)
OptId = TypeVar("OptId", bound=str)
ModelId = TypeVar("ModelId", bound=str)
ResourceUri = TypeVar("ResourceUri", bound=str)


# ---------------------------------------------------------------------------- #
class MetricDirection(str, Enum):
    ASCENDING = "asc"
    DESCENDING = "desc"

    @classmethod
    def _missing_(cls, value: object):
        """Handles 2 conflicting representation for this enum: min/max &
        asc/desc
        """
        if isinstance(value, str):
            if value == "min":
                return cls.ASCENDING
            if value == "max":
                return cls.DESCENDING
        return super()._missing_(value)


class MlTask(str, Enum):
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
    FORECASTING = "forecasting"


class ProductionStageName(str, Enum):
    TUNING = "tuning"
    FILTERING = "filtering"
    STACKING = "stacking"
    VOTING = "voting"


class EvaluationStep(str, Enum):
    TRAIN = "train"
    VALIDATION = "validation"
    TEST = "test"


class OutputType(str, Enum):
    PREDICTIONS = "predictions"
    PROBABILITIES = "probabilities"
    FEATUREIMPORTANCE = "featureImportance"


class ModelStatus(str, Enum):
    defined = "defined"
    failed = "failed"
    completed = "completed"
    running = "running"


class OptimizationIdMap(BaseModel):
    """
    Map from Thanos Trial ID to Blackwidow Optimization Execution ID
    """

    trialId: str
    optimizationId: str


class ValidationDataSlice(BaseModel):
    fileId: str
    foldIndex: int


class MetricDefinition(BaseModel):
    name: str
    slug: str
    order: MetricDirection


class ProductionStage(BaseModel):
    name: ProductionStageName
    index: int


class ModelParameter(BaseModel):
    name: str
    value: Any


class MetricValues(BaseModel):
    slug: str
    evaluationStep: EvaluationStep
    values: List[float]
    validationFold: Optional[int] = None


class PreprocessTask(BaseModel):
    originalTrainFileId: str
    originalTestFileId: str
    trainFileId: str
    testFileId: str
    sampleFileId: str
    settingsFileId: str
    columnsInfoFileId: str
    extraInfosFileId: str
    pipelineAppendixFileId: str


class ModelInitialization(BaseModel):
    id: str
    startedAt: str
    productionStage: ProductionStage
    name: str = Field(..., alias="mlModelName")
    parameters: List[ModelParameter]
    preprocessorId: str


class ModelOutput(BaseModel):
    fileId: str
    outputType: OutputType
    evaluationStep: EvaluationStep
    validationFold: Optional[int] = None


class ModelEvaluationResult(BaseModel):
    outputs: List[ModelOutput]
    metrics: List[MetricValues]


class OversampleStrategy(str, Enum):
    NONE = "none"
    AUTO = "auto"
    SINGLE_INSTANCE = "single-instance"
    SMOTE = "smote"
    BORDERLINE_SMOTE = "borderline-smote"
    RAMDOM_OVERSAMPLING = "random-oversampling"
    ADAPTIVE_SYNTHETIC_SAMPLING = "adasyn"
    SVM_SMOTE = "svm-smote"
    SMOTE_TOMEK = "smote-tomek"


class ValidationMethod(str, Enum):
    """Enumeration of the supported validation methods.

    This links 1 ↔ 1 with a model defining parameters (options) for each of this
    enumeration's members.
    """

    cross_validation = "cross-validation"
    holdout = "holdout"
    sliding_window = "sliding-window"
    expanding_window = "expanding-window"
    forecast_holdout = "forecast-holdout"

    value: str  # To avoid LSP warnings in the methods

    def get_option_field(self) -> str:
        """Each enum member has a corresponding option field (where you expect
        to find the config for this method)
        """
        # Convert the current value from 'kebab-case' to 'camelCase'
        words = self.value.split("-")
        camelcase = words[0] + "".join(map(str.capitalize, words[1:]))
        return f"{camelcase}Options"


class CrossValidationOptions(BaseModel):
    """Individual parameters for the 'cross-validation' method"""

    folds: int = Field(5, ge=2, le=10)
    keepOrder: bool = False


class HoldoutOptions(BaseModel):
    """Individual parameters for the 'holdout' method"""

    size: float = Field(0.01, ge=0.01, le=0.5)
    keepOrder: bool = False


class SlidingWindowOptions(BaseModel):
    """Individual parameters for the 'sliding-window' method"""

    horizon: Optional[int] = Field(None, ge=1)
    gap: int = Field(0, ge=0)
    trainWindowLength: Optional[int] = Field(None, ge=1)
    slideLength: Optional[int] = Field(None, ge=1)


class ExpandingWindowOptions(BaseModel):
    """Individual parameters for the 'expanding-window' method"""

    horizon: Optional[int] = Field(None, ge=1)
    gap: int = Field(0, ge=0)
    initialTrainWindowLength: Optional[int] = Field(None, ge=1)
    expansionLength: Optional[int] = Field(None, ge=1)


class ForecastHoldoutOptions(BaseModel):
    """Individual parameters for the 'forecasting-holdout' method"""

    horizon: Optional[int] = Field(None, ge=1)
    gap: int = Field(0, ge=0)
    trainStartIndex: int = Field(0, ge=0)
    trainStopIndex: Optional[int] = Field(None, ge=0)


class ValidationMethodOptions(BaseModel):
    method: ValidationMethod = ValidationMethod.cross_validation
    crossValidationOptions: Optional[CrossValidationOptions]
    holdoutOptions: Optional[HoldoutOptions]
    slidingWindowOptions: Optional[SlidingWindowOptions]
    expandingWindowOptions: Optional[ExpandingWindowOptions]
    forecastHoldoutOptions: Optional[ForecastHoldoutOptions]


class OptimizationConfig(BaseModel):
    datasetId: str
    datasetName: str
    trialId: str
    trialName: str
    labelMapping: List[str]
    timeSeries: bool
    labelColumn: str
    indexColumnIndex: Optional[int]
    labelColumnIndex: int
    positiveClass: Optional[str]
    mlTask: MlTask
    objectives: List[str]
    filterBudget: int
    tuningBudget: int
    includeGreenMetrics: bool
    optimizer_name: str
    thread_count: int
    class_count: int
    oversamplingStrategy: OversampleStrategy
    oversamplingRatio: float
    scorers: Optional[dict] = None
    customScorers: Optional[dict] = None
    validationMethodOptions: ValidationMethodOptions
    seed: int


class ModelDefinition(BaseModel):
    name: str
    parameterSpace: Dict
    metadata: Dict


class Optimization(BaseModel):
    featureEngineeringId: FengId
    state: ModelStatus


class GraphType(str, Enum):
    all = "All"
    confusion_matrix = "ClassificationConfusionMatrix"
    roc_curve = "ClassificationRocCurve"
    pr_curve = "ClassificationPrCurve"
    gain_chart = "ClassificationGainChart"
    lift_chart = "ClassificationLiftChart"
    absolute_residuals = "ClassificationAbsoluteResiduals"
    probability_density_plot = "ClassificationProbaDensityPlot"
    binary_ks_curve = "ClassificationBinaryKsCurve"
    probability_calibration = "ClassificationProbaCalibration"

    scatter_plot = "RegressionScatterPlot"
    residual_box_plot = "RegressionResidualBoxPlot"
    residual_scatter_plot = "RegressionResidualScatterPlot"
    residual_histogram = "RegressionResidualHistogram"


class ThanosMetricValues(BaseModel):
    values: List[float]
    min: float
    max: float
    average: float
    median: float


class PipelineMetrics(BaseModel):
    train: ThanosMetricValues
    validation: ThanosMetricValues
    test: Optional[ThanosMetricValues]


class ModelPipelines(BaseModel):
    """
    List of model pipelines
    """

    pipelines: List[Pipeline]


SlugDict = Dict[str, List[str]]

# for featureOverrides, we can have a slug key with a slugValue
# of null, This has the implicit meaning of inheriting the slugs
# from the parent type
InheritableSlugDict = Dict[str, Optional[List[str]]]


class FeatureFilter(str, Enum):
    """Enum deciding what to do when filtering features (feature selection)"""

    drop = "drop"
    keep = "keep"
    auto = "auto"


class ImputeStrategy(str, Enum):
    """Enumeration of impute strategies (ways to replace missing values)"""

    constant = "constant"
    mean = "mean"
    median = "median"
    most_frequent = "most-frequent"
    auto = "auto"


class ImputeOptions(BaseModel):
    """Defines the strategy to impute missing data. Strategies are enum linking
    to functions taking in the data and figuring out the value to use as
    replacement. The 'constant' strategy is an exception as it requires user
    input. This model encodes a separate field to deal with this exception.
    """

    strategy: ImputeStrategy = ImputeStrategy.auto
    value: Optional[str] = None


class FeatureOverride(BaseModel):
    columnIndex: int
    filter: FeatureFilter = FeatureFilter.auto
    impute: Optional[ImputeOptions]
    encoderSlugs: InheritableSlugDict
    scalerSlugs: InheritableSlugDict


class TransformationOption(BaseModel):
    detectedType: str
    impute: ImputeOptions = ImputeOptions()
    encoderSlugs: SlugDict
    scalerSlugs: SlugDict
    featureOverrides: List[FeatureOverride]

    @root_validator()
    def inherit_impute(cls, values: dict):
        """In the frontend, if a user doesn't set any impute strategy when
        setting the preprocessing options for a specific column
        (i.e. .featureOverrides.impute = null), this implies that they wish to
        inherit the default impute strategy for the detected type of that column
        (i.e. .impute).

        In this case, we copy over the default impute strategy to the
        column-specific feature overrides. This is because the preprocessor is
        not written in a way that it knows to fetch the default impute strategy
        if the column-specific ones is null.

        Note: this is the same mechanism as encoder/scalers, except simpler
        because we have a static sub-model.
        """
        parent_impute: ImputeOptions = values["impute"]

        feature_overrides: List[FeatureOverride] = values["featureOverrides"]
        for override in feature_overrides:
            override.impute = override.impute or parent_impute  # replace None
        return values

    @root_validator()
    def transform_inheritable_slug_dicts(cls, values: dict):
        """In the frontend, if a user doesn't set any encoders or scalers
        for when setting the preprocessing options for a specific column
        (i.e. .featureOverrides.encoderSlugs|scalerSlugs.<slugKey> = null),
        This implies that they wish to inherit the default encoders and scalers
        for the detected type of that column (i.e. .encoderSlugs|scalerSlugs).

        In this case, we copy over the default encoders and scalers to the
        column-specific feature overrides. This is because the preprocessor
        worker currently doesn't handle null slug values, nor is written in
        a way that it knows to fetch the default encoders and scalers if
        the column-specific ones are null.
        """

        for slugType in ("encoderSlugs", "scalerSlugs"):
            parent_slugs: SlugDict = values.get(slugType)

            for slugKey, slugValue in parent_slugs.items():
                # focus all overridable slugs that are None
                unset_slugs = (
                    lens.Get("featureOverrides")
                    .Each()
                    .GetAttr(slugType)
                    .Get(slugKey)
                    .Filter(lambda value: value is None)
                )

                # and set them to the parent slug
                values = unset_slugs.set(slugValue)(values)

        return values


class FeatureSelectionOptions(BaseModel):
    enable: bool
    featureImportanceModels: List[str] = Field(..., alias="models")
    variancePercentageCutoff: Optional[float]
    correlationMethod: str
    sequentialSelector: bool
    noOfFeatures: Optional[int]


class FeatureGenerationOptions(BaseModel):
    enable: bool
    noOfNewFeatures: int
    unaryOps: List[str]
    polyOps: List[str]
    epochs: int


class PreprocessOptions(BaseModel):
    splittingMethodOptions: SplitMethodOptions
    models: List[ModelDefinition] = Field(..., min_items=1)
    transformationOptions: List[TransformationOption] = []
    mlTask: MlTask
    isTimeseries: bool
    indexColumnIndex: Optional[int]
    featureSelectionOptions: Optional[FeatureSelectionOptions]
    featureGenerationOptions: Optional[FeatureGenerationOptions]


class OptimiseOptions(BaseModel):
    """Generic options mandatory for any optimise process"""

    mlTask: MlTask
    isTimeseries: bool = Field(..., alias="isTimeSeries")
    indexColumnIndex: Optional[int]
    models: List[ModelDefinition] = Field(..., min_items=1)
    budget: ResourceAllocation
    includeGreenMetrics: bool = False
    positiveClass: Optional[str] = Field(
        None,
        example="employed",
        alias="selectedPositiveLabel",
        description=""
        "In a binary classification, decides which class should be positive (1)."
        " Requires `mlTask` to be 'classification' if the value is not null. "
        "The default (null) leaves the choice to the current implementation.",
    )
    lossFunctionsIds: Optional[List[str]] = Field([])
    executionTimeLimit: Optional[int] = Field(None, gt=0, example=100, decription="Maximal execution time in seconds")
    validationMethodOptions: ValidationMethodOptions


class RawThanosConfig(OptimiseOptions, PreprocessOptions):
    """Config received by inlining the 'options' & 'dataRetrieval' dictionaries
    provided to Loki by Thanos.

    This config can rename field, but should be able to parse the data as
    received from Thanos.
    """

    trialId: str
    datasetId: str
    columnIndex: int
    windowSize: Optional[int] = Field(default=None, ge=1, alias="timeSeriesWindowSize")

    def to_trial_config(self) -> TrialConfig:
        objectives = thanos_helper.loss_function_slugs_from_ids(self.lossFunctionsIds)

        config = TrialConfig(
            datasetId=self.datasetId,
            datasetName=thanos_helper.dataset_name(self.datasetId),
            trialId=self.trialId,
            trialName=thanos_helper.trial_name(self.trialId),
            labelMapping=["Placeholder"],  # This will be populated by pre-proc
            timeSeries=self.isTimeseries,
            labelColumn="Placeholder",  # This will be populated by pre-proc
            labelColumnIndex=self.columnIndex,
            indexColumnIndex=self.indexColumnIndex,
            positiveClass=self.positiveClass,
            mlTask=self.mlTask,
            objectives=objectives,
            filterBudget=self.budget.filtering,
            tuningBudget=self.budget.tuning,
            includeGreenMetrics=self.includeGreenMetrics,
            optimizer_name="nsgaii",
            thread_count=4,  # TODO probably don't store this
            class_count=0,  # TODO probably don't store this
            scorers={},
            customScorers={},
            validationMethodOptions=self.validationMethodOptions,
        )
        return config


class OptimizationOptions(RawThanosConfig):
    """Options configuring the behaviour of the optimisation process. This
    affects how the process will run without being a part of each independant
    solutions.
    """

    # @TODO: now we're reusing the RawThanosConfig. There might be an
    # opportunity to find a different organisation/naming later

    # → OptimisationOptions from evoml_models
    # examples:
    # - n_threads
    # - budget


class OptimizationDefinition(BaseModel):
    """Defines the space and options for the feature engineering process"""

    # → PreprocessorOptions from Loki
    options: OptimizationOptions
    space: OptimizationSpace


class OptimizationCreation(OptimizationDefinition):
    """Optimization Definition adding some top level concepts required to
    instanciate an optimization problem (mainly foreign keys)
    """

    featureEngineeringId: FeatEngId


# ─────────────────────────── feature engineering ──────────────────────────── #
class FeatureEngineeringMetadata(BaseModel):
    labelMappings: Optional[List[str]] = None


class FeatureEngineering(BaseModel):
    id: str = Field(..., alias="_id")
    datasetFileId: DatasetFileId
    targetColumnIndex: int
    metadata: FeatureEngineeringMetadata


class FeatureEngineeringOptions(BaseModel):
    ...
    # @TODO: this is temporary, while we don't *really* need correct options


class FeatureEngineeringSpace(BaseModel):
    """Search space for feature engineering. Every preprocessor created for
    this problem will be a different point in this research space
    """

    # → Doesn't really exist yet
    # Note: also it is probably mixed with Loki config (exp. the models)


class FeatureEngineeringProblemDefinition(BaseModel):
    """Defines the space and options for the feature engineering process"""

    # → PreprocessorOptions from Loki
    options: FeatureEngineeringOptions
    space: FeatureEngineeringSpace
    datasetFileId: FileId = None
    targetColumnIndex: int = None


class FeatureEngineeringCreate(FeatureEngineeringProblemDefinition):
    """Feature Engineering Problem Definition adding some top level concepts
    required to instanciate feature engineering"""

    datasetFileId: DatasetFileId
    targetColumnIndex: int = Field(..., ge=0)


class PreprocessorParameters(BaseModel):
    """Specific parameters for a given preprocessor"""


class PreprocessorCreate(BaseModel):
    """Minimum known state of a preprocessor, required to register one as
    potential solution to this problem
    """

    parameters: PreprocessorParameters
    name: str = Field(..., example="RoBERTa-5-feature")
    preprocessorId: str


# ────────────────────────────────── models ────────────────────────────────── #
class Model(BaseModel):
    state: ModelStatus


# Loki info
class TrialDataset(BaseModel):
    datasetId: str
    columnIndex: int
    trialId: str


class ModelCompletion(BaseModel):
    model_eval: ModelEvaluationResult
    loki_data_retrieval: TrialDataset
    ml_task: MlTask
    loki_task_id: Optional[str] = None
    loki_process_id: Optional[str] = None
    send_thanos_flag: bool = True


class Status(str, Enum):
    DEFINED = "defined"
    FAILED = "failed"
    COMPLETED = "completed"
    RUNNING = "running"


class StatusContainer(BaseModel):
    """Response wrapping a resource status"""

    uri: ResourceUri
    status: Status


# ────────────────────────────── Type Detection ────────────────────────────── #
ColumnIndex = TypeVar("ColumnIndex", bound=int)


class ColumnAnalysis(BaseModel):
    """
    Model containing all fields from BaseColumnInfo, ColumnInfo
    and a subset from GenericColumnStatistics - ratios are excluded
    as the count keys are sufficient to trivially calculate the ratios
    """

    detectedType: DetectedType
    confidenceScore: float
    metadata: Optional[Dict[str, Any]]
    defaultTrialOptions: Optional[ColumnDefaultTrialOptions] = None
    statistics: List[ColumnStatistics] = []
    tags: List[ColumnTag] = []
    anomalies: Optional[ColumnAnomalies] = None
    # @TODO: this needs to be renamed to something more descriptive
    isDeleted: bool = False
    statsUniqueValuesCount: int
    statsMissingValuesCount: int
    statsValuesCount: int


class ColumnInfo(BaseModel):
    """
    Singular Column info, used in calls where the index is known from
    another source (URL params etc.). Analysis is optional to allow for
    when TD posts QuickColumn info models which just contain;
    name, base type & index
    """

    name: str
    baseType: BaseTypes
    analysis: Optional[ColumnAnalysis]


class IndexedColumnInfo(ColumnInfo):
    """
    A singular Column info, used in calls where the index needs to be
    in the model, for example when working with lists of Column Indexes.
    The distinction is made in an attempt to avoid duplication of the key
    when Posting a singular column info.
    """

    index: ColumnIndex


class MultiColumnInfoContainer(BaseModel):
    column_infos: List[IndexedColumnInfo]
