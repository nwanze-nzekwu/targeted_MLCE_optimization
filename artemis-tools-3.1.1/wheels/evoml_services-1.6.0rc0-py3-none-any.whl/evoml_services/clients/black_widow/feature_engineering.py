"""HTTP Client handling methods for the subset of Black Widow's endpoints
dealing with Feature Engineering & Preprocessors
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path
from typing import List, Optional

# Dependencies
import pandas as pd

# Module
from .base import BaseBlackWidowClient
from .models import FengId, PreprocessorId, FileId  # Main type aliases
from . import models


# ------------------------------ generic client ------------------------------ #
class FeatureEngineeringClient(BaseBlackWidowClient):
    """This is a client implementation for Black Widow Data API. This client is
    interacting with Black Widow's `Feature Engineering` concept.

    This is mainly to allow contextualisation of endpoints and avoid needing to
    prefix every method with the concept it applies to.
    """

    FENG_PATH = "/v1/feature-engineering"

    # -------------------------------- utils --------------------------------- #
    def _get_single_preprocessor(self, feng_id: FengId) -> PreprocessorId:
        """For Feature Engineering containing a single preprocessor, return that
        preprocessor's id.

        Note: this utils method should not be used directly by the user. The
        preferred usage pattern is to make `preprocessor_id` optional in methods
        and get this entry as a fallback:

        ```python
        def method(self, feng_id, preprocessor_id = None):
            preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)
        ```
        """
        preprocessor_ids = self.get_preprocessor_ids(feng_id)
        if len(preprocessor_ids) == 1:
            return preprocessor_ids[0]
        n = len(preprocessor_ids)
        raise ValueError(f"Feature Engineering {feng_id} has {n} preprocessors (expected 1)")

    def _preprocessor_path(self, feng_id: FengId, preprocessor_id: PreprocessorId) -> str:
        """Builds the base path for all preprocessor interactions:
        `/v1/feature-engineering/{feng_id}/preprocessors/{preprocessor_id}`
        """
        return f"{self.FENG_PATH}/{feng_id}/preprocessors/{preprocessor_id}"

    # ──────────────────────────────────────────────────────────────────────── #
    # Feature Engineering

    # --------------------------------- feng --------------------------------- #
    def get_feng(self, feng_id: FengId) -> models.FeatureEngineering:
        return models.FeatureEngineering.parse_obj(self.get(f"{self.FENG_PATH}/{feng_id}"))

    def define_feng(self, create: models.FengCreate) -> FengId:
        return self.post(f"{self.FENG_PATH}", json=create.dict())["featureEngineeringId"]

    # ----------------------------- start / stop ----------------------------- #
    def start_feng(self, feng_id: FengId):
        self.post(f"{self.FENG_PATH}/{feng_id}/start")

    def close_feng(self, feng_id: FengId):
        self.post(f"{self.FENG_PATH}/{feng_id}/close")

    def get_preprocessor_ids(self, feng_id: FengId) -> List[PreprocessorId]:
        return self.get(f"{self.FENG_PATH}/{feng_id}/preprocessors")["docs"]

    # ──────────────────────────────────────────────────────────────────────── #
    # Preprocessor

    # ----------------------------- preprocessor ----------------------------- #
    def get_preprocessor(
        self, feng_id: FengId, preprocessor_id: Optional[PreprocessorId] = None
    ) -> models.Preprocessor:
        preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)
        return models.Preprocessor.parse_obj(self.get(f"{self.FENG_PATH}/{feng_id}/preprocessors/{preprocessor_id}"))

    def define_preprocessor(self, feng_id: FengId, create: models.PreprocessorCreate) -> PreprocessorId:
        return self.post(f"{self.FENG_PATH}/{feng_id}/preprocessors", json=create.dict())["preprocessorId"]

    def close_preprocessor(self, feng_id: FengId, preprocessor_id: Optional[PreprocessorId] = None):
        preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)
        self.post(self._preprocessor_path(feng_id, preprocessor_id) + "/close")

    # ------------------------------- sources -------------------------------- #
    def post_preprocessor_sources(
        self,
        sources_folder: Path,
        feng_id: FengId,
        lib_version: str,
        lib_extras: List[str],
        preprocessor_id: Optional[PreprocessorId] = None,
    ):
        preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)
        self.post(
            self._preprocessor_path(feng_id, preprocessor_id) + "/sources",
            json={
                "appendixFileId": self.thor_client.upload_folder(sources_folder).id,
                "preprocessorLibrary": {"version": lib_version, "extras": lib_extras},
            },
        )

    # -------------------------------- report -------------------------------- #
    def post_preprocessor_report(
        self,
        report: models.PreprocessorReport,
        feng_id: FengId,
        preprocessor_id: Optional[PreprocessorId] = None,
    ):
        preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)
        self.post(
            self._preprocessor_path(feng_id, preprocessor_id) + "/report",
            json=report.dict(),
        )

    # ──────────────────────────────────────────────────────────────────────── #
    # Preprocessor Actions outputs

    # -------------------------- split transformed --------------------------- #
    def get_split_transformed(
        self,
        feng_id: FengId,
        preprocessor_id: Optional[PreprocessorId] = None,
        file_id: Optional[FileId] = None,
    ) -> models.SplitTransform:
        """Gets the split & transformed version of a dataset. Understand that it
        converts from `original` → (`preprocessed_train`, `preprocessed_test`).

        Returns a named tuple with two dataframes, the second one (test) being
        optional.
        """
        preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)

        path = self._preprocessor_path(feng_id, preprocessor_id)
        endpoint = f"{path}/split-transform" + (f"/{file_id}" if file_id else "")

        split = models.SplitTransformFileIds.parse_obj(self.get(endpoint))
        train_data = self.thor_client.download_dataframe(split.trainFileId)
        if not split.testFileId:
            return models.SplitTransform(train_data, None)

        test_data = self.thor_client.download_dataframe(split.testFileId)
        return models.SplitTransform(train_data, test_data)

    def post_split_transform(
        self,
        train: pd.DataFrame,
        test: Optional[pd.DataFrame],
        feng_id: FengId,
        preprocessor_id: Optional[PreprocessorId] = None,
        file_id: Optional[FileId] = None,
    ):
        """Registers the train & test preprocessed versions of a dataset"""
        # Arguments handling
        preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)
        path = self._preprocessor_path(feng_id, preprocessor_id)
        endpoint = f"{path}/split-transform" + (f"/{file_id}" if file_id else "")

        # Upload dataframes to file id
        train_file_id = self.thor_client.upload_dataframe(train).id
        test_file_id = None
        if test is not None:
            test_file_id = self.thor_client.upload_dataframe(test).id

        self.post(endpoint, json={"trainFileId": train_file_id, "testFileId": test_file_id})

    # ---------------------------- split indices ----------------------------- #
    def get_split_indices(
        self,
        feng_id: FengId,
        preprocessor_id: Optional[PreprocessorId] = None,
        file_id: Optional[FileId] = None,
    ) -> models.SplitFilesIndices:
        preprocessor_id = preprocessor_id or self._get_single_preprocessor(feng_id)

        path = self._preprocessor_path(feng_id, preprocessor_id)
        endpoint = f"{path}/split" + (f"/{file_id}" if file_id else "")

        split = models.SplitFileIds.parse_obj(self.get(endpoint))

        train_index = self.thor_client.download_indices(split.train.indicesFileId)

        test_index, drop_train_index, drop_test_index = None, None, None
        if split.test:
            test_index = self.thor_client.download_indices(split.test.indicesFileId)
        if split.drop_train:
            drop_train_index = self.thor_client.download_indices(split.drop_train.indicesFileId)
        if split.drop_test:
            drop_test_index = self.thor_client.download_indices(split.drop_test.indicesFileId)
        return models.SplitFilesIndices(train_index, test_index, drop_train_index, drop_test_index)
