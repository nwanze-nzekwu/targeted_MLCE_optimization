"""HTTP Client handling methods for the subset of Black Widow's endpoints
dealing with Optimization, Models & Metrics
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path
from typing import Dict, List, Optional
import io

# Dependencies
import pandas as pd
from pydantic.v1 import parse_obj_as

# Module
from evoml_services.clients.thor.models import Pagination
from evoml_services.clients.utils.models import Empty
from .base import BaseBlackWidowClient
from .models import OptId, ModelId, FileId  # Main type aliases
from . import models


class OptimizationClient(BaseBlackWidowClient):
    """This is a client implementation for Black Widow Data API. This client is
    interacting with Black Widow's `Feature Engineering` concept.

    This is mainly to allow contextualisation of endpoints and avoid needing to
    prefix every method with the concept it applies to.
    """

    OPT_PATH = "/v1/optimization"

    # ──────────────────────────────────────────────────────────────────────── #
    # Utils
    def _models_path(self, opt_id: OptId, model_id: ModelId) -> str:
        return f"{self.OPT_PATH}/{opt_id}/models/{model_id}"

    # ──────────────────────────────────────────────────────────────────────── #
    # Optimization

    # -------------------------------- legacy -------------------------------- #
    def map_trial_id(self, trial_id: str) -> models.TrialMapping:
        return models.TrialMapping(self.get(f"/v1/legacy/trials/{trial_id}/optimization")["optimizationId"])

    def get_opt_model_definitions(self, opt_id: OptId) -> List[models.ModelDefinition]:
        return parse_obj_as(
            List[models.ModelDefinition],
            self.get(f"/v1/legacy/optimization/{opt_id}/config/model-definitions"),
        )

    # ----------------------------- optimization ----------------------------- #
    def define_optimization(self, create: models.OptimizationCreate) -> OptId:
        return self.post(f"{self.OPT_PATH}", json=create.dict())["optimizationRunId"]

    def get_optimization(self, opt_id: OptId) -> models.Optimization:
        return models.Optimization.parse_obj(self.get(f"{self.OPT_PATH}/{opt_id}"))

    def get_opt_config(self, opt_id: OptId) -> models.OptimizationConfig:
        return models.OptimizationConfig.parse_obj(self.get(f"{self.OPT_PATH}/{opt_id}/config"))

    def close_optimization(self, opt_id: OptId) -> models.StatusContainer:
        return models.StatusContainer.parse_obj(self.post(f"{self.OPT_PATH}/{opt_id}/close"))

    # ──────────────────────────────────────────────────────────────────────── #
    # Models

    # -------------------------------- model --------------------------------- #
    def define_model(
        self,
        opt_id: OptId,
        model: models.ModelInitialization,
        loki_data: Optional[models.LokiData],
    ) -> ModelId:
        return self.post(
            f"{self.OPT_PATH}/{opt_id}/models",
            json={"model": model.dict(), "loki_data": (loki_data or Empty()).dict()},
        )["modelId"]

    def close_model(
        self,
        opt_id: OptId,
        model_id: ModelId,
        loki_data: Optional[models.LokiData],
        closure_info: models.ClosureInfo = models.ClosureInfo(),
    ) -> models.StatusContainer:
        return models.StatusContainer.parse_obj(
            self.post(
                self._models_path(opt_id, model_id) + "/close",
                json={"closure_info": closure_info.dict(), "loki_data": (loki_data or Empty()).dict()},
            ),
        )

    def get_model(self, opt_id: OptId, model_id: ModelId) -> models.Model:
        return models.Model.parse_obj(self.get(self._models_path(opt_id, model_id)))

    # -------------------------- validation slices --------------------------- #
    def add_validation_slices(self, opt_id: OptId, slices: List[models.ValidationSlice]):
        self.post(
            f"{self.OPT_PATH}/{opt_id}/validation-slices",
            json={
                "validationSlices": [
                    {
                        "index": i + 1,  # 1-indexed
                        "trainIndicesFileId": self.indices_to_file_id(train_idx),
                        "testIndicesFileId": self.indices_to_file_id(test_idx),
                    }
                    for i, (train_idx, test_idx) in enumerate(slices)
                ]
            },
        )

    # -------------------------------- model artifacts -------------------------------- #
    def add_model_artifact(
        self,
        model_artifact_details: models.ModelArtifactDetails = None,
    ):
        """Registers a zip file containing all model artifacts, given as a readable binary object
        (e.g. io.BytesIO)
        """
        model_artifact_details.artifact_binary.seek(0)  # Reset the file index, after writing points to EOF
        self.post(
            self._models_path(model_artifact_details.optimisation_id, model_artifact_details.model_id) + "/estimator",
            json={
                "fileId": self.thor_client.upload_simple_file(
                    ("model_artifact.zip", model_artifact_details.artifact_binary)
                ).id,
                "metamlLibrary": {
                    "version": model_artifact_details.metaml_version,
                    "extras": model_artifact_details.metaml_extras,
                },
            },
        )

    # ---------------------- explainability / metadata ----------------------- #
    def add_model_feature_importance(self, opt_id: OptId, model_id: models.ModelId, feature_importances: dict):
        """Registers feature importance"""
        file = self.thor_client.upload_json(feature_importances)
        self.post(
            self._models_path(opt_id, model_id) + "/feature-importance",
            json={"fileId": file.id},
        )

    # ---------------------------- model outputs ----------------------------- #
    def add_model_predictions(
        self,
        opt_id: OptId,
        model_id: ModelId,
        step: models.EvaluationStep,
        predictions: pd.Series,
        fold: int = 0,
    ):
        """Registers predictions for a given model and evaluation step"""
        prediction_file = self.thor_client.upload_dataframe(
            pd.DataFrame({"Prediction": predictions}, index=predictions.index)
        )
        self.post(
            self._models_path(opt_id, model_id) + f"/{step}/{fold}/predictions",
            json={"fileId": prediction_file.id},
        )

    def add_model_probabilities(
        self,
        opt_id: OptId,
        model_id: ModelId,
        step: models.EvaluationStep,
        probabilities: pd.DataFrame,
        labels: Optional[list] = None,
        fold: int = 0,
    ):
        """Registers probabilities for a given model and evaluation step"""
        assert not labels or len(labels) == probabilities.shape[1]
        n_classes = probabilities.shape[1]
        probabilities.columns = [
            f"PredictionProbability_{labels[i]}" if labels else f"PredictionProbability_{i}" for i in range(n_classes)
        ]
        probas_file = self.thor_client.upload_dataframe(probabilities)
        self.post(
            self._models_path(opt_id, model_id) + f"/{step}/{fold}/probabilities",
            json={"fileId": probas_file.id},
        )

    def add_model_metrics(
        self,
        opt_id: OptId,
        model_id: models.ModelId,
        step: models.EvaluationStep,
        metrics: Dict[str, List[float]],
        loki_data: Optional[models.LokiData],
        fold: int = 0,
    ):
        """Registers metrics for a given model and evaluation step. `metrics` is
        expected to be a map of metric slug to metric value.
        """
        self.post(
            self._models_path(opt_id, model_id) + f"/{step}/{fold}/metrics",
            json={
                "metrics": [{"slug": key, "values": values} for key, values in metrics.items()],
                "loki_data": (loki_data or Empty()).dict(),
            },
        )

    # ──────────────────────────────────────────────────────────────────────── #
    # Metrics
    def get_metrics(self, slugs: List[str]) -> List[models.MetricDefinition]:
        return Pagination[models.MetricDefinition].parse_obj(self.get("/v1/metrics", params={"slug": slugs})).docs
