from typing import Optional, List

import numpy as np


def indices_query(
    indices: Optional[List[int]],
    n_cols: Optional[int] = None,
    inversion_min_size: int = 200,
) -> Optional[np.ndarray]:
    """Shortens the URL for a column selection query in an API that supports ','
    joined lists and negative indices (see `Properties` below) by switching to
    negative indices for exclusion. Important: as the return list can't mix
    signs, the number 0 counts for `-0`.

    Context
    =======
    In a production environment, the size of URL sent to an API can be limited
    (by nginx for instance). On very large datasets, the naive
    implementation (delegate the responsibility to the `requests` library
    and its `params={'select': [...]}` keyword argument) is highly
    inefficient, as it leads to URLs that will look like:

    ```text
        /datasets/{id}/download?select=0&select=1&select=2&select=3
    ```

    Properties
    ==========
    This algorithm uses 2 properties of the target API endpoint:

    - accepts `select=1,2,3` (not default behaviour for FastAPI)
    - accepts two modes of selection for columns:
        • inclusion: sequence of positive integers
        • exclusion: sequence of strictly negative integers
    """
    # Arguments checks
    if not indices:  # None & empty list
        return None

    # Corner case: all indices are provided
    if n_cols and len(set(indices)) == n_cols:
        return None

    min_, max_ = min(indices), max(indices)
    if min_ < 0 < max_:
        raise ValueError("Indexes can be negative or positive, " f"not mixed (min: {min_}, max: {max_})")

    indices = np.array(indices)

    # As explained in the docstring, we have 2 tools to reduce the length of
    # URLs. The first tool (shorter syntax) is very easy to implement. The
    # second however requires additional context and computation, so we only
    # use it for larget enough queries.
    if n_cols is not None and len(indices) >= inversion_min_size:
        # This strategy to shorten the URL is to pick the minimal length
        # between the negative expression and the positive expression. To
        # switch from one to the other, we need to know the total number of
        # columns.
        positive = min_ >= 0

        # Knowing which expression is shorter is somewhat tricky, as the
        # negative numbers use up 1 more character with '-'.
        # So we'll have a heuristic bias of slightly preferring positive
        # indices.

        # Implementation detail: this implementation (using numpy) is faster
        # than other trivial alternatives only for large (>= ~100) number of
        # columns
        if positive and len(indices) >= 0.55 * n_cols:
            indices = -np.delete(np.arange(n_cols), indices)
        elif not positive and len(indices) >= 0.45 * n_cols:
            indices = np.delete(np.arange(n_cols), -indices)

    return indices
