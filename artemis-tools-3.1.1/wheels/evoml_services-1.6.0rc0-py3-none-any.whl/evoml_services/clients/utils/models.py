"""Generic shared models between the different services"""

from typing import TypeVar, Generic, List, Optional
from pydantic.v1.generics import GenericModel
from pydantic.v1 import BaseModel


DataT = TypeVar("DataT")


class Pagination(GenericModel, Generic[DataT]):
    """Generic model presenting a list of any model in a page by page
    format. The `docs`field contains this list of items.
    """

    docs: List[DataT]  # Requested items
    totalDocs: int  # Total number of items matching request
    limit: int  # Maximum number of items per page
    totalPages: int  # Number of pages available
    page: int  # Current page, 1-indexed
    pagingCounter: int  # Number of the first item of current page (1-indexed)
    hasPrevPage: bool
    hasNextPage: bool
    prevPage: Optional[int]  # Number of the previous page
    nextPage: Optional[int]  # Number of the next page
    sideloads: Optional[dict]


class Empty(BaseModel):
    """Literally an empty JSON "{}".

    Useful as a potential default/fallback object when you're in a context where
    your're working with pydantic models instead of dictionaries.
    """

    ...

    class Config:
        extra = "forbid"
