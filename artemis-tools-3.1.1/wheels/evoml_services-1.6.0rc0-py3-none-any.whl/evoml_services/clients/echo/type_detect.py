from evoml_services.clients.echo.base import EchoClientBase
from evoml_services.clients.echo.models import type_detect as models
from evoml_services.clients.echo.models import FileId, Pagination


class TypeDetectClient(EchoClientBase):
    TYPE_PATH_TEMPLATE = "/files/{file_id}/columns"

    def patch_column_infos(self, file_id: FileId, columns: models.MultiColumnInfoContainer):
        """Associate the given column infos with the fileID of this client"""
        path = self.TYPE_PATH_TEMPLATE.format(file_id=file_id)
        return self.patch(path, json=columns.dict())

    def get_column_infos(self, file_id: FileId) -> models.MultiColumnInfoContainer:
        """Retrieve the infos for the fileID of this client"""
        response = self.get(
            self.TYPE_PATH_TEMPLATE.format(file_id=file_id),
            params={"page": 1, "perPage": int(1e10)},
        )
        single_page = Pagination[models.IndexedColumnInfo].parse_obj(response)

        # We're using this to get all the data in memory, so don't care about
        # paginating to save memory, just make sure pagination doesn't get in the way.
        assert single_page.totalPages == 1
        return models.MultiColumnInfoContainer(column_infos=single_page.docs)
