from __future__ import annotations
from typing import List, Optional, Any, Dict

from pydantic.v1 import BaseModel
from evoml_api_models import (
    DetectedType,
    ColumnDefaultTrialOptions,
    ColumnStatistics,
    ColumnTag,
    ColumnAnomalies,
    BaseTypes,
)
from .common import ColumnIndex


# ────────────────────────────── Type Detection ────────────────────────────── #
class ColumnAnalysis(BaseModel):
    """
    Model containing all fields from BaseColumnInfo, ColumnInfo
    and a subset from GenericColumnStatistics - ratios are excluded
    as the count keys are sufficient to trivially calculate the ratios
    """

    detectedType: DetectedType
    confidenceScore: float
    metadata: Optional[Dict[str, Any]]
    defaultTrialOptions: Optional[ColumnDefaultTrialOptions] = None
    statistics: List[ColumnStatistics] = []
    tags: List[ColumnTag] = []
    anomalies: Optional[ColumnAnomalies] = None
    # @TODO: this needs to be renamed to something more descriptive
    isDeleted: bool = False
    statsUniqueValuesCount: int
    statsMissingValuesCount: int
    statsValuesCount: int


class ColumnInfo(BaseModel):
    """
    Singular Column info, used in calls where the index is known from
    another source (URL params etc.). Analysis is optional to allow for
    when TD posts QuickColumn info models which just contain;
    name, base type & index
    """

    name: str
    baseType: BaseTypes
    analysis: Optional[ColumnAnalysis]


class IndexedColumnInfo(ColumnInfo):
    """
    A singular Column info, used in calls where the index needs to be
    in the model, for example when working with lists of Column Indexes.
    The distinction is made in an attempt to avoid duplication of the key
    when Posting a singular column info.
    """

    index: ColumnIndex


class MultiColumnInfoContainer(BaseModel):
    column_infos: List[IndexedColumnInfo]
