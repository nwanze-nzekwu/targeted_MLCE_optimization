from typing import TypeVar

from evoml_services.clients.utils.models import Pagination  # Transitive import


ColumnIndex = TypeVar("ColumnIndex", bound=int)
FileId = TypeVar("FileId", bound=str)


__all__ = ["FileId", "ColumnIndex", "Pagination"]
