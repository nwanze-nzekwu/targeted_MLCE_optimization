from __future__ import annotations

from enum import Enum
from typing import Optional, Dict, Tuple, List

from pydantic.v1 import BaseModel, root_validator
from evoml_services.clients.echo.models import ColumnIndex
from .graph_data import *


# ────────────────────────────────── Graphs ────────────────────────────────── #
class GraphType(str, Enum):
    BARCHART = "bar-chart"
    BOXPLOT = "boxplot"
    KDE = "kde"
    HISTOGRAM = "histogram"
    LINE_HISTOGRAM = "line-histogram"
    VIOLIN_PLOT = "violin-plot"
    LINE_GRAPH = "line-graph"
    MAP_PLOT = "map-plot"
    CALENDAR_PLOT = "calendar-plot"
    SCATTER_PLOT = "scatter-plot"
    HEAT_MAP = "heat-map"
    BOX_VIOLIN_PLOT = "box-violin-plot"
    COLUMN_CHART = "column-chart"
    WORD_CLOUD = "word-cloud"
    HIGH_CHART_GRAPH = "high-chart"


GRAPH_TYPE_MAP: Dict[GraphType, GraphData] = {
    GraphType.HIGH_CHART_GRAPH: HighChartsData,
    GraphType.BARCHART: BarChartData,
    GraphType.BOXPLOT: BoxPlotData,
    GraphType.KDE: KdeData,
    GraphType.HISTOGRAM: HistogramData,
    GraphType.LINE_HISTOGRAM: LineHistogramData,
    GraphType.VIOLIN_PLOT: ViolinPlotData,
    GraphType.LINE_GRAPH: LineGraphData,
    GraphType.MAP_PLOT: MapPlotData,
    GraphType.CALENDAR_PLOT: CalendarPlotData,
    GraphType.SCATTER_PLOT: ScatterPlotData,
    GraphType.HEAT_MAP: HeatMapData,
    GraphType.BOX_VIOLIN_PLOT: BoxViolinData,
    GraphType.COLUMN_CHART: ColumnChartData,
    GraphType.WORD_CLOUD: WordCloudData,
}


class Graph(BaseModel):
    """Base class for all graphs"""

    title: Optional[str]
    x_axis: Optional[List[str]]
    y_axis: Optional[List[str]]
    # TODO: figure out how to use generics for this
    type: GraphType
    data: GraphData

    @root_validator
    def data_matches_graph_type(cls, values: dict):
        graph_type: GraphType = values.get("type")
        graph_data: GraphData = values.get("data")
        expected_model: GraphData = GRAPH_TYPE_MAP[graph_type]
        if graph_type == GraphType.HIGH_CHART_GRAPH:
            return values
        try:
            expected_model.parse_obj(graph_data)
        except Exception:
            raise ValueError(
                f"data contents does not match expected shape for {graph_type}\n"
                f"the correct data model is: {expected_model} with schema: \n"
                f"{expected_model.schema_json()}"
            )
        return values


class SingleColumnGraph(Graph):
    """Base class for all single column graphs"""

    pass


class GraphCollection(BaseModel):
    indexGraphsMap: Dict[ColumnIndex, List[SingleColumnGraph]] = dict()


class ColumnPairGraph(Graph):
    """Base class for all column pair graphs"""

    columns: Tuple[ColumnIndex, ColumnIndex]
