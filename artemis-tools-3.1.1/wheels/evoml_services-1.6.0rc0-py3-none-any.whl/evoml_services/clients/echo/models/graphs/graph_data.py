"""Data models for specific graph Types"""

from datetime import datetime
from enum import Enum
from typing import Tuple, Any, TypeVar, Union, Dict, List, Optional

from pydantic.v1 import BaseModel


# ───── Generic Plotting Concepts ───── #
class Point(BaseModel):
    """
    A point in 2d space - this is probably excessive and we should realistically
    make point an alias for Tuple[float, float] and agree that x=point[0], y=point[1]
    """

    x: float
    y: float


class Line(BaseModel):
    """
    Y=mx+c with: optional limits and R2
    m = coefficient (gradient),
    c = intercept (where line crosses y axis),
    R2 = Coefficient of determination (how closely the line fits the data)
    """

    m: float
    c: float
    r2: Optional[float]
    start: Optional[Point]
    stop: Optional[Point]


class Spline(BaseModel):
    """
    A curve, can assume points are in plotting order.
    Better representation: an actual spline - set of polynomials with ranges
    over x - https://en.wikipedia.org/wiki/Spline_(mathematics)
    """

    points: List[Point]


class Category(BaseModel):
    """
    An optionally labeled float
    """

    label: Optional[str]
    y: float


class Bin(Category):
    """
    A Category with width
    """

    l: float
    r: float


class Quartiles(BaseModel):
    """
    min, 25%, median, 75%, max
    """

    q0: float
    q1: float
    q2: float
    q3: float
    q4: float


# ───── Graph Type Specific Data ───── #
HighChartsData = TypeVar("HighChartsData", bound=Dict)


class CategoryCluster(BaseModel):
    """Group multiple categories under a common label"""

    label: Optional[str]
    columns: List[Category]


class BarChartData(BaseModel):
    """1 or many optional labeled groups of 1 or many optionally labeled 'bars'"""

    categories: List[CategoryCluster]


class ColumnChartData(BaseModel):
    """literally just a bar chart but sideways"""

    categories: List[CategoryCluster]


class BoxPlotData(BaseModel):
    """
    List of 1 or more box plots, each plot is a tuple of [quartiles, outliers]
    where q0 & q4 are the whiskers of the plot, q1 & q3 are left and right edges
    and q3 is the median. Outliers is a list of float where each float is a point
    on the X axis (y axis has no meaning in this plot)
    """

    boxes: List[Tuple[Quartiles, List[float]]]


class KdeData(BaseModel):
    spline: Spline
    anomalies: List[Point]


class HistogramData(BaseModel):
    bins: List[Bin]


class LineHistogramData(BaseModel):
    bins: List[Bin]
    kde: Spline


class ViolinPlotData(BaseModel):
    label: Optional[str]
    spline: Spline
    mean: float
    quartiles: Quartiles
    anomalies: List[Point]


class LineGraphData(BaseModel):
    spline: Spline
    anomalies: List[Point]


class Bubble(BaseModel):
    areaKey: str
    y: float


class MapPlotData(BaseModel):
    """Points have keys (x,y) but in this context x=lat, y=long"""

    mapKey: str
    bubbles: List[Bubble]
    points: Optional[List[Point]]


class CalendarType(str, Enum):
    SINGLE_YEAR = "single_year"
    YEAR_MONTH = "year_month"


class CalendarEntry(BaseModel):
    """
    d = date on the calendar, c = list of category IDs and their frequencies
    """

    d: datetime
    c: List[Tuple[int, int]]


class CalendarPlotData(BaseModel):
    """
    Entries is a list of dates where each date has a list of (catID, freq) pairs.
    catMap is a lookup from catId to category label
    """

    years: List[int]
    calType: CalendarType
    catMap: Dict[int, str]
    entries: List[CalendarEntry]


class ScatterPlotData(BaseModel):
    points: List[Point]
    anomalies: Optional[List[Point]]
    trend: Optional[Line]


class AxisSlice(BaseModel):
    """
    Slice on an axis, b=begin, e=end
    """

    b: float
    e: float


class HeatMapCell(BaseModel):
    """
    Single cell in a heatmap, x= index of a AxisSlice in x_slices,
    y= index of a AxisSlice in y_slices, c= count of rows in that
    cell
    """

    x: int
    y: int
    c: int


class HeatMapData(BaseModel):
    """
    A heatmap made up of cells, where the indexes of x_slices and y_slices
    are referenced by cells to identify where the count is on the grid
    """

    x_slices: List[AxisSlice]
    y_slices: List[AxisSlice]
    cells: List[HeatMapCell]


class BoxViolinData(BaseModel):
    classes: List[ViolinPlotData]


class WordCloudData(BaseModel):
    """List of weighted words, where weight is represented by size on screen"""

    words: List[Category]


GraphData = Union[
    HighChartsData,
    BarChartData,
    BoxPlotData,
    KdeData,
    HistogramData,
    LineHistogramData,
    ViolinPlotData,
    LineGraphData,
    MapPlotData,
    CalendarPlotData,
    ScatterPlotData,
    HeatMapData,
    BoxViolinData,
    ColumnChartData,
    WordCloudData,
]

__all__ = [
    "BarChartData",
    "BoxPlotData",
    "KdeData",
    "HistogramData",
    "LineHistogramData",
    "ViolinPlotData",
    "LineGraphData",
    "MapPlotData",
    "CalendarPlotData",
    "ScatterPlotData",
    "HeatMapData",
    "BoxViolinData",
    "ColumnChartData",
    "WordCloudData",
    "HighChartsData",
    "GraphData",
]
