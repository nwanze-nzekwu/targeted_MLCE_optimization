"""
Client for Echo Api /files/{file_id}/graphs/... endpoints

Usage:
from evoml_services.clients.black_widow.v1 import BlackWidowSettings
from evoml_services.clients.echo.graphs import ColumnGraphsClient
from evoml_services.clients.thor import ThorClient, ThorSettings
thor=ThorClient(ThorSettings(host=..., port=8091))
settings=BlackWidowSettings(host=..., port=8094, postfix="/echo")
client = ColumnGraphsClient(settings, thor)
"""

from typing import List, Tuple

from evoml_services.clients.echo.base import EchoClientBase
from evoml_services.clients.echo.models import graphs as models
from evoml_services.clients.echo.models import FileId


class ColumnGraphsClient(EchoClientBase):
    GRAPH_PATH_TEMPLATE = "/files/{file_id}/graphs"

    # ───── Single Column graphs ───── #
    def post_single_column_graphs(
        self,
        file_id: FileId,
        column_index: int,
        graphs: List[models.SingleColumnGraph],
    ):
        """Post 1 or more graphs about a target column"""
        path = self.GRAPH_PATH_TEMPLATE.format(file_id=file_id) + f"/single/{column_index}"
        self.post(path, json=[g.dict() for g in graphs])

    def get_column_graphs(self, file_id: FileId, column_index: int) -> List[models.SingleColumnGraph]:
        """Get all graphs about a target column"""
        path = self.GRAPH_PATH_TEMPLATE.format(file_id=file_id) + f"/single"
        graph_container: models.GraphCollection = models.GraphCollection.parse_obj(
            self.get(path, params={"columnIndices": [column_index]})
        )
        return graph_container.indexGraphsMap[column_index]

    # ───── Pair graphs ───── #
    def post_column_pair_graphs(self, file_id: FileId, graphs: List[models.ColumnPairGraph]):
        """
        Post 1 or more graphs involving pairs of columns. Column indexes
        are extracted on a per-graph basis so graphs list can contain
        multiple column pairs
        """
        path = self.GRAPH_PATH_TEMPLATE.format(file_id=file_id) + "/pair"
        self.post(path, json=[g.dict() for g in graphs])

    def get_column_pair_graphs(self, file_id: FileId, column_indices: Tuple[int, int]) -> List[models.ColumnPairGraph]:
        """Get all graphs about a target column pair"""
        path = self.GRAPH_PATH_TEMPLATE.format(file_id=file_id) + "/pair"
        graph_dicts: List[dict] = self.get(path, params={"columnIndices": column_indices})
        return [_parse_col_pair_graph_dict(g) for g in graph_dicts]


def _parse_single_col_graph_dict(graph_dict: dict) -> models.SingleColumnGraph:
    graph = models.SingleColumnGraph.parse_obj(graph_dict)
    if graph.type == models.GraphType.HIGH_CHART_GRAPH:
        return graph
    data_model = models.top_level.GRAPH_TYPE_MAP[graph.type]
    graph.data = data_model.parse_obj(graph.data)
    return graph


def _parse_col_pair_graph_dict(graph_dict: dict) -> models.ColumnPairGraph:
    graph = models.ColumnPairGraph.parse_obj(graph_dict)
    if graph.type == models.GraphType.HIGH_CHART_GRAPH:
        return graph
    data_model = models.top_level.GRAPH_TYPE_MAP[graph.type]
    graph.data = data_model.parse_obj(graph.data)
    return graph
