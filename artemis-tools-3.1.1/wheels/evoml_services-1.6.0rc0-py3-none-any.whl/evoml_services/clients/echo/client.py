from evoml_services.clients.echo.base import BlackWidowSettings
from evoml_services.clients.echo.models import FileId
from evoml_services.clients.echo.type_detect import TypeDetectClient
from evoml_services.clients.echo.graphs import ColumnGraphsClient


class EchoSettings(BlackWidowSettings):
    pass


class EchoClient(TypeDetectClient, ColumnGraphsClient):
    pass
