"""
Wrap the blackwidow base
"""

# ───────────────────────────────── imports ────────────────────────────────── #

# Module
from evoml_services.clients.black_widow.base import BaseBlackWidowClient, BlackWidowSettings


# ──────────────────────────────────────────────────────────────────────────── #
class EchoClientBase(BaseBlackWidowClient):
    pass
