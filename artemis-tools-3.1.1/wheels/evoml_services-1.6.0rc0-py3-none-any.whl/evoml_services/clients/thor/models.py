"""Models for Thor API"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import TypeVar, Optional, List
from enum import Enum

# Dependencies
from pydantic.v1 import BaseModel, Field

# Module
from evoml_services.clients.utils.models import Pagination  # Transitive import

from . import field_types


# ──────────────────────────────────────────────────────────────────────────── #
# Redefine types for backward compatibilit:
FileId = field_types.FileId
DatasetFileId = field_types.DatasetFileId
IndicesFileId = field_types.IndicesFileId


class BaseType(str, Enum):
    """BaseType as supported by Thor"""

    FLOAT = "float"
    INTEGER = "int"
    STRING = "string"


class File(BaseModel):
    """Metadata about a file (zip, images, ...) stored in the File API. This
    metadata contains the url where the file can be downloaded. This is not the
    file itself.
    """

    id: FileId = Field(..., alias="_id", example="5e1f0cfe1aa7100029617827")
    originalFilename: str = Field(..., example="filename.csv")
    sizeInBytes: int = Field(..., example=10268120)  # unused?


class DatasetFileColumn(BaseModel):
    """Information about a Dataset File's column"""

    name: str
    originalName: Optional[str]
    index: int
    baseType: BaseType


class DatasetFileAnalysis(BaseModel):
    """Information about a Dataset File's analysis results"""

    indexName: str = Field(..., example="df-index")
    columns: List[DatasetFileColumn]
    totalRows: int  # unused
    totalColumns: int  # unused
    encoding: Optional[str]
    delimiter: Optional[str]


class DatasetFile(File):
    """Metadata about a data file (csv) in the File API. This type of file
    provides more features specific to tabular data files.
    """

    id: DatasetFileId = Field(..., alias="_id", example="5e1f0cfe1aa7100029617827")
    analysis: DatasetFileAnalysis


class CompoundFileType(str, Enum):
    """Types of coumpound files supported by Thor"""

    FILE = "file"
    ARCHIVE = "archive"


class CompoundFile(BaseModel):
    """Archive or file to be combined by Thor lazyly from fileId"""

    id: FileId
    type: CompoundFileType = CompoundFileType.FILE
    path: str
