"""Field and type aliases introduced by the Thor client"""

from typing import Sequence, Optional, Union

FileId = str
"""File Id defined by interactions with Thor on the `/files` cluster of endpoints"""

DatasetFileId = str
"""File Id defined by interactions with Thor on the `/datasets` cluster of
endpoints
"""

IndicesFileId = str
"""Special case of DatasetFileId for datasets representing a single column of
integers, named `Indices`. This column represents the indices of a subset of
rows of another `DatasetFileId`
"""

ArchiveFileId = str
"""File Id defines in the `/files` cluster of endpoints, but containing an
archive type (e.g. `.zip`, `.tar.gz`) which can be extracted
"""

# Implementation Detail
# ---------------------
# Typed as a sequence as we don't mutate the list of required columns in any of
# the functionalities of ThorClient, and this allows List[int] to be a valid
# Sequence[Union[int, str]], which would not be the case if we typed this as
# List[Union[int, str]] as List is invariant.
#
# See https://mypy.readthedocs.io/en/stable/common_issues.html#variance
# See https://github.com/python/mypy/issues/3351#issuecomment-300447832
RequiredColumns = Optional[Sequence[Union[int, str]]]
"""List of columns required when downloading a dataset, expressed either as
indices or names of columns. None means all columns are required.
"""

__all__ = [
    "FileId",
    "DatasetFileId",
    "IndicesFileId",
    "ArchiveFileId",
    "RequiredColumns",
]
