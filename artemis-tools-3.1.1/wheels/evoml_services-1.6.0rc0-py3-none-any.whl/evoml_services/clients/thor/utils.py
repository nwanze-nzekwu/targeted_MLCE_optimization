"""Utilities for the Thor File API client"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator
from uuid import uuid4
from shutil import rmtree


# ──────────────────────────────────────────────────────────────────────────── #
@contextmanager
def temp_dir(root: Path = Path("/tmp")) -> Iterator[Path]:
    """Context manager providing a temporary directory (for the duration of the
    context) under the given root directory (defaults to /tmp).

    Arguments:
        root (Path):
            Root directory in which the temporary directory will be created.

    Returns:
        directory (ContextManager[Path]):
            Returns a path (the temporary directory) valid for the duration of
            the context, then deleted on context exit.
    """
    # Setup
    unique_id = str(uuid4()).replace("-", "")[:16]
    directory = root / f"thor-client-{unique_id}"
    directory.mkdir()

    # Context
    yield directory

    # Teardown
    rmtree(directory)
