"""Implements an HTTP client for Thor File API"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
import io
import json
import logging
import os
import zipfile
from functools import lru_cache
from pathlib import Path
from tempfile import SpooledTemporaryFile
from typing import Any, BinaryIO, Dict, List, Optional, Tuple, TypeVar, Union


# Dependencies
import pandas as pd
from pydantic.v1 import BaseModel
from requests import Response
from turing_task_manager.clients.core import (
    ApiAddress,
    HTTPMethod,
    Json,
    JsonClient,
    PathLike,
    authenticated,
)

# Module
from ..utils.urls import indices_query
from .models import (
    CompoundFile,
    DatasetFile,
    File,
)
from .field_types import *
from .utils import temp_dir

# ──────────────────────────────────────────────────────────────────────────── #
T = TypeVar("T")
OList = Optional[List[T]]


# ──────────────────────────────────────────────────────────────────────────── #
class ThorSettings(ApiAddress):
    """Settings for Thor File API"""


# ──────────────────────────────────────────────────────────────────────────── #
class ThorClient(JsonClient):
    """This is a client implementation for Thor File API"""

    LOGGER = logging.getLogger("thor")
    USE_HTTPS = False
    SUPPORTED_EXTENSIONS = [".csv", ".parquet", ".avro"]
    MAX_MEMORY = 500_000_000  # 500MB, max memory allocation at once
    SELECT_INVERSION_MIN_SIZE = 200
    INDICES_SINGLE_COLUMN = "Indices"

    # Static information
    EMPTY_FILE_HTTP_EXCEPTION = 416

    # ──────────────────────────── authentication ──────────────────────────── #
    def authenticate(self):
        """Not authentication for Thor File API yet"""

    def is_authenticated(self) -> bool:
        return True

    # ──────────────────────────── regular files ───────────────────────────── #
    @authenticated
    def upload_simple_file(self, filepath: Union[Tuple[str, BinaryIO], Path]) -> File:
        """Uploads a simple file (text, zip, ...) to the File API, and creates
        an abstract pointer to that file. Returns the model describing that
        file.

        Args:
            filepath: Path, str or Tuple of (filename, File-like object) to upload
        """
        return File.parse_obj(self.upload_file("/files", filepath))

    @authenticated
    def download_simple_file(
        self, file_id: FileId, filepath: Optional[PathLike], stream: bool = False, max_size_bytes: Optional[int] = None
    ) -> Optional[Response]:
        """Downloads a file by id to the given path. Does not check that the
        path's extension is consistent with the downloaded file's original
        extension or metadata.
        """
        if filepath is None and not stream:
            raise ValueError("File path is required when stream is False")

        if filepath is not None:
            filepath = filepath if isinstance(filepath, Path) else Path(filepath)

        kwargs: Dict[str, Any] = {}
        if max_size_bytes is not None:
            kwargs["params"] = {"skip_if_size_greater_than": max_size_bytes}

        return self.download_file(f"/files/{file_id}/download", filepath, stream=stream, **kwargs)

    @authenticated
    @lru_cache(maxsize=5)
    def get_file(self, file_id: FileId) -> File:
        """Retrieves the model describing a simple file by id"""
        return File.parse_obj(self.get(f"/files/{file_id}"))

    @authenticated
    @lru_cache(maxsize=5)
    def get_archive_list_file(self, file_id: FileId):
        """Retrieves the model describing a simple file by id"""
        return self.get(f"/files/{file_id}/archive-list")

    @authenticated
    def delete_file(self, file_id: FileId):
        """Deletes a file by id (invalidates that id for further requests)"""
        self.delete(f"/files/{file_id}")

    # ───────────────────── json - through regular files ───────────────────── #
    @authenticated
    def upload_json(self, _json: Union[dict, BaseModel]) -> File:
        """Uploads a json or pydantic model to Thor's /files storage"""
        _json = _json.dict() if isinstance(_json, BaseModel) else _json
        string_io = io.StringIO()
        json.dump(_json, string_io)
        return File.parse_obj(self.upload_file("/files", ("data.json", string_io)))

    @authenticated
    def download_json(self, file_id: FileId) -> Json:
        """Downloads a json from Thor's /files storage"""
        return self.get(f"/files/{file_id}/download")

    # ──────────────────────────── folders (zip) ───────────────────────────── #
    @authenticated
    def upload_folder(self, folder: Path) -> File:
        """Compresses a folder (only zip supported for now) then uploads the
        compressed file. Returns the model of that file.

        Arguments:
            folder (Path):
                Path to the folder to compress and upload.

        Returns:
            file_model (File):
                Model of the file once uploaded to the Thor File API.
        """
        # Use a temporary directory context manager to handle the file deletion
        with temp_dir() as directory:
            zip_path = directory / folder.with_suffix(".zip")
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as ziph:
                for root, _, files in os.walk(folder):
                    root_path = Path(root)
                    for file_name in files:
                        if not os.path.islink(root_path / file_name):
                            ziph.write(
                                root_path / file_name,
                                root_path.relative_to(folder) / file_name,
                            )
                        else:
                            self.LOGGER.warning(f"Skipping symlink: {root_path / file_name}")
            file_model = self.upload_simple_file(zip_path)
        return file_model

    @authenticated
    def download_folder(self, folder_id: FileId, target_path: Path, max_file_size_bytes: Optional[int] = None):
        """Downloads a compressed folder (only zip supported for now) by id,
        then uncompresses it to the target path.

        Arguments:
            folder_id (FileId):
                Unique id of a simple file that should be a compressed archive
                (only zip supported for now).
            target_path (Path):
                Path where the archive should be extracted. Created if it
                doesn't exist, undefined behaviour if it already exists.

        Raises:
            ValueError: if the given file id is not a compressed file (zip)
        """
        folder_model = self.get_file(folder_id)
        folder_name = folder_model.originalFilename

        if not folder_model.originalFilename.endswith(".zip"):
            raise ValueError(f"Expected a zip file, found {folder_name}")

        target_path.mkdir(exist_ok=True, parents=True)
        with temp_dir() as directory:
            zip_path = directory / folder_name
            self.download_simple_file(folder_model.id, zip_path, max_size_bytes=max_file_size_bytes)
            with zipfile.ZipFile(zip_path, "r") as ziph:
                ziph.extractall(target_path)

    @authenticated
    def compound_file(self, files: List[Union[CompoundFile, dict]], lazy: bool = True) -> File:
        """Creates a compound file by combining one or more archives and single
        files together to the given paths. Returns a simple file with a zip
        format.
        """
        validated = [CompoundFile.parse_obj(f) if isinstance(f, dict) else f for f in files]
        return File.parse_obj(
            self.post(
                "/files/compound",
                json={"files": [v.dict() for v in validated], "lazy": lazy},
            )
        )

    # ──────────────────────────── dataset files ───────────────────────────── #
    def _select_query(self, indices: Optional[List[int]], n_cols: Optional[int] = None) -> Optional[str]:
        """Shortens the URL for the column selection query in Thor's
        `/datasets/{id}/download` endpoint.

        See `clients.utils.urls.indices_query` for more information.
        """
        converted = indices_query(indices, n_cols, self.SELECT_INVERSION_MIN_SIZE)
        if converted is None:
            return None

        positive = min(converted) >= 0
        return ",".join([str(i) if positive or i != 0 else "-0" for i in converted])

    def _download_parquet(self, path: str, request_params: dict) -> pd.DataFrame:
        """Downloads a pd.DataFrame from an endpoint that returns a
        parquet, using a spooled temporary file to accomodate for
        using the hard drive above a certain size threshold
        """
        # Implementation detail
        # ---------------------
        # We're using a spooled temporary file because 'pd.read_parquet' expects
        # a seekable filetype, which is not directly available with requests'
        # 'stream=True' keyword argument
        with SpooledTemporaryFile(max_size=self.MAX_MEMORY, suffix="parquet") as tempfile:
            response = self.request(path, HTTPMethod.GET, params=request_params)
            for chunk in response:
                tempfile.write(chunk)
            tempfile.seek(0)
            data: pd.DataFrame = pd.read_parquet(tempfile)
        return data

    @authenticated
    def upload_dataframe(self, data: pd.DataFrame) -> DatasetFile:
        """Uploads a pandas dataframe and returns the model describing the
        resulting dataset file created in Thor.

        Arguments:
            data (pd.DataFrame):
                Dataframe to upload to Thor

        Raises:
            ValueError: when a non-default index is not named

        Return (DatasetFile):
            Thor description of the created dataset file.
        """
        if not (isinstance(data.index.name, str) or data.index.name is None):
            raise ValueError("Unexpected index name")

        index_name = data.index.name

        is_range_index = (
            isinstance(data.index, pd.RangeIndex) and data.index.start == 0 and data.index.stop == len(data)
        )
        if index_name is None and not is_range_index:
            raise ValueError("Non default index columns must be named for upload to Thor")

        # If the index has a name, we set the index explicitly and need to
        # communicate its name so Thor can isolate that column
        payload = {"indexName": index_name}

        # We explictly copy the index to a column with the provided name.
        if index_name:
            data[index_name] = data.index

        with SpooledTemporaryFile(max_size=self.MAX_MEMORY, suffix="parquet") as tempfile:
            data.to_parquet(tempfile)
            tempfile.seek(0)
            dataset = self.upload_file("/datasets", ("data.parquet", tempfile), params=payload)

        # # Restore dataframe to its original state
        if index_name:
            data.drop(columns=[index_name], inplace=True)

        return DatasetFile.parse_obj(dataset)

    @authenticated
    def _download_index_column(self, file_id: DatasetFileId) -> pd.Series:
        """Downloads the index column stored by Thor for a given dataset.

        Arguments:
            file_id (DatasetFileId):
                File Id of the dataset to download the index of

        Returns:
            pd.Series:
                Index column stored by Thor for the given dataset.
        """
        index_df = self._download_parquet(f"/datasets/{file_id}/index", {"type": "parquet"})
        if len(index_df.columns) != 1:
            raise ValueError(f"Expected a single column, found {index_df.columns}")
        return index_df.iloc[:, 0]

    @authenticated
    def download_dataframe(
        self,
        file_id: DatasetFileId,
        include_index: bool = True,
        required_columns: RequiredColumns = None,
        row_range: Optional[Tuple[int, int]] = None,
    ) -> pd.DataFrame:
        """Downloads a dataset file from Thor by id directly into a pandas
        DataFrame instance in memory.

        Unlike `download_dataset_file`, it does not reorder columns in the order
        of the indexes given.

        Arguments:
            file_id (DatasetFileId):
                File Id of the dataset to download
            include_index (bool):
                Whether to download and assign as `index` in the return
                DataFrame the index column stored by Thor for this dataset.
            required_columns (RequiredColumns):
                List of column indexes or column names that we want to include
                in the downloaded dataframe.
                Does not allow negative indexes "python style" (e.g. -1 for the
                last column).
                Empty list or None (default) downloads all available columns.
            row_range (Tuple[int,int] | None):
                start and end row indexes for the file slice. Selected rows are
                start -> end -1
                When None, download all rows.

        Raises:
            ValueError:
                if a required index is out of the range of available indexes
                of the dataframe or if some required columns are not found in
                the dataframe

        Return (pd.DataFrame):
            The dataset loaded to memory, including the correct indexing if
            `include_index` was provided.
        """
        request_params = {"type": "parquet"}
        required_columns = required_columns or []

        # As Thor considers negative indices as exclusion of a column, we need
        # to build a set of positive integers
        indices = set()

        dataset = self.get_dataset_file(file_id)
        n_cols = dataset.analysis.totalColumns
        for col_index in (i for i in required_columns if isinstance(i, int)):
            if col_index >= n_cols or col_index < 0:
                raise ValueError(f"Invalid required index: {col_index}")
            indices.add(col_index)

        # Required columns: convert column names to indexes (positive)
        column_names = set(c for c in required_columns if isinstance(c, str))
        if column_names:
            for column in dataset.analysis.columns:
                if column.name in column_names:
                    indices.add(column.index)
                    column_names.remove(column.name)

            if len(column_names) > 0:
                raise ValueError(f"Following columns not found in the dataset: {column_names}")

        select_query = self._select_query(list(indices), n_cols)
        if select_query is not None:
            request_params["select"] = select_query

        # Set the slice of the file to download
        if row_range is not None:
            if row_range[0] > row_range[1]:
                raise ValueError(f"Invalid slice: {row_range} - start must be < end")
            request_params["range"] = f"{row_range[0]},{row_range[1]}"

        data = self._download_parquet(f"/datasets/{file_id}/download", request_params)

        # Implementation Detail
        # ---------------------
        # There is a query param to download the index directly from Thor. This
        # is not optimised, and can incurr slowdowns in the current
        # implementation. We prefer to download the index column separately and
        # set the index ourselves.
        if include_index:
            # Reindex the dataframe using the thor index column
            index_column = self._download_index_column(file_id)
            data.set_index(index_column, inplace=True)

        return data

    @authenticated
    def download_dataframe_subset(self, file_id: DatasetFileId, indices_file_id: IndicesFileId) -> pd.DataFrame:
        """Downloads a subset of a dataset by providing a dataset and an
        associated indices file (indicating the subset to use).

        Note: right now this downloads everything then drops unwanted data.
        """
        dataframe = self.download_dataframe(file_id, include_index=True)
        index = self.download_indices(indices_file_id)
        if dataframe.index.name is not None:
            index.name = dataframe.index.name
        return dataframe.loc[index]

    @authenticated
    def upload_indices(self, index: pd.Index) -> DatasetFile:
        """Uploads a pandas indices as a dataframe that contains a single column
        named `Indices`. Returns a thor dataset file model.

        This is a way to store a "view" of a dataset subset, without creating
        data duplication in Thor. This is not a feature recognised by Thor, but
        a specific
        """
        dataframe = pd.DataFrame({self.INDICES_SINGLE_COLUMN: index})
        dataframe.reset_index(inplace=True, drop=True)
        return self.upload_dataframe(dataframe)

    @authenticated
    def download_indices(self, indices_file_id: IndicesFileId) -> pd.Index:
        """Downloads an `IndicesFileId` as a pandas Index."""
        file_info = self.get_dataset_file(indices_file_id)
        if file_info.analysis.totalColumns != 1:
            raise ValueError("IndicesFileId should have only 1 column")
        dataframe = self.download_dataframe(indices_file_id, include_index=False)
        return pd.Index(dataframe.iloc[:, 0])

    @authenticated
    def upload_dataset_file(self, filepath: PathLike) -> DatasetFile:
        """Uploads a dataset file (tabular data, csv, parquet, ...) and returns
        the model describing that file

        Supports any extension in `ThorClient.SUPPORTED_EXTENSIONS`

        Args:
            filepath: Path, str or Tuple of (filename, File-like object) to upload
        """
        if isinstance(filepath, Path):
            extension = filepath.suffix
        elif isinstance(filepath, tuple):
            extension = Path(filepath[0]).suffix
        else:
            extension = Path(filepath).suffix

        if extension not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(f"{extension} extension not supported for upload")
        return DatasetFile.parse_obj(self.upload_file("/datasets", filepath))

    @authenticated
    def download_dataset_file(
        self,
        file_id: DatasetFileId,
        filepath: Optional[PathLike] = None,
        indexes: Optional[List[int]] = None,
        stream: bool = False,
    ) -> Optional[Response]:
        """Downloads a dataset file by id to the given path. Supports many
        extensions at download time, mainly '.csv', '.avro', '.parquet'. Those
        extensions are not checked by the client (unsupported extensions will
        lead to an HTTP error).

        Supports a list of indexes to download a partial file only.

        Arguments:
            file_id (DatasetFileId):
                Unique id of the dataset file to download to a file or stream.
            filepath (PathLike | None):
                Path where the file should be downloaded when `stream=False`.
            indexes (List[int] | None):
                List of indexes to select from this dataset. Accepts a list of
                strictly negative numbers to exclude, or a list of strictly
                positive numbers to include.

                When the `n_cols` optional argument is provided (i.e. number of
                columns), the client will try to pick the shortest URL between
                using negative and positives.
            stream (bool):
                When this option is on, returns a response to stream the file.
        """

        if filepath is None and not stream:  # !stream ⇒ filepath
            raise ValueError("File path is required when stream is False")

        n_cols = None
        if len(indexes or []) >= self.SELECT_INVERSION_MIN_SIZE:
            n_cols = self.get_dataset_file(file_id).analysis.totalColumns

        params = {"select": self._select_query(indexes, n_cols), "index": False}

        if filepath is not None:  # PathLike ⇒ Path
            filepath = filepath if isinstance(filepath, Path) else Path(filepath)
            params["type"] = filepath.suffix[1:]  # suffix has leading dot: '.csv' → 'csv'

        return self.download_file(f"/datasets/{file_id}/download", filepath, params=params, stream=stream)

    @authenticated
    @lru_cache(maxsize=5)
    def get_dataset_file(self, file_id: DatasetFileId, indexes: Optional[List[int]] = None) -> DatasetFile:
        """Retrieves a dataset file model by id.

        Retrieves the model describing a dataset file, by id. Restricts the
        analysis information to the given subset of indexes.

        Args:
            file_id (DatasetFileId):
                Unique id of a dataset file
            indexes (Optional[List[int]]):
                A subset of column indexes to select from the analysis section
                of the file model. All columns are kept if the value is None.

                This helps keep the length of file_model.analysis.column
                consistent with the length of the dataset when downloading
                a subset of a dataset.
        Returns:
            file_model (DatasetFile):
                The model describing the dataset file
        """
        file_model = DatasetFile.parse_obj(self.get(f"/datasets/{file_id}"))
        columns = file_model.analysis.columns

        def is_selected(index):
            return not indexes or index in indexes

        file_model.analysis.columns = [column for (i, column) in enumerate(columns) if is_selected(i)]
        return file_model

    @authenticated
    def sample_dataset_file(self, file_id: DatasetFileId, options: dict) -> DatasetFile:
        """Samples a dataset file by id and returns the model describing the
        newly created sample file

        Args:
            file_id (DatasetFileId):
                Unique id of the dataset file to sample
            options (dict):
                Options to pass to the sampling endpoint.
                Not typed using pydantic yet as the python code rarely needs to
                use this endpoint.
        Returns:
            file_model (DatasetFile):
                The model describing the newly created sample file
        """
        return DatasetFile.parse_obj(self.post(f"/datasets/{file_id}/sampler/file", json=options))

    @authenticated
    def delete_dataset_file(self, file_id: DatasetFileId):
        """Deletes a dataset file by id (invalidates that id for further
        requests)
        """
        return self.delete(f"/datasets/{file_id}")
