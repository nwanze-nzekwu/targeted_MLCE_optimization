# ───────────────────────────────────────────────────── imports ────────────────────────────────────────────────────── #
import json
import logging
from abc import ABC
from json import JSONDecodeError
from time import sleep
from typing import Optional, Any, Union

from requests import Response
from turing_task_manager.clients import HttpException
from turing_task_manager.clients.core import JsonClient, ApiSettings
from turing_task_manager.clients.core.client import HTTPMethod

from evoml_services.clients.base.client_exceptions import (
    HTTP_CLIENT_MAPPING,
    ServiceUnavailable,
    NoHttpClientMappingError,
    InternalServerError,
)

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                           specifies all modules that shall be loaded and imported into the                           #
#                                current namespace when we use 'from package import *'                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #

__all__ = ["BaseClient"]


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                     Client class                                                     #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class BaseClient(JsonClient, ABC):
    """Base class for all API clients that makes them serializable"""

    def __init__(self, settings: ApiSettings, use_https: bool = False, retries: int = 0):
        super().__init__(settings)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(settings.log_level.value)
        self.use_https = use_https
        self.retries = retries

    def __reduce__(self):
        """Make the client serializable"""
        deserializer = self.__class__
        serialized_data = (
            self.settings,
            self.use_https,
            self.retries,
        )
        return deserializer, serialized_data

    # ---------------------------------------- Authentication ---------------------------------------- #

    def authenticate(self):
        """Authenticate to Thanos Backend API and caches the access_token"""

    def is_authenticated(self) -> bool:
        return not self.use_https

    # ------------------------------------------- Request -------------------------------------------- #

    def request(self, path: str, method: HTTPMethod, **kwargs) -> Any:
        """Wrapper sending a request through the _request method, returns a json

        Args:
            path (str): Endpoint path
            method (str): Request operation
            kwargs (**Dict): Additional arguments to pass to the request
                retries (int): Number of retries to perform when the request fails with a 500 error.

        Returns:
            body (Any): The response body
        """

        # Log the path & body of the request
        self.logger.debug(
            "Calling: [%s] %s\nJSON: %s\nQuery Params: %s",
            method,
            self.settings.get_adress(),
            json.dumps(kwargs.get("json", {}), indent=2),
            json.dumps(kwargs.get("params", {}), indent=2),
        )

        retries = kwargs.get("retries", self.retries) + 1
        while retries > 0:
            retries -= 1
            try:
                try:
                    response = super().request(path, method, **kwargs)
                except HttpException as exc:
                    response = exc.response
                return self.check_response(response=response)

            except InternalServerError as exc:
                if retries <= 0:
                    raise exc
                self.logger.info(f"Request to {path} retrying due to 500 series response")
                sleep(0.1)

    def get(self, path: str, **kwargs) -> Any:
        """Wrapper sending a get through the _request method, returns a json"""
        return self.request(path, method=HTTPMethod.GET, **kwargs)

    def post(self, path: str, **kwargs) -> Any:
        """Wrapper sending a get through the _request method, returns a json"""
        return self.request(path, method=HTTPMethod.POST, **kwargs)

    def put(self, path: str, **kwargs) -> Any:
        """Wrapper sending a put through the _request method, returns a json"""
        return self.request(path, method=HTTPMethod.PUT, **kwargs)

    def patch(self, path: str, **kwargs) -> Any:
        """Wrapper sending a patch through the _request method, returns a json"""
        return self.request(path, method=HTTPMethod.PATCH, **kwargs)

    def delete(self, path: str, **kwargs) -> Any:
        """Wrapper sending a put through the _request method, returns a json"""
        return self.request(path, method=HTTPMethod.DELETE, **kwargs)

    # ------------------------------------------- Response ------------------------------------------- #

    def _raise_client_error(self, status_code: int, message: Union[dict, list, str]):
        message = message if isinstance(message, str) else json.dumps(message)
        _error = HTTP_CLIENT_MAPPING.get(status_code, None)
        error = _error(message=message) if _error else NoHttpClientMappingError(message=message, status=status_code)
        self.logger.error(f"{error.__class__.__name__}: error_code={status_code}, error={message}")
        raise error

    def check_response(self, response: Response, error_field: Optional[str] = None) -> Any:
        """Check that the answer is as expected

        Args:
            response: Service invocation response
            error_field: Response field where the message error is stored.

        Returns:
            body (Any): The content of the response
        """
        if response is None:
            raise ServiceUnavailable(message="Response not received from the API")

        status_code = response.status_code

        body_json: Union[list, dict, None]
        try:
            body_json = response.json()
        except JSONDecodeError:
            body_json = None

        body = body_json if body_json is not None else response.text

        self.logger.debug(f"Response: status_code={status_code}, body={body}")

        if status_code > 299:
            if isinstance(body, dict):
                # If it's an error response, it raises the error message
                error_message: Union[dict, str] = body.get(error_field or "detail", body)
                body = error_message
            self._raise_client_error(status_code=status_code, message=body)

        return body
