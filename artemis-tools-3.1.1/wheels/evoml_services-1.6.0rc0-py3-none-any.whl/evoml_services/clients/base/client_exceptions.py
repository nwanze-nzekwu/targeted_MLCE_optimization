"""
This is a provisional solution until the error management library is ready
"""

# ───────────────────────────────────────────────────── imports ────────────────────────────────────────────────────── #
from typing import Optional

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                           specifies all modules that shall be loaded and imported into the                           #
#                                current namespace when we use 'from package import *'                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #

__all_ = [
    "ClientException",
    "NoHttpClientMappingError",
    "BadParametersError",
    "ConflictError",
    "NotFoundError",
    "OAuthError",
    "EntityError",
    "ServiceUnavailable",
]


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                API Client Exceptions                                                 #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class ClientException(Exception):
    message = "Client API Internal Error"

    def __init__(self, message: Optional[str] = None, details: Optional[str] = None):
        """
        Args:
            message (str): Error message. This will replace the defined class message.
            details (str): Details about the error.
        """
        self.message = self._compose_message(message=message, details=details)
        super().__init__(self.message)

    def __str__(self):
        return self.message

    def _compose_message(self, message: Optional[str] = None, details: Optional[str] = None) -> str:
        """Composition of the error message

        Args:
            message (str): Error message. This will replace the defined class message.
            details (str): Details about the error.

        Returns:
            message (str): A message  error with the following format:
                self.message: message - details
        """
        return " - ".join([msg for msg in [message or self.message, details] if msg])


class NoHttpClientMappingError(ClientException):
    message = "No HTTP Client Mapping"

    def __init__(self, status: int, message: Optional[str] = None):
        super().__init__(message=f"[{status}] {message or self.message}")


# ───────────────────────────────────────── INTERNAL SERVER ERROR Exceptions ───────────────────────────────────────── #


class InternalServerError(ClientException):
    message = "Internal Server Error"


# ────────────────────────────────────────────── BAD REQUEST Exceptions ────────────────────────────────────────────── #


class BadParametersError(ClientException):
    message = "Bad input data"


# ─────────────────────────────────────────────── CONFLICT Exceptions ──────────────────────────────────────────────── #


class ConflictError(ClientException):
    message = "The resource already exists"


# ─────────────────────────────────────────────── NOT_FOUND Exceptions ─────────────────────────────────────────────── #


class NotFoundError(ClientException):
    message = "Resource not found"


# ───────────────────────────────────────────── UNAUTHORIZED Exceptions ────────────────────────────────────────────── #


class OAuthError(ClientException):
    message = "Authentication Error"


# ───────────────────────────────────────── UNPROCESSABLE ENTITY Exceptions ────────────────────────────────────────── #


class EntityError(ClientException):
    message = "Unprocessable Entity"


# ────────────────────────────────────────── SERVICE UNAVAILABLE Exceptions ────────────────────────────────────────── #


class ServiceUnavailable(ClientException):
    message = "Service Unavailable"


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


HTTP_CLIENT_MAPPING = {
    400: BadParametersError,
    401: OAuthError,
    404: NotFoundError,
    409: ConflictError,
    422: EntityError,
    500: InternalServerError,
    501: NotImplementedError,
    503: ServiceUnavailable,
}
