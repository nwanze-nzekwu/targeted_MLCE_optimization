from enum import Enum


class RepoType(str, Enum):
    MODELS = "models"
