import os
import shutil
import glob
from pathlib import Path
from turing_task_manager.clients import JsonClient
from turing_task_manager.clients.core.config import ApiAddress
from typing import List, Optional

from turing_task_manager.clients import (
    authenticated,
    RetryConfiguration,
)
from evoml_services.clients.thor import ThorClient, ThorSettings
from evoml_services.clients.thanos.models import JWTToken, LoginForm
from evoml_api_models import MlTask

from .models import RepoType
from evoml_services.clients.thanos import ThanosClient, ThanosSettings

HugsModelId = str


class HugsSettings(ApiAddress):
    """Hugs settings, including user and token authentication"""

    ...


class HugsClient(JsonClient):
    token: Optional[JWTToken]
    AUTH_RETRY = RetryConfiguration(tries=2, delay=1.0)
    settings: HugsSettings

    def __init__(
        self, settings: HugsSettings = None, thor_settings: ThorSettings = None, thanos_settings: ThanosSettings = None
    ):
        settings = settings or HugsSettings.with_env_prefix("black_widow")
        super().__init__(settings)
        self.thor_client = ThorClient(thor_settings or ThorSettings.with_env_prefix("thor"))
        self.thanos_client = ThanosClient(thanos_settings or ThanosSettings.with_env_prefix("thanos"))
        self.token = None

    # ──────────────────────────────── utils ──────────────────────────────── #
    # def check_zip_content(self, file_id: str, model_name: HugsModelId) -> str:
    def check_zip_content(self, file_id: str, namespace: str, name: str) -> str:
        arch_list = self.thor_client.get_archive_list_file(file_id)
        if len(arch_list["files"]) > 0:
            first_file = arch_list["files"][0]
            # if the zip contains a folder with the necessary files we extract the folder inside the namespace folder
            if first_file.endswith("/") and first_file.count("/") == 1:
                # Return namespace if exists
                return namespace if namespace else ""
            # if the zip contains all the necessary files in the root folder
        return f"{namespace}/{name}" if namespace else name

    # ──────────────────────────── authentication ──────────────────────────── #
    def authenticate(self):
        """Authenticate to Thanos Backend API and caches the access_token"""
        self.token = JWTToken.parse_obj(
            self.thanos_client.post(
                "/auth/login",
                json=LoginForm.parse_obj(self.thanos_client.settings),
            )
        )
        self.session.headers.update({"Authorization": f"Bearer {self.token.access_token}"})

    def is_authenticated(self) -> bool:
        return self.token is not None

    # ──────────────────────────── HUGS Function ──────────────────────────── #
    @authenticated
    def create_model(
        self,
        model_name: str,
        file_id: str,
        namespace: Optional[str] = None,
        pipeline_tag: Optional[str] = None,
        tags: List[str] = None,
        repo_type: RepoType = RepoType.MODELS,
        ml_task: MlTask = MlTask.forecasting,
        private: bool = False,
    ):
        tags = tags or []
        return self.post(
            "/hugs/repos/models",
            json={
                "namespace": namespace,
                "modelName": model_name,
                "pipelineTag": pipeline_tag,
                "tags": tags,
                "repoType": repo_type,
                "mlTask": ml_task,
                "fileId": file_id,
                "private": private,
            },
        )

    @authenticated
    def upload_model(
        self,
        path: Path,
        model_name: str,
        namespace: Optional[str] = None,
        pipeline_tag: Optional[str] = None,
        tags: List[str] = None,
        repo_type: RepoType = RepoType.MODELS,
        ml_task: MlTask = MlTask.forecasting,
    ):
        """Uploads a model to Hugs. It is uploaded to Thor and then the model is
        created in Hugs.
        """
        tags = tags or []
        file_id = self.thor_client.upload_simple_file(path)
        return self.create_model(
            namespace=namespace,
            model_name=model_name,
            file_id=file_id.id,
            pipeline_tag=pipeline_tag,
            tags=tags,
            repo_type=repo_type,
            ml_task=ml_task,
        )

    def get_model_info_by_name(self, model_name: HugsModelId) -> dict:
        return self.post(f"/hugs/repos/models/{model_name}")

    def get_model_info_by_id(self, model_id: int) -> dict:
        return self.get(f"/hugs/repos/models/{model_id}")

    def delete_model(self, model_name: HugsModelId) -> dict:
        model_id = self.get_model_info_by_name(model_name)["id"]
        return self.delete(f"/hugs/repos/models/{model_id}")

    def list_models(self) -> dict:
        return self.get(f"/hugs/repos/models")

    def download_model(self, model_name: HugsModelId, path: Optional[Path] = Path.cwd()) -> Path:
        """...if path is None, then the model is downloaded to the current
        directory under a new folder named '{model_name}'
        """
        info = self.get_model_info_by_name(model_name)
        file_id = info["fileId"]
        final_path = path / info["namespace"] / info["name"] if info["namespace"] else path / info["name"]
        if os.path.exists(final_path):
            shutil.rmtree(final_path)
        path = path / self.check_zip_content(file_id=file_id, namespace=info["namespace"], name=info["name"])
        path.mkdir(parents=True, exist_ok=True)
        self.thor_client.download_folder(folder_id=file_id, target_path=path)

        if path != final_path:
            list_of_files = glob.glob(str(path / "*"))
            latest_file = max(list_of_files, key=os.path.getctime)
            path = Path(latest_file)

        while True:
            if len(os.listdir(path)) == 1 and os.path.isdir(path / os.listdir(path)[0]):
                path = path / os.listdir(path)[0]
            else:
                break
        os.rename(path, final_path)
        return final_path
