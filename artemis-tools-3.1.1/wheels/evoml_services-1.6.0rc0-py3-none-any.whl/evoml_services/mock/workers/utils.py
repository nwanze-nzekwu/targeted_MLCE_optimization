"""Utils function for testing workers using this services library"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import Any, Dict, Optional, Tuple, Type, TypeVar, Union
from pathlib import Path
import json

# Dependencies
from pydantic.v1 import BaseModel
from pydantic.v1.fields import ModelField

try:
    from pydantic.v1.main import ModelMetaclass
except:
    from pydantic.main import ModelMetaclass

# ────────────────────────────────── utils ─────────────────────────────────── #
SPACE, BRANCH, TEE, LAST = "    ", "│   ", "├── ", "└── "


def tree(dir_path: Path, prefix: str = ""):
    """A recursive generator, given a directory Path object will yield a visual
    tree structure line by line with each line prefixed by the same characters
    """
    if prefix == "":
        yield dir_path.name + "/"
    contents = sorted(list(dir_path.iterdir()))
    # contents each get pointers that are ├── with a final └── :
    pointers = [TEE] * (len(contents) - 1) + [LAST]
    for pointer, path in zip(pointers, contents):
        yield prefix + pointer + path.name + ("/" if path.is_dir() else "")
        if path.is_dir():  # extend the prefix and recurse:
            extension = BRANCH if (pointer == TEE) else SPACE
            # i.e. SPACE because LAST, └── , above so no more |
            yield from tree(path, prefix=prefix + extension)


def print_tree(dir_path: Path):
    """Small wrapper around tree to print the directory directly"""
    print()
    for path in tree(dir_path):
        print(path)


def print_json(json_path: Path):
    """Prints a json file's content"""
    bold, reset = "\x1b[1m", "\x1b[0m"
    print()
    print(f"{bold}{json_path.name}{reset}")
    print(json.dumps(json.loads(json_path.read_text()), indent=2))


# ─────────────────────── strict loading test function ─────────────────────── #
class RequiredFields(ModelMetaclass):
    """Metaclass setting all fields of a pydantic model to required"""

    def __new__(self, name: str, bases: Tuple[Type[BaseModel]], namespace: Dict[str, Any], **kwargs):
        """On class building, gather all fields accross the current class and
        its parents, and set them to required
        """
        # The __fields__ field in pydantic models is a {field_name → ModelField}
        # map. Every 'ModelField' instance has a `required` attribute

        # Gather all fields accross current class & parent classes
        fields: Dict[str, ModelField] = namespace.get("__fields__", {})
        for base in bases:
            fields.update(base.__fields__)

        # Update every field to be required
        from copy import copy

        for key, field in fields.items():
            fields[key] = copy(field)
            fields[key].required = True

        namespace["__fields__"] = fields

        # Delegate the actual building to pydantic's ModelMetaclass
        return super().__new__(self, name, bases, namespace, **kwargs)


ModelT = TypeVar("ModelT", bound=BaseModel)


def strict_loading(model_class: Type[ModelT], path_or_obj: Union[Path, dict]) -> ModelT:
    """Loads a 'strict' version of a pydantic model from a path or object.

    The strict version of this pydantic model will have every field as required,
    and will refuse every unexpected fields.

    Making fields required allows for testing extensively against any typo for
    fields in the config built by the workers layer, even if the given field is
    optional.
    Forbidding extra fields allows us to test for input files containing exactly
    what we need, and nothing more (to avoid confusion).

    Args:
        model_class(Type[ModelT]):
            The pydantic model class that should be loaded in 'strict mode'.
        path_or_obj(Union[Path, dict]):
            The path or dict/obj that should be used to load the model.
    Returns:
        ModelT:
            The model loaded after strict verifications.
    """

    # On the fly 'strict' class built using pydantic's config and metaclasses
    class StrictModel(model_class, metaclass=RequiredFields):
        """Class that rejects:
        - missing fields (see the metaclass 'RequiredFields')
        - extra fields (see pydantic's Config.extra)
        """

        class Config(model_class.Config):
            """Reject any unexpected field on loading"""

            extra = "forbid"

    # Load a model using the local strict class
    if isinstance(path_or_obj, Path):
        model = StrictModel.parse_file(path_or_obj)
    else:
        model = StrictModel.parse_obj(path_or_obj)

    # Convert it back to an instance of the initial class
    return model_class.parse_obj(model)
