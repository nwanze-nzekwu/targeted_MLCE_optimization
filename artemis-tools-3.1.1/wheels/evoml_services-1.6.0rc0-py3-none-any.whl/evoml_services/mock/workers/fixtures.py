"""Fixtures for testing workers using this services library"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library

# Dependencies
import pytest
from pytest_mock import MockFixture

# Module
from evoml_services.mock.thanos.fixtures import (  # pylint: disable=W0611
    thanos_api,
    thanos_settings,
    thanos_client,
    ThanosClient,
)
from evoml_services.mock.thor.fixtures import (  # pylint: disable=W0611
    thor_api,
    thor_settings,
    thor_client,
    ThorClient,
)
from evoml_services.workers.clients import ApiClients

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = ["mock_clients"]


# ──────────────────────────────────────────────────────────────────────────── #
@pytest.fixture
def mock_clients(
    thanos_client: ThanosClient,
    thor_client: ThorClient,
    mocker: MockFixture,
) -> None:
    """Mocks the API clients for every worker created within this fixture's
    context
    """
    mocker.patch.object(ApiClients, "thor_settings", thor_client.settings)
    mocker.patch.object(ApiClients, "thanos_settings", thanos_client.settings)
    yield
