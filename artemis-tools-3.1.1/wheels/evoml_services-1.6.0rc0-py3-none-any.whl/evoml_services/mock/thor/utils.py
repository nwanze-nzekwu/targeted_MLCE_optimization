"""Utils for the Mock Thor API"""

from typing import IO, Optional, Iterator
from pathlib import Path
from contextlib import contextmanager
from uuid import uuid4

from fastapi import HTTPException
import pandas as pd


# -------------------------------------------------- general utils --------------------------------------------------- #
@contextmanager
def temp_dir(base_dir: Path) -> Iterator[Path]:
    """Context manager providing a temporary directory and deleting it on exit"""
    directory = base_dir / str(uuid4()).replace("-", "")[:16]
    directory.mkdir(parents=True)

    yield directory


# -------------------------------------------------- loading utils --------------------------------------------------- #
def load_dataframe_from_stream(io: IO, extension: Optional[str] = None) -> pd.DataFrame:
    """Loads a DataFrame from a file. You can optionally provide an extension if
    the file does not have one.
    """
    if extension == ".csv":
        data = pd.read_csv(io)  # type: ignore
        if not isinstance(data, pd.DataFrame):
            raise TypeError("pd.read_csv(...) did not return a pd.DataFrame")
        return data
    if extension == ".parquet":
        return pd.read_parquet(io)  # type: ignore
    raise HTTPException(501, f"`{extension}` extension not supported for stream loading")


def load_dataframe(path: Path, extension: Optional[str] = None) -> pd.DataFrame:
    """Loads a DataFrame from a file. You can optionally provide an extension if
    the file does not have one.
    """
    extension = extension or path.suffix
    if extension == ".csv":
        data = pd.read_csv(path)
        if not isinstance(data, pd.DataFrame):
            raise TypeError(f"pd.read_csv({path}) did not return a pd.DataFrame")
        return data
    if extension == ".parquet":
        return pd.read_parquet(path)
    raise HTTPException(501, f"`{extension}` extension not supported for loading")


def save_dataframe(dataframe: pd.DataFrame, path: Path):
    """Save a DataFrame to a file"""
    if path.suffix == ".csv":
        dataframe.to_csv(path, index=False)
    elif path.suffix == ".parquet":
        dataframe.to_parquet(path, index=None)
    else:
        raise HTTPException(501, f"`{path.suffix}` extension not supported for saving")


def save_dataframe_to_stream(dataframe: pd.DataFrame, io: IO, extension: str):
    """Save a DataFrame to a file"""
    if extension == ".csv":
        dataframe.to_csv(io, index=False)
    elif extension == ".parquet":
        dataframe.to_parquet(io, index=None)
    else:
        raise HTTPException(501, f"`{extension}` extension not supported for saving")
