"""This module is a mock version of Thor File API
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from dataclasses import dataclass
import logging
import shutil
import zipfile
from contextlib import contextmanager
from pathlib import Path
from typing import ContextManager, List, Optional
from uuid import uuid4

import pandas as pd
import numpy as np
import tinydb

# Dependencies
from fastapi import Body, FastAPI, File, HTTPException, Query, UploadFile
from starlette.responses import FileResponse
from starlette.datastructures import Headers
from starlette.status import (
    HTTP_200_OK,
    HTTP_201_CREATED,
)

from . import models as rest

# Module
from . import service, utils
from .database import FileDatabase

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger("uvicorn")

app = FastAPI()

BASE_DIR = Path()
TMP_DIR = BASE_DIR / str(uuid4()).replace("-", "")[:16]


# ───────────────────────────── database objects ───────────────────────────── #


DATABASES: service.ThorDatabases


@app.on_event("startup")
def startup():
    """Setup the mock database"""
    global DATABASES  # pylint: disable=W0603
    logger.info("Working directory: %s", BASE_DIR.absolute())
    TMP_DIR.mkdir(exist_ok=True, parents=True)
    DATABASES = service.ThorDatabases(TMP_DIR)
    logger.info("File database: %s", DATABASES.file_db_path.absolute())
    logger.info("Json database: %s", DATABASES.json_db_path.absolute())


@app.on_event("shutdown")
def shutdown():
    """Tear down the mock database and delete temp files"""
    global DATABASES
    DATABASES.json_database.close()
    DATABASES.json_db_path.unlink()
    shutil.rmtree(DATABASES.directory)
    del DATABASES


# ────────────────────────── simple files (/files) ─────────────────────────── #
FILES_TAG = "Files"


@app.post(
    "/files",
    tags=[FILES_TAG],
    status_code=HTTP_201_CREATED,
    response_model=rest.FileInfo,
)
def upload_file(file: UploadFile = File(...)) -> rest.FileInfo:
    assert file.filename is not None
    file_id = DATABASES.file_database.save(file.file)

    file_info = rest.FileInfo(
        _id=file_id,
        sizeInBytes=DATABASES.file_database.get(file_id).stat().st_size,
        originalFilename=file.filename,
    )

    matches = DATABASES.json_database.table("files").search(service.file_id_query(file_id))
    if not matches:
        DATABASES.json_database.table("files").insert(file_info.dict())

    logger.info(f"→ /files: created {file_info.id}")
    return file_info


@app.post(
    "/files/compound",
    tags=[FILES_TAG],
    status_code=HTTP_200_OK,
)
def compound_file(files: List[rest.CompoundFile] = Body(...), lazy: bool = Body(True)):
    # Note: we ignore the lazy argument
    with utils.temp_dir(TMP_DIR) as tmp_directory:
        directory: Path = tmp_directory / "compound_archive"
        for cfile in files:
            # --------------------------- archives --------------------------- #
            if cfile.type == rest.CompoundFileType.ARCHIVE:
                archive = get_file_info(cfile.id)
                if not archive.originalFilename.endswith(".zip"):
                    raise HTTPException(
                        500,
                        "This endpoint only supports ZIP archives (conflict: {archive.originalFilename})",
                    )

                target_dir = directory / cfile.path.relative_to("/")
                target_dir.mkdir(exist_ok=True, parents=True)

                with zipfile.ZipFile(DATABASES.file_database.get(cfile.id), "r") as zipr:
                    zipr.extractall(target_dir)

            # ------------------------ regular files ------------------------- #
            elif cfile.type == rest.CompoundFileType.FILE:
                target_path = directory / cfile.path.relative_to("/")
                target_path.parent.mkdir(exist_ok=True, parents=True)

                shutil.copy(DATABASES.file_database.get(cfile.id), target_path)

        archive_compound: Path = tmp_directory / "archive_compound.zip"
        shutil.make_archive(str(archive_compound.parent / archive_compound.stem), "zip", directory)

        with archive_compound.open("rb") as fobj:
            return upload_file(
                UploadFile(fobj, filename=archive_compound.name, headers=Headers({"content_type": "application/zip"}))
            )


@app.get(
    "/files/{file_id}",
    tags=[FILES_TAG],
    status_code=HTTP_200_OK,
    response_model=rest.FileInfo,
)
def get_file_info(file_id: rest.FileId, select: List[str] = Query(None)) -> rest.FileInfo:
    matches = DATABASES.json_database.table("files").search(service.file_id_query(file_id))
    if len(matches) == 0:
        raise HTTPException(404, f"Metadata of file {file_id} not found")
    return rest.FileInfo.parse_obj(matches[0])


@app.get(
    "/files/{file_id}/download",
    tags=[FILES_TAG],
    status_code=HTTP_200_OK,
    response_class=FileResponse,
)
def download_file(file_id: rest.FileId) -> FileResponse:
    file_info = get_file_info(file_id)
    return FileResponse(
        DATABASES.file_database.get(file_id),
        filename=file_info.originalFilename,
    )


@app.delete(
    "/files/{file_id}",
    tags=[FILES_TAG],
    status_code=HTTP_200_OK,
)
def delete_file(file_id: rest.FileId):
    DATABASES.json_database.table("files").remove(service.file_id_query(file_id))
    DATABASES.file_database.delete(file_id)


# ──────────────────────── dataset files (/datasets) ───────────────────────── #
DATASETS_TAG = "Datasets"

MAX_MEMORY = 500_000_000  # 500MB


# ---------------------------------- utils ----------------------------------- #
def _find_index_name(data: pd.DataFrame) -> Optional[str]:
    candidates = ["df-index"] + [f"df-index-{i}" for i in range(5)]
    for candidate in candidates:
        if candidate not in data.columns:
            return candidate
    return None


# -------------------------------- endpoints --------------------------------- #
@app.post(
    "/datasets",
    tags=[DATASETS_TAG],
    status_code=HTTP_201_CREATED,
    response_model=rest.DatasetFileInfo,
)
def create_dataset(
    file: UploadFile = File(...), index_name: Optional[str] = Query(None, alias="indexName")
) -> rest.DatasetFileInfo:
    assert file.filename is not None
    filename = Path(file.filename)
    data = utils.load_dataframe_from_stream(file.file, filename.suffix)

    # Explicit index column -> set as a new separate column
    if data.index.name is not None:
        data[data.index.name] = data.index
        data.reset_index(drop=True, inplace=True)

    # If the index column is missing, inject it
    has_index = index_name is not None
    index_name = index_name or _find_index_name(data)

    if not has_index:
        data[index_name] = np.arange(len(data))

    if index_name is None:
        raise HTTPException(500, "Could not find a name for the index column")

    if index_name not in data.columns:
        raise HTTPException(400, f"Index column {index_name} not found in dataset")

    dataset_info = service.save_dataset(DATABASES, data, filename, index_name)
    return dataset_info


@app.get(
    "/datasets/{file_id}",
    tags=[DATASETS_TAG],
    status_code=HTTP_201_CREATED,
    response_model=rest.DatasetFileInfo,
)
def get_dataset_info(file_id: rest.DatasetFileId, select: List[str] = Query(None)) -> rest.DatasetFileInfo:
    return service.get_dataset_info(DATABASES, file_id)


@app.get(
    "/datasets/{file_id}/index",
    tags=[DATASETS_TAG],
    status_code=HTTP_200_OK,
    response_class=FileResponse,
)
def download_file_index(file_id: rest.DatasetFileId, filetype: str = Query(None, alias="type")) -> FileResponse:
    """Downloads the index of a dataset, separately"""
    data = service.load_dataset(DATABASES, file_id)
    dataset_info = service.get_dataset_info(DATABASES, file_id)

    index = pd.DataFrame({dataset_info.analysis.indexName: data[dataset_info.analysis.indexName]})

    # Serve the file
    with utils.temp_dir(TMP_DIR) as directory:
        target_path = (directory / dataset_info.originalFilename).with_suffix(f".{filetype}")
        utils.save_dataframe(index, target_path)
        return FileResponse(target_path, filename=target_path.name)


@app.get(
    "/datasets/{file_id}/download",
    tags=[DATASETS_TAG],
    status_code=HTTP_200_OK,
    response_class=FileResponse,
)
def download_dataset(
    file_id: rest.DatasetFileId,
    select: str = Query(None),
    filetype: str = Query(None, alias="type"),
    index: bool = Query(False),
) -> FileResponse:
    dataset_info = service.get_dataset_info(DATABASES, file_id)
    filename = dataset_info.originalFilename
    extension = Path(filename).suffix
    filetype = filetype or extension[1:]

    if extension not in [".csv", ".parquet"] or filetype not in ["csv", "parquet"]:
        raise HTTPException(501, f"conversion {extension[1:]} → {filetype} not supported")

    selected_indices = list(map(int, select.split(","))) if select else None

    dataframe = service.load_dataset(DATABASES, file_id)

    # Always remove the index before performing operations
    index_name = dataset_info.analysis.indexName
    index_col = dataframe[index_name]
    dataframe.drop(columns=[index_name], inplace=True)

    if selected_indices is not None:
        if any(i >= len(dataframe.columns) for i in selected_indices):
            raise HTTPException(400, "invalid column selection")
        dataframe = dataframe.iloc[:, selected_indices]

    # Add the index back if required
    if index:
        dataframe[index_name] = index_col

    with utils.temp_dir(TMP_DIR) as directory:
        target_path = (directory / filename).with_suffix(f".{filetype}")
        utils.save_dataframe(dataframe, target_path)
        return FileResponse(target_path, filename=target_path.name)


@app.post(
    "/datasets/{file_id}/sampler/file",
    tags=[DATASETS_TAG],
    status_code=HTTP_200_OK,
    response_model=rest.DatasetFileInfo,
)
def sample_file(
    file_id: rest.DatasetFileId, options: rest.SampleOptions = Body(...), sorting: list = Body([])
) -> rest.DatasetFileInfo:
    """Samples a dataset according to the sampling options"""
    dataframe = service.load_dataset(DATABASES, file_id)
    dataset_info = service.get_dataset_info(DATABASES, file_id)

    if options.sampleMethod == rest.SampleMethod.RANDOM:
        sample = dataframe.sample(n=options.methodOptions.rows)
    elif options.sampleMethod == rest.SampleMethod.TOP:
        sample = dataframe.head(n=options.methodOptions.rows)
    elif options.sampleMethod == rest.SampleMethod.BOTTOM:
        sample = dataframe.tail(n=options.methodOptions.rows)
    else:
        raise HTTPException(501, f"Sampling method {options.sampleMethod} not supported")

    filename = service.get_dataset_info(DATABASES, file_id).originalFilename
    sample_name = f"sample_{options.get_hash()}_{filename}"
    return service.save_dataset(DATABASES, sample, Path(sample_name), dataset_info.analysis.indexName)


@app.delete(
    "/datasets/{file_id}",
    tags=[DATASETS_TAG],
    status_code=HTTP_200_OK,
)
def delete_dataset(file_id: rest.DatasetFileId):
    DATABASES.json_database.table("datasets").remove(service.file_id_query(file_id))
    DATABASES.file_database.delete(file_id)
