"""Service layer for Mock Thor API"""

import logging
from tempfile import SpooledTemporaryFile
from pathlib import Path

import pandas as pd
import tinydb
from fastapi import HTTPException  # We shouldn't, but it makes things simpler
from fastapi.responses import StreamingResponse
from tinydb.queries import QueryLike

from . import models as rest
from . import utils
from .database import FileDatabase, FilesystemDatabase

logger = logging.getLogger("uvicorn")
MAX_SPOOL_SIZE: int = 50_000_000  # 50MB


class ThorDatabases:
    """A dataclass for holding the mock databases"""

    def __init__(self, tmp_dir: Path) -> None:
        self.directory = tmp_dir
        self.file_database: FileDatabase = FilesystemDatabase(tmp_dir)
        self.file_db_path = self.file_database.root
        self.json_db_path = self.file_db_path.with_suffix(".json")
        self.json_database: tinydb.TinyDB = tinydb.TinyDB(self.json_db_path)


def to_basetype(dtype: str) -> rest.BaseType:
    if "float" in dtype:
        return rest.BaseType.FLOAT
    if "int" in dtype:
        return rest.BaseType.INTEGER
    return rest.BaseType.STRING


def file_id_query(file_id: str) -> QueryLike:
    """Query for an object with an _id field matching the given file_id"""
    return tinydb.Query()._id == file_id  # type: ignore


def save_dataset(dbs: ThorDatabases, data: pd.DataFrame, filename: Path, index_name: str) -> rest.DatasetFileInfo:
    """Saves a dataframe and returns a registered DatasetFile"""
    assert index_name in data.columns

    with SpooledTemporaryFile(max_size=MAX_SPOOL_SIZE) as file_io:
        utils.save_dataframe_to_stream(data, file_io, filename.suffix)
        file_io.seek(0)
        file_id = dbs.file_database.save(file_io)

    file_path = dbs.file_database.get(file_id)

    if data.shape[0] == 0:  # No rows in the dataset
        raise HTTPException(416)

    columns = [name for name in data.columns if name != index_name]
    dataset_info = rest.DatasetFileInfo(
        _id=file_id,
        sizeInBytes=file_path.stat().st_size,
        originalFilename=filename.name,
        analysis=rest.DatasetFileAnalysis(
            indexName=index_name,
            totalRows=data.shape[0],
            totalColumns=len(columns),
            encoding="utf-8",
            delimiter=",",
            columns=[
                rest.DatasetFileColumn(
                    name=name,
                    originalName=name,
                    index=i,
                    baseType=to_basetype(str(data[name].dtype)),
                )
                for (i, name) in enumerate(columns)
            ],
        ),
    )

    matches = dbs.json_database.table("datasets").search(file_id_query(file_id))
    if not matches:
        dbs.json_database.table("datasets").insert(dataset_info.dict())
    logger.info(f"→ /datasets: created {dataset_info.id}")
    return dataset_info


def get_dataset_info(dbs: ThorDatabases, file_id: rest.FileId) -> rest.DatasetFileInfo:
    """Returns the registered DatasetFile info for the given file_id"""
    matches = dbs.json_database.table("datasets").search(file_id_query(file_id))
    if len(matches) == 0:
        raise HTTPException(404, f"Metadata of datasets {file_id} not found")
    return rest.DatasetFileInfo.parse_obj(matches[0])


def load_dataset(dbs: ThorDatabases, file_id: rest.FileId) -> pd.DataFrame:
    """Loads a dataframe from a registered DatasetFile"""
    dataset_info = get_dataset_info(dbs, file_id)

    original_path = dbs.file_database.get(file_id)
    filename = dataset_info.originalFilename
    extension = Path(filename).suffix

    return utils.load_dataframe(original_path, extension)
