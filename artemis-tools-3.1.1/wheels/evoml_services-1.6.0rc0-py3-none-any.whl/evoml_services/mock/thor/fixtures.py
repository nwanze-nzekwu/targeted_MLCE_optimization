"""Fixtures for the mock Thor API server"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path
from typing import Iterator

# Dependencies
import pytest
from _pytest.tmpdir import TempPathFactory

from turing_task_manager.clients.fixtures import ApiFixture, Server

# Module
from evoml_services.mock.thor.api import app as thor_app
from evoml_services.clients.thor.client import ThorClient, ThorSettings

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = [
    "thor_api",
    "Server",  # server fixture
    "thor_settings",
    "ThorSettings",  # settings fixture
    "thor_client",
    "ThorClient",  # client fixture
]


# ─────────────────────────── API client & server ──────────────────────────── #
@pytest.fixture(scope="session")
def thor_api(tmp_path_factory: TempPathFactory) -> Iterator[Server]:
    """Runs Thor File API in the background. The Server object provided the
    address/port of the server and allows access to the logs redirection
    """
    tmp_dir: Path = tmp_path_factory.mktemp("thor")
    fixture = ApiFixture(thor_app, tmp_dir, server_name="Thor")
    server = fixture.setup()
    yield server
    fixture.teardown()


@pytest.fixture(scope="session")
def thor_settings(thor_api: Server) -> Iterator[ThorSettings]:
    """Fixture providing settings for a Thor API mock instance running in the
    background. Also provides groupped print of the logs/prints of this API
    instance
    """
    thor_api.print_logs()
    yield ThorSettings(host=thor_api.host, port=thor_api.port)
    thor_api.print_logs()


@pytest.fixture(scope="session")
def thor_client(thor_settings: ThorSettings) -> Iterator[ThorClient]:
    """Fixture providing a Thor API client instance connected to a mock API
    running in the background
    """
    yield ThorClient(thor_settings)
