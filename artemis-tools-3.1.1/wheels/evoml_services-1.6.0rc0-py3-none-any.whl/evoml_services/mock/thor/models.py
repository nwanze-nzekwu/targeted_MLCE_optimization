"""This module contains the models used by the mock Thor API"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import TypeVar, Optional, List
from enum import Enum
from pathlib import Path

# Dependencies
from pydantic.v1 import BaseModel, Field

# Module
from evoml_api_models.utils import use_alias

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = [
    "FileId",
    "DatasetFileId",
    "FileInfo",
    "DatasetFileColumn",
    "DatasetFileAnalysis",
    "DatasetFileInfo",
]
# ──────────────────────────────────────────────────────────────────────────── #
FileId = str
DatasetFileId = str


class BaseType(str, Enum):
    FLOAT = "float"
    INTEGER = "int"
    STRING = "string"


@use_alias
class FileInfo(BaseModel):
    """Metadata about a file (zip, images, ...) stored in the File API. This
    metadata contains the url where the file can be downloaded. This is not the
    file itself.
    """

    id: FileId = Field(..., alias="_id", example="5e1f0cfe1aa7100029617827")
    originalFilename: str = Field(..., example="filename.csv")
    sizeInBytes: int = Field(..., example=10268120)


class DatasetFileColumn(BaseModel):
    """Information about a Dataset File's column"""

    name: str
    originalName: Optional[str]
    index: int
    baseType: BaseType


class DatasetFileAnalysis(BaseModel):
    """Information about a Dataset File's analysis results"""

    indexName: str
    columns: List[DatasetFileColumn]
    totalRows: int
    totalColumns: int
    encoding: Optional[str]
    delimiter: Optional[str]


@use_alias
class DatasetFileInfo(FileInfo):
    """Metadata about a data file (csv) in the File API. This type of file
    provides more features specific to tabular data files.
    """

    id: DatasetFileId = Field(..., alias="_id", example="5e1f0cfe1aa7100029617827")
    analysis: DatasetFileAnalysis


class CompoundFileType(str, Enum):
    """Types of files supported for compounf file creation in Thor"""

    FILE = "file"
    ARCHIVE = "archive"


class CompoundFile(BaseModel):
    """Metadata about a data file (csv) in the File API. This type of file
    provides more features specific to tabular data files.
    """

    type: CompoundFileType = CompoundFileType.FILE
    id: FileId = Field(..., example="5e1f0cfe1aa7100029617827")
    path: Path


class SampleMethod(str, Enum):
    RANDOM = "random"
    BOTTOM = "bottom"
    TOP = "top"


class SampleMethodOptions(BaseModel):
    rows: int


class SampleOptions(BaseModel):
    methodOptions: SampleMethodOptions
    sampleMethod: SampleMethod

    def get_hash(self) -> int:
        return hash(self.json())
