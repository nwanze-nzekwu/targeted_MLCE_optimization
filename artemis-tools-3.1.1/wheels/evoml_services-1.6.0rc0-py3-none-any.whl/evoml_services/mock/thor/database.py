"""This module is a mock database handling full files in a local temporary
directory
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import IO, Optional, TypeVar
from pathlib import Path
from abc import ABC, abstractmethod
from uuid import uuid4
from io import BytesIO
import hashlib
import shutil

# Dependencies
import tinydb

# Module
# ──────────────────────────────────────────────────────────────────────────── #
UniqueId = TypeVar("UniqueId", bound=str)
ByteSize = TypeVar("ByteSize", bound=int)
Json = TypeVar("Json", list, dict)


# ────────────────────────────────── utils ─────────────────────────────────── #
def get_id() -> str:
    """Returns a unique id"""
    return str(uuid4()).replace("-", "")[:16]


# -------------------------------- interface --------------------------------- #
class FileDatabase(ABC):
    """A simple database allowing to save, retrieve and delete files"""

    # ----------------------- constructor / destructor ----------------------- #
    @abstractmethod
    def __init__(self):
        """Initialises the database and allocate any needed resources"""

    @abstractmethod
    def __del__(self):
        """Cleans the database and frees any resources"""

    # ---------------------------- public methods ---------------------------- #
    @abstractmethod
    def save(self, file: IO) -> UniqueId:
        """Saves the given file and returns an unique id to retrieve it"""

    @abstractmethod
    def get(self, unique_id: UniqueId) -> Path:
        """Retrieves a file given its unique id"""

    @abstractmethod
    def delete(self, unique_id: UniqueId):
        """Deletes a file given its unique id"""


# ------------------------ local filesystem database ------------------------- #
class FilesystemDatabase(FileDatabase):
    """Simple file database implementing the FileDatabase interface using
    a local filesystem temporary directory
    """

    # Static attributes
    HASH_CHUNK_SIZE: ByteSize = -1  # read entire files for now

    # Instance attributes
    root: Path

    # ----------------------- constructor / destructor ----------------------- #
    def __init__(self, directory: Optional[Path] = None):
        super().__init__()
        # Search for a suitable temporary directory
        base_dir = directory or Path()

        self.root = base_dir / f"database-{get_id()}"
        self.root.mkdir()  # should NOT exist, its parents should exist

    def __del__(self):
        shutil.rmtree(self.root)

    # --------------------------------- impl --------------------------------- #
    def save(self, file: IO) -> UniqueId:
        # Read a chunk to figure out a unique id (hash)
        chunk = file.read(self.HASH_CHUNK_SIZE)
        is_bytes = isinstance(chunk, bytes)  # IO's interface is bytes or str

        chunk_bytes = chunk if is_bytes else chunk.encode("utf-8")
        hash_id = hashlib.md5(chunk_bytes).hexdigest()[:16]

        # If the file is already saved, return early
        file_path = self.root / hash_id
        if file_path.is_file():
            return hash_id

        # Write both the chunk & the rest of the file, accounting for str/bytes
        content = file.read()
        write_mode = "ab" if is_bytes else "a"  # open in append mode
        with file_path.open(write_mode) as fileobj:
            fileobj.write(chunk)
            fileobj.write(content)

        return hash_id

    def get(self, unique_id: UniqueId) -> Path:
        return self.root / unique_id

    def delete(self, unique_id: UniqueId):
        (self.root / unique_id).unlink()
