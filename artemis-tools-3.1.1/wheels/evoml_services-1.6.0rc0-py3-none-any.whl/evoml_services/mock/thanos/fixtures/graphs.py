"""Provides fake graph data generation for any Graph related test"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library

# Dependencies
import pytest
from evoml_api_models import ConvertedGraph

# Module
from .generator import Generator

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = ["graph_generator", "GraphGenerator"]

# ──────────────────────────────────────────────────────────────────────────── #
BAR_CHART = {}


class GraphGenerator(Generator):
    """Class providing graph data instances generated randomly"""

    def get_empty(self) -> ConvertedGraph:
        """Returns an empty graph instance, enough to test the basics of
        POST/GET
        """
        return ConvertedGraph(type="highcharts", data={})

    def from_size(self, size: int) -> ConvertedGraph:
        """Returns an empty graph instance, enough to test the basics of
        POST/GET
        """
        categories = [f"x_{i}" for i in range(size)]
        _dict = {
            "type": "highcharts",
            "data": {
                "chart": {"type": "bar"},
                "title": {"text": "Mock Graph"},
                "xAxis": {
                    "title": {"text": "Category"},
                    "categories": categories,
                },
                "yAxis": [
                    {
                        "title": {"text": "Frequency"},
                    }
                ],
                "series": [
                    {
                        "name": "fake_categories",
                        "data": [
                            {"x": i, "y": 1.0, "x_cat": c, "percentage": 1 / size} for (i, c) in enumerate(categories)
                        ],
                    }
                ],
            },
            "description": "Mock graph generated for testing purposes",
        }
        return ConvertedGraph.parse_obj(_dict)


@pytest.fixture
def graph_generator(random_seed: int) -> GraphGenerator:
    return GraphGenerator(random_seed)
