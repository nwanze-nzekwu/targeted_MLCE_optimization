"""Provides fixtures to generate random dataframes"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from __future__ import annotations
from typing import Callable, List
from enum import Enum

# Dependencies
import numpy as np
import pandas as pd
import pytest

# Module
from .generator import Generator

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = ["DataGenerator", "data_generator"]


# ──────────────────────────────────────────────────────────────────────────── #
class RandomType(str, Enum):
    """A enumeration of random types supported for the data generator"""

    letters = "letters"
    names = "names"
    boolean = "boolean"
    normal_float = "normal_float"
    normal_int = "normal_int"
    uniform_float = "uniform_float"
    uniform_int = "uniform_int"
    unary = "unary"


class DataGenerator(Generator):
    """Class allowing an interface for dataframe generation designed for the
    purpose of services layer testing: simple datasets exploring a subset of the
    possible behaviours, focusing on the core functionalities.
    """

    DEFAULT_MIXED_COLS = list(RandomType) * 2
    NAMES = [
        "Carwyn",
        "Britton",
        "Arwa",
        "Moody",
        "Shanon",
        "Nielsen",
        "Effie",
        "Wicks",
        "Yisroel",
        "Montoya",
        "Milla",
        "Byers",
        "Magnus",
        "Esparza",
        "Saif",
        "Bassett",
        "Zakariya",
        "Battle",
        "Katey",
        "Herbert",
        "Suzanne",
        "Hernandez",
        "Jordan",
        "Mejia",
        "Rukhsar",
        "Byrne",
        "Zion",
        "Searle",
        "Bella",
        "Findlay",
        "Ignacy",
        "Preston",
        "Harry",
        "Maynard",
        "Alaw",
        "Barrera",
        "Hareem",
        "Amin",
        "Saad",
        "Novak",
    ]
    LETTERS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    RandomType = RandomType  # Expose the enum to simplify imports

    def _get_column(self, rows: int, rtype: RandomType) -> np.array:
        """Returns a single column for a given random type"""
        if rtype == RandomType.unary:
            return np.zeros([rows], dtype=int)
        if rtype == RandomType.boolean:
            return self.rng.binomial(1, 0.5, size=[rows]).astype(np.bool_)
        if rtype == RandomType.normal_float:
            return self.rng.normal(0, 1, size=[rows])
        if rtype == RandomType.normal_int:
            return self.rng.normal(50, 10, size=[rows]).astype(int)
        if rtype == RandomType.uniform_float:
            return self.rng.uniform(0, 100, size=[rows])
        if rtype == RandomType.uniform_int:
            return self.rng.uniform(0, 100, size=[rows]).astype(int)
        if rtype == RandomType.letters:
            return self.rng.choice(self.LETTERS, size=[rows])
        if rtype == RandomType.names:
            return self.rng.choice(self.NAMES, size=[rows])
        raise NotImplementedError(f"Unsupported rtype: {rtype}")

    def from_single_type(self, rows: int = 100, cols: int = 20, rtype: RandomType = "uniform_int") -> pd.DataFrame:
        """Generates a dataset with columns of the same given random type"""
        return self.from_mixed_types(rows, [rtype] * cols)

    def from_mixed_types(self, rows: int = 100, cols: List[RandomType] = None) -> pd.DataFrame:
        """Generates a dataset with columns of mixed random types"""
        cols = cols or self.DEFAULT_MIXED_COLS
        data = pd.DataFrame()
        for i, rtype in enumerate(cols):
            data[f"col_{i}:{rtype}"] = self._get_column(rows, rtype)
        return data


# ───────────────────────────────── fixtures ───────────────────────────────── #
@pytest.fixture
def data_generator(random_seed: int) -> DataGenerator:
    return DataGenerator(random_seed)
