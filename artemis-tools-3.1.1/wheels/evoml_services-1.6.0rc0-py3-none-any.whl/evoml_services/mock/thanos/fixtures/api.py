"""Fixtures for the mock Thanos API server"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path

# Dependencies
import pytest
from _pytest.tmpdir import TempPathFactory

from turing_task_manager.clients.fixtures import ApiFixture, Server

# Module
from evoml_services.mock.thanos.api import app as thanos_app
from evoml_services.clients.thanos.client import ThanosClient, ThanosSettings

# ──────────────────────────────────────────────────────────────────────────── #

# Expose fixtures & their types for convenience
__all__ = [
    "thanos_api",
    "Server",  # server fixture
    "thanos_settings",
    "ThanosSettings",  # settings fixture
    "thanos_client",
    "ThanosClient",  # client fixture
]


# ─────────────────────────── API client & server ──────────────────────────── #
@pytest.fixture(scope="session")
def thanos_api(tmp_path_factory: TempPathFactory) -> Server:
    """Runs Thanos File API in the background. The Server object provided the
    address/port of the server and allows access to the logs redirection
    """
    tmp_dir: Path = tmp_path_factory.mktemp("thanos")
    fixture = ApiFixture(thanos_app, tmp_dir, server_name="Thanos")
    server = fixture.setup()
    yield server
    fixture.teardown()


@pytest.fixture(scope="session")
def thanos_settings(thanos_api: Server) -> ThanosSettings:
    """Fixture providing settings for a Thanos API mock instance running in the
    background. Also provides groupped print of the logs/prints of this API
    instance
    """
    thanos_api.print_logs()
    yield ThanosSettings(
        host=thanos_api.host,
        port=thanos_api.port,
        client_id="arbitrary",
        client_secret="arbitrary",
    )
    thanos_api.print_logs()


@pytest.fixture
def thanos_client(thanos_settings: ThanosClient) -> ThanosClient:
    """Fixture providing a Thor API client instance connected to a mock API
    running in the background
    """
    yield ThanosClient(thanos_settings)
