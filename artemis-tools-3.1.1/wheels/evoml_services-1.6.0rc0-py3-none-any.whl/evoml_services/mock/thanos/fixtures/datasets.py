"""Defines fixtures for creating datasets in the mock Thanos API. Provides
methods for API logic and for random data generation.
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import List, Callable, TypeVar, Optional
from pathlib import Path
from contextlib import suppress

# Dependencies
import pandas as pd
import numpy as np
import pytest

from evoml_api_models import ColumnInfo
from turing_task_manager.clients.core import HttpException

# Module
from evoml_services.mock.thor.fixtures import thor_api, thor_settings, thor_client, ThorClient
from evoml_services.clients.thanos.models import DatasetId, Dataset

from .api import thanos_api, thanos_settings, thanos_client, ThanosClient
from ..models import CreateDatasetDto, DatasetMetadata

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = ["get_dataset_id", "GetDatasetId", "DatasetBuilder"]

# ──────────────────────────────────────────────────────────────────────────── #
T = TypeVar("T")
OList = Optional[List[T]]


class DatasetBuilder:
    """Class uploading datasets to dataset id in Thanos API, providing the
    backend for several level of fixtures (dataset, dataset + column)
    """

    def __init__(self, thanos_client: ThanosClient, thor_client: ThorClient, tmp_path: Path):
        self.thanos_client = thanos_client
        self.thor_client = thor_client
        self.folder = tmp_path / ".fixtures" / "datasets"
        self.folder.mkdir(parents=True, exist_ok=True)

    def make_dataset(self, data: pd.DataFrame, columns: OList[ColumnInfo] = None, index: int = 0) -> Dataset:
        """Uploads a dataset to Thanos from a dataframe and returns its id. If
        given, adds column infos to the dataset's id.
        """
        # We might generate different datasets with this function so we're
        # indexing them just in case
        data_path = self.folder / f"data_{index}.parquet"
        data.to_parquet(data_path)
        file_model = self.thor_client.upload_dataset_file(data_path)

        # Note: creating datasets is not needed in the service layer (we're
        # always working on an existing dataset_id) so we don't have a method
        # for it, neither do we have a partial model for creation
        dataset_model = CreateDatasetDto(
            name="dataset",
            fileId=file_model.id,
            description="",
            tags=[],
            metadata=DatasetMetadata(
                rowsCount=file_model.analysis.totalRows,
                columnsCount=file_model.analysis.totalColumns,
                encoding=file_model.analysis.encoding,
                delimiter=file_model.analysis.delimiter,
                sourceSizeInBytes=file_model.sizeInBytes,
                sourceName=file_model.originalFilename,
            ),
        )
        dataset_model.name = f"fixture_{index}"
        dataset = Dataset.parse_obj(self.thanos_client.post("/datasets", json=dataset_model))

        if columns is not None:
            self.thanos_client.set_columns_info(dataset.id, columns)

        return dataset

    @staticmethod
    def get_columns(data: pd.DataFrame) -> List[ColumnInfo]:
        """Creates a simple fake column info supporting a subset of types"""
        columns = []
        for i, colname in enumerate(data.columns):
            unique = set(data[colname])

            # Base guess for the detected type
            dtype = str(data[colname].dtype)
            if dtype.startswith("int"):
                base_type = "int"
                detected_type = "basicInteger"
            elif dtype.startswith("float"):
                base_type = "float"
                detected_type = "basicFloat"
            elif dtype == "bool":
                base_type = "int"
                detected_type = "binary"
            else:
                base_type = "string"
                detected_type = "categorical"

            # Refine cases unary
            if len(unique) == 1:
                detected_type = "unary"

            columns.append(
                ColumnInfo(
                    name=colname,
                    columnIndex=i,
                    confidenceScore=1.0,
                    statsUniqueValuesRatio=len(unique) / len(data[colname]),
                    statsUniqueValuesCount=len(unique),
                    statsMissingValuesRatio=0.0,
                    statsMissingValuesCount=0,
                    statsValuesCount=len(data[colname]),
                    baseType=base_type,
                    detectedType=detected_type,
                )
            )
        return columns


# ───────────────────────────────── fixtures ───────────────────────────────── #
GetDatasetId = Callable[[pd.DataFrame, bool], DatasetId]


@pytest.fixture
def get_dataset_id(thanos_client: ThanosClient, thor_client: ThorClient, tmp_path: Path) -> GetDatasetId:
    """Function that generates a dataset_id from the given pd.DataFrame for the
    duration of the fixture.
    """
    # As we're returning a function that generates dataset_ids, we need to keep
    # track of the datasets generated on the main fixture level. This allows to
    # tear down any generated data on test teardown
    generated: List[Dataset] = []

    def make_dataset(data: pd.DataFrame, add_columns: bool = False) -> DatasetId:
        """Converts the dataframe to a file, uploads it to Thor File API, then
        uploads it as dataset in Thanos. Returns the unique dataset id.
        """
        builder = DatasetBuilder(thanos_client, thor_client, tmp_path)
        columns = builder.get_columns(data) if add_columns else None

        dataset = builder.make_dataset(data, columns, index=len(generated))
        generated.append(dataset)
        return dataset.id

    yield make_dataset  # Our return is the function to generate datasets

    # Teardown, we have the list of generated ids
    for dataset in generated:
        # The file/dataset might have been deleted by the test
        with suppress(HttpException):
            thor_client.delete_dataset_file(dataset.fileId)
        with suppress(HttpException):
            thanos_client.delete_dataset(dataset.id)
