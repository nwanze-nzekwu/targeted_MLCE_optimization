"""Base class for data generation classes"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Dependencies
import pytest
import numpy as np

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = ["random_seed"]


# ──────────────────────────────────────────────────────────────────────────── #
class Generator:
    """Generic class for data generation classes simplifying the interface to
    random instances of objects to test (data for the Thanos API in this
    context).
    """

    rng: np.random.Generator

    def __init__(self, seed: int):
        """Initialises the DataGenerator with a random seed"""
        self.rng = np.random.default_rng(seed)


# ───────────────────────────────── fixtures ───────────────────────────────── #
@pytest.fixture
def random_seed() -> int:
    return 12345678
