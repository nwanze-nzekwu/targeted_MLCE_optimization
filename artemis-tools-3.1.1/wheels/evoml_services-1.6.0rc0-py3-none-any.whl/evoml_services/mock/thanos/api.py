"""This module is a mock version of Thor File API
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import Any, List, Type, TypeVar
from pathlib import Path
from uuid import uuid4
import logging

# Dependencies
from fastapi import FastAPI, Query, File, UploadFile, HTTPException, Request
from starlette.responses import JSONResponse
from starlette.status import (
    HTTP_200_OK,
    HTTP_201_CREATED,
    HTTP_204_NO_CONTENT,
)
from pydantic.v1 import parse_obj_as

# Module
from evoml_services.clients.thanos.models import Pagination
from .database import TinydbDatabase, UniqueId
from . import models

# ──────────────────────────────────────────────────────────────────────────── #
# Unique Id aliases for specific entities
TrialId = TypeVar("TrialId", bound=str)
DatasetId = TypeVar("DatasetId", bound=str)
GraphId = TypeVar("GraphId", bound=str)


# ---------------------------------------------------------------------------- #
logger = logging.getLogger("uvicorn")

app = FastAPI(root_path="/api")

BASE_DIR = Path()


# ────────────────────────────────── utils ─────────────────────────────────── #
def get_id() -> str:
    """Returns a unique id"""
    return str(uuid4()).replace("-", "")[:16]


ModelT = TypeVar("ModelT")


def paginate(model_list: List[ModelT]) -> Pagination[ModelT]:
    """Puts a list of models in a pagination form"""
    # We assume that types are identical over the model list
    model_type = Any if len(model_list) == 0 else type(model_list[0])
    return Pagination[model_type](
        docs=model_list,
        totalDocs=len(model_list),
        limit=0,
        totalPages=1,
        page=0,
        pagingCounter=0,
        hasPrevPage=False,
        hasNextPage=False,
    )


TypeT = TypeVar("TypeT")


def arbitrary(_type: Type[TypeT]) -> TypeT:
    """Creates an arbitrary value for required fields in Thanos Models that are
    not relevant to the mock API
    """
    if _type is str:
        return "arbitrary"
    if _type is list:
        return []
    raise TypeError(f"{_type} not surported")


# ───────────────────────────────── database ───────────────────────────────── #
JSON_DATABASE: TinydbDatabase


@app.on_event("startup")
def startup():
    """Setup the mock database"""
    global JSON_DATABASE  # pylint: disable=W0603
    logger.info("Working directory: %s", BASE_DIR.absolute())
    JSON_DATABASE = TinydbDatabase(BASE_DIR / f"database-{get_id()}")
    logger.info("Json database: %s", JSON_DATABASE.path.absolute())


@app.on_event("shutdown")
def shutdown():
    """Tear down the mock database"""
    global JSON_DATABASE  # pylint: disable=W0603
    del JSON_DATABASE


# ──────────────────────────────── middleware ──────────────────────────────── #
MAX_CONTENT_SIZE = 100000


@app.middleware("http")
async def limit_size(request: Request, call_next):
    size: int = int(request.headers.get("content-length", -1))
    if size >= 0 and size > MAX_CONTENT_SIZE:
        return JSONResponse(status_code=413, content={"reason": "Payload Too Large"})
    response = await call_next(request)
    return response


# ─────────────────────────────────── auth ─────────────────────────────────── #
AUTH_TAG = "Authentication"


@app.post(
    "/auth/login",
    tags=[AUTH_TAG],
    status_code=HTTP_200_OK,
)
def authenticate() -> dict:
    return {
        "access_token": arbitrary(str),
        "token_type": arbitrary(str),
        "expires_in": 0,
        "refresh_token": arbitrary(str),
    }


# ───────────────────────────────── datasets ───────────────────────────────── #
DATASETS_TAG = "Datasets"


@app.post(
    "/datasets",
    tags=[DATASETS_TAG],
    status_code=HTTP_201_CREATED,
    response_model=models.Dataset,
)
def create_dataset(dataset_create: models.CreateDatasetDto) -> models.Dataset:
    dataset_json = dict(
        # Set fields not relevant to the mock
        userId=arbitrary(str),
        description=arbitrary(str),
        analysisProcessId=arbitrary(str),
        tags=arbitrary(list),
        # Add the actual required fields
        **dataset_create.dict(exclude={"description", "tags"}),
    )
    inserted = JSON_DATABASE.insert_json("dataset", dataset_json)
    return models.Dataset.parse_obj(inserted)


@app.get(
    "/datasets/{dataset_id}",
    tags=[DATASETS_TAG],
    status_code=HTTP_200_OK,
    response_model=models.Dataset,
)
def get_dataset(dataset_id: DatasetId) -> models.Dataset:
    dataset_json = JSON_DATABASE.get_by_id("dataset", dataset_id)
    if dataset_json is None:
        raise HTTPException(404, f"Dataset with id {dataset_id} not found for get")
    return models.Dataset.parse_obj(dataset_json)


@app.delete(
    "/datasets/{dataset_id}",
    tags=[DATASETS_TAG],
    status_code=HTTP_200_OK,
)
def delete_dataset(dataset_id: DatasetId):
    deleted = JSON_DATABASE.delete_by_id("dataset", dataset_id)
    if not deleted:
        raise HTTPException(404, f"Dataset with id {dataset_id} not found for deletion")


# ───────────────────────────────── columns ────────────────────────────────── #
COLUMNS_TAG = "Columns Info"


@app.get(
    "/datasets/{dataset_id}/columns-info",
    tags=[COLUMNS_TAG],
    status_code=HTTP_200_OK,
    response_model=Pagination[models.UpdateColumnDto],
)
def get_columns(dataset_id: DatasetId, columnIndex: str = Query(None)) -> Pagination[models.UpdateColumnDto]:
    dataset_json = JSON_DATABASE.get_by_id("dataset", dataset_id)
    columns = parse_obj_as(
        List[models.UpdateColumnDto],
        dataset_json.get("columnsList", []),
    )
    elements = []
    paginated_result: Pagination[models.UpdateColumnDto]
    if columnIndex:
        indexes = columnIndex.split(",")
        for index in indexes:
            elements.append(columns[int(index)])
        paginated_result = paginate(elements)
    else:
        paginated_result = paginate(columns)
    return paginated_result


@app.get(
    "/datasets/{dataset_id}/columns-info/{index}",
    tags=[COLUMNS_TAG],
    status_code=HTTP_200_OK,
    response_model=models.UpdateColumnDto,
)
def get_columns(dataset_id: DatasetId, index: int) -> models.UpdateColumnDto:
    dataset_json = JSON_DATABASE.get_by_id("dataset", dataset_id)
    columns = parse_obj_as(
        List[models.UpdateColumnDto],
        dataset_json.get("columnsList", []),
    )
    for column in columns:
        if column.columnIndex == index:
            return column
    raise HTTPException(404, f"Column with index {index} not found for dataset {dataset_id}")


@app.patch(
    "/datasets/{dataset_id}/columns-info",
    tags=[COLUMNS_TAG],
    status_code=HTTP_201_CREATED,
)
def update_columns(dataset_id: DatasetId, columns_update: models.UpdateColumnsDto):
    dataset_json = JSON_DATABASE.get_by_id("dataset", dataset_id)
    current_columns = parse_obj_as(List[models.UpdateColumnDto], dataset_json.get("columnsList", []))

    # Columns in the update payload have priority over existing columns with the
    # same index
    columns = parse_obj_as(List[models.UpdateColumnDto], columns_update.data)

    update_indexes = [column.columnIndex for column in columns]

    # Re-add existing column if they have not been updated
    columns.extend([col for col in current_columns if (col.columnIndex not in update_indexes)])

    # Save this to the json
    dataset_json["columnsList"] = [column.dict(by_alias=True) for column in columns]
    JSON_DATABASE.update_by_id("dataset", dataset_json)


# ────────────────────────────────── graphs ────────────────────────────────── #
GRAPHS_TAG = "Graphs"


@app.get(
    "/graphs/{graph_id}",
    tags=[GRAPHS_TAG],
    status_code=HTTP_200_OK,
    response_model=models.Graph,
)
def get_graph(graph_id: GraphId) -> models.Graph:
    graph_json = JSON_DATABASE.get_by_id("graph", graph_id)
    return models.Graph.parse_obj(graph_json)


@app.post(
    "/graphs",
    tags=[GRAPHS_TAG],
    status_code=HTTP_201_CREATED,
    response_model=models.Graph,
)
def post_graph(graph: models.CreateGraphDto) -> models.Graph:
    graph_json = JSON_DATABASE.insert_json("graph", graph.dict())
    return models.Graph.parse_obj(graph_json)


# ─────────────────────────────── preprocessed ─────────────────────────────── #
PREPROCESSED_TAG = "Preprocessed File"


@app.get(
    "/trials/{trial_id}/preprocessed-file",
    tags=[PREPROCESSED_TAG],
    status_code=HTTP_200_OK,
    response_model=models.PreprocessedFile,
)
def get_preprocessed(trial_id: TrialId) -> models.PreprocessedFile:
    preprocessed_id = trial_id
    return models.PreprocessedFile.parse_obj(JSON_DATABASE.get_by_id("preprocessed", preprocessed_id))


@app.put(
    "/trials/{trial_id}/preprocessed-file",
    tags=[PREPROCESSED_TAG],
    status_code=HTTP_201_CREATED,
    response_model=models.PreprocessedFile,
)
def put_preprocessed(trial_id: TrialId, preprocessed: models.PreprocessedFile) -> models.PreprocessedFile:
    preprocessed_id = trial_id
    preprocessed_json = {"_id": preprocessed_id, **preprocessed.dict()}
    return models.PreprocessedFile.parse_obj(JSON_DATABASE.insert_json("preprocessed", preprocessed_json))


# ────────────────────────────────── trials ────────────────────────────────── #
TRIAL_TAG = "Trials"


@app.post("/trials", tags=[TRIAL_TAG], status_code=HTTP_201_CREATED)
def post_trial(trial: dict) -> dict:
    trial = JSON_DATABASE.insert_json("trial", trial)
    return trial


@app.get("/trials/{trial_id}", tags=[TRIAL_TAG], status_code=HTTP_200_OK)
def get_trial(trial_id: str) -> dict:
    trial = JSON_DATABASE.get_by_id("trial", trial_id)
    return trial


# ────────────────────────────── loss functions ────────────────────────────── #
LOSS_TAG = "Loss Functions"


@app.post("/loss-functions", tags=[LOSS_TAG], status_code=HTTP_201_CREATED)
def post_loss_function(loss_function: dict) -> dict:
    existing = JSON_DATABASE.get_by_id("loss-functions", loss_function["_id"])
    if existing is not None:
        return existing

    lf = JSON_DATABASE.insert_json("loss-functions", loss_function)
    return lf


@app.get("/loss-functions", tags=[LOSS_TAG], status_code=HTTP_200_OK)
def get_loss_function(_id: List[str] = Query(...)) -> dict:
    functions = []
    for lf_id in _id:
        functions.append(JSON_DATABASE.get_by_id("loss-functions", lf_id))
    return paginate(functions)
