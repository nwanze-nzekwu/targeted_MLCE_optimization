"""This module is a mock API providing a very generic database functionality
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from datetime import datetime
from typing import Optional, TypeVar, Any, Dict
from pathlib import Path
from abc import ABC, abstractmethod
from uuid import uuid4
from io import BytesIO
import hashlib
import shutil

# Dependencies
from fastapi import APIRouter
from starlette.status import HTTP_201_CREATED
import tinydb

# Module
# ──────────────────────────────────────────────────────────────────────────── #
UniqueId = TypeVar("UniqueId", bound=str)


# ────────────────────────────────── utils ─────────────────────────────────── #
def get_id() -> str:
    """Returns a unique id"""
    return str(uuid4()).replace("-", "")[:16]


def timestamp() -> str:
    """Returns the current timestamp as a datetime"""
    return datetime.now().isoformat()


# ──────────────────────────────── exceptions ──────────────────────────────── #
class ItemNotFoundException(BaseException):
    """Exception raised when an item is not found"""


class DuplicateItemsException(BaseException):
    """Exception raised when multiple items have the same unique id"""


# ──────────────────────────────────────────────────────────────────────────── #
class JsonDatabase(ABC):
    """Simple json Database interface providing services such as automatic
    unique id, creation & update date, filtering, ...
    """

    @abstractmethod
    def insert_json(self, table: str, item: dict) -> dict:
        """Inserts a json in the given table.

        Returns a json adding the following fields:
        - _id: unique id for this table
        - createdAt: timestamp of creation
        - updatedAt: timestamp of update

        Args:
            table: Name of the table where this item will be inserted
            item: Item to insert

        Returns:
            dict:
                Item after insertion, will have the (`_id`, `createdAt`,
                `updatedAt`) additional fields
        """

    @abstractmethod
    def filter_json(self, item: dict, **filters: Dict[str, Any]) -> dict:
        """Filters a json's field according to a set of key with values"""

    @abstractmethod
    def get_by_id(self, table: str, unique_id: UniqueId) -> Optional[dict]:
        """Retrieves a json from a table by unique id. Returns the item if it
        exists, otherwise returns None.

        Args:
            table: Name of the table where this item will be inserted
            unique_id: The unique id of the item in this table

        Returns:
            Optional[dict]:
                The item if found, else None

        Raises:
            DuplicateItemsException: if there's more than 1 item with this unique id
        """

    @abstractmethod
    def update_by_id(self, table: str, item: dict) -> Optional[dict]:
        """Updates a json from a table by unique id.  Returns the updated item
        if it exists, otherwise returns None.

        Args:
            table: Name of the table where this item will be inserted
            item: The item to update, must have _id, createdAt, updatedAt fields

        Returns:
            Optional[dict]:
                The item after update found, else None

        Raises:
            ItemNotFoundException: if the item did not exist already
            DuplicateItemsException: if there's more than 1 item with this id
        """

    @abstractmethod
    def delete_by_id(self, table: str, unique_id: UniqueId) -> bool:
        """Deletes a json from a table by unique id.

        Args:
            table: Name of the table where this item will be inserted
            unique_id: The unique id of the item in this table

        Returns:
            bool: True if the item was deleted, False if it didn't exist

        Raises:
            DuplicateItemsException: if there's more than 1 item with this id
        """


# ──────────────────────────────────────────────────────────────────────────── #
class TinydbDatabase(JsonDatabase):
    """Simple json Database interface implementation using tinydb as a backend"""

    database: tinydb.TinyDB
    path: Path

    # ----------------------- constructor / destructor ----------------------- #
    def __init__(self, db_path: Optional[Path] = None):
        """Instanciates the database"""
        self.path = db_path or Path("/tmp") / f"database-{get_id()}.json"
        self.database = tinydb.TinyDB(self.path)

    def __del__(self):
        """Cleans up the database and allocated resources"""
        del self.database
        self.path.unlink()

    # -------------------------------- utils --------------------------------- #
    @staticmethod
    def query_id(unique_id: UniqueId) -> tinydb.Query:
        """Builds a query for a given unique id (_id field)"""
        return tinydb.Query()._id == unique_id  # pylint: disable=W0212

    # --------------------------- public interface --------------------------- #
    def insert_json(self, table: str, item: dict) -> dict:
        # update time always changes
        item["updatedAt"] = timestamp()
        # creation time is set if it doesn't exist
        item.setdefault("createdAt", item["updatedAt"])
        # id is inserted if it doesn't exist
        item.setdefault("_id", get_id())
        self.database.table(table).insert(item)
        return item

    def filter_json(self, item: dict, **filters: Dict[str, Any]) -> dict:
        pass

    def get_by_id(self, table: str, unique_id: UniqueId) -> Optional[dict]:
        matches = self.database.table(table).search(self.query_id(unique_id))
        if len(matches) == 0:
            return None
        if len(matches) == 1:
            return matches[0]
        raise DuplicateItemsException(f"Duplicate items with id {unique_id} in table {table}")

    def update_by_id(self, table: str, item: dict) -> dict:
        assert all(field in item for field in ("_id", "createdAt", "updatedAt"))
        item["updatedAt"] = timestamp()

        if not self.delete_by_id(table, item["_id"]):
            raise ItemNotFoundException(f"Item with id {item['_id']} not found in table {table}")
        return self.insert_json(table, item)

    def delete_by_id(self, table: str, unique_id: UniqueId):
        removed = self.database.table(table).remove(self.query_id(unique_id))
        if len(removed) > 1:
            raise DuplicateItemsException(f"Duplicate items with id {unique_id} in table {table}")
        return len(removed) == 1
