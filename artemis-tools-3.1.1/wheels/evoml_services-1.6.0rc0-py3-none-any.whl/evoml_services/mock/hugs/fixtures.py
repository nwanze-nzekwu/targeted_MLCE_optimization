"""Fixtures for the mock Thanos API server"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path

# Dependencies
import pytest
from _pytest.tmpdir import TempPathFactory
from git import Repo
from pytest_mock import MockerFixture

from turing_task_manager.clients.fixtures import ApiFixture, Server

# Module

from evoml_services.clients.hugs.client import HugsClient, HugsSettings

# ──────────────────────────────────────────────────────────────────────────── #

# Expose fixtures & their types for convenience
__all__ = [
    # "hugs_api",
    "Server",  # server fixture
    # "hugs_settings",
    "HugsSettings",  # settings fixture
    "hugs_client",
    "HugsClient",  # client fixture
]

from evoml_services.clients.thanos import ThanosClient, ThanosSettings

from evoml_services.clients.thor import ThorClient, ThorSettings


# ─────────────────────────── API client & server ──────────────────────────── #
# @pytest.fixture(scope="session")
# def hugs_api(tmp_path_factory: TempPathFactory) -> Server:
#     """Runs Hugs API in the background. The Server object provided the
#     address/port of the server and allows access to the logs redirection
#     """
#     tmp_dir: Path = tmp_path_factory.mktemp("hugs")
#     fixture = ApiFixture(hugs_app, tmp_dir, server_name="Hugs")
#     server = fixture.setup()
#     yield server
#     fixture.teardown()
#
#
# @pytest.fixture(scope="session")
# def hugs_settings(hugs_api: Server) -> HugsSettings:
#     """Fixture providing settings for a Thanos API mock instance running in the
#     background. Also provides groupped print of the logs/prints of this API
#     instance
#     """
#     hugs_api.print_logs()
#     yield HugsSettings(
#         host=hugs_api.host,
#         port=hugs_api.port,
#         client_id="arbitrary",
#         client_secret="arbitrary",
#         username="arbitrary",
#         password="arbitrary",
#     )
#     hugs_api.print_logs()


@pytest.fixture
def thor_client(thor_settings: ThorSettings) -> ThorClient:
    """Fixture providing a Thor API client instance connected to a mock API
    running in the background
    """
    yield ThorClient(thor_settings)


@pytest.fixture
def hugs_client(
    hugs_settings: HugsSettings, thor_settings: ThorSettings, thanos_settings: ThanosSettings
) -> HugsClient:
    """Fixture providing a Thor API client instance connected to a mock API
    running in the background
    """
    yield HugsClient(hugs_settings, thor_settings, thanos_settings)


def download_static_model(temp_dir: Path) -> Path:
    """Downloads a static model that has the same structure as a model downloaded from Hugs"""
    repo_path = Repo.clone_from(url="https://huggingface.co/t5-small", to_path=temp_dir).working_dir
    return Path(repo_path)


@pytest.fixture(scope="session")
def mock_download_model(session_mocker: MockerFixture, tmp_path_factory: TempPathFactory):
    tmp_dir = tmp_path_factory.mktemp("hugs-model")
    download_function = lambda _, hugs_model, path: download_static_model(temp_dir=tmp_dir)
    return session_mocker.patch.object(HugsClient, "download_model", download_function)


__all__ = ["mock_download_model"]
