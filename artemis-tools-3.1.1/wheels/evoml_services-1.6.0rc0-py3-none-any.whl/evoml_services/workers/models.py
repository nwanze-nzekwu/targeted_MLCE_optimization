# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import List, Optional, Any, Union
from enum import Enum

# Dependencies
from pydantic.v1 import BaseModel, Field, StrictInt

from evoml_api_models import MlTask

from evoml_services.clients.thanos.models import FileId


# ──────────────────────────────────────────────────────────────────────────── #
#                             ML Models Parameters                             #
# ──────────────────────────────────────────────────────────────────────────── #
class InputParameter(BaseModel):
    parameterName: str
    parameterType: str
    fixedValue: Optional[bool] = False
    minValue: Optional[Union[StrictInt, float]] = None
    maxValue: Optional[Union[StrictInt, float]] = None
    values: List[Any]
    defaultValue: Any


class ModelMetadata(BaseModel):
    model: str


class ModelParameter(BaseModel):
    inputParameters: List[InputParameter]
    metadata: Optional[ModelMetadata]


class ModelDefinition(BaseModel):
    name: str
    parameters: Optional[ModelParameter]
