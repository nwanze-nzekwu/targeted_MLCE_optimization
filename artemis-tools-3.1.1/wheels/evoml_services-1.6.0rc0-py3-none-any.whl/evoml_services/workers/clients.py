"""Common worker class exposing methods and attributes necessary for any worker
providing a service in the Evoml ecosystem.
Should be used as a base for more specific workers (e.g. optimisation workers)
"""

# ──────────────────────────────────────────────────────────────────────────── #
# Standard library
import logging
from pathlib import Path
from typing import Union

from evoml_services.clients.hugs import HugsSettings, HugsClient

# Dependencies (http clients)
from evoml_services.clients.thanos import ThanosClient, ThanosSettings
from evoml_services.clients.thor import ThorClient, ThorSettings
from evoml_services.clients.black_widow import BlackWidowClient, BlackWidowSettings
from evoml_services.clients.echo.client import EchoClient, EchoSettings

# ──────────────────────────────────────────────────────────────────────────── #
# Entities exposed when using `from package import *`
__all__ = ["ApiClients"]


class ApiClients:
    """Class instanciating all the API clients needed for the Evoml platform"""

    logger = logging.getLogger(__name__)

    thanos: ThanosClient
    thor: ThorClient
    black_widow: BlackWidowClient
    echo: EchoClient
    hugs: HugsClient

    def __init__(self, env_file: Union[Path, str] = ".env"):
        """Constructor instanciating the API clients (thanos API & thor API)"""
        self.env_file = Path(env_file)

        # Thanos API Client
        self.logger.debug("Thanos configuration:\n%s", self.thanos_settings.json(indent=2))
        self.thanos = ThanosClient(self.thanos_settings)

        # Thor API Client
        self.logger.debug("Thor configuration:\n%s", self.thor_settings.json(indent=2))
        self.thor = ThorClient(self.thor_settings)

        # Black Widow API Client
        self.logger.debug("Black Widow configuration:\n%s", self.black_widow_settings.json(indent=2))
        self.black_widow = BlackWidowClient(self.black_widow_settings, self.thor)

        # Echo API Client
        self.logger.debug("Black Widow configuration:\n%s", self.echo_settings.json(indent=2))
        self.echo = EchoClient(self.echo_settings, self.thor)

        # Hugs API Client
        self.logger.debug("Black Widow configuration:\n%s", self.hugs_settings.json(indent=2))
        self.hugs = HugsClient(self.hugs_settings, self.thor_settings, self.thanos_settings)

    # -------------------------------- utils --------------------------------- #
    @property
    def thor_settings(self) -> ThorSettings:
        """Getter for Thor API Settings"""
        return ThorSettings.with_env_prefix("thor", self.env_file)

    @property
    def thanos_settings(self) -> ThanosSettings:
        """Getter for Thanos API Settings"""
        return ThanosSettings.with_env_prefix("thanos", self.env_file)

    @property
    def black_widow_settings(self) -> BlackWidowSettings:
        """Getter for Blackwidow API Settings"""
        return BlackWidowSettings.with_env_prefix("black_widow", self.env_file)

    @property
    def echo_settings(self) -> EchoSettings:
        """Getter for Echo API Settings"""
        settings = EchoSettings.with_env_prefix("black_widow", self.env_file)
        settings.postfix = "/echo"
        return settings

    @property
    def hugs_settings(self) -> HugsSettings:
        """Getter for Echo API Settings"""
        settings = HugsSettings.with_env_prefix("black_widow", self.env_file)
        settings.postfix = "/hugs"
        return settings
