"""Common worker class exposing methods and attributes necessary for any worker
providing a service in the Evoml ecosystem.
Should be used as a base for more specific workers (e.g. optimisation workers)
"""

# ──────────────────────────────────────────────────────────────────────────── #
# Standard library
from typing import List, Tuple, Optional
from pathlib import Path
import logging
import json

# Dependencies
import turing_task_manager as ttm
from turing_task_manager.exceptions import TaskDependencyMissing
from evoml_api_models import LossFunction, DatasetConfig, MlTask

# Http Clients
from evoml_services.clients.thanos import ThanosClient, ThanosSettings
from evoml_services.clients.thor import ThorClient, ThorSettings
from evoml_services.clients.black_widow import BlackWidowClient, BlackWidowSettings

# ──────────────────────────────────────────────────────────────────────────── #

logger = logging.getLogger(__name__)
inputs_logger = logging.getLogger(__name__ + ".inputs_download")

# ──────────────────────────────────────────────────────────────────────────── #

# Entities exposed when using `from package import *`
__all__ = ["EvomlWorker"]


# ──────────────────────────────────────────────────────────────────────────── #
#                            Worker Implementation                             #
# ──────────────────────────────────────────────────────────────────────────── #


class EvomlWorker(ttm.BaseWorker):
    """Project specific worker, covering specificities of the evoml ecosystem
    (clients to interact with the API, loading settings, ...)
    """

    logger = logging.getLogger(__name__)
    inputs_logger = logging.getLogger(__name__ + ".inputs_download")

    thanos_client: ThanosClient = None
    thor_client: ThorClient = None
    black_widow_client: BlackWidowClient = None

    @classmethod
    def setup(cls):
        """Class method setting up static attributes (here, mostly clients) as
        singletons.
        """
        if cls.thanos_client is None or cls.thor_client is None or cls.black_widow_client is None:
            thanos_settings = ThanosSettings.with_env_prefix("thanos")
            cls.thanos_client = ThanosClient(thanos_settings)
            cls.logger.debug("Thanos configuration:\n%s", thanos_settings.json(indent=2))

            thor_settings = ThorSettings.with_env_prefix("thor")
            cls.thor_client = ThorClient(thor_settings)
            cls.logger.debug("Thor configuration:\n%s", thor_settings.json(indent=2))

            black_widow_settings = BlackWidowSettings.with_env_prefix("black_widow")
            cls.black_widow_client = BlackWidowClient(black_widow_settings, cls.thor_client)
            cls.logger.debug("Black Widow configuration:\n%s", black_widow_settings.json(indent=2))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setup()

    # ───────────── generic methods to download frequent inputs ────────────── #
    @classmethod
    def download_dataset(
        cls,
        dataset_id: str,
        path: Path,
        headers: bool = True,
        indexes: Optional[List[int]] = None,
    ) -> DatasetConfig:
        """
        Download a dataset by datasetId.

        Download a dataset (by datasetId) to the given path, and adds the
        metadata of the dataset to the given config dictionary (overwriting
        existing keys in case of conflict).

        :param dataset_id: Unique id of the dataset to download.
        :param path: Path to save the dataset.
            The path extension must be `.csv` (csv) or `.parquet` (Apache
            Parquet)
        :param headers: Add the map of "original headers" → "cleaned headers"
            to the config.
        :param indexes: Restrict the dataset to the given list of column
            indices. By default, all columns are downloaded.
        """
        cls.inputs_logger.debug("↳ [get] dataset model %s", dataset_id)
        dataset = cls.thanos_client.get_dataset(dataset_id)

        file_id = dataset.fileId

        # ---------------------------------
        # Downloading the input data [csv]
        cls.inputs_logger.debug(
            "↳ [get] %s %s",
            path.name,
            "complete" if indexes is None else ",".join(map(str, indexes)),
        )
        cls.thor_client.download_dataset_file(file_id, path, indexes)

        # ---------------------------------
        # Headers information
        original_headers, cleaned_headers = cls._get_headers(file_id) if headers else ([], [])

        return DatasetConfig(
            original_haders=original_headers, cleaned_headers=cleaned_headers, metadata=dataset.metadata
        )

    @classmethod
    def _get_headers(cls, file_id: str) -> Tuple[list, list]:
        file_model = cls.thor_client.get_dataset_file(file_id)
        original_headers = [None] * len(file_model.analysis.columns)
        cleaned_headers = [""] * len(file_model.analysis.columns)
        for column in file_model.analysis.columns:
            original_headers.insert(column.index, column.originalName)
            cleaned_headers.insert(column.index, column.name)
        return original_headers, cleaned_headers

    @classmethod
    def download_columns_stats(
        cls,
        dataset_id: str,
        path: Path,
        ncols: int = None,
        indexes: Optional[List[int]] = None,
    ):
        """Downloads the columns statistics (or infos) about a dataset (by
        datasetId) to the given path.

        If the dataset is restricted to specific indexes, it filters those
        indices in the json and maps them in order (ex: [4, 7] => 4 → 0, 7 → 1)
        """
        if indexes is None:
            cls.inputs_logger.debug("↳ [get] col-infos {complete}")
            cols_list = cls.thanos_client.get_columns_info(dataset_id)
        else:
            ncols = len(indexes)
            cols_list = []
            for index in indexes:
                cls.inputs_logger.debug("↳ [get] col-info {%s}", index)
                cols_list.append(cls.thanos_client.get_single_column_info(dataset_id, index))

        cols_json = []
        for column in cols_list:
            if indexes is None:
                cols_json.append(column.dict())
            elif column.columnIndex in indexes:
                # We map the selected index to where it should be in the
                # restricted dataset
                column.columnIndex = indexes.index(column.columnIndex)
                cols_json.append(column.dict())

        with path.open("w") as fobj:
            json.dump(cols_json, fobj, allow_nan=False)

        if ncols is not None and len(cols_list) != ncols:
            length = len(cols_list)
            raise TaskDependencyMissing(
                f"The number of columns in column-info ({length}) "
                f"doesn't match the number of columns of the dataset "
                f"({ncols})"
            )

    @classmethod
    def get_loss_functions(cls, ml_task: MlTask, loss_functions_ids: List[str]) -> List[LossFunction]:
        """Replaces a list of loss functions ids by the actual loss function
        information
        """
        return cls.thanos_client.get_loss_functions(*loss_functions_ids, ml_task=ml_task)
