"""This file provides an Adapter class for the `Dataset` concept in Thanos. It
should hide all API calls to Thanos and Thor
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import List, Optional, Type, TypeVar, Union
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import json
import logging

# Dependencies
from pydantic.v1 import BaseModel, validator

# Module
from evoml_services.clients.thanos import ThanosClient
from evoml_services.clients.thor import ThorClient
from evoml_services.clients.thanos.models import (
    Dataset,
    DatasetId,
)

from evoml_api_models import ColumnInfo

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger("adapters.dataset")

# Type Aliases
PathLike = TypeVar("PathLike", str, Path)
T = TypeVar("T")  # pylint: disable=C0103
OList = Optional[List[T]]


# Public interface for this module
__all__ = ["IndexMap", "DatasetAdapter", "DatasetConfig"]


# ──────────────────────────────────────────────────────────────────────────── #
# @TODO: those models should come from evoml_api_models
class CsvConfig(BaseModel):
    """Config needed to open a csv file"""

    encoding: Optional[str] = None
    delimiter: Optional[str] = None


class DatasetMetadata(BaseModel):
    """Size of the dataset"""

    columnsCount: int
    rowsCount: int


class HeadersConfig(BaseModel):
    """Config needed to clean the headers of a file"""

    original_headers: List[Optional[str]]
    cleaned_headers: List[Optional[str]]


class DatasetConfig(HeadersConfig, CsvConfig, DatasetMetadata):
    """Dataset config with the minimal information needed to load a dataset"""

    indexColumn: Optional[str] = None
    isTimeseries: Optional[bool] = False

    @validator("isTimeseries")
    def none_is_false(cls, is_timeseries: Optional[bool]):
        """The database allows None for isTimeseires, but components only handle
        bool (true/false). We want to replace None with False.
        """
        if is_timeseries is None:
            return False
        return is_timeseries


# ──────────────────────────────────────────────────────────────────────────── #
@dataclass
class IndexMap:
    """This class provides the ability to map indexes for a 'virtual' dataset
    subset.

    When you download and reorder a subset of columns from a dataset (as Thor
    does), you loose the information of where the column of index 'n' in the
    original dataset is in the new smaller, reordered dataset.

    The following diagram shows the problem when downloading only the columns of
    indexes [6, 1, 4], in that order:

              0   1   2   3   4   5   6     │
            ┌───┬───┬───┬───┬───┬───┬───┐   │
            │ A │ B │ C │ D │ E │ F │ G │   │   original   virtual
            └───┴─┬─┴───┴───┴─┬─┴───┴─┬─┘   │
                  │   ┌───────┼───────┘     │       6 ◄─────► 0
                  └───┼───┐   │             │
                      ▼   ▼   ▼             │       1 ◄─────► 1
                      0   1   2             │
                    ┌───┬───┬───┐           │       4 ◄─────► 2
                    │ G │ A │ E │           │
                    └───┴───┴───┘           │

    We go from a set of 'original indexes' in the complete dataset, ([6, 1, 4]
    in this example) to a set of 'virtual indices' once the dataset is
    downloaded and reordered.

    This class allows methods to map an index between 'original' and 'virtual',
    both ways.
    """

    indexes: List[int]

    @property
    def virtual_indexes(self):
        """List of the virtual indexes for this index map"""
        return list(range(len(self.indexes)))

    def to_virtual(self, original_index: int) -> int:
        """Maps an original index to a virtual index

        Arguments:
            original_index (int):
                The original index to map

        Raises:
            ValueError: the given index is not valid for this instance

        Returns:
            virtual_index (int):
                The virtual index (where to find the column that has the
                original index in the smaller, reordered dataset).
        """
        if original_index not in self.indexes:
            raise ValueError(f"{original_index} is not in {self.indexes}")
        return self.indexes.index(original_index)

    def to_original(self, virtual_index: int) -> int:
        """Maps a virtual index to an original index

        Arguments:
            virtual_index (int):
                The virtual index to map

        Raises:
            ValueError: the given index is not valid for this instance

        Returns:
            original_index (int):
                The original index (where to find in the original dataset the
                column at the given index in the smaller dataset)
        """
        if not 0 <= virtual_index < len(self.indexes):
            raise ValueError(f"{virtual_index} is not in {self.virtual_indexes}")
        return self.indexes[virtual_index]


# ──────────────────────────────────────────────────────────────────────────── #
class DatasetAdapter:
    """Adapter handling all interactions on a dataset level with Thanos & Thor
    APIs.

    This class should have methods converting Thanos & other APIs concept into
    the models and concepts used as input for the machine learning processing
    pipeline (detection, preprocess, optimise).
    """

    LOGGER = logger

    def __init__(
        self,
        dataset_id: DatasetId,
        thanos_client: ThanosClient,
        thor_client: ThorClient,
    ):
        """The dataset adapter instance hides the dataset id at
        instanciation. One instance is dedicated to one dataset
        """
        self.dataset_id = dataset_id
        self.thor_client = thor_client
        self.thanos_client = thanos_client

    @property
    def dataset(self) -> Dataset:
        """Cached property returning the dataset for this adapter instance"""
        # Note: the caching is done on the client level
        return self.thanos_client.get_dataset(self.dataset_id)

    def download_dataset(self, path: PathLike, index_map: Optional[IndexMap] = None) -> DatasetConfig:
        """Downloads this instance's dataset to the given path. Returns the
        dataset's configuration (required information to work with the data).

        Downloads a dataset to the current path using this instance's
        dataset_id. The extension of the path can be any of [.csv, .parquet].

        Args:
            path (PathLike):
                string or pathlib.Path where the dataset should be saved
            index_map (Optional[IndexMap]):
                Only downloads the subset of indices provided in this index map.
                No value (i.e. None) means we're downloading the entire dataset.

        Returns:
            dataset_config (DatasetConfig):
                A pydantic model containing the minimal information to load and
                use the saved dataset file.
        """
        path = Path(path) if not isinstance(path, Path) else path
        indexes = tuple(index_map.indexes) if index_map is not None else None

        self.LOGGER.debug(
            "↳ [get] dataset %s\n         %s %s",
            self.dataset_id,
            path.name,
            "complete" if indexes is None else str(indexes),
        )
        dataset = self.thanos_client.get_dataset(self.dataset_id)
        file_model = self.thor_client.get_dataset_file(dataset.fileId, indexes)
        self.thor_client.download_dataset_file(dataset.fileId, path, indexes)

        original, cleaned = zip(*[(col.originalName, col.name) for col in file_model.analysis.columns])

        dataset_config = DatasetConfig(
            original_headers=original,
            cleaned_headers=cleaned,
            columnsCount=dataset.metadata.columnsCount,
            rowsCount=dataset.metadata.rowsCount,
        )
        if path.suffix == ".csv":
            dataset_config.delimiter = file_model.analysis.delimiter
            dataset_config.encoding = file_model.analysis.encoding
        return dataset_config

    def download_columns(self, path: PathLike, index_map: Optional[IndexMap] = None):
        """Downloads information about the columns of a dataset to the given
        path.

        Downloads a json containing a list of information for the selected (see
        indexes) columns of this instance's dataset id. If a subset of columns
        is selected (using an index map), applies a mapping of indexes so that
        the column info's indexes are accurate in the smaller, reordered
        dataset.

        See the documentation of `IndexMap` for more information.

        Args:
            path (PathLike):
                Path where the column information json should be saved
            index_map (IndexMap):
                Instance to map indexes between the original dataset (indexes
                used by the column info) and the downloaded dataset (that might
                have fewer and reordered columns, thus different indexes).
                None means that indexes do not need to be mapped (you're using
                the original dataset, so they map to themselve).

        Raises:
            IndexError: if the index map is inconsistent with the dataset
        """
        indexes = None if index_map is None else index_map.indexes
        columns_info = self.thanos_client.get_columns_info(self.dataset_id, indexes)

        # List[ColumnInfo] is a mutable object, so we change indexes inplace
        if index_map is not None:
            for column in columns_info:
                column.columnIndex = index_map.to_virtual(column.columnIndex)

        with open(path, "w") as fobj:
            json.dump([ColumnInfo.parse_obj(column).dict() for column in columns_info], fobj)
