"""This file provides an Adapter class for the `Preprocessed` concept in
Thanos. It should hide all API calls to Thanos and Thor
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from dataclasses import dataclass
from typing import List, Optional, Type, TypeVar, Union
from pathlib import Path
import json
import logging

# Dependencies
from pydantic.v1 import BaseModel, validator

# Module
from evoml_services.clients.thanos import ThanosClient
from evoml_services.clients.thor import ThorClient
from evoml_services.clients.thanos.models import (
    DatasetId,
    TrialId,
)

from evoml_api_models import ColumnInfo

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger("adapters.preprocessed")

# Type Aliases
PathLike = TypeVar("PathLike", str, Path)
T = TypeVar("T")  # pylint: disable=C0103
OList = Optional[List[T]]
# ---------------------------------------------------------------------------- #
# Public interface for this module
__all__ = ["PreprocessedId", "PreprocessedAdapter"]


# ──────────────────────────────────────────────────────────────────────────── #
@dataclass
class PreprocessedId:
    dataset_id: DatasetId
    column_index: int
    trial_id: TrialId


# ──────────────────────────────────────────────────────────────────────────── #
class PreprocessedAdapter:
    """Adapter handling all interactions on a preprocessed level with Thanos
    & Thor APIs.

    This class should have methods converting Thanos & other APIs concept into
    the models and concepts used as input for the machine learning processing
    pipeline (preprocess, optimise).
    """

    LOGGER = logger

    def __init__(
        self,
        preprocessed_id: PreprocessedId,
        thanos_client: ThanosClient,
        thor_client: ThorClient,
    ):
        """The preprocessed adapter instance hides the preprocessed id at
        instanciation. One instance is dedicated to one preprocessed file.
        """
        self.dataset_id = preprocessed_id.dataset_id
        self.label_index = preprocessed_id.column_index
        self.trial_id = preprocessed_id.trial_id
        self.thor_client = thor_client
        self.thanos_client = thanos_client
