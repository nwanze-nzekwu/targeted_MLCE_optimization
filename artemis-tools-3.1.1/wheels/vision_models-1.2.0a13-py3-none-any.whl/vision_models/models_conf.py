class VisionModelsConfig:
    default_model: str = "gpt-4-o-mini"
    default_big_model: str = "gpt-4-o"


models_conf_mgr = VisionModelsConfig()
