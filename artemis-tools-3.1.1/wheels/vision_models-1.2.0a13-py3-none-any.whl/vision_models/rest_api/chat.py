from pydantic import BaseModel

# Source imports
from vision_models.service.message import TimestampedConversationMessage


class ConversationResponse(BaseModel):
    messages: list[TimestampedConversationMessage]
