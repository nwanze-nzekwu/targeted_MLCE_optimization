from abc import ABC
from uuid import UUID, uuid4

from pydantic import ConfigDict, Field

# Source imports
from vision_models.models_conf import models_conf_mgr
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.llm import LLMType
from vision_models.service.message import (
    MessagePart,
    TaskInfo,
)


class BaseLLMRequest(BaseModelWithAlias, ABC):
    """Data structure for all LLM requests.

    The user_id is mandatory for all requests.
    """

    task_id: UUID = Field(default_factory=uuid4)
    store_message: bool = Field(default=False)
    model_type: LLMType = Field(default=LLMType(models_conf_mgr.default_model))
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "model_type": "gpt-3.5-turbo",
                    "store_message": False,
                }
            ]
        }
    )

    @property
    def prompts(self) -> list[dict[str, str]]:
        return [p.dict() for batch in self.get_message_parts() for p in batch]

    def get_message_parts(self) -> list[list[MessagePart]]:
        # outer list is for batch
        # inner list is for messages
        raise NotImplementedError


class BaseLLMResponse(BaseModelWithAlias, ABC):
    """Data structure for all LLM responses."""

    task_id: UUID
    task_info: TaskInfo | None = None

    def get_message_parts(self) -> list[MessagePart]:
        raise NotImplementedError

    @property
    def completions(self) -> list[str]:
        raise NotImplementedError
