# Source imports
from vision_models.rest_api.basellm import BaseLLMRequest
from vision_models.service.base_data_types import BaseModelWithAlias


class PromptSuggestionRequest(BaseLLMRequest):
    context: str = "This is a chat bot."
    number: int = 5


class PromptSuggestion(BaseModelWithAlias):
    name: str
    prompt: str


class PromptSuggestionResponse(BaseModelWithAlias):
    suggestions: list[PromptSuggestion]
