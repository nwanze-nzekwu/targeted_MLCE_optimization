# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.rerank import (
    RerankDetails,
    RerankItemResponse,
    RerankModelEnum,
)


class RerankRequest(BaseModelWithAlias):
    model_name: RerankModelEnum
    documents: list[str]
    query: str


class RerankResponse(BaseModelWithAlias):
    results: list[RerankItemResponse]


class RerankModelListResponse(BaseModelWithAlias):
    """Response model for a list of models."""

    models: list[RerankDetails]
