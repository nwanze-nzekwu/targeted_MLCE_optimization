# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.llm import LLMType
from vision_models.service.tokenize import Token, TokenizerEnum


class TokeniseRequest(BaseModelWithAlias):
    model_name: TokenizerEnum | None = None
    llm_name: LLMType | None = None
    query: str


class TokeniseBatchRequest(BaseModelWithAlias):
    model_name: TokenizerEnum | None = None
    llm_name: LLMType | None = None
    queries: list[str]


class TokeniseResponse(BaseModelWithAlias):
    results: list[Token]


class TokeniseCountResponse(BaseModelWithAlias):
    count: int


class TokeniseBatchCountResponse(BaseModelWithAlias):
    counts: list[int]
