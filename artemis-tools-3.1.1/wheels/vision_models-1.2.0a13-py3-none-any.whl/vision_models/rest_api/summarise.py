from pydantic import Field

# Source imports
from vision_models.models_conf import models_conf_mgr
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.llm import LLMRole, LLMType
from vision_models.service.message import LLMConversationMessage


class LLMSummariseDocument(BaseModelWithAlias):
    content: str

    def to_llm_message(self) -> LLMConversationMessage:
        return LLMConversationMessage(role=LLMRole.USER, content=f"Summarise the following text: {self.content}")


class LLMSummariseRequest(BaseModelWithAlias):
    model_type: LLMType = Field(default=LLMType(models_conf_mgr.default_model))
    document: LLMSummariseDocument


class LLMSummariseResponse(BaseModelWithAlias):
    document: LLMSummariseDocument
