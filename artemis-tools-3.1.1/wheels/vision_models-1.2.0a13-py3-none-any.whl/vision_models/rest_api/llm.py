from typing import Literal

from pydantic import Field

# Source imports
from vision_models.models_conf import models_conf_mgr
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.llm import (
    NOT_PROVIDED,
    Capability,
    LLMDetails,
    LLMModelPatchInfo,
    LLMType,
)


class ModelListResponse(BaseModelWithAlias):
    """Response model for getting the list of available models."""

    models: list[LLMDetails]
    default: LLMType | None = LLMType(models_conf_mgr.default_model)
    default_big: LLMType | None = LLMType(models_conf_mgr.default_big_model)
    default_scoring_llms: list[LLMType] = Field(description="default LLMs for scoring")
    default_code_generation_llms: list[LLMType] = Field(description="default LLMs for code generation")
    default_chat_llm: LLMType | None = Field(default=None, description="default LLM for chat")
    default_pair_coder_llm: LLMType | None = Field(default=None, description="default LLM for pair coding")
    default_extraction_llm: LLMType | None = Field(default=None, description="default LLM for extraction")
    default_pull_request_llm: LLMType | None = Field(default=None, description="default LLM for pull request")
    default_report_generation_llm: LLMType | None = Field(default=None, description="default LLM for report generation")


class ModelStatusDetails(BaseModelWithAlias):
    """Response model for the status of a single model."""

    is_available: bool
    error_message: str | None = None
    error_type: str | None = None


class ModelStatusListResponse(BaseModelWithAlias):
    """Response model for the statuses of all supported models."""

    statuses: dict[LLMType, ModelStatusDetails]


class LLMModelPatchInfoListRequest(BaseModelWithAlias):
    """Model for enable/disable patch info for multiple llms as well as default llms for different tasks."""

    info: list[LLMModelPatchInfo] = Field(default_factory=list, description="list of llm patch information")
    default_scoring_llms: list[LLMType] | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default LLMs for scoring"
    )
    default_code_generation_llms: list[LLMType] | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default LLMs for code generation"
    )
    default_chat_llm: LLMType | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default LLM for chat"
    )
    default_pair_coder_llm: LLMType | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default LLM for pair coding"
    )
    default_extraction_llm: LLMType | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default LLM for extraction"
    )
    default_pull_request_llm: LLMType | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default LLM for pull request"
    )
    default_report_generation_llm: LLMType | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default LLM for report generation"
    )

    class Config:
        extra = "forbid"


class LLMCapabilitiesRequest(BaseModelWithAlias):
    """Request model for getting the capabilities of a model."""

    capabilities: list[Capability] = Field(
        default_factory=list, description="list of capabilities to check for the model"
    )
    is_large: bool | None = Field(
        description="whether to model contains over 100b parameters",
        default=None,
    )


class LLMCapabilitiesResponse(BaseModelWithAlias):
    """Response model for the capabilities of a model."""

    models: list[LLMDetails]
