from typing import TypeVar

from pydantic import BaseModel

# Source imports
from vision_models.rest_api.inference import LLMInferenceRequest
from vision_models.service.ai.tool_presets.artemis import (
    ArtemisToolPresetResults,
)
from vision_models.service.ai.tool_presets.google import (
    GoogleToolPresetResults,
)
from vision_models.service.ai.tool_presets.webscrape import (
    WebscrapeToolPresetResults,
)
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.llm import LLMType
from vision_models.service.message import LLMConversationMessage
from vision_models.service.source import SourceDetails, SourcesConfig, SourceType

OutputT = TypeVar("OutputT", bound=BaseModel)


class SourceListResponse(BaseModelWithAlias):
    """Response model for a list of models."""

    sources: list[SourceDetails]


# ----------------------------------- Gather Sources ----------------------------------


class SourceRequest(BaseModelWithAlias):
    model_type: LLMType
    message: LLMConversationMessage
    sources: SourcesConfig

    def to_inference_request(self, sources: bool = False) -> LLMInferenceRequest:
        return LLMInferenceRequest(
            model_type=self.model_type,
            messages=[self.message],
            sources=self.sources if sources else None,
        )


class RagSearchSourceResponse(BaseModelWithAlias):
    name: SourceType
    data: ArtemisToolPresetResults


class WebSearchSourceResponse(BaseModelWithAlias):
    name: SourceType
    data: GoogleToolPresetResults


class ScrapedWebSearchSourceResponse(BaseModelWithAlias):
    name: SourceType
    data: WebscrapeToolPresetResults


class SourceResponse(BaseModelWithAlias):
    code: RagSearchSourceResponse | None = None
    web: WebSearchSourceResponse | None = None
    scraped: ScrapedWebSearchSourceResponse | None = None
