from pydantic import Field

# Source imports
from vision_models.service.base_data_types import (
    BaseModelWithAlias,
    PaginatedResponseModel,
)


class BalanceResponse(BaseModelWithAlias):
    ext_user_id: str = Field(description="external user id")
    balance: float = Field(description="money available")


class PaginatedBalanceResponse(PaginatedResponseModel[BalanceResponse]): ...
