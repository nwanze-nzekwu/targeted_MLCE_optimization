import uuid
from typing import Literal, Optional, Annotated
from uuid import UUID

from artemis_tools.models.embeddings import EmbeddingInfo
from artemis_tools.models.generic import Language
from pydantic import BaseModel, Field
from typing_extensions import Self

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.embedding import (
    CodeSearchResult,
    EmbeddingDetails,
    EmbeddingModelEnum,
    EmbeddingPresetDetails,
    EmbeddingPresetEnum,
    SimilarityEmbedType,
    TextSearchResult,
)
from vision_models.service.llm import NOT_PROVIDED


class BaseEmbeddingRequest(BaseModelWithAlias):
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))


class EmbedQueryRequest(BaseEmbeddingRequest):
    embed_preset: EmbeddingPresetEnum
    query: str

class FileMetadata(BaseModel):
    filename: str | None

class FileContent(BaseModel):
    file_metadata: FileMetadata
    file_data: bytes

class EmbedFileRequest(BaseEmbeddingRequest):
    original_file_path: str | None = None
    project_id: str
    embedding_id: str
    language: Language | None = None
    embed_preset: EmbeddingPresetEnum
    file_to_embed: FileContent | None = Field(default=None)


class EmbedFileResponse(BaseModelWithAlias): ...


class EmbedQueryResponse(BaseModelWithAlias):
    embeddings: EmbeddingInfo


class EmbedDocumentRequest(BaseEmbeddingRequest):
    """Model for an embed document request."""

    text: str
    name: str
    project_id: str
    embedding_id: str
    embed_preset: EmbeddingPresetEnum
    language: Language | None = Field(None)


class EmbeddingModelListResponse(BaseModelWithAlias):
    """Response model for a list of models."""

    models: list[EmbeddingDetails]
    default_embedding_model: EmbeddingModelEnum | None = None
    disabled_embedding_models: list[EmbeddingModelEnum] = Field(
        default_factory=list, description="list of disabled embedding models"
    )


class EmbeddingModelPresetResponse(BaseModelWithAlias):
    """Response model for a list of models."""

    presets: list[EmbeddingPresetDetails]


class EstimateCostRequest(BaseEmbeddingRequest):
    """Request model for estimating the cost of embedding a text.

    Attributes:
        text (str): The input text to be embedded.
        embedding_model (str): The name or identifier of the embedding model to be used.
    """

    text: str
    embedding_model: EmbeddingModelEnum


class EstimateCostResponse(BaseModelWithAlias):
    """Response model for the estimated cost of embedding a text.

    Attributes:
        cost (float): The estimated cost of embedding the provided text using the specified model.
    """

    cost: float


class SimilarityRequest(BaseEmbeddingRequest):
    model_name: EmbeddingModelEnum
    text: str
    ref_text: str
    embed_type: SimilarityEmbedType = SimilarityEmbedType.TEXT


class SimilarityResponse(BaseModelWithAlias):
    score: float


class GetProjectIndexesRequest(BaseModelWithAlias):
    project_ids: list[UUID]


class GetProjectIndexesResponse(BaseModelWithAlias):
    indexes: list[str]


class SearchResultsResponse(BaseModelWithAlias):

    results: list[CodeSearchResult | TextSearchResult] = Field(default_factory=list)

    def __iadd__(self, other: "SearchResultsResponse") -> Self:
        self.results += other.results
        return self


class EmbeddingModelPatchInfo(BaseModelWithAlias):
    """Model for enable/disable patch info for embedding models."""

    enabled: bool
    model: EmbeddingModelEnum


class EmbeddingModelPatchInfoListRequest(BaseModelWithAlias):
    """Model for enable/disable patch info for multiple embedding models as well as default models."""

    info: list[EmbeddingModelPatchInfo] = Field(
        default_factory=list, description="list of embedding model patch information"
    )
    default_embedding_model: EmbeddingModelEnum | None | Literal["NOT_PROVIDED"] = Field(
        default=NOT_PROVIDED, description="default embedding model"
    )

    class Config:
        extra = "forbid"
