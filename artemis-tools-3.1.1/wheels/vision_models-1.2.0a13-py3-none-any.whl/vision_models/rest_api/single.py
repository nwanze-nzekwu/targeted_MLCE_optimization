from pydantic import ConfigDict
from typing_extensions import override

# Source imports
from vision_models.rest_api.basellm import (
    BaseLLMRequest,
    BaseLLMResponse,
)
from vision_models.service.llm import LLMRole
from vision_models.service.message import MessagePart


class LLMSingleInferenceRequest(BaseLLMRequest):
    """Data structure of an information group."""

    user: str
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "model_type": "gpt-3.5-turbo",
                    "store_message": False,
                    "user": "Hello",
                }
            ]
        }
    )

    @override
    def get_message_parts(self) -> list[list[MessagePart]]:
        return [[MessagePart(role=LLMRole.USER, content=self.user)]]


class LLMSystemSingleInferenceRequest(LLMSingleInferenceRequest):
    """Data structure of an information group."""

    system: str
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "model_type": "gpt-3.5-turbo",
                    "store_message": False,
                    "user": "Hello",
                    "system": "You are a bot.",
                }
            ]
        }
    )

    @override
    def get_message_parts(self) -> list[list[MessagePart]]:
        return [
            [
                MessagePart(role=LLMRole.USER, content=self.user),
                MessagePart(role=LLMRole.SYSTEM, content=self.system),
            ]
        ]


class CodeAIResponse(BaseLLMResponse):
    """Data structure of an information group."""

    result: str
