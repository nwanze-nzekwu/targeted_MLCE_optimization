from typing import Any

from pydantic import ConfigDict, Field, field_validator
from typing_extensions import override

# Source imports
from vision_models.models_conf import models_conf_mgr
from vision_models.rest_api.basellm import BaseLLMRequest, BaseLLMResponse
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.embedding import EmbeddingConfig, EmbeddingModelEnum
from vision_models.service.llm import LLMType
from vision_models.service.message import (
    BatchErrorPart,
    BatchPart,
    LLMConversationMessage,
    MessageDict,
    MessagePart,
)
from vision_models.service.source import SourcesConfig
from vision_models.service.tool import LLMTool

# ----------------------------------------------- Inference --------------------------------------------


class ExtraParams(BaseModelWithAlias):
    llm_temperature: float | None = None
    timeout_s: int | None = None
    force_tool_call: bool | None = None


class LLMInferenceRequest(BaseLLMRequest):
    """Data structure of the general inference request.

    This consists of:
    - A sequence of messages (most recent last)
    - Sources config (optional, list of source configs)
    - Embeddings config (optional)
    """

    messages: list[LLMConversationMessage]
    tools: list[LLMTool] | None = Field(default=None)
    sources: SourcesConfig | None = Field(default=None)
    embeddings: EmbeddingConfig | None = Field(default=None)
    extra_params: ExtraParams = Field(default_factory=ExtraParams)

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "user_id": "066de609-b04a-4b30-b46c-32537c7f1f6e",
                    "model_type": "gpt-3.5-turbo",
                    "messages": [
                        {"role": "system", "content": "You are a bot."},
                        {"role": "user", "content": "Hello"},
                    ],
                    "store_message": True,
                }
            ]
        }
    )

    @field_validator("tools")
    @classmethod
    def validate_tools(cls, tools: list[LLMTool] | None) -> list[LLMTool] | None:
        return tools or None

    @override
    def get_message_parts(self) -> list[list[MessagePart]]:
        return [[message.get_message_part() for message in self.messages]]

    @property
    def messages_dict(self) -> list[MessageDict]:
        return [{"content": msg.content, "role": msg.role.value} for msg in self.messages]

    @property
    def last_message(self) -> str:
        if not self.messages:
            raise AttributeError("No messages in the request")
        return self.messages[-1].content


class LLMResponse(BaseLLMResponse):
    """Data structure of an information group."""

    messages: list[LLMConversationMessage]

    @property
    @override
    def completions(self) -> list[str]:
        return [self.messages[-1].content]

    @property
    def last_message(self) -> LLMConversationMessage:
        return self.messages[-1]


# ------------------------------------------ Structured Infererence ----------------------------------------


class LLMAskInferenceRequest(LLMInferenceRequest):
    """Inference request with extra include history attribute"""

    with_history: bool = True


class LLMStructuredInferenceRequest(LLMInferenceRequest):
    """Structured."""

    response_schema: dict[str, object] | None = None
    example: dict[str, Any] | None = None


class LLMStructuredResponse(BaseLLMResponse):
    """Data structure of an information group."""

    messages: list[LLMConversationMessage]
    output: dict[str, Any] | None

    @property
    @override
    def completions(self) -> list[str]:
        return [self.messages[-1].content]

    @property
    def last_message(self) -> LLMConversationMessage:
        return self.messages[-1]


# -------------------------------------------- Batch Inference ------------------------------------------------


class BatchRequest(BaseLLMRequest):
    parts: list[BatchPart]
    sources: SourcesConfig | None = Field(default=None)
    with_history: bool = True
    extra_params: ExtraParams = Field(default_factory=ExtraParams)
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "parts": [
                        {
                            "id": "1",
                            "messages": [
                                {"role": "system", "content": "You are a bot."},
                                {
                                    "role": "user",
                                    "content": "Hello",
                                },
                            ],
                        },
                        {
                            "id": "2",
                            "messages": [
                                {"role": "system", "content": "You are a bot."},
                                {
                                    "role": "user",
                                    "content": "World",
                                },
                            ],
                        },
                    ]
                },
            ]
        }
    )

    @override
    def get_message_parts(self) -> list[list[MessagePart]]:
        return [part.get_batch_message_part() for part in self.parts]


class BatchResponse(BaseLLMResponse):
    parts: list[BatchPart]
    errors: list[BatchErrorPart] | None = Field(default_factory=list)

    @property
    @override
    def completions(self) -> list[str]:
        return [part.messages[-1].content for part in self.parts]


# ------------------------------------- Structured Batch Inference ------------------------------------------


class StructuredBatchRequestPart(BatchPart):
    response_schema: dict[str, Any] | None = None
    example: dict[str, Any] | None = None


class StructuredBatchRequest(BaseLLMRequest):
    model_type: LLMType = Field(default=models_conf_mgr.default_model)
    parts: list[StructuredBatchRequestPart]
    sources: SourcesConfig | None = Field(default=None)
    extra_params: ExtraParams = Field(default_factory=ExtraParams)


class StructuredBatchResponsePart(BatchPart):
    output: dict[str, Any] | None


class StructuredBatchResponse(BaseLLMResponse):
    parts: list[StructuredBatchResponsePart]
    errors: list[BatchErrorPart] | None = Field(default_factory=list)

    @property
    @override
    def completions(self) -> list[str]:
        return [part.messages[-1].content for part in self.parts]
