import uuid
from datetime import datetime
from enum import StrEnum

from pydantic import ConfigDict, Field, field_validator
from typing_extensions import override

# Source imports
from vision_models.service.mongo import (
    MongoBaseModel,
    MongoCollection,
)


class MongoTransactionBase(MongoBaseModel):
    collection = MongoCollection.TRANSACTIONS.value


class TaskType(StrEnum):
    PROMPT = "prompt"
    EMBEDDING = "embedding"
    COMPLETION = "completion"
    TOPUP = "topup"


class Transaction(MongoTransactionBase):
    ext_user_id: str
    task_id: str
    expense: float = Field(description="money spent")
    model: str = Field(description="model used")
    task_type: TaskType = Field(description="task type")
    timestamp: datetime = Field(default_factory=datetime.now)

    @field_validator("ext_user_id")
    @classmethod
    def validate_fk_ids(cls, v: uuid.UUID) -> str:
        return str(v)

    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={
            "example": {
                "extUserId": "066de609-b04a-4b30-b46c-32537c7f1f6e",
                "taskId": "066de609-b04a-4b30-b46c-32537c7f1f6e",
                "taskType": "prompt",
                "expense": 100.0,
                "model": "model_name",
            }
        },
    )

    @override
    def __hash__(self) -> int:
        if self.pk_id is None:
            raise ValueError("Transaction is only hashable when in db")
        return self.pk_id.__hash__()


class MongoBalanceBase(MongoBaseModel):
    collection = MongoCollection.BALANCES.value


class Balance(MongoBalanceBase):
    ext_user_id: str
    balance: float = Field(description="money available")

    @field_validator("ext_user_id")
    @classmethod
    def validate_fk_ids(cls, v: uuid.UUID) -> str:
        return str(v)

    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={
            "example": {
                "extUserId": "066de609-b04a-4b30-b46c-32537c7f1f6e",
                "balance": 100.0,
            }
        },
    )

    @override
    def __hash__(self) -> int:
        if self.pk_id is None:
            raise ValueError("Balance is only hashable when in db")
        return self.pk_id.__hash__()
