import hashlib
from typing import Any

from pydantic import ConfigDict, Field
from typing_extensions import override

# Source imports
from vision_models.service.mongo import (
    MongoBaseModel,
    MongoCollection,
)


class MongoTextBase(MongoBaseModel):
    collection = MongoCollection.TEXTS.value


class Text(MongoTextBase):
    """Text model.

    This is a text/code entry associated with a qdrant entry
    """

    entry: str = Field(...)
    entry_id: str = Field(..., description="entry id for qdrant")
    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={
            "example": {
                "message": "hello world",
            }
        },
    )

    @classmethod
    def from_string(cls, entry: str) -> "Text":
        return cls(entry=entry, entry_id=cls.get_string_hash(entry))

    @override
    def __hash__(self) -> int:
        try:
            return int(self.entry_id, 16)
        except Exception:
            return hash(self.entry)

    @override
    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, Text):
            return False
        return self.entry_id == other.entry_id

    @staticmethod
    def get_string_hash(s: str) -> str:
        return hashlib.md5(s.encode()).hexdigest()
