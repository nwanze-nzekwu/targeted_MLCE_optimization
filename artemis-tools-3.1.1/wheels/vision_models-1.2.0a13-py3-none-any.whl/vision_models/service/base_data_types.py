"""In this module a base class is implemented with generic methods and properties."""

# ────────────────────────────────────────── imports ────────────────────────────────────────── #

from typing import TYPE_CHECKING, Any, Dict, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_pascal
from pydantic.main import IncEx
from typing_extensions import override

if TYPE_CHECKING:
    from pydantic.typing import DictStrAny

# ───────────────────────────────────────────────────────────────────────────────────────────── #
#                                        Base Model Class                                       #
# ───────────────────────────────────────────────────────────────────────────────────────────── #


DocTypeT = TypeVar("DocTypeT", bound=BaseModel)


def to_lower_camel(value: str) -> str:
    # Helper function to convert to lower camel case
    camel_value = to_pascal(value)
    return camel_value[0].lower() + camel_value[1:] if camel_value else camel_value


class BaseModelWithAlias(BaseModel):
    """Base Model with enabled alias.

    Whether an aliased field may be populated by its name as given by the model attribute, as well as the alias
    """

    @override
    def dict(
        self,
        *,
        include: "AbstractSetIntStr | MappingIntStrAny | None" = None,
        exclude: "AbstractSetIntStr | MappingIntStrAny | None" = None,
        by_alias: bool = True,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = True,
    ) -> "DictStrAny":
        # overwrite `exclude_none` to True
        # overwrite `by_alias` to True
        return super().dict(
            include=include,
            exclude=exclude,
            by_alias=by_alias,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
        )

    @override
    def model_dump(
        self,
        *,
        mode: Literal["json", "python"] | str = "python",
        include: IncEx | None = None,
        exclude: IncEx | None = None,
        context: Any | None = None,
        by_alias: bool = True,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
        round_trip: bool = False,
        warnings: bool | Literal["none", "warn", "error"] = True,
        serialize_as_any: bool = False,
    ) -> Dict[str, Any]:  # type: ignore[reportDeprecated]
        return super().model_dump(
            mode=mode,
            include=include,
            exclude=exclude,
            context=context,
            by_alias=by_alias,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
            round_trip=round_trip,
            warnings=warnings,
            serialize_as_any=serialize_as_any,
        )

    @override
    def model_dump_json(
        self,
        *,
        indent: int | None = None,
        include: IncEx | None = None,
        exclude: IncEx | None = None,
        context: Any | None = None,
        by_alias: bool = True,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
        round_trip: bool = False,
        warnings: bool | Literal["none", "warn", "error"] = True,
        serialize_as_any: bool = False,
    ) -> str:
        return super().model_dump_json(
            indent=indent,
            include=include,
            exclude=exclude,
            context=context,
            by_alias=by_alias,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
            round_trip=round_trip,
            warnings=warnings,
            serialize_as_any=serialize_as_any,
        )

    model_config = ConfigDict(
        alias_generator=to_lower_camel,
        # Convert snake_case to camelCase for JSON serialization
        populate_by_name=True,
        # Allows setting values by both the original name and the alias
        arbitrary_types_allowed=True,  # Allows arbitrary (non-Pydantic) types
        protected_namespaces=(),
    )


class NullableBaseModelWithAlias(BaseModelWithAlias):
    @override
    def dict(
        self,
        *,
        include: "AbstractSetIntStr | MappingIntStrAny | None" = None,
        exclude: "AbstractSetIntStr | MappingIntStrAny | None" = None,
        by_alias: bool = False,
        skip_defaults: bool | None = None,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
    ) -> "DictStrAny":
        # overwrite `exclude_none` to False
        return super().dict(
            include=include,
            exclude=exclude,
            by_alias=by_alias,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=False,
        )


class ErrorMessage(BaseModelWithAlias):
    content: str = Field(..., description="Error message")


class ResultsStatsModel(BaseModelWithAlias):
    mean: float = Field(..., description="Mean value")
    mean_adjusted: float = Field(..., description="Mean adjusted value")
    std: float = Field(..., description="Standard deviation")
    min: float = Field(..., description="Minimum value")
    max: float = Field(..., description="Maximum value")


class PaginationRequestModel(BaseModelWithAlias):
    """Data structure of an information group."""

    page: int = Field(1, description="Page number")
    per_page: int = Field(10, description="Number of items per page")


class PaginatedResponseModel(BaseModelWithAlias, Generic[DocTypeT]):
    """Data structure of an information group."""

    docs: list[DocTypeT | dict[str, Any]] = Field(..., description="List of items")
    total_docs: int = Field(..., description="Total number of items")
    limit: int = Field(10, description="Number of items per page")
    total_pages: int = Field(..., description="Number of items per page")
    has_prev_page: bool = Field(..., description="Whether previous page exists")
    has_next_page: bool = Field(..., description="Whether next page exists")
    page: int = Field(..., description="Number of page")
    paging_counter: int = Field(..., description="Counter of page")
    prev_page: int | None = Field(None, description="Number of previous page")
    next_page: int | None = Field(None, description="Number of next page")
