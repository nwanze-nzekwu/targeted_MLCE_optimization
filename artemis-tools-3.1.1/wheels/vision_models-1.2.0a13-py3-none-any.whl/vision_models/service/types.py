from pydantic import BaseModel

# Source imports
from vision_models.rest_api.inference import (
    LLMInferenceRequest,
    LLMStructuredInferenceRequest,
)
from vision_models.service.ai.llm_presets import QueryGenResponse
from vision_models.service.ai.sources.webscrape import (
    WebscrapeInput,
    WebscrapeOutput,
)
from vision_models.service.ai.tool_presets.artemis import (
    ArtemisToolPresetResults,
)
from vision_models.service.ai.tool_presets.google import (
    GoogleSearchRequest,
    GoogleToolPresetResults,
)
from vision_models.service.ai.tool_presets.webscrape import (
    WebscrapeToolPresetResults,
)
from vision_models.service.embedding import EmbeddingSearchRequest
from vision_models.service.source import SourceSelectionInfo
from vision_models.service.streaming import (
    AgentToolIO,
    LLMSSEChunk,
    SingleStreamResponse,
)

LLMSSEChunkAny = (
    LLMSSEChunk[EmbeddingSearchRequest]
    | LLMSSEChunk[ArtemisToolPresetResults]
    | LLMSSEChunk[GoogleToolPresetResults]
    | LLMSSEChunk[WebscrapeToolPresetResults]
    | LLMSSEChunk[GoogleSearchRequest]
    | LLMSSEChunk[LLMInferenceRequest]
    | LLMSSEChunk[LLMStructuredInferenceRequest]
    | LLMSSEChunk[QueryGenResponse]
    | LLMSSEChunk[WebscrapeInput]
    | LLMSSEChunk[WebscrapeOutput]
    | LLMSSEChunk[SourceSelectionInfo]
    | LLMSSEChunk[SingleStreamResponse]
    | LLMSSEChunk[AgentToolIO]
    | LLMSSEChunk[BaseModel]
)
