from pydantic import Field

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias


class UserInfo(BaseModelWithAlias):
    id: str = Field(description="Token User Id.")
    type: str = Field(description="Type of ownership.")
    token: str = Field(description="Token.")

    @property
    def is_admin(self):
        return self.type == "admin"
