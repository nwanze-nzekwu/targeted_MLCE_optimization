from collections.abc import Sequence

# Source imports
from vision_models.service.ai.sources.enums import LLMToolEnum
from vision_models.service.base_data_types import BaseModelWithAlias


class ToolPresetResult(BaseModelWithAlias):
    index: int
    similarity: float

    def to_llm_message(self) -> str: ...

    @property
    def llm_tool_enum(self) -> LLMToolEnum: ...


class ToolPresetResults(BaseModelWithAlias):
    results: Sequence[ToolPresetResult]
