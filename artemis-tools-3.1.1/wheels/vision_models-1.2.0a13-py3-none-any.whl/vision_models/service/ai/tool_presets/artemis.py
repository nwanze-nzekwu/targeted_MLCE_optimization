from typing_extensions import Self, override

# Source imports
from vision_models.service.ai.sources.enums import LLMToolEnum
from vision_models.service.ai.tool_presets.base import ToolPresetResult
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.embedding import CodeSearchResult, TextSearchResult


class ArtemisToolPresetResult(ToolPresetResult):
    file_path: str
    content: str
    node_type: str
    file: str
    language: str
    project_id: str
    part: int

    @classmethod
    def from_search_result(cls, result: CodeSearchResult | TextSearchResult, index: int) -> Self:
        return cls(
            file_path=result.metadata.file,
            content=result.text,
            node_type=(result.metadata.node_type if isinstance(result, CodeSearchResult) else ""),
            file=result.metadata.file,
            language=result.metadata.language,
            project_id=result.metadata.project_id,
            part=result.metadata.part,
            index=index,
            similarity=result.similarity,
        )

    @override
    def to_llm_message(self) -> str:
        return f"{self.index}. ```{self.content}```"

    @property
    @override
    def llm_tool_enum(self) -> LLMToolEnum:
        return LLMToolEnum.ARTEMIS_SEARCH


class ArtemisToolPresetResults(BaseModelWithAlias):
    results: list[ArtemisToolPresetResult] = []
