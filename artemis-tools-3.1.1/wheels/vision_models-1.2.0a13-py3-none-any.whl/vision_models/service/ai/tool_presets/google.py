from typing_extensions import Self, override

# Source imports
from vision_models.service.ai.sources.enums import LLMToolEnum
from vision_models.service.ai.sources.google import GoogleLink
from vision_models.service.ai.tool_presets.base import ToolPresetResult
from vision_models.service.base_data_types import BaseModelWithAlias


class GoogleSearchRequest(BaseModelWithAlias):
    query: str


class GoogleToolPresetResult(ToolPresetResult):
    title: str
    link: str
    snippet: str

    @classmethod
    def from_google_model(cls, google_model: GoogleLink, index: int) -> Self:
        return cls(
            title=google_model.title,
            link=google_model.link,
            snippet=google_model.snippet,
            similarity=google_model.similarity,
            index=index,
        )

    @override
    def to_llm_message(self) -> str:
        return f"[{self.index}]:{self.snippet}"

    @property
    @override
    def llm_tool_enum(self) -> LLMToolEnum:
        return LLMToolEnum.GOOGLE_SEARCH


class GoogleToolPresetResults(BaseModelWithAlias):
    results: list[GoogleToolPresetResult] = []
