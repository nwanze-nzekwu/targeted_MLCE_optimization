from typing_extensions import override

# Source imports
from vision_models.service.ai.sources.enums import LLMToolEnum
from vision_models.service.ai.tool_presets.google import GoogleToolPresetResult
from vision_models.service.base_data_types import BaseModelWithAlias


class WebscrapeToolPresetResult(GoogleToolPresetResult):
    content: str
    scraped: bool

    @override
    def to_llm_message(self) -> str:
        if self.scraped:
            return f"[{self.index}]:{self.content}"
        return f"[{self.index}]:{self.snippet}"

    @property
    @override
    def llm_tool_enum(self) -> LLMToolEnum:
        return LLMToolEnum.WEBSCRAPE


class WebscrapeToolPresetResults(BaseModelWithAlias):
    results: list[WebscrapeToolPresetResult] = []
