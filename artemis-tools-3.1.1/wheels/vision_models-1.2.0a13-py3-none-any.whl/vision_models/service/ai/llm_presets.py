"""Preset Responses.

A preset is defined as a fixed pipeline of tools, and the output of such a preset can be custom defined here.
"""

from typing import Literal, cast

from artemis_tools.conf.base_data_types import BaseModelWithSchema
from pydantic import ConfigDict, ValidationInfo, field_validator


class QueryGenResponse(BaseModelWithSchema):
    query: str
    mode: Literal["any", "code", "text"]
    model_config = ConfigDict(extra="ignore")

    @field_validator("mode", mode="before")
    def validate_mode(cls, v: str, info: ValidationInfo) -> Literal["any", "code", "text"]:
        if "mode" not in info.data:
            return "any"
        if v in ["any", "code", "text"]:
            v = cast(Literal["any", "code", "text"], v)
            return v
        return "any"
