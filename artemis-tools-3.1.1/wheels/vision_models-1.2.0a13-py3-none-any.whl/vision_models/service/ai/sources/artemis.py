from pydantic import BaseModel
from typing_extensions import Self

# Source imports
from vision_models.service.source import (
    SingleSourceConfig,
    SourceType,
)


class ArtemisParams(BaseModel):
    project_ids: list[str] = []
    threshold: float = 0.5
    user_id: str


class ArtemisConfig(BaseModel):
    name: SourceType = SourceType.artemis
    params: ArtemisParams

    @classmethod
    def from_source(cls, source: SingleSourceConfig, user_id: str) -> Self:
        return cls(name=source.name, params=ArtemisParams(user_id=user_id, **source.params))
