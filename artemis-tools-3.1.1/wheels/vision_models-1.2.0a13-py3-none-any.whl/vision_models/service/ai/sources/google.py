from pydantic import BaseModel, field_validator
from typing_extensions import Self, TypedDict

# Source imports
from vision_models.service.embedding import EmbeddingConfig, EmbeddingModelEnum
from vision_models.service.source import SingleSourceConfig, SourceType


class SerializedGoogleLink(TypedDict):
    title: str
    link: str
    snippet: str
    similarity: float


class GoogleLink(BaseModel):
    title: str
    link: str
    snippet: str
    similarity: float = 0.0


class GoogleSearchResponse(BaseModel):
    results: list[GoogleLink]

    @field_validator("results")
    @classmethod
    def validate_results(cls, v: list[SerializedGoogleLink]) -> list[SerializedGoogleLink]:
        if len(v) == 1 and "Result" in v[0]:
            return []
        return v


class GoogleParams(BaseModel):
    limit: int = 3
    embedding_model: EmbeddingModelEnum


class GoogleConfig(BaseModel):
    name: SourceType = SourceType.google
    params: GoogleParams

    @classmethod
    def from_source(cls, source: SingleSourceConfig, embedding: EmbeddingConfig) -> Self:
        return cls(
            name=source.name,
            params=GoogleParams(embedding_model=embedding.model, **source.params),
        )
