from typing import Any

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.source import SourceType
