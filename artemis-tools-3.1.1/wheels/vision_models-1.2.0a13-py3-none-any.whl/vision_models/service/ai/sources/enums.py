from enum import StrEnum


class LLMToolEnum(StrEnum):
    """LLM tool Enum.

    Tells the front-end what tool is running.
    """

    QUERY_GEN = "query-gen"
    ARTEMIS_SEARCH = "artemis-search"
    ARTEMIS_PROJECT_SEARCH = "artemis-project-search"
    GOOGLE_SEARCH = "google-search"
    CHAT = "chat"
    FILTER = "filter"
    WEBSCRAPE = "webscrape"
