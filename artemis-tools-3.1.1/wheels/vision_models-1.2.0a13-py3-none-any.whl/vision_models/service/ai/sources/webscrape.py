from pydantic import BaseModel
from typing_extensions import Self

# Source imports
from vision_models.service.embedding import EmbeddingConfig, EmbeddingModelEnum
from vision_models.service.source import SingleSourceConfig, SourceType


class WebscrapeInput(BaseModel):
    query: str
    url: str


class WebscrapeOutput(BaseModel):
    response: int
    text: str


class WebscrapeParams(BaseModel):
    embedding_model: EmbeddingModelEnum


class WebscrapeConfig(BaseModel):
    name: SourceType = SourceType.webscrape
    params: WebscrapeParams

    @classmethod
    def from_source(cls, source: SingleSourceConfig, embedding: EmbeddingConfig) -> Self:
        return cls(
            name=source.name,
            params=WebscrapeParams(embedding_model=embedding.model, **source.params),
        )
