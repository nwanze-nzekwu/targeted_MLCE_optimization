from enum import StrEnum

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias


class RerankModelEnum(StrEnum):
    COHERE_ENGLISH_V3 = "cohere_english_v3"
    HF_EMBED_MIXEDBREAD = "hf_embed_mixedbread"
    HF_EMBED_JINA = "hf_embed_jina"


class RerankDetails(BaseModelWithAlias):
    name: str
    service: str
    description: str | None = None
    code: str
    cost: float


class RerankItemResponse(BaseModelWithAlias):
    index: int
    relevance: float
