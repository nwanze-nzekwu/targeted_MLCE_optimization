from enum import StrEnum

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias


class TokenizerEnum(StrEnum):
    HF_EMBED_MIXEDBREAD = "mixedbread-embed"
    HF_EMBED_JINA = "jina-embed"
    HF_LLAMA_2_7B = "llama-2-7b"
    HF_LLAMA_2_70B = "llama-2-70b"
    HF_LLAMA_3_8B = "llama-3-8b"
    HF_LLAMA_3_70B = "llama-3-70b"
    HF_LLAMA_3_2_90B = "hf-llama-3-2-90b"
    HF_LLAMA_4_SCOUT_17B_16E = "hf-llama-4-scout-17B-16E"
    HF_LLAMA_4_MAVERICK_17B_128E = "hf-llama-4-maverick-17B-128E"
    HF_MIXEDBREAD = "mixedbread"
    HF_JINA = "jina"
    OPENAI = "cl100k-base"
    OPENAI_SMALL = "cl100k-base-small"
    GEMINI_2_5_PRO = "gemini-2.5-pro"
    GEMINI_2_0_PRO = "gemini-2.0-pro"
    GEMINI_2_0_FLASH = "gemini-2.0-flash"
    GEMINI_2_0_FLASH_LITE = "gemini-2.0-flash-lite"
    GEMINI_1_5_FLASH = "gemini-1.5-flash-002"
    GEMINI_1_5_PRO = "gemini-1.5-pro-002"
    COHERE_ENGLISH_V3 = "cohere-english-v3"
    HF_COHERE_ENGLISH_V3 = "hf-cohere-english-v3"
    HF_QWEN_2_5_CODER_32B = "hf-qwen-2.5-coder-32b"


class Token(BaseModelWithAlias):
    id_: int
    token: str | None = None


class TokenizerDetails(BaseModelWithAlias):
    name: str
    service: str
    description: str
    code: str
