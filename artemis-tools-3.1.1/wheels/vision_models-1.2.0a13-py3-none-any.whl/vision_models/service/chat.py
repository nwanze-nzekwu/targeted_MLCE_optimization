import uuid
from datetime import datetime

from pydantic import ConfigDict, Field, field_validator
from typing_extensions import override

# Source imports
from vision_models.service.mongo import (
    MongoBaseModel,
    MongoCollection,
)


class MongoMessageBase(MongoBaseModel):
    collection = MongoCollection.MESSAGES.value


class UserMessageResponse(MongoMessageBase):
    """Message model.

    Each message is associated with a user and a conversation.

    The conversation type is either:
    - chat
    - task based

    The message type is either:
    - user
    - system
    - bot

    The llm field is the target of the conversation
    """

    ext_user_id: str = Field(...)
    task_id: str = Field(...)
    message_type: str = Field(...)
    llm: str | None = Field(default=None)
    message: str = Field(...)
    timestamp: datetime = Field(default_factory=datetime.now)

    @field_validator("ext_user_id", "task_id")
    @classmethod
    def validate_fk_ids(cls, v: uuid.UUID) -> str:
        return str(v)

    @override
    def __hash__(self) -> int:
        if self.pk_id is None:
            raise ValueError("UserMessage is only hashable when in db")
        return self.pk_id.__hash__()

    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={
            "example": {
                "extUserId": "066de609-b04a-4b30-b46c-32537c7f1f6e",
                "taskId": "066de609-b04a-4b30-b46c-32537c7f1f6e",
                "messageType": "system",
                "llm": None,
                "message": "You are a bot",
            }
        },
    )


class UserMessageUpdate(MongoMessageBase):
    message: str | None = None
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "message": "Hello, how are you?",
            }
        }
    )
