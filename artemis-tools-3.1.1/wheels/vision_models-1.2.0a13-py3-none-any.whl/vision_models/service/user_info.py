import uuid

from pydantic import ConfigDict, Field, field_validator

# Source imports
from vision_models.service.embedding import EmbeddingModelEnum
from vision_models.service.llm import LLMType
from vision_models.service.mongo import MongoBaseModel, MongoCollection


class MongoUserInfoBase(MongoBaseModel):
    collection = MongoCollection.USER_INFO.value


class UserInfo(MongoUserInfoBase):
    user_id: str
    disabled_llms: list[LLMType] | None = Field(default_factory=list, description="list of disabled LLMs")
    default_scoring_llms: list[LLMType] | None = Field(default_factory=list, description="default LLMs for scoring")
    default_code_generation_llms: list[LLMType] | None = Field(
        default_factory=list, description="default LLMs for code generation"
    )
    default_chat_llm: LLMType | None = Field(default=None, description="default LLM for chat")
    default_pair_coder_llm: LLMType | None = Field(default=None, description="default LLM for pair coding")
    default_extraction_llm: LLMType | None = Field(default=None, description="default LLM for extraction")
    default_pull_request_llm: LLMType | None = Field(default=None, description="default LLM for pull request")
    default_report_generation_llm: LLMType | None = Field(default=None, description="default LLM for report generation")
    # Default embedding models
    disabled_embedding_models: list[EmbeddingModelEnum] | None = Field(
        default_factory=list, description="list of disabled embedding models"
    )
    default_embedding_model: EmbeddingModelEnum | None = Field(default=None, description="default embedding model")

    @field_validator("user_id")
    @classmethod
    def validate_fk_ids(cls, v: uuid.UUID) -> str:
        return str(v)

    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={
            "example": {
                "user_id": "066de609-b04a-4b30-b46c-32537c7f1f6e",
                "disabled_llms": [LLMType.OPENAI_GPT_4_O],
                "default_scoring_llms": [LLMType.OPENAI_GPT_4_O],
                "default_code_generation_llms": [LLMType.OPENAI_GPT_4_O],
                "default_chat_llm": LLMType.OPENAI_GPT_4_O,
                "default_pair_coder_llm": LLMType.OPENAI_GPT_4_O,
                "default_extraction_llm": LLMType.OPENAI_GPT_4_O,
                "default_pull_request_llm": LLMType.OPENAI_GPT_4_O,
                "default_report_generation_llm": LLMType.OPENAI_GPT_4_O,
                "disabled_embedding_models": [EmbeddingModelEnum.OPENAI_SMALL],
                "default_embedding_model": EmbeddingModelEnum.VERTEX_TEXT_V5,
            }
        },
    )
