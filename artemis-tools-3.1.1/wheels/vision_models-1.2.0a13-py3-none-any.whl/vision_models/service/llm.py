from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias

NOT_PROVIDED = "NOT_PROVIDED"


class LLMRole(StrEnum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"

    @classmethod
    def from_openai(cls, role: Literal["assistant", "user", "system", "tool"]) -> "LLMRole":
        match role:
            case "assistant":
                return cls.ASSISTANT
            case "user":
                return cls.USER
            case "system":
                return cls.SYSTEM
            case "tool":
                return cls.TOOL

    def to_openai(self) -> Literal["assistant", "user", "system", "tool"]:
        return self.value


class LLMDetails(BaseModel):
    name: str
    service: str
    description: str | None = None
    tokenizer: str
    code: str
    input_cost: float
    output_cost: float
    context_length: int
    enabled: bool = True
    is_large: bool = True
    capabilities: set[Capability]


# TODO: we ideally want the values to be prepended by the service provider
# but to avoid a migration, only new values will apply this convention
class LLMType(StrEnum):
    OPENAI_GPT_41 = "gpt-41"
    OPENAI_GPT_41_MINI = "gpt-41-mini"
    OPENAI_GPT_41_NANO = "gpt-41-nano"
    OPENAI_GPT_45 = "gpt-45"
    OPENAI_GPT_5_CODEX = "gpt-5-codex"
    OPENAI_GPT_5 = "gpt-5"
    OPENAI_GPT_5_MINI = "gpt-5-mini"
    OPENAI_GPT_5_NANO = "gpt-5-nano"
    OPENAI_GPT_4_O = "gpt-4-o"
    OPENAI_GPT_4_O_SEARCH = "gpt-4-o-search"
    OPENAI_GPT_4_O_MINI = "gpt-4-o-mini"
    OPENAI_GPT_4_TURBO = "gpt-4-turbo"
    OPENAI_GPT_O_1 = "gpt-o1"
    OPENAI_GPT_O_1_MINI = "gpt-o1-mini"
    OPENAI_GPT_O_3 = "gpt-o3"
    OPENAI_GPT_O_3_MINI = "gpt-o3-mini"
    OPENAI_GPT_O_4_MINI = "gpt-o4-mini"
    VERTEX_GEMINI_V15_PRO = "gemini-v15-pro"
    VERTEX_GEMINI_V15_FLASH = "gemini-v15-flash"
    VERTEX_GEMINI_V20_PRO = "gemini-v20-pro"
    VERTEX_GEMINI_V25_PRO = "gemini-v25-pro"
    VERTEX_GEMINI_V20_FLASH_THINKING = "gemini-v20-flash-thinking"
    VERTEX_GEMINI_V20_FLASH = "gemini-v20-flash"
    VERTEX_GEMINI_V20_FLASH_LITE = "gemini-v20-flash-lite"
    VERTEX_GEMINI_V25_FLASH_LITE = "gemini-v25-flash-lite"
    VERTEX_GEMINI_V25_FLASH = "gemini-v25-flash"
    VERTEX_GEMINI_V30_PRO = "gemini-v30-pro"
    VERTEX_CLAUDE_V4_OPUS = "vertex-claude-v4-opus"
    VERTEX_CLAUDE_V4_OPUS_THINKING = "vertex-claude-v4-opus-thinking"
    VERTEX_CLAUDE_V41_OPUS = "vertex-claude-v41-opus"
    VERTEX_CLAUDE_V41_OPUS_THINKING = "vertex-claude-v41-opus-thinking"
    VERTEX_CLAUDE_V4_SONNET = "vertex-claude-v4-sonnet"
    VERTEX_CLAUDE_V4_SONNET_THINKING = "vertex-claude-v4-sonnet-thinking"
    VERTEX_CLAUDE_V45_SONNET = "vertex-claude-v45-sonnet"
    VERTEX_CLAUDE_V45_SONNET_THINKING = "vertex-claude-v45-sonnet-thinking"
    VERTEX_CLAUDE_V37_SONNET = "vertex-claude-v37-sonnet"
    VERTEX_CLAUDE_V37_SONNET_THINKING = "vertex-claude-v37-sonnet-thinking"
    VERTEX_CLAUDE_V35_HAIKU = "vertex-claude-v35-haiku"
    VERTEX_CLAUDE_V35_SONNET = "vertex-claude-v35-sonnet"
    VERTEX_CLAUDE_V3_OPUS = "vertex-claude-v3-opus"
    VERTEX_LLAMA_4_SCOUT_17B_16E = "vertex-llama-4-scout-17B_16E"
    VERTEX_LLAMA_4_MAVERICK_17B_128E = "vertex-llama-4-maverick-17B_128E"
    VERTEX_LLAMA_3_2_11B = "vertex-llama-3-2-11b"
    VERTEX_LLAMA_3_2_90B = "vertex-llama-3-2-90b"
    BEDROCK_CLAUDE_V4_SONNET = "claude-v4-sonnet"
    BEDROCK_CLAUDE_V4_SONNET_THINKING = "claude-v4-sonnet-thinking"
    BEDROCK_CLAUDE_V45_SONNET = "claude-v45-sonnet"
    BEDROCK_CLAUDE_V45_SONNET_THINKING = "claude-v45-sonnet-thinking"
    BEDROCK_CLAUDE_V4_OPUS = "claude-v4-opus"
    BEDROCK_CLAUDE_V4_OPUS_THINKING = "claude-v4-opus-thinking"
    BEDROCK_CLAUDE_V41_OPUS = "claude-v41-opus"
    BEDROCK_CLAUDE_V41_OPUS_THINKING = "claude-v41-opus-thinking"
    BEDROCK_CLAUDE_V37_SONNET = "claude-v37-sonnet"
    BEDROCK_CLAUDE_V37_SONNET_THINKING = "claude-v37-sonnet-thinking"
    BEDROCK_CLAUDE_V35_SONNET = "claude-v35-sonnet"
    BEDROCK_CLAUDE_V35_HAIKU = "claude-v35-haiku"
    BEDROCK_CLAUDE_V3_OPUS = "claude-v3-opus"
    BEDROCK_LLAMA_3_8B = "llama-3-8b"
    BEDROCK_LLAMA_3_1_8B = "llama-3-1-8b"
    BEDROCK_3_1_70B = "llama-3-1-70b"
    BEDROCK_LLAMA_3_1_405B = "llama-3-1-405b"
    BEDROCK_MISTRAL_LARGE_2 = "mistral-large-2"
    ARTEMIS_LLM_INTEL = "artemis-llm-intel"
    NVIDIA_LLAMA_3_3_70B = "nim-llama-3-3-70b"
    NVIDIA_YI_LARGE = "yi-large"
    INTEL_DEEPSEEK_DISTILL_LLAMA_3_70B = "intel-deepseek-distill-llama-3-70b"
    DEEPSEEK_DEEPSEEK_V3 = "deepseek-deepseek-v3"
    DEEPSEEK_DEEPSEEK_R1 = "deepseek-deepseek-r1"
    NVIDIA_SNOWFLAKE_ARCTIC = "snowflake-arctic"
    BEDROCK_COMMAND_R_PLUS = "command-r-plus"
    HF_NEURAL_CHAT = "neural-chat"
    OPENCODER_8B = "opencoder-8B"
    QWEN_2_5_CODER_32B = "qwen-2-5-coder-32b"
    INTEL_QWEN_2_5_CODER_3B_INSTRUCT = "intel-qwen-2-5-coder-3b-instruct"
    INTEL_PHI_4_MINI_INSTRUCT = "intel-phi-4-mini-instruct"
    CUSTOM_LOCAL_LLM = "custom-local-llm"
    ANTHROPIC_CLAUDE_V4_SONNET = "anthropic-claude-v4-sonnet"
    ANTHROPIC_CLAUDE_V4_SONNET_THINKING = "anthropic-claude-v4-sonnet-thinking"
    ANTHROPIC_CLAUDE_V45_SONNET = "anthropic-claude-v45-sonnet"
    ANTHROPIC_CLAUDE_V45_SONNET_THINKING = "anthropic-claude-v45-sonnet-thinking"
    ANTHROPIC_CLAUDE_V4_OPUS = "anthropic-claude-v4-opus"
    ANTHROPIC_CLAUDE_V4_OPUS_THINKING = "anthropic-claude-v4-opus-thinking"
    ANTHROPIC_CLAUDE_V41_OPUS = "anthropic-claude-v41-opus"
    ANTHROPIC_CLAUDE_V41_OPUS_THINKING = "anthropic-claude-v41-opus-thinking"


DEFAULT_CODE_TAGS = {
    "python",
    "cpp",
    "java",
    "javascript",
    "ruby",
    "swift",
    "go",
    "c",
    "csharp",
    "php",
    "scala",
}


class ArtemisBaseOutput(BaseModelWithAlias):
    """Base class for all the structured outputs."""

    model_config = ConfigDict(extra="allow")


class ArtemisInvalidOutput(ArtemisBaseOutput):
    fail_message: str = Field(description="The message explaining why the code is invalid")


class CodeExplanationOutput(ArtemisBaseOutput):
    """The structured output for code with explanation."""

    code: str = Field(description="The modified code")
    explanation: str = Field(description="Explanation of the modification")

    @field_validator("code")
    @classmethod
    def validate_code(cls, v: str) -> str:
        if not v:
            raise ValueError("Code cannot be empty")
        # clean the code
        if v.startswith("```"):
            code_tag = v[3 : v.find("\n")]
            if code_tag not in DEFAULT_CODE_TAGS:
                code_tag = ""
            from artemis_tools.services.parsers.pattern_extractors import (
                extract_code_pattern,
            )

            v, _, _ = extract_code_pattern(v, code_tag=code_tag, clean_tags=True)
        return v


class LLMModelPatchInfo(BaseModelWithAlias):
    """Model for enable/disable patch info for a llm."""

    enabled: bool
    llm: LLMType


class Capability(StrEnum):
    """Capability of an LLM."""

    STRUCTURED_OUTPUT = "structured_output"
    CODING_PROFICIENT = "coding_proficient"
    STREAMING_OUTPUT = "streaming_output"
    TOOL_CALLING = "tool_calling"
    THINKING = "thinking"

    @staticmethod
    def all() -> set[Capability]:
        return {
            Capability.STRUCTURED_OUTPUT,
            Capability.CODING_PROFICIENT,
            Capability.STREAMING_OUTPUT,
            Capability.TOOL_CALLING,
            Capability.THINKING,
        }

    @staticmethod
    def all_without_thinking() -> set[Capability]:
        return {
            Capability.STRUCTURED_OUTPUT,
            Capability.CODING_PROFICIENT,
            Capability.STREAMING_OUTPUT,
            Capability.TOOL_CALLING,
        }
