from enum import StrEnum
from typing import Generic, TypeVar

from artemis_tools.models.generic import Language
from pydantic import BaseModel, Field
from typing_extensions import Self, override

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias

# -------------------------------------- Embedding Choices ----------------------------------------


class EmbeddingModelEnum(StrEnum):
    HF_MIXEDBREAD = "hf-mixedbread"
    HF_JINA = "hf-jina"
    OPENAI_SMALL = "openai-small"
    OPENAI_LARGE = "openai-large"
    OPENAI_ADA = "openai-ada"
    ARCTIC_EMBED_L = "arctic-embed-l"
    NV_EMBED_V1 = "nv-embed-v1"
    BGE_M3 = "bge-m3"
    COHERE_ENGLISH_V3 = "cohere-english-v3"
    VERTEX_TEXT_V4 = "vertex-text-v4"  # WARN: Deprecates January 14, 2026
    VERTEX_TEXT_V5 = "vertex-text-v5"
    BEDROCK_TITAN = "bedrock-titan"
    GOOGLE_HF_MIXEDBREAD = "google-hf-mixedbread"
    GOOGLE_HF_JINA = "google-hf-jina"
    GEMINI_EMBEDDING_V1 = "gemini-embedding-v1"
    CUSTOM_LOCAL_EMBEDDING = "custom-local-embedding"


class EmbeddingPreset(BaseModelWithAlias):
    text_model: EmbeddingModelEnum
    code_model: EmbeddingModelEnum


class EmbeddingPresetEnum(StrEnum):
    HUGGINGFACE = "huggingface"
    OPENAI = "openai"
    OPENAI_ADA = "openai-ada"
    COHERE = "cohere"
    VERTEX_V4 = "vertex-v4"
    VERTEX_V5 = "vertex-v5"
    BEDROCK = "bedrock"
    GEMINI = "gemini"
    CUSTOM_LOCAL = "custom-local"


class EmbedType(StrEnum):
    TEXT_DOC = "text_doc"
    TEXT_QUERY = "text_query"
    CODE_DOC = "code_doc"
    CODE_QUERY = "code_query"


class SimilarityEmbedType(StrEnum):
    TEXT = "text"
    CODE = "code"


class QueryTypeEnum(StrEnum):
    """Distinguish different types of prompts used to retrieve embeddings."""

    TEXT = "text"
    CODE = "code"
    ANY = "any"


def embedding_preset_factory(preset: EmbeddingPresetEnum) -> EmbeddingPreset:
    match preset:
        case EmbeddingPresetEnum.HUGGINGFACE:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.GOOGLE_HF_MIXEDBREAD,
                code_model=EmbeddingModelEnum.GOOGLE_HF_JINA,
            )
        case EmbeddingPresetEnum.OPENAI:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.OPENAI_SMALL,
                code_model=EmbeddingModelEnum.OPENAI_SMALL,
            )
        case EmbeddingPresetEnum.OPENAI_ADA:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.OPENAI_ADA,
                code_model=EmbeddingModelEnum.OPENAI_ADA,
            )
        case EmbeddingPresetEnum.COHERE:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.COHERE_ENGLISH_V3,
                code_model=EmbeddingModelEnum.COHERE_ENGLISH_V3,
            )
        case EmbeddingPresetEnum.VERTEX_V4:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.VERTEX_TEXT_V4,
                code_model=EmbeddingModelEnum.VERTEX_TEXT_V4,
            )
        case EmbeddingPresetEnum.VERTEX_V5:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.VERTEX_TEXT_V5,
                code_model=EmbeddingModelEnum.VERTEX_TEXT_V5,
            )
        case EmbeddingPresetEnum.BEDROCK:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.BEDROCK_TITAN,
                code_model=EmbeddingModelEnum.BEDROCK_TITAN,
            )
        case EmbeddingPresetEnum.GEMINI:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.GEMINI_EMBEDDING_V1,
                code_model=EmbeddingModelEnum.GEMINI_EMBEDDING_V1,
            )
        case EmbeddingPresetEnum.CUSTOM_LOCAL:
            return EmbeddingPreset(
                text_model=EmbeddingModelEnum.CUSTOM_LOCAL_EMBEDDING,
                code_model=EmbeddingModelEnum.CUSTOM_LOCAL_EMBEDDING,
            )


def embedding_preset_display_name(preset: EmbeddingPresetEnum) -> str:
    match preset:
        case EmbeddingPresetEnum.HUGGINGFACE:
            return "MixedBread / JinaAI"
        case EmbeddingPresetEnum.OPENAI:
            return "OpenAI"
        case EmbeddingPresetEnum.OPENAI_ADA:
            return "OpenAI ADA"
        case EmbeddingPresetEnum.COHERE:
            return "Cohere"
        case EmbeddingPresetEnum.VERTEX_V4:
            return "Vertex v4"
        case EmbeddingPresetEnum.VERTEX_V5:
            return "Vertex v5"
        case EmbeddingPresetEnum.BEDROCK:
            return "Bedrock Titan"
        case EmbeddingPresetEnum.GEMINI:
            return "Gemini Embedding v1"
        case EmbeddingPresetEnum.CUSTOM_LOCAL:
            return "Custom Local Embedding"


# -------------------------------------- Embedding Model Metadata ----------------------------------------


class EmbeddingDetails(BaseModelWithAlias):
    name: str
    service: str
    description: str | None = None
    code: str
    cost: float
    default_prompt: str
    tokenizer_name: str
    embedding_size: int
    enabled: bool = True


class EmbeddingPresetDetails(BaseModelWithAlias):
    name: str
    code: str
    models: list[EmbeddingModelEnum]


# -------------------------------------- Embedding Output Metadata ----------------------------------------


class EmbeddingMetadata(BaseModelWithAlias):
    """This is the base model that is used by Qdrant collections."""

    file: str = Field(..., description="The name given to the file that this embed chunk is from")
    language: str = Field(..., description="The type of the file that this embed chunk is from")
    project_id: str = Field(
        ...,
        description="The project that this embed chunk belongs to, useful for searching",
    )
    embedding_id: str = Field(
        ...,
        description="The embedding job that this embed chunk belongs to, useful for searching",
    )
    user_id: str = Field(
        ...,
        description="The user that this embed chunk belongs to, useful for searching",
    )
    entry_id: str = Field(..., description="The id of the stored chunk (before embedding)")
    part: int = Field(..., description="The index of the chunk after text splitting")

    def to_payload(self) -> dict[str, str]:
        return {
            "file": self.file,
            "language": self.language,
            "project_id": self.project_id,
            "embedding_id": self.embedding_id,
            "user_id": self.user_id,
            "part": str(self.part),
            "entry_id": self.entry_id,
        }


class TextEmbeddingMetadata(EmbeddingMetadata):
    """Metadata for text embeddings."""

    ...


class MemoryEmbeddingMetadata(TextEmbeddingMetadata):
    """Metadata for memory embeddings."""

    task_id: str = Field(..., description="The task that groups this set of embeddings")


class CodeEmbeddingMetadata(TextEmbeddingMetadata):
    """Metadata for code embeddings."""

    # currently we output line/col info from the treesitter service, since it's useful for
    # extracting code from files in falcon.
    start_line: int
    end_line: int
    start_col: int
    end_col: int

    # extra code specific metadata extracted from treesitter
    node_type: str
    name: str

    @override
    def to_payload(self) -> dict[str, str]:
        return {
            **super().to_payload(),
            "start_line": str(self.start_line),
            "end_line": str(self.end_line),
            "start_col": str(self.start_col),
            "end_col": str(self.end_col),
            "node_type": self.node_type,
            "name": self.name,
        }


class EmbeddingVector(BaseModelWithAlias):
    """Generic vector definition for embedding with qdrant.

    TODO: This should be less dependent on qdrant schema
    """

    # list of floats
    text: list[float] | None

    def __bool__(self):
        if isinstance(self.text, list):
            return len(self.text) > 0
        return bool(self.text)

    @override
    def __repr__(self) -> str:
        if self.text is None:
            return "EmbeddingVector(text=None)"
        if isinstance(self.text, list):
            return f"EmbeddingVector(text=array[{len(self.text)}])"
        return super().__repr__()


class TextEmbeddingVector(EmbeddingVector):
    """Vector for text embeddings.

    - text
    """

    ...


class CodeEmbeddingVector(EmbeddingVector):
    """Vectors for code embeddings.

    - code
    - text (documentation)
    """

    code: list[float] | None

    @override
    def __bool__(self):
        valid_vectors = True
        if isinstance(self.text, list):
            valid_vectors = valid_vectors and len(self.text) > 0
        if isinstance(self.code, list):
            valid_vectors = valid_vectors and len(self.code) > 0
        return valid_vectors

    @override
    def __repr__(self) -> str:
        if self.text is None:
            text_part = "text=None"
        elif isinstance(self.text, list):
            text_part = f"text=array[{len(self.text)}]"
        else:
            text_part = "text=vector"

        if self.code is None:
            code_part = "code=None"
        elif isinstance(self.code, list):
            code_part = f"code=array[{len(self.code)}]"
        else:
            code_part = "code=vector"

        return f"CodeEmbeddingVector({text_part}, {code_part})"


EmbeddingVectorT = TypeVar("EmbeddingVectorT", bound=EmbeddingVector)
EmbeddingMetadataT = TypeVar("EmbeddingMetadataT", bound=EmbeddingMetadata)


class BaseEmbeddingEntry(BaseModel, Generic[EmbeddingVectorT, EmbeddingMetadataT]):
    metadata: EmbeddingMetadataT
    embedding: EmbeddingVectorT


class TextEmbeddingEntry(BaseEmbeddingEntry[TextEmbeddingVector, TextEmbeddingMetadata]):
    metadata: TextEmbeddingMetadata
    embedding: TextEmbeddingVector


class CodeEmbeddingEntry(BaseEmbeddingEntry[CodeEmbeddingVector, CodeEmbeddingMetadata]):
    metadata: CodeEmbeddingMetadata
    embedding: CodeEmbeddingVector


# -------------------------------------- File Metadata ----------------------------------------


class FileMetadata(BaseModelWithAlias):
    """This is the base output of any text preprocessing."""

    # metadata
    file: str
    language: Language
    project_id: str
    embedding_id: str
    user_id: str

    # used by splitting
    part: int = 0

    def to_embedding_metadata(self, entry_id: str) -> TextEmbeddingMetadata:
        return TextEmbeddingMetadata(
            file=self.file,
            language=self.language.value,
            project_id=self.project_id,
            embedding_id=self.embedding_id,
            user_id=self.user_id,
            entry_id=entry_id,
            part=self.part,
        )


class CodeFileMetadata(FileMetadata):

    # currently we output line/col info from the treesitter service, since it's useful for
    # extracting code from files in falcon.
    start_line: int
    end_line: int
    start_col: int
    end_col: int

    # extra code specific metadata extracted from treesitter
    node_type: str
    description: str
    name: str

    def to_file_metadata(self) -> FileMetadata:
        return FileMetadata(
            file=self.file,
            language=self.language,
            project_id=self.project_id,
            embedding_id=self.embedding_id,
            user_id=self.user_id,
            part=self.part,
        )

    @override
    def to_embedding_metadata(self, entry_id: str) -> CodeEmbeddingMetadata:
        return CodeEmbeddingMetadata(
            file=self.file,
            language=self.language.value,
            project_id=self.project_id,
            embedding_id=self.embedding_id,
            user_id=self.user_id,
            entry_id=entry_id,
            part=self.part,
            start_line=self.start_line,
            end_line=self.end_line,
            start_col=self.start_col,
            end_col=self.end_col,
            node_type=self.node_type,
            name=self.name,
        )


MetadataT = TypeVar("MetadataT", bound=FileMetadata)


class DocumentContents(BaseModelWithAlias, Generic[MetadataT]):
    text: str
    metadata: MetadataT

    def clone_with_new_text(self, new_text: str) -> Self:
        clone = self.model_copy(deep=True)
        clone.text = new_text
        return clone

    def clone_with_new_description(self, new_description: str) -> Self:
        clone = self.model_copy(deep=True)
        if isinstance(clone.metadata, CodeFileMetadata):
            clone.metadata.description = new_description
        return clone


class FileContents(DocumentContents[FileMetadata]):
    text: str
    metadata: FileMetadata


class CodeFileContents(DocumentContents[CodeFileMetadata]):
    text: str
    metadata: CodeFileMetadata

    def to_file_contents(self) -> FileContents:
        return FileContents(text=self.metadata.description, metadata=self.metadata.to_file_metadata())


class TextSearchResult(BaseModelWithAlias):
    similarity: float
    text: str
    metadata: TextEmbeddingMetadata


class MemorySearchResult(BaseModelWithAlias):
    similarity: float
    text: str
    metadata: MemoryEmbeddingMetadata


class CodeSearchResult(BaseModelWithAlias):
    similarity: float
    text: str
    metadata: CodeEmbeddingMetadata


class CodeSearchResults(BaseModelWithAlias):
    """Results for code snippet search."""

    results: list[CodeSearchResult] = Field(default_factory=list)

    def __iadd__(self, other: "CodeSearchResults") -> Self:
        self.results += other.results
        return self


class TextSearchResults(BaseModelWithAlias):

    results: list[TextSearchResult] = Field(default_factory=list)

    def __iadd__(self, other: "TextSearchResults") -> Self:
        self.results += other.results
        return self


class MemorySearchResults(BaseModelWithAlias):
    results: list[MemorySearchResult] = Field(default_factory=list)

    def __iadd__(self, other: "MemorySearchResults") -> Self:
        self.results += other.results
        return self


# -------------------------------------- Embedding Search ----------------------------------------


class EmbeddingSearchRequest(BaseModelWithAlias):
    project_ids: list[str]
    query: str
    query_type: QueryTypeEnum
    user_id: str


class EmbeddingConfig(BaseModelWithAlias):
    model: EmbeddingModelEnum
