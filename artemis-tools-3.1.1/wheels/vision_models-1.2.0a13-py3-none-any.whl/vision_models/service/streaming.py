from enum import StrEnum
from typing import Any, Generic, Protocol, TypeVar
from uuid import UUID, uuid4

from pydantic import BaseModel, Field

# Source imports
from vision_models.service.ai.sources.enums import LLMToolEnum
from vision_models.service.base_data_types import BaseModelWithAlias

OutputT = TypeVar("OutputT", bound=BaseModel)


class LLMSSEEnum(StrEnum):
    """LLM server side event Enum Tells the front-end what status the tool is in."""

    TOOL_START = "tool-start"
    TOOL_UPDATE = "tool-update"
    TOOL_END = "tool-end"
    TOOL_HIDDEN = "tool-hidden"
    OUTPUT_TOKENS = "output-tokens"
    THINKING_TOKENS = "thinking-tokens"
    ERROR_MESSAGE = "error-message"


class LLMSSEStatusEnum(StrEnum):
    """LLM server side event status Enum.

    Tells the front-end whether a tool succeeded or failed.
    """

    SUCCESS = "success"
    ERROR = "error"


# ---------------------------------- Streaming Data Types --------------------------------------


class SingleStreamResponse(BaseModel):
    token: str


class AgentToolIO(BaseModel):
    value: Any = None


# ------------------------------------ SSE Data --------------------------------------------


class LLMSSEChunkData(BaseModelWithAlias, Generic[OutputT]):
    tool_data: OutputT = Field(description="The input/output of the tool (structured)")
    tool_name: LLMToolEnum = Field(description="The name of the tool")
    tool_run_id: UUID = Field(default_factory=uuid4, description="The ID for running the tool")
    status: LLMSSEStatusEnum
    error_message: str | None = Field(default=None, description="Error message used if the status is not success")


class LLMSSEErrorData(BaseModelWithAlias, Generic[OutputT]):
    message: OutputT = Field(description="The input/output of the tool (structured)")
    status: LLMSSEStatusEnum = Field(description="The status of the tool")


class LLMSSEChunk(BaseModelWithAlias, Generic[OutputT]):
    data: LLMSSEChunkData[OutputT] | LLMSSEErrorData[OutputT]
    event: str

    def serialize(self):
        return {"event": self.event, "data": self.data.model_dump_json(by_alias=False)}


class SerializableSSE(Protocol):
    def serialize(self) -> dict[str, str]: ...

    data: LLMSSEChunkData[BaseModel]
