from datetime import datetime

from pydantic import ConfigDict, Field

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.mongo import (
    MongoBaseModel,
    MongoCollection,
)


class MongoIndexBase(MongoBaseModel):
    collection = MongoCollection.INDEXES.value


class Index(MongoIndexBase):
    """Index model.

    This stores the index results per project, for efficient searching
    """

    project_id: str = Field(
        description="Project id",
    )
    models: dict[str, datetime] = Field(
        default={},
        description="Mapping of model name to last used in the index",
    )

    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={
            "example": {
                "models": [
                    {
                        "name": "bedrock",
                        "count": 100,
                        "last_updated": "2021-10-01T00:00:00",
                    }
                ]
            }
        },
    )


class IndexUpdate(BaseModelWithAlias):
    """Index update model.

    This stores the index update information
    """

    project_id: str = Field(
        description="Project id",
    )
    model_name: str = Field(
        description="Model name",
    )
    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={
            "example": {
                "project_id": "1234",
                "model_name": "bedrock",
                "last_updated": "2021-10-01T00:00:00",
            }
        },
    )
