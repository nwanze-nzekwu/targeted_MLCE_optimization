import json
from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass
from decimal import Decimal
from typing import (
    Annotated,
    Any,
    Generic,
    Iterable,
    Literal,
    NotRequired,
    Self,
    TypeVar,
    cast,
)
from uuid import UUID, uuid4

import langchain_core.messages as langchain
import openai.types.chat as openai
from anthropic.types import (
    ContentBlock,
    DocumentBlockParam,
    ImageBlockParam,
    MessageParam,
    TextBlock,
    TextBlockParam,
    ToolResultBlockParam,
    ToolUseBlockParam,
)
from anthropic.types.tool_use_block import ToolUseBlock
from openai.types.chat.chat_completion_message import ChatCompletionMessage
from pydantic import BaseModel, Field
from typing_extensions import TypedDict, override

# Source imports
from vision_models.service.base_data_types import BaseModelWithAlias
from vision_models.service.llm import LLMRole


class MessageDict(TypedDict):
    role: str
    content: str


class VertexBlob(TypedDict):
    mimeType: str
    data: str


class VertexFile(TypedDict):
    mimeType: str
    fileUri: str


class VertexFunctionCall(TypedDict):
    name: str
    args: dict[str, Any]


class VertexFunctionResponse(TypedDict):
    name: str
    response: dict[str, Any]


class VertexPart(TypedDict):
    text: NotRequired[str | None]
    inlineData: NotRequired[VertexBlob | None]
    fileData: NotRequired[VertexFile | None]
    functionCall: NotRequired[VertexFunctionCall | None]
    functionResponse: NotRequired[VertexFunctionResponse | None]


class VertexResponsePart(TypedDict):
    text: str | None
    inlineData: VertexBlob | None
    fileData: VertexFile | None
    functionCall: NotRequired[VertexFunctionCall | None]
    functionResponse: VertexFunctionResponse | None


class VertexMessage(TypedDict):
    role: Literal["user", "model"]
    parts: list[VertexPart]


class VertexResponseMessage(TypedDict):
    role: Literal["user", "model"]
    parts: list[VertexResponsePart]


class BedrockToolUseBlock(TypedDict):
    input: dict[str, Any]
    name: str
    toolUseId: str


class ThinkingBlock(TypedDict):
    type: Literal["thinking"]
    thinking: str
    signature: str


class RedactedThinkingBlock(TypedDict):
    type: Literal["redacted_thinking"]
    data: str


def llm_role_to_anthropic(value: LLMRole) -> Literal["user", "assistant"]:
    if value == LLMRole.USER:
        return "user"
    elif value == LLMRole.ASSISTANT:
        return "assistant"
    else:
        return "user"


def llm_role_to_cohere(value: LLMRole) -> Literal["USER", "CHATBOT"]:
    if value == LLMRole.USER:
        return "USER"
    elif value == LLMRole.ASSISTANT:
        return "CHATBOT"
    else:
        return "USER"


class ToolCall(BaseModelWithAlias):
    task_id: str
    name: str
    args: dict[str, Any]

    def to_openai(self) -> openai.ChatCompletionMessageToolCallParam:
        return {
            "type": "function",
            "id": self.task_id,
            "function": {
                "name": self.name,
                "arguments": str(self.args),
            },
        }

    def to_gemini(self) -> VertexPart:
        return {
            "functionCall": {
                "name": self.name,
                "args": self.args,
            },
        }

    def to_anthropic(self) -> ToolUseBlock:
        return ToolUseBlock(
            id=self.task_id,
            name=self.name,
            input=self.args,
            type="tool_use",
        )

    @classmethod
    def from_openai(cls, tool_call: openai.ChatCompletionMessageToolCall) -> Self:
        return cls(
            task_id=tool_call.id,
            name=tool_call.function.name,
            args=json.loads(tool_call.function.arguments),
        )

    @classmethod
    def from_anthropic(cls, tool_call: ToolUseBlock) -> Self:
        return cls(task_id=str(uuid4()), name=tool_call.name, args=tool_call.input)

    def to_langchain(self) -> langchain.ToolCall:
        return langchain.ToolCall(name=self.name, id=self.task_id, args=self.args)

    @classmethod
    def from_langchain(cls, tool_call: langchain.ToolCall) -> Self:
        return cls(
            name=tool_call["name"],
            task_id=tool_call["id"] or str(uuid4()),
            args=tool_call["args"],
        )

    @classmethod
    def from_vertex(cls, tool_call: VertexFunctionCall) -> Self:
        return cls(name=tool_call["name"], task_id=str(uuid4()), args=tool_call["args"])

    @classmethod
    def from_bedrock(cls, tool_call: BedrockToolUseBlock) -> Self:
        return cls(
            task_id=tool_call["toolUseId"],
            name=tool_call["name"],
            args=tool_call["input"],
        )


class CohereOutput(TypedDict):
    role: Literal["USER", "CHATBOT"]
    message: str


class BedrockToolResultContentBlock(TypedDict):
    # NOTE: all dict[str, Any] are just schemas we don't care enough about to explicitly show here
    document: NotRequired[dict[str, Any]]
    image: NotRequired[dict[str, Any]]
    json: NotRequired[dict[str, Any]]
    text: NotRequired[str]


class BedrockToolResultBlock(TypedDict):
    content: list[BedrockToolResultContentBlock]
    toolUseId: str
    status: Literal["success", "error"]


class BedrockContentBlock(TypedDict):
    # NOTE: all dict[str, Any] are just schemas we don't care enough about to explicitly show here
    documentBlock: NotRequired[dict[str, Any]]
    guardContent: NotRequired[dict[str, Any]]
    image: NotRequired[dict[str, Any]]
    text: NotRequired[str]
    toolResult: NotRequired[BedrockToolResultBlock]
    toolUse: NotRequired[BedrockToolUseBlock]


class BedrockMessage(TypedDict):
    role: Literal["user", "assistant"]
    content: list[BedrockContentBlock]


class LLMChunk(BaseModelWithAlias):
    """Streaming the LLM message.

    Only relevant for assistant messages, so LLMRole is not required
    """

    content: str
    name: str | None = Field(default=None)

    ## TOOLS
    task_id: str | None = Field(default=None)
    tool_calls: Sequence[ToolCall] | None = Field(default=None)


# no validation
@dataclass
class MessagePart:
    role: LLMRole
    content: str

    def dict(self):
        return {"role": self.role, "content": self.content}


class LLMConversationMessage(BaseModelWithAlias):
    role: LLMRole
    content: str
    name: str | None = Field(default=None)

    ## TOOLS
    # tools are tasks tracked by ID
    task_id: str | None = Field(default=None)
    # tool_calls are equivalently named in openai
    tool_calls: Sequence[ToolCall] | None = Field(default=None)

    ## Thking blocks
    thinking_blocks: list[ThinkingBlock] | None = Field(default=None)

    def get_message_part(self) -> MessagePart:
        return MessagePart(role=self.role, content=self.content)

    def to_langchain(self) -> langchain.BaseMessage:
        match self.role:
            case LLMRole.USER:
                return langchain.HumanMessage(content=self.content)
            case LLMRole.SYSTEM:
                return langchain.SystemMessage(content=self.content)
            case LLMRole.ASSISTANT:
                return langchain.AIMessage(
                    content=self.content,
                    tool_calls=([t.to_langchain() for t in self.tool_calls] if self.tool_calls else []),
                )
            case LLMRole.TOOL:
                return langchain.ToolMessage(content=self.content, tool_call_id=self.task_id)

    def to_anthropic(self) -> MessageParam:
        match self.role:
            case LLMRole.USER:
                return {
                    "role": "user",
                    "content": self.content,
                }
            case LLMRole.ASSISTANT:
                content_blocks = []

                if self.thinking_blocks:
                    content_blocks.extend(self.thinking_blocks)

                if self.content:
                    content_blocks.append({"text": self.content, "type": "text"})

                if self.tool_calls:
                    content_blocks.extend(t.to_anthropic() for t in self.tool_calls)

                if content_blocks:
                    return {
                        "role": "assistant",
                        "content": content_blocks,
                    }
                else:
                    return {
                        "role": "assistant",
                        "content": "failed to generate content",
                    }

            case LLMRole.TOOL:
                if self.task_id is None:
                    raise ValueError("Tool message must have a task_id")
                return {
                    "role": "user",
                    "content": [
                        ToolResultBlockParam(
                            tool_use_id=self.task_id,
                            content=self.content,
                            is_error=False,
                            type="tool_result",
                        )
                    ],
                }
            case LLMRole.SYSTEM:
                raise ValueError(f"System message encountered: {self.content}")
            case _:
                raise NotImplementedError

    def to_cohere(self) -> CohereOutput:
        return {
            "role": llm_role_to_cohere(self.role),
            "message": self.content,
        }

    def to_openai(
        self,
    ) -> (
        openai.ChatCompletionUserMessageParam
        | openai.ChatCompletionSystemMessageParam
        | openai.ChatCompletionAssistantMessageParam
        | openai.ChatCompletionToolMessageParam
    ):
        match self.role:
            case LLMRole.USER:
                return {
                    "role": "user",
                    "content": self.content,
                }
            case LLMRole.SYSTEM:
                return {
                    "role": "system",
                    "content": self.content,
                }
            case LLMRole.ASSISTANT:
                if not self.tool_calls:
                    return {
                        "role": "assistant",
                        "content": self.content,
                    }
                else:
                    return {
                        "role": "assistant",
                        "content": self.content,
                        "tool_calls": [t.to_openai() for t in self.tool_calls],
                    }
            case LLMRole.TOOL:
                if self.task_id is None:
                    raise ValueError("Tool message must have a task_id")
                return {
                    "role": "tool",
                    "content": self.content,
                    "tool_call_id": self.task_id,
                }

    def to_bedrock(self) -> BedrockMessage:
        # NOTE: system messages are not supported in this field
        bedrock_role = "assistant" if self.role == LLMRole.ASSISTANT else "user"

        content_blocks: list[BedrockContentBlock] = []
        if self.content:
            content_blocks.append({"text": self.content})

        # If there are tool calls, append them as "toolUse" blocks
        if self.tool_calls:
            for t in self.tool_calls:
                content_blocks.append(
                    {
                        "toolUse": {
                            "toolUseId": t.task_id,
                            "name": t.name,
                            "input": t.args,
                        }
                    }
                )

        return {
            "role": cast(Literal["assistant", "user"], bedrock_role),
            "content": content_blocks,
        }

    def to_vertex(self) -> VertexMessage:
        match self.role:
            case LLMRole.USER:
                return {
                    "role": "user",
                    "parts": [{"text": self.content}],
                }
            case LLMRole.ASSISTANT:
                parts: list[VertexPart] = []
                if self.tool_calls:
                    parts = [t.to_gemini() for t in self.tool_calls]
                if self.content:
                    parts.append({"text": self.content})
                if not parts:
                    # cannot be empty
                    parts = [{"text": "[empty]"}]
                return {
                    "role": "model",
                    "parts": parts,
                }
            case LLMRole.TOOL:
                return {
                    "role": "user",
                    "parts": [
                        {"functionResponse": {"name": self.name or "Untitled", "response": {"result": self.content}}}
                    ],
                }
            case _:
                return {
                    "role": "user",
                    "parts": [{"text": self.content}],
                }

    @classmethod
    def from_langchain(cls, message: langchain.BaseMessage) -> Self:
        match message.type:
            case "human":
                m = cast(langchain.HumanMessage, message)
                return cls(role=LLMRole.USER, content=str(m.content), name=m.name)
            case "system":
                m = cast(langchain.SystemMessage, message)
                return cls(role=LLMRole.SYSTEM, content=str(m.content), name=m.name)
            case "ai":
                m = cast(langchain.AIMessage, message)
                return cls(
                    role=LLMRole.ASSISTANT,
                    content=str(m.content),
                    name=m.name,
                    task_id=m.id,
                    tool_calls=[ToolCall.from_langchain(t) for t in m.tool_calls],
                )
            case "tool":
                m = cast(langchain.ToolMessage, message)
                return cls(role=LLMRole.TOOL, content=str(m.content), task_id=m.tool_call_id)
            case _:
                raise NotImplementedError(f"Message type {message.type} not supported")

    @classmethod
    def from_openai(cls, message: ChatCompletionMessage) -> Self:
        return cls(
            role=LLMRole.from_openai(message.role),
            content=message.content or "",
            task_id=None,
            tool_calls=(
                [ToolCall.from_openai(t) for t in message.tool_calls] if message.tool_calls is not None else None
            ),
        )


class MessageWithId(BaseModel):
    """Temporarily placed here for the agent"""

    id_: UUID = Field(default_factory=uuid4)
    message: LLMConversationMessage


class AssistantOutput(BaseModelWithAlias):
    message: LLMConversationMessage
    structured_output: dict[str, Any] | None = None
    input_tokens: int
    output_tokens: int
    total_cost: Decimal


class MessageChunk(BaseModelWithAlias):
    content: str
    type: Literal["message"] = "message"


class ErrorChunk(BaseModelWithAlias):
    content: str
    type: Literal["error"] = "error"


class InputMetadataChunk(BaseModelWithAlias):
    input_tokens: int
    type: Literal["input-metadata"] = "input-metadata"


class OutputMetadataChunk(BaseModelWithAlias):
    output_tokens: int
    total_cost: float
    structured_output: dict[str, Any] | None = None
    type: Literal["output-metadata"] = "output-metadata"


class ThinkingMetadataChunk(BaseModelWithAlias):
    thinking_block: ThinkingBlock
    type: Literal["thinking"] = "thinking"


StreamChunk = Annotated[
    MessageChunk | InputMetadataChunk | OutputMetadataChunk | ThinkingMetadataChunk,
    Field(discriminator="type"),
]


class TimestampedConversationMessage(LLMConversationMessage):
    timestamp: float


class TaskInfo(BaseModelWithAlias):
    total_tokens: int
    total_cost: float


class BatchPart(BaseModelWithAlias):
    id: str
    messages: list[LLMConversationMessage]
    task_info: TaskInfo | None = None

    def get_batch_message_part(self) -> list[MessagePart]:
        return [message.get_message_part() for message in self.messages]

    @property
    def last_message(self) -> LLMConversationMessage:
        return self.messages[-1]


class BatchErrorPart(BaseModelWithAlias):
    id: str
    error: str


# ┌────────────────────────────────────────────────────────────────────────────┐
# │                                  Adapters                                  │
# └────────────────────────────────────────────────────────────────────────────┘


ProviderMessage = TypeVar("ProviderMessage", MessageParam, BedrockMessage)


class BaseMessageAdapter(ABC, Generic[ProviderMessage]):
    """Base class for converting Vision messages to provider-specific formats.

    Args:
        tools: A sequence of ToolCall objects representing known tools.

    Attributes:
        tools: The sequence of known ToolCall objects that can be invoked by messages.
        tool_names: The names of the known tools, extracted from `tools`.
        tool_uses: A dictionary mapping tool usage IDs (strings) to tool names (strings),
            used for referencing tool usage in subsequent blocks.
    """

    def __init__(self, tools: Sequence[ToolCall]):
        self.tools = tools
        self.tool_names = [tool.name for tool in tools]
        self.tool_uses: dict[str, str] = {}

    @abstractmethod
    def convert_single_message(self, message: LLMConversationMessage) -> ProviderMessage:
        """Convert a single Vision message to the provider format.

        Args:
            message: The LLMConversationMessage to be converted.

        Returns:
            ProviderMessage: The converted message in the provider-specific format.
        """
        pass

    @abstractmethod
    def merge_messages(self, prev_message: ProviderMessage, curr_message: ProviderMessage) -> ProviderMessage:
        """Merge two consecutive provider messages of the same role.

        We use Converse API from Amazon Bedrock, and it requires the messages to have alternating roles.

        Args:
            prev_message: The previously converted provider message.
            curr_message: The currently converted provider message.

        Returns:
            ProviderMessage: A single provider message that merges the content of both.
        """
        pass

    def convert_messages(self, messages: Sequence[LLMConversationMessage]) -> list[ProviderMessage]:
        """Convert a list of Vision messages to provider-specific format.

        This method:
        1. Iterates over each message in `messages`,
        2. Converts each message via `convert_single_message`,
        3. Merges consecutive messages that have the same role via `merge_messages`.

        Args:
            messages: A sequence of LLMConversationMessage objects to be converted.

        Returns:
            list[ProviderMessage]: A list of messages in the provider format.
        """
        converted_messages: list[ProviderMessage] = []

        for message in messages:
            converted = self.convert_single_message(message)

            # If the previous message is of the same role
            if converted_messages and converted_messages[-1]["role"] == converted["role"]:
                converted_messages[-1] = self.merge_messages(converted_messages[-1], converted)
            else:
                converted_messages.append(converted)

        return converted_messages


AnthropicBlock = (
    TextBlockParam
    | ImageBlockParam
    | ToolUseBlockParam
    | ToolResultBlockParam
    | DocumentBlockParam
    | ContentBlock
    | ThinkingBlock
    | RedactedThinkingBlock
)


class AnthropicMessageAdapter(BaseMessageAdapter[MessageParam]):
    """Adapter for converting Vision messages to Anthropic format."""

    def __init__(self, tools: Sequence[ToolCall], thinking_enabled: bool = False):
        """Initialize the adapter with tools and thinking configuration.

        Args:
            tools: A sequence of ToolCall objects representing known tools.
            thinking_enabled: Whether extended thinking is enabled for this conversation.
        """
        super().__init__(tools)
        self.thinking_enabled = thinking_enabled
        self.preserved_thinking_blocks: list[ThinkingBlock | RedactedThinkingBlock] = []

    @override
    def convert_single_message(self, message: LLMConversationMessage) -> MessageParam:
        """Convert a single Vision message to Anthropic's MessageParam format.

        This method:
        - Validates that the message role is either "user" or "assistant".
        - Converts the content into a list of blocks or a single text block.
        - Replaces unknown tool calls with textual placeholders.

        Args:
            message: The LLMConversationMessage to be converted.

        Returns:
            MessageParam: The message in Anthropic's format.

        Raises:
            ValueError: If the message role is neither "user" nor "assistant".
        """
        anthropic_message = message.to_anthropic()

        if anthropic_message["role"] not in {"user", "assistant"}:
            raise ValueError(f"Invalid role '{anthropic_message['role']}', expected 'user' or 'assistant'.")

        content = anthropic_message["content"]

        if isinstance(content, str):
            return anthropic_message

        if anthropic_message["role"] == "user":
            anthropic_message["content"] = (
                self._process_user_content(content) if not isinstance(content, str) else content
            )

        elif anthropic_message["role"] == "assistant":
            anthropic_message["content"] = (
                self._process_assistant_content(content) if not isinstance(content, str) else content
            )

        return anthropic_message

    def _extract_thinking_blocks(
        self, content_blocks: Iterable[AnthropicBlock]
    ) -> list[ThinkingBlock | RedactedThinkingBlock]:
        """Extract thinking blocks from content blocks."""
        thinking_blocks = []
        for block in content_blocks:
            if isinstance(block, dict) and block.get("type") in {"thinking", "redacted_thinking"}:
                thinking_blocks.append(block)
        return thinking_blocks

    def _has_tool_use_blocks(self, content_blocks: Iterable[AnthropicBlock]) -> bool:
        """Check if content blocks contain any tool use blocks."""
        for block in content_blocks:
            if isinstance(block, ToolUseBlock):
                return True
            elif isinstance(block, dict) and block.get("type") == "tool_use":
                return True
        return False

    def _ensure_thinking_block_for_tool_use(self, content_blocks: list[AnthropicBlock]) -> list[AnthropicBlock]:
        """Ensure that tool use messages start with a thinking block when thinking is enabled."""
        if not self.thinking_enabled:
            return content_blocks

        # Check if this message has tool use
        has_tool_use = self._has_tool_use_blocks(content_blocks)
        if not has_tool_use:
            return content_blocks

        # Check if the message already starts with a thinking block
        if (
            content_blocks
            and isinstance(content_blocks[0], dict)
            and content_blocks[0].get("type") in {"thinking", "redacted_thinking"}
        ):
            return content_blocks

        # If we have preserved thinking blocks from previous messages, use the most recent one
        if self.preserved_thinking_blocks:
            return [self.preserved_thinking_blocks[-1]] + content_blocks

        # As a fallback, create a minimal thinking block
        fallback_thinking = {
            "type": "thinking",
            "thinking": "I need to use a tool to help with this request.",
            "signature": "fallback_thinking_block",
        }
        return [fallback_thinking] + content_blocks

    def _process_user_content(self, content_blocks: Iterable[AnthropicBlock]) -> list[AnthropicBlock]:
        """Process the content blocks for a user message in Anthropic format.

        This method:
        - Passes `ToolUseBlock` and `TextBlock` blocks through unmodified.
        - Detects `tool_result` blocks and determines whether the tool is known.
        - Converts unknown tool results into text blocks.

        Args:
            content_blocks: An iterable of AnthropicBlock objects for a user message.

        Returns:
            list[AnthropicBlock]: A list of processed blocks for the user message.
        """
        new_content_blocks: list[AnthropicBlock] = []
        for block in content_blocks:
            if isinstance(block, ToolUseBlock | TextBlock):
                # Keep known text blocks or tool use blocks as is
                new_content_blocks.append(block)
            elif isinstance(block, dict) and block.get("type") == "tool_result":
                block = cast(ToolResultBlockParam, block)
                new_content_blocks.append(self._handle_tool_result_block(block))
            else:
                # Any other kind of block is simply passed through
                new_content_blocks.append(block)
        return new_content_blocks

    def _handle_tool_result_block(self, block: ToolResultBlockParam) -> AnthropicBlock:
        """Process a 'tool_result' block, converting unknown tool results into text.

        Args:
            block: A dictionary representing a tool result block.

        Returns:
            AnthropicBlock: Either the original block (if tool is known),
                            or a text block summarizing the unknown tool result.
        """
        tool_use_id = block["tool_use_id"]
        if tool_use_id in self.tool_uses and self.tool_uses[tool_use_id] in self.tool_names:
            # Known tool -> pass the block through
            return block
        else:
            # Unknown tool -> convert to text
            content_text = block.get("content", "")
            return TextBlockParam(
                text=f"Tool ({tool_use_id}) returned `{content_text}`",
                type="text",
            )

    def _process_assistant_content(self, content_blocks: Iterable[AnthropicBlock]) -> list[AnthropicBlock]:
        """Process the content blocks for an assistant message in Anthropic format.

        This method:
        - Passes `TextBlock` blocks through unmodified.
        - For `ToolUseBlock` blocks, checks whether the tool is known and records usage.
        - Converts unknown tool usage into text blocks.
        - Also handles dictionary-based "tool_use" blocks, applying the same logic.
        - Preserves thinking blocks for future use when extended thinking is enabled.

        Args:
            content_blocks: An iterable of AnthropicBlock objects for an assistant message.

        Returns:
            list[AnthropicBlock]: A list of processed blocks for the assistant message.
        """
        content_list = list(content_blocks)

        # Extract and preserve thinking blocks if thinking is enabled
        if self.thinking_enabled:
            thinking_blocks = self._extract_thinking_blocks(content_list)
            if thinking_blocks:
                self.preserved_thinking_blocks.extend(thinking_blocks)

        new_content_blocks: list[AnthropicBlock] = []
        for block in content_list:
            if isinstance(block, ToolUseBlock | TextBlock):
                # Object-based block (e.g., ToolUseBlock or TextBlock)
                new_content_blocks.append(self._handle_assistant_object_block(block))
            else:
                # Dictionary-based blocks or something else
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    block = cast(ToolUseBlockParam, block)
                    new_content_blocks.append(self._handle_assistant_dict_tool_use(block))
                else:
                    new_content_blocks.append(block)

        # Ensure thinking block for tool use if needed
        new_content_blocks = self._ensure_thinking_block_for_tool_use(new_content_blocks)

        return new_content_blocks

    def _handle_assistant_object_block(self, block: ToolUseBlock | TextBlock) -> AnthropicBlock:
        """Handle assistant blocks that are ToolUseBlock or TextBlock objects.

        For `ToolUseBlock`:
        - Records tool usage (`self.tool_uses[block.id] = block.name`)
        - Converts unknown tool usage to a text block.

        For `TextBlock`:
        - Returns it directly.

        Args:
            block: A ToolUseBlock or TextBlock object.

        Returns:
            AnthropicBlock: The processed block (or a text block if tool is unknown).
        """
        if block.type == "tool_use":
            self.tool_uses[block.id] = block.name
            if block.name in self.tool_names:
                return block
            else:
                # Unknown tool usage
                text = f"Tool ({block.id}) `{block.name}` with ({block.input}) called"
                return TextBlock(text=text, type="text")
        else:
            # It's a TextBlock or something else recognized
            return block

    def _handle_assistant_dict_tool_use(self, block: ToolUseBlockParam) -> AnthropicBlock:
        """Handle dictionary-based 'tool_use' blocks for assistant messages.

        Args:
            block: A dictionary representing a 'tool_use' block, containing 'id', 'name', and 'input'.

        Returns:
            AnthropicBlock: The processed block (or a text block if tool is unknown).
        """
        tool_id = block["id"]
        tool_name = block["name"]
        self.tool_uses[tool_id] = tool_name

        if tool_name in self.tool_names:
            return block
        else:
            text = f"Tool ({tool_id}) `{tool_name}` with ({block['input']}) called"
            return TextBlockParam(text=text, type="text")

    @override
    def merge_messages(self, prev_message: MessageParam, curr_message: MessageParam) -> MessageParam:
        """Merge two consecutive Anthropic messages of the same role.

        Merges the content blocks from `prev_message` and `curr_message`.
        If a content block is a string, it is converted into a `TextBlockParam`
        before merging.

        Args:
            prev_message: The previously converted Anthropic message.
            curr_message: The currently converted Anthropic message.

        Returns:
            MessageParam: A new Anthropic message that combines the content
                blocks of both messages.
        """
        prev_content = prev_message["content"]
        curr_content = curr_message["content"]

        if isinstance(prev_content, str):
            prev_blocks = [TextBlockParam(text=prev_content, type="text")]
        else:
            prev_blocks = prev_content

        if isinstance(curr_content, str):
            curr_blocks = [TextBlockParam(text=curr_content, type="text")]
        else:
            curr_blocks = curr_content

        return MessageParam(role=prev_message["role"], content=[*prev_blocks, *curr_blocks])

    def convert_messages(self, messages: Sequence[LLMConversationMessage]) -> list[MessageParam]:
        """Convert a list of Vision messages to provider-specific format.

        This method:
        1. Iterates over each message in `messages`,
        2. Converts each message via `convert_single_message`,
        3. Merges consecutive messages that have the same role via `merge_messages`.
        4. Ensures the last assistant message starts with a thinking block when using extended thinking with tools.

        Args:
            messages: A sequence of LLMConversationMessage objects to be converted.

        Returns:
            list[MessageParam]: A list of messages in the provider format.
        """
        converted_messages: list[MessageParam] = []

        for message in messages:
            converted = self.convert_single_message(message)

            # If the previous message is of the same role
            if converted_messages and converted_messages[-1]["role"] == converted["role"]:
                converted_messages[-1] = self.merge_messages(converted_messages[-1], converted)
            else:
                converted_messages.append(converted)

        # Final check: ensure the last assistant message starts with thinking if it has tool use
        if self.thinking_enabled and converted_messages:
            last_message = converted_messages[-1]
            if (
                last_message["role"] == LLMRole.ASSISTANT
                and not isinstance(last_message["content"], str)
                and self._has_tool_use_blocks(last_message["content"])
            ):

                # Ensure thinking block at the start
                content_blocks = list(last_message["content"])
                if not (
                    content_blocks
                    and isinstance(content_blocks[0], dict)
                    and content_blocks[0].get("type") in {"thinking", "redacted_thinking"}
                ):

                    if self.preserved_thinking_blocks:
                        content_blocks = [self.preserved_thinking_blocks[-1]] + content_blocks
                    else:
                        fallback_thinking = {
                            "type": "thinking",
                            "thinking": "I need to use a tool to help with this request.",
                            "signature": "fallback_thinking_block",
                        }
                        content_blocks = [fallback_thinking] + content_blocks

                    last_message["content"] = content_blocks

        return converted_messages


class BedrockMessageAdapter(BaseMessageAdapter[BedrockMessage]):
    """Adapter for converting Vision messages to Bedrock format."""

    @override
    def convert_single_message(self, message: LLMConversationMessage) -> BedrockMessage:
        """Convert a single Vision message to BedrockMessage format.

        This method:
        - Retrieves the Bedrock representation of the message via `message.to_bedrock()`.
        - Validates the role (must be "user" or "assistant").
        - Processes the content, which may be a string or list of blocks.
        - Converts unknown tool usage to text blocks.

        Args:
            message: The LLMConversationMessage to be converted.

        Returns:
            BedrockMessage: The message transformed into Bedrock's required format.

        Raises:
            ValueError: If the message role is invalid (i.e., not "user" or "assistant").
        """
        bedrock_message = message.to_bedrock()

        if bedrock_message["role"] not in {"user", "assistant"}:
            raise ValueError(f"Invalid role '{bedrock_message['role']}', expected 'user' or 'assistant'.")

        content = bedrock_message["content"]

        if isinstance(content, str):
            return BedrockMessage(role=bedrock_message["role"], content=[BedrockContentBlock(text=content)])

        if bedrock_message["role"] == "user":
            processed = self._process_user_content(content)
        else:
            processed = self._process_assistant_content(content)

        bedrock_message["content"] = processed
        return bedrock_message

    def _process_user_content(self, blocks: list[str | dict[str, Any]]) -> list[BedrockContentBlock | dict[str, Any]]:
        """Process the content blocks of a user Bedrock message.

        This method checks for strings (treated as text blocks),
        for tool usage (`toolUse`) blocks, and for tool result (`toolResult`) blocks.
        Unknown tool usage or tool results are converted to text.

        Args:
            blocks: A list of blocks or strings representing user content.

        Returns:
            list[BedrockContentBlock | dict[str, Any]]: A list of processed content blocks
                suitable for a user role in Bedrock messages.
        """
        content_blocks: list[BedrockContentBlock | dict[str, Any]] = []

        for block in blocks:
            if isinstance(block, str):
                content_blocks.append(BedrockContentBlock(text=block))
            elif "toolUse" in block:
                content_blocks.append(self._handle_tool_use(block))
            elif "toolResult" in block:
                content_blocks.append(self._handle_tool_result(block))
            else:
                # Generic or unknown block
                content_blocks.append(block)

        return content_blocks

    def _process_assistant_content(
        self, blocks: list[str | dict[str, Any]]
    ) -> list[BedrockContentBlock | dict[str, Any]]:
        """Process the content blocks of an assistant Bedrock message.

        This method checks for strings (treated as text blocks) and for tool usage
        (`toolUse`) blocks. Unknown tools are converted to plain text blocks.

        Args:
            blocks: A list of blocks or strings representing assistant content.

        Returns:
            list[BedrockContentBlock | dict[str, Any]]: A list of processed content blocks
                suitable for an assistant role in Bedrock messages.
        """
        content_blocks: list[BedrockContentBlock | dict[str, Any]] = []

        for block in blocks:
            if isinstance(block, str):
                content_blocks.append(BedrockContentBlock(text=block))
            elif "toolUse" in block:
                content_blocks.append(self._handle_tool_use(block))
            else:
                # Generic or unknown block
                content_blocks.append(block)

        return content_blocks

    def _handle_tool_use(self, block: dict[str, Any]) -> BedrockContentBlock | dict[str, Any]:
        """Handle recognized or unrecognized tool usage.

        If the tool name is known (in `self.tool_names`), the block is returned unchanged.
        Otherwise, it is converted into a text block indicating that a tool was called.

        Args:
            block: A dictionary containing a `toolUse` sub-dict, describing the tool usage.

        Returns:
            BedrockContentBlock | dict[str, Any]:
                The original block if recognized, or a text block if the tool is unknown.
        """
        tool_use = block["toolUse"]
        self.tool_uses[tool_use["toolUseId"]] = tool_use["name"]

        if tool_use["name"] in self.tool_names:
            return block
        else:
            text = f"Tool ({tool_use['toolUseId']}) `{tool_use['name']}` with ({tool_use['input']}) called"
            return BedrockContentBlock(text=text)

    def _handle_tool_result(self, block: dict[str, Any]) -> BedrockContentBlock | dict[str, Any]:
        """Process a `toolResult` block, converting unknown tool results to text.

        This method:
        - Checks if the `toolUseId` is recognized in `self.tool_uses`.
        - If recognized, returns the block unmodified.
        - If unrecognized, extracts text from the result and returns a text block.

        Args:
            block: A dictionary containing a `toolResult` sub-dict.

        Returns:
            BedrockContentBlock | dict[str, Any]:
                The original `toolResult` block, or a text block if the tool is unknown.
        """
        tool_result = block["toolResult"]
        if tool_result["toolUseId"] in self.tool_uses and self.tool_uses[tool_result["toolUseId"]] in self.tool_names:
            return block
        else:
            result_content = []
            for result_block in tool_result["content"]:
                if "text" in result_block:
                    result_content.append(result_block["text"])
            content_text = " ".join(result_content) if result_content else ""
            return BedrockContentBlock(text=f"Tool ({tool_result['toolUseId']}) returned `{content_text}`")

    @override
    def merge_messages(self, prev_message: BedrockMessage, curr_message: BedrockMessage) -> BedrockMessage:
        """Merge two consecutive Bedrock messages with the same role.

        The content in both messages is combined into a single `BedrockMessage`.
        Any string blocks in `prev_message` or `curr_message` are converted to
        `BedrockContentBlock` objects.

        Args:
            prev_message: The previously converted Bedrock message.
            curr_message: The currently converted Bedrock message.

        Returns:
            BedrockMessage: A new message containing the merged content of both.
        """

        def ensure_content_block(block: BedrockContentBlock | str) -> BedrockContentBlock:
            if isinstance(block, str):
                return BedrockContentBlock(text=block)
            return block

        return BedrockMessage(
            role=prev_message["role"],
            content=[
                *[ensure_content_block(block) for block in prev_message["content"]],
                *[ensure_content_block(block) for block in curr_message["content"]],
            ],
        )


def vision_messages_to_anthropic(
    messages: Sequence[LLMConversationMessage], tools: Sequence[ToolCall], thinking_enabled: bool = False
) -> list[MessageParam]:
    adapter = AnthropicMessageAdapter(tools, thinking_enabled=thinking_enabled)
    return adapter.convert_messages(messages)


def vision_messages_to_bedrock(
    messages: Sequence[LLMConversationMessage], tools: Sequence[ToolCall]
) -> list[BedrockMessage]:
    adapter = BedrockMessageAdapter(tools)
    return adapter.convert_messages(messages)
