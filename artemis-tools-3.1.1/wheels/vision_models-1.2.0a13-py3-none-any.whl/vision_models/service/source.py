from enum import StrEnum
from typing import Any, TypeVar

from pydantic import BaseModel

# Source imports
from vision_models.service.ai.sources.enums import LLMToolEnum
from vision_models.service.base_data_types import BaseModelWithAlias

OutputT = TypeVar("OutputT", bound=BaseModel)


class SourceType(StrEnum):
    google = "google"
    artemis = "artemis"
    webscrape = "webscrape"
    artemis_hyde = "artemis-hyde"


class SingleSourceConfig(BaseModelWithAlias):
    """A configuration for a single source.

    Not to be used directly, but to be used as a base class for other source configs,
    since derived classes define a `params` field
    """

    name: SourceType
    params: Any


class SingleSourceSelectionInfo(BaseModel):
    """Source to index mapping.

    See `SourceSelectionInfo`. When the list of used sources is returned to
    front-end, these sources are identified by index. We just return the list
    of sources used.
    """

    source: LLMToolEnum
    index: int


class SourceSelectionInfo(BaseModel):
    """Which sources got selected.

    During a task where more sources are generated than used by the LLM, it is necessary to communicate which ones are
    used, as a chunk after the original sources are sent over. This is done separately due to streaming, the decision of
    which sources to use is done after the sources are sent
    """

    sources: list[SingleSourceSelectionInfo]


class SourceDetails(BaseModel):
    name: str
    code: str


class SourcesConfig(BaseModelWithAlias):
    enabled: list[SingleSourceConfig]
