from typing import Optional
from uuid import UUID

from falcon_models.service.base_data_types import BaseModelWithAlias


class Tool(BaseModelWithAlias):
    name: str
    label: Optional[str] = None
    value: Optional[float] = None
    description: Optional[str] = None

    def __str__(self):
        parts = [f"tool: **{self.name}**"]

        if self.label is not None and self.value is not None:
            parts.append(f"*{self.label}*: `{self.value}`")
        else:
            if self.label is not None:
                parts.append(f"*outcome*: `{self.label}`")
            if self.value is not None:
                parts.append(f"*value*: `{self.value}`")

        if self.description is not None:
            parts.append(f"*reasoning*: {self.description}")

        return " | ".join(parts)


class CodeContextModel(BaseModelWithAlias):
    """Tool context standardised by sourcekon"""

    customspec_id: UUID
    tool_id: UUID
    context: str
