from enum import StrEnum

from falcon_models.service.base_data_types import BaseModelWithAlias


class DBType(StrEnum):
    POSTGRESQL = "POSTGRESQL"
    MONGODB = "MONGODB"


class DbConnectionDetails(BaseModelWithAlias):
    db_host: str
    db_port: int | None = None
    db_name: str
    db_username: str
    db_password: str
    db_schema: str | None = None
    connection_url: str | None = None
