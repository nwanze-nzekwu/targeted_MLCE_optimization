from falcon_models.service.base_data_types import BaseModelWithAlias


class GroupedSpecs(BaseModelWithAlias):
    score: float
    occurences: int


class AggregatedScore(BaseModelWithAlias):
    name: str
    score: float
    occurences: int
