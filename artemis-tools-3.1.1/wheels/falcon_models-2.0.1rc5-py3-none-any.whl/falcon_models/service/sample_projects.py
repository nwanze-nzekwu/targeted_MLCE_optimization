from enum import Enum
from typing import Dict

from pydantic import model_validator

from falcon_models.api.code_models import ProjectInfoRequest
from falcon_models.service.base_data_types import BaseModelWithAlias, PaginatedBase
from falcon_models.service.utils import no_trailing_slash


class SampleProjectEnum(str, Enum):
    JSON = "json"
    SIMPLE = "simple"
    XGBOOST = "xgboost"
    LEVELDB = "leveldb"
    CPP_LLM = "cpp-llm"
    JAVA_LLM = "java-llm"
    PY_LLM = "py-llm"
    PY_CHAT = "py-chat"
    NEXTJS = "nextjs-starter"
    NEXTJS_ELEVENLABS = "nextjs-elevenlabs-ai"
    JS_LANDING = "js-landing-page"
    REACT_NATIVE = "react-native-starter"
    NODEJS_STARTER = "nodejs-api-starter"
    AGENT_KIT = "agent-kit-starter"
    OPEN_OPERATOR = "open-operator-starter"
    HTML_STARTER = "html-starter"
    DOTNET_STARTER = "dotnet-starter"
    DJANGO_STARTER = "django-starter"
    FLASK_STARTER = "flask-starter"
    SWIFT_STARTER = "swift-starter"
    RAILS_STARTER = "rails-starter"


class SampleProjectInfo(BaseModelWithAlias):
    """Sample project info"""

    name: str
    description: str
    code: SampleProjectEnum
    project: ProjectInfoRequest
    fork_link: str | None = None

    @model_validator(mode="after")
    def fork_link_setup(self):
        """We want to remove any trailing slash if value is not the empty string"""
        if not self.fork_link and "github" in self.project.git_url:
            self.fork_link = f"{no_trailing_slash(value=self.project.git_url)}/fork"
        return self


class PaginatedSampleProjectInfoResponse(PaginatedBase[SampleProjectInfo]): ...


SAMPLE_PROJECTS: Dict[str, SampleProjectInfo] = {
    "cpp-llm": SampleProjectInfo(
        name="Sample C++ Project",
        code=SampleProjectEnum.CPP_LLM,
        description="This is a sample project for C++ optimization",
        project=ProjectInfoRequest(
            name="Sample C++ Project",
            git_url="https://github.com/turintech/sample-project-cpp",
            compile_command="cd {{PROJECT_DIR}} && make && {{BEAR}} make compile",
            unit_test_command="cd {{PROJECT_DIR}} && build/tests/tests [test]",
            perf_command="cd {{PROJECT_DIR}} && build/tests/tests [benchmark]",
        ),
    ),
    "java-llm": SampleProjectInfo(
        name="Sample Java Project",
        code=SampleProjectEnum.JAVA_LLM,
        description="This is a sample project for Java optimization",
        project=ProjectInfoRequest(
            name="Sample Java Project",
            git_url="https://github.com/turintech/sample-project-java",
            compile_command="chmod +x gradlew && ./gradlew build -x test",
            unit_test_command="./gradlew test",
            perf_command="./gradlew run",
        ),
    ),
    "py-llm": SampleProjectInfo(
        name="Sample Python Project",
        code=SampleProjectEnum.PY_LLM,
        description="This is a sample project for Python optimization",
        project=ProjectInfoRequest(
            name="Sample Python Project",
            git_url="https://github.com/turintech/sample-project-python",
            compile_command="pip3 install poetry && python -m poetry install",
            unit_test_command="python -m poetry run pytest --benchmark-skip tests/",
            perf_command="python -m poetry run pytest --benchmark-only tests/",
        ),
    ),
    "py-chat": SampleProjectInfo(
        name="Python LLM Chat",
        code=SampleProjectEnum.PY_CHAT,
        description="A template to create any LLM Inference Web Apps using Python only.",
        project=ProjectInfoRequest(
            name="Python LLM Chat",
            git_url="https://github.com/Avaiga/demo-chatbot",
            compile_command="pip install -r requirements.txt && python main.py",
        ),
    ),
    "nextjs-starter": SampleProjectInfo(
        name="Next.js Boilerplate",
        code=SampleProjectEnum.NEXTJS,
        description="A starter boilerplate for Next.js 15 with App Router and Page Router support, Tailwind CSS 4 and TypeScript.",
        project=ProjectInfoRequest(
            name="Next.js Boilerplate",
            git_url="https://github.com/ixartz/Next-js-Boilerplate",
            compile_command="npm install && npm run dev",
            unit_test_command="npm run test",
        ),
    ),
    "nextjs-elevenlabs-ai": SampleProjectInfo(
        name="NextJS Conversational AI Template",
        code=SampleProjectEnum.NEXTJS_ELEVENLABS,
        description="ElevenLabs Conversational AI NextJS v15 Template.",
        project=ProjectInfoRequest(
            name="ElevenLabs Conversational AI NextJS Template",
            git_url="https://github.com/ixartz/Next-js-Boilerplate",
            compile_command="npm install && npm run dev",
            unit_test_command="npm run test",
        ),
    ),
    "js-landing-page": SampleProjectInfo(
        name="React / Next.js Landing Page Template",
        code=SampleProjectEnum.JS_LANDING,
        description="React / Next.js landing page template designed to showcase open source projects, SaaS products, online services, and more.",
        project=ProjectInfoRequest(
            name="React / Next.js landing page template",
            git_url="https://github.com/cruip/open-react-template",
            compile_command="npm install && npm run dev",
            unit_test_command="npm run test",
        ),
    ),
    "react-native-starter": SampleProjectInfo(
        name="React Native Template",
        code=SampleProjectEnum.REACT_NATIVE,
        description="A React Native template for building solid applications using JavaScript or Typescript.",
        project=ProjectInfoRequest(
            name="React Native Template",
            git_url="https://github.com/thecodingmachine/react-native-boilerplate",
            compile_command="npm install && npm run dev",
            unit_test_command="npm run test",
        ),
    ),
    "nodejs-api-starter": SampleProjectInfo(
        name="Node.js CRUD API Template",
        code=SampleProjectEnum.NODEJS_STARTER,
        description=" A production-ready LLM-Powered Node.js & TypeScript REST API template, with a focus on Clean Architecture.",
        project=ProjectInfoRequest(
            name="Node.js CRUD API template",
            git_url="https://github.com/vyancharuk/nodejs-todo-api-boilerplate",
            compile_command="npm install && npm run dev",
            unit_test_command="npm run test",
        ),
    ),
    "agent-kit-starter": SampleProjectInfo(
        name="Agent Kit",
        code=SampleProjectEnum.AGENT_KIT,
        description="Starter-kit to build constrained agents with Nextjs, FastAPI and Langchain.",
        project=ProjectInfoRequest(
            name="Agent Kit",
            git_url="https://github.com/BCG-X-Official/agentkit",
        ),
    ),
    "open-operator-starter": SampleProjectInfo(
        name="Open Operator",
        code=SampleProjectEnum.OPEN_OPERATOR,
        description="A template for building web agents with Stagehand on Browserbase.",
        project=ProjectInfoRequest(
            name="Open Operator",
            git_url="https://github.com/browserbase/open-operator",
            compile_command="pnpm install && pnpm dev",
        ),
    ),
    "html-starter": SampleProjectInfo(
        name="HTML5 Boilerplate",
        code=SampleProjectEnum.HTML_STARTER,
        description="A front-end template for building fast, robust, and adaptable web apps or sites.",
        project=ProjectInfoRequest(
            name="HTML5 Boilerplate",
            git_url="https://github.com/h5bp/html5-boilerplate",
        ),
    ),
    "dotnet-starter": SampleProjectInfo(
        name=".NET 9 Starter Kit",
        code=SampleProjectEnum.DOTNET_STARTER,
        description="Production Grade Cloud-Ready .NET 9 Starter Kit (Web API + Blazor Client) with Multitenancy Support.",
        project=ProjectInfoRequest(
            name=".NET 9 Starter Kit",
            git_url="https://github.com/fullstackhero/dotnet-starter-kit",
        ),
    ),
    "django-starter": SampleProjectInfo(
        name="Django Boilerplate",
        code=SampleProjectEnum.DJANGO_STARTER,
        description="A production-ready django SAAS Boilerplate.",
        project=ProjectInfoRequest(
            name="Django Boilerplate",
            git_url="https://github.com/PaulleDemon/Django-SAAS-Boilerplate",
            compile_command="pip install -r requirements.txt",
        ),
    ),
    "flask-starter": SampleProjectInfo(
        name="Flask App Builder",
        code=SampleProjectEnum.FLASK_STARTER,
        description="Simple and rapid application development framework, built on top of Flask.",
        project=ProjectInfoRequest(
            name="Flask App Builder",
            git_url="https://github.com/dpgaspar/Flask-AppBuilder",
        ),
    ),
    "swift-starter": SampleProjectInfo(
        name="Swift 6 Module Template",
        code=SampleProjectEnum.SWIFT_STARTER,
        description="Template for reusable Swift 6 modules.",
        project=ProjectInfoRequest(
            name="Swift 6 Module Template",
            git_url="https://github.com/fulldecent/swift6-module-template",
        ),
    ),
    "rails-starter": SampleProjectInfo(
        name="Rails + Docker App",
        code=SampleProjectEnum.RAILS_STARTER,
        description="A production ready example Rails app that's using Docker and Docker Compose.",
        project=ProjectInfoRequest(
            name="Rails + Docker app",
            git_url="https://github.com/nickjj/docker-rails-example",
        ),
    ),
}
