from enum import StrEnum

from falcon_models.service.base_data_types import BaseModelWithAlias


class BoxplotData(BaseModelWithAlias):
    """
    Model for the boxplot data
    """

    min: float
    q1: float
    median: float
    q3: float
    max: float


class AnalysisScore(BaseModelWithAlias):
    """
    Model for the analysis score
    """

    average_score: float
    occurrences: int
    boxplot_data: BoxplotData


class ScoreType(StrEnum):
    """
    Enum for the different types of scores that can be generated
    """

    PERFORMANCE = "performance"
    QUALITY = "quality"
    COMPATIBILITY = "compatibility"
    SECURITY = "security"
    EQUIVALENCE = "equivalence"
    VALUE = "value"
    OPTIMISATION = "optimisation"


class ValidationType(StrEnum):
    """
    Model for the compilation graph
    """

    COMPILATION = "compilation"
    UNIT = "unit"


class ValidationResults(BaseModelWithAlias):
    """
    Model for the validation results
    """

    filtering_type: str
    llm_type: str
    total_occurrences: int
    total_passed: int
    total_failed: int


class ModelCost(BaseModelWithAlias):
    name: str
    input_cost: float
    output_cost: float
