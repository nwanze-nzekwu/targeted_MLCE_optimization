from datetime import datetime
from typing import TYPE_CHECKING, List, Literal, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel
from sqlalchemy import Column, DateTime, func
from sqlmodel import Field, Relationship

from falcon_models.api.ai_models import AIInferenceTask
from falcon_models.service.base_data_types import BaseSQLModelWithAlias

if TYPE_CHECKING:
    from falcon_models.service.code import CustomSpecScore, ProjectInfo


class PromptBase(BaseSQLModelWithAlias):
    """
    Info about a specific prompt
    """

    name: str | None = Field(default=None, description="Prompt name", nullable=True)
    body: str = Field(description="Prompt body")
    task: AIInferenceTask = Field(
        ...,
        description="Type of inference task for which this prompt is used",
        index=True,
    )
    subtask: Optional[str] = Field(
        default=None,
        description="Type of inference subtask for which this prompt is used",
        index=True,
        nullable=True,
    )
    model: Optional[str] = Field(
        default=None,
        description="Model to which this prompt is tied",
        index=True,
        nullable=True,
    )
    source_prompt_id: Optional[UUID] = Field(
        default=None,
        description="ID of prompt source",
    )


class Prompt(PromptBase, table=True):
    __table_args__ = ({"extend_existing": True},)

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of prompt",
    )
    project_id: Optional[UUID] = Field(
        None,
        description="ID of project",
        foreign_key="projectinfo.id",
        nullable=True,
        ondelete="CASCADE",
    )

    project: Optional["ProjectInfo"] = Relationship(back_populates="prompts")

    created_at: datetime = Field(
        default_factory=datetime.now,
        description="Timestamp of project prompt creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
        ),
    )

    last_used_at: Optional[datetime] = Field(
        default=None,
        description="Timestamp of project prompt last used",
        sa_column=Column(DateTime),
    )

    scores: List["CustomSpecScore"] = Relationship(back_populates="prompt")
