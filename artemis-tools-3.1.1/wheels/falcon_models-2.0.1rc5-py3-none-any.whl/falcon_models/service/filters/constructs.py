from datetime import datetime
from typing import TYPE_CHECKING, Dict, List, Optional, Type, Union
from uuid import UUID, uuid4

from sqlmodel import Column, DateTime, Field, ForeignKeyConstraint, Relationship, String, UniqueConstraint, func

from falcon_models.enums.filters.constructs import FilterTypeEnum, ValidationFilterTypeEnum
from falcon_models.service.base_data_types import BaseModelWithAlias, BaseSQLModelWithAlias, PaginationParams

if TYPE_CHECKING:
    from falcon_models.service.code import CustomSpec, FilteringRun


class IncludeExcludePattern(BaseModelWithAlias):
    pattern: str
    match_case: bool = False
    regex: bool = False


class LocationFilterParams(BaseModelWithAlias):
    include: List[IncludeExcludePattern] = []
    exclude: List[IncludeExcludePattern] = []


class ScoreType(BaseModelWithAlias):
    name: str
    min: Optional[float]
    max: Optional[float]


class ScoreAverage(BaseModelWithAlias):
    min: Optional[float]
    max: Optional[float]


class BaseScoresFilterParams(BaseModelWithAlias):
    types: Optional[List[ScoreType]] = None
    average: Optional[ScoreAverage] = None
    llms: Optional[List[str]] = None


class RecommendationScoresFilterParams(BaseScoresFilterParams): ...


class OriginalScoreFilterParams(BaseScoresFilterParams): ...


class Tag(BaseModelWithAlias):
    id: UUID
    project_id: UUID | None = None
    name: str


class TagsFilterParams(BaseModelWithAlias):
    values: List[Tag]


class RecommendationsFilterParams(BaseModelWithAlias):
    exists: Optional[bool] = None
    enabled_only: bool = False
    top_only: bool = False
    original: Optional[bool] = None
    optimisation_id: Optional[UUID] = None
    solution_id: Optional[UUID] = None
    optimisation_original: Optional[bool] = False
    recommendation_ids: Optional[List[UUID]] = None


class ValidatedFilterParams(BaseModelWithAlias):
    passed: List[str] | None = None
    failed: List[str] | None = None
    not_failed: bool | None = None
    has_validation: bool | None = None


class LineLength(BaseModelWithAlias):
    min: Optional[float]
    max: Optional[float]


class SnippetFilterParams(BaseModelWithAlias):
    ids: Optional[List[str]] = None
    lines: Optional[LineLength] = None
    enabled_only: bool = False
    deprecated: bool | None = False


class ExtractionRunFilterParams(BaseModelWithAlias):
    extraction_ids: List[UUID]


FILTER_TYPE_MAP: Dict[FilterTypeEnum, Type[BaseModelWithAlias]] = {
    FilterTypeEnum.location: LocationFilterParams,
    FilterTypeEnum.originalScore: OriginalScoreFilterParams,
    FilterTypeEnum.tags: TagsFilterParams,
    FilterTypeEnum.recommendations: RecommendationsFilterParams,
    FilterTypeEnum.recommendationScores: RecommendationScoresFilterParams,
    FilterTypeEnum.validated: ValidatedFilterParams,
    FilterTypeEnum.snippets: SnippetFilterParams,
    FilterTypeEnum.extraction: ExtractionRunFilterParams,
}


class GenericConstructFilter(BaseModelWithAlias):
    type: FilterTypeEnum
    params: Union[
        dict,
        LocationFilterParams,
        OriginalScoreFilterParams,
        TagsFilterParams,
        RecommendationsFilterParams,
        RecommendationScoresFilterParams,
        ValidatedFilterParams,
        SnippetFilterParams,
        ExtractionRunFilterParams,
    ]

    def get_params(self):
        params_class = FILTER_TYPE_MAP.get(self.type)
        return params_class(**self.params)


class ConstructFilter(BaseModelWithAlias):
    filters: Optional[List[GenericConstructFilter]] = []


class FilteringResultBase(BaseSQLModelWithAlias):
    """Results of filtering a construct"""

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        description="ID of filter result",
    )
    project_id: UUID = Field(
        description="ID of concrete construct",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    filtering_id: UUID = Field(description="ID of filtering run", index=True)
    filtering_type: ValidationFilterTypeEnum = Field(sa_column=Column(String(), index=True, nullable=False))
    spec_id: Optional[UUID] = Field(None, description="Name of spec", index=True)
    passed: bool = Field(description="Whether the filter passed")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of pipeline creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
        ),
    )


class FilteringResult(FilteringResultBase, table=True):
    """Results of filtering a construct"""

    __table_args__ = (
        ForeignKeyConstraint(
            ["filtering_id"],
            ["filteringrun.id"],
        ),
        ForeignKeyConstraint(["spec_id"], ["customspec.id"], ondelete="CASCADE", onupdate="CASCADE"),
        UniqueConstraint("project_id", "spec_id", "filtering_type"),
    )

    spec: "CustomSpec" = Relationship(back_populates="filter_results")
    filter: "FilteringRun" = Relationship(back_populates="results")
    logs: Optional[str] = Field(None, description="Logs of filtering run")
    cpu: Optional[float] = Field(None, description="CPU usage during filtering")
    memory: Optional[float] = Field(None, description="Memory usage during filtering")
    runtime: Optional[float] = Field(None, description="Runtime of filtering run in seconds")


class PaginatedConstructFilter(ConstructFilter, PaginationParams):
    sort_by: Optional[str] = None
    descending: Optional[bool] = False
