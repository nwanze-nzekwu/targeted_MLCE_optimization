from loguru import logger


def calculate_cpu_time(cpu_percentages: list[float], runtimes: list[float]) -> list[float]:
    """
    Convert CPU percentages to CPU time

    Args:
        cpu_percentages: List of CPU usage percentages
        runtimes: List of corresponding runtime measurements

    Returns:
        List of CPU time values based on available matching data
    """
    # Handle empty inputs
    if not cpu_percentages or not runtimes:
        return []

    # Use as many values as we have in both lists
    usable_length = min(len(cpu_percentages), len(runtimes))

    # If lengths don't match, log a warning
    if len(cpu_percentages) != len(runtimes):
        logger.debug(
            f"Warning: CPU percentages ({len(cpu_percentages)}) and runtimes ({len(runtimes)}) lists have different lengths. Using first {usable_length} entries."
        )

    # Calculate CPU time for as many items as we can match
    return [cpu_percentages[i] * runtimes[i] / 100 for i in range(usable_length)]


def no_trailing_slash(value: str):
    """We want to remove any trailing slash if value is not the empty string"""
    return value[:-1] if value and value.endswith("/") else value
