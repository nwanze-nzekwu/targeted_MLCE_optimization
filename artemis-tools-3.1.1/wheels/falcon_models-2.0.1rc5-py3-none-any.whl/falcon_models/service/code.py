from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, NamedTuple, Optional, TypedDict
from uuid import UUID, uuid4

import numpy as np
from pydantic import BaseModel, ValidationInfo, field_validator, model_validator
from sqlalchemy import (
    Column,
    DateTime,
    FetchedValue,
    Float,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import Mapped
from sqlalchemy.orm.exc import DetachedInstanceError
from sqlmodel import Field, Relationship
from typing_extensions import override

from artemis_tools.models.generic import Language
from artemis_tools.services.language import LanguageBase

from falcon_models.enums.code import AIApplicationMethodEnum, FileOperationEnum, SolutionStatusEnum
from falcon_models.enums.filters.constructs import ValidationFilterTypeEnum
from falcon_models.service.base_data_types import BaseModelWithAlias, BaseSQLModelWithAlias
from falcon_models.service.filters.constructs import FilteringResult, GenericConstructFilter
from falcon_models.service.general import ProcessStatus
from falcon_models.service.git_key import GitAuthKeys
from falcon_models.service.llm import Prompt
from falcon_models.service.utils import calculate_cpu_time

if TYPE_CHECKING:
    from falcon_models.service.observations import AuditRun


class CodeOptimisationTask(BaseModel):
    project_id: int
    file_id: Optional[str] = None
    git_url: Optional[str] = None

    @field_validator("git_url")
    @classmethod
    def check_git_or_path(cls, v, values):
        """Checks whether a Git URL or a path was provided"""
        if "file_id" not in values and not v:
            raise ValueError("Either project path or Git URL is required")
        return v


# ----------- Project ------------ #


class ProjectInfoBase(BaseSQLModelWithAlias):
    """
    Info about a specific project
    """

    name: str = Field(description="Name of project")
    description: str | None = Field(default=None, description="Description of project")
    file_id: str | None = Field(default=None, description="File id of project")
    key_id: UUID | None = Field(
        default=None,
        description="Auth key id of project",
        foreign_key="gitauthkeys.id",
        unique=False,
    )
    git_url: str | None = Field(default=None, description="Git URL of project")
    git_hash: str | None = Field(default=None, description="Hash of Git commit to use")
    git_branch: str | None = Field(default=None, description="Name of Git Branch")
    setup_command: str | None = Field(default=None, description="Command to setup project")
    clean_command: str | None = Field(default=None, description="Command to clean project")
    compile_command: str | None = Field(default=None, description="Compile command for project")
    perf_command: str | None = Field(default=None, description="Performance test command for project")
    unit_test_command: str | None = Field(default=None, description="Unit test command for project")
    runner_name: str | None = Field(default=None, description="name to use for custom filter workers")
    reindex_required: bool = Field(default=False, description="Whether reindexing is required for this project")
    is_auto_sync_enabled: bool = Field(default=False, description="Whether automatic sync is enabled for this project")
    agent_validate_compilation: bool = Field(default=False, description="Whether agent should validate compilation")
    agent_validate_unit_test: bool = Field(default=False, description="Whether agent should validate unit tests")
    agent_validate_benchmark: bool = Field(default=False, description="Whether agent should validate benchmarks")
    auto_publish: bool = Field(default=False, description="Whether to automatically publish changes")

    @field_validator("git_url")
    @classmethod
    def check_git_or_path(cls, v: str, info: ValidationInfo) -> str:
        """Checks whether a Git URL or a path was provided"""
        if "file_id" not in info.data and not v:
            raise ValueError("Either project path or Git URL is required")
        return v


class ProjectIngestRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of project run",
    )
    name: str = Field(description="Name of project")
    description: str | None = Field(default=None, description="Description of project")
    requested_by: str = Field(description="User id of the person who requested the project run")

    db_host: Optional[str] = Field(default=None, description="Host of the database connection")
    db_port: Optional[int] = Field(default=None, description="Port of the database connection")
    db_name: Optional[str] = Field(default=None, description="Database of project")
    db_schema: Optional[str] = Field(default=None, description="Schema of the database")
    db_type: Optional[str] = Field(default=None, description="Type of database")
    db_username: Optional[str] = Field(default=None, description="Username of the database connection")

    connection_url: Optional[str] = Field(
        default=None, description="Full connection URL (e.g. postgres://user:pass@host:5432/dbname)"
    )

    project_id: Optional[UUID] = Field(
        default=None,
        description="ID of project",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of project process",
        foreign_key="processstatus.id",
    )
    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of file creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
        ),
    )
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last file update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=FetchedValue()),
    )


class ProjectIngestRun(ProjectIngestRunBase, table=True):
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})


class ProjectInfoTableBase(ProjectInfoBase):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of project",
    )
    user_id: str = Field(description="User id of project", index=True, unique=False)
    created_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of project creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
        ),
    )
    updated_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last project update",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
            nullable=False,
        ),
    )


class RelatedProject(BaseSQLModelWithAlias, table=True):
    parent_project_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("projectinfo.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        ),
        description="ID of parent project",
    )
    child_project_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("projectinfo.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        ),
        description="ID of child project",
    )

    # Define relationships using SQLAlchemy's relationship with back_populates
    parent_project: "ProjectInfo" = Relationship(
        back_populates="related_projects",
        sa_relationship_kwargs={"foreign_keys": "RelatedProject.parent_project_id"},
    )
    child_project: "ProjectInfo" = Relationship(
        back_populates="related_by",
        sa_relationship_kwargs={"foreign_keys": "RelatedProject.child_project_id"},
    )


class ProjectInfo(ProjectInfoTableBase, table=True):
    constructs: List["ConcreteConstruct"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    extractions: List["ExtractionRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    optimisations: List["OptimisationRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    embedding_runs: List["EmbeddingRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    pair_coder_runs: List["PairCoderRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    filters: List["FilteringRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    ai_runs: List["AIApplicationRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    reranks: List["RerankRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    prompts: List["Prompt"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    summarisations: List["SummarisationRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    key: GitAuthKeys = Relationship(back_populates="projects")
    queries: List["OrionQuery"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    related_projects: List["RelatedProject"] = Relationship(
        back_populates="parent_project",
        sa_relationship_kwargs={"foreign_keys": "RelatedProject.parent_project_id"},
    )
    related_by: List["RelatedProject"] = Relationship(
        back_populates="child_project",
        sa_relationship_kwargs={"foreign_keys": "RelatedProject.child_project_id"},
    )
    report_runs: List["ReportRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    audit_runs: list["AuditRun"] = Relationship(
        back_populates="project",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )


# ----------- Construct ------------ #


class DeprecationInfoBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        nullable=False,
        description="Unique identifier for the deprecation.",
    )
    git_hash: str | None = Field(default=None, description="Hash of Git commit at time of deprecation")
    git_branch: str | None = Field(default=None, description="Name of Git Branch at time of deprecation")
    timestamp: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of deprecation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )


class DeprecationInfo(DeprecationInfoBase, table=True): ...


class ConcreteConstructBase(BaseSQLModelWithAlias):
    """Schema for information about a block of code extracted
    from the original codebase. This does not store the contents of that block.

    Instead, it stores the location as specified by the file, lineno,
    and end_lineno fields, as well as a reference to the original contents of
    the block is stored in the original_spec_id field.
    """

    original_spec_id: UUID = Field(
        description="Unique identifier for the specification of the original code contained in the given construct.",
        index=True,
    )
    lineno: int = Field(
        description="The starting line number of the code block in the file.",
        index=True,
    )
    end_lineno: int = Field(description="The ending line number of the code block in the file.", index=True)
    file: str = Field(description="The path of the file where the code block is located.", index=True)
    enabled: bool = Field(
        default=True,
        description="Indicates whether the code construct is enabled on the UI. Defaults to True.",
    )
    language: str = Field(description="Language of construct")
    deprecation_id: Optional[UUID] = Field(
        default=None,
        description="Information about deprecation of this snippet",
        sa_column=Column(PGUUID, ForeignKey("deprecationinfo.id"), index=True, nullable=True),
    )


class CustomSpecBase(BaseSQLModelWithAlias):
    """Schema for the table containing original/alternative code content of
    concrete constructs."""

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        nullable=False,
        description="Unique identifier for a specification of the content of a concrete construct.",
    )
    name: str = Field(
        description="Name of spec. Examples include 'original', 'gemini-v15-flash', etc.",
        index=True,
    )
    llm_model: Optional[str] = Field(
        default=None,
        description="LLM model used to generate this spec (e.g., 'gpt-4', 'gemini-v25-pro')",
        nullable=True,
    )
    file_operation: FileOperationEnum = Field(
        default=FileOperationEnum.EDIT, sa_column=Column(String(), nullable=False)
    )
    content: str = Field(description="Code content of the spec.")
    imports: Optional[List[str]] = Field(
        default_factory=list,
        description="List of imports.",
        sa_column=Column(ARRAY(String())),
    )
    enabled: bool = Field(
        default=True,
        description="Indicates whether the spec is enabled on the UI. Defaults to True.",
    )


class ConcreteConstructTagging(BaseSQLModelWithAlias, table=True):
    __table_args__ = (UniqueConstraint("construct_id", "tag_id"),)

    construct_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("concreteconstruct.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        ),
        description="ID of construct",
    )
    tag_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("concreteconstructtag.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        ),
        description="ID of tag",
    )


class ConcreteConstruct(ConcreteConstructBase, table=True):
    __table_args__ = (Index("project_file_location", "project_id", "lineno", "end_lineno", "file"),)

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of concrete construct",
    )
    extraction_id: Optional[UUID] = Field(
        default=None,
        description="ID of extraction run",
        foreign_key="extractionrun.id",
        nullable=True,
    )
    project_id: UUID = Field(
        ...,
        description="ID of project",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    extraction: "ExtractionRun" = Relationship(back_populates="constructs")
    project: "ProjectInfo" = Relationship(back_populates="constructs")
    custom_specs: Mapped[List["CustomSpec"]] = Relationship(
        back_populates="concrete",
        sa_relationship_kwargs={
            "cascade": "all, delete-orphan",
            "foreign_keys": "[CustomSpec.concrete_id]",
            "overlaps": "original_spec",
        },
    )
    tags: Mapped[List["ConcreteConstructTag"]] = Relationship(
        back_populates="constructs",
        link_model=ConcreteConstructTagging,
    )
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of entry creation",
        sa_column=Column(DateTime, server_default=func.now(), index=True),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last entry update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=func.now()),
    )

    @property
    def original_spec(self) -> "CustomSpec":
        return next(spec for spec in self.custom_specs if spec.id == self.original_spec_id)


class ConcreteConstructTag(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of tag",
    )
    name: str = Field(description="Name of tag", unique=True, index=True)

    constructs: List["ConcreteConstruct"] = Relationship(
        back_populates="tags",
        link_model=ConcreteConstructTagging,
    )

    def __eq__(self, other):
        return self.name == other.name and self.id == other.id

    def __hash__(self):
        return hash((self.name, self.id))


class CustomSpecTagging(BaseSQLModelWithAlias, table=True):
    __table_args__ = (UniqueConstraint("spec_id", "tag_id"),)

    spec_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("customspec.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        ),
        description="ID of construct",
    )
    tag_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("customspectag.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
        ),
        description="ID of tag",
    )


class CustomSpecTag(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of tag",
    )
    name: str = Field(description="Name of tag", index=True, unique=True)
    specs: List["CustomSpec"] = Relationship(
        back_populates="tags",
        link_model=CustomSpecTagging,
    )

    def __eq__(self, other):
        return self.name == other.name and self.id == other.id

    def __hash__(self):
        return hash((self.name, self.id))


class CustomSpec(CustomSpecBase, table=True):
    """Custom specs for a construct"""

    __table_args__ = (UniqueConstraint("concrete_id", "name"),)

    source_ids: List[UUID] | None = Field(
        default=[],
        description="List of source spec IDs, null if original spec.",
        sa_column=Column(ARRAY(PGUUID(as_uuid=True)), nullable=True),
    )
    root_id: UUID = Field(description="ID of root spec")
    ai_run_id: Optional[UUID] = Field(
        default=None,
        description="ID of AI run, the process that created this spec, null if generated manually.",
        foreign_key="aiapplicationrun.id",
        nullable=True,
        ondelete="CASCADE",
    )
    concrete_id: UUID = Field(
        description="ID of concrete construct",
        sa_column=Column(
            PGUUID,
            ForeignKey("concreteconstruct.id", ondelete="CASCADE"),
            index=True,
            nullable=False,
        ),
    )
    concrete: Mapped["ConcreteConstruct"] = Relationship(
        back_populates="custom_specs",
        sa_relationship_kwargs={"foreign_keys": "[CustomSpec.concrete_id]"},
    )
    custom_spec_metrics: List["CustomSpecMetric"] = Relationship(back_populates="custom_spec")
    scores: Mapped[List["CustomSpecScore"]] = Relationship(
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
        back_populates="custom_spec",
    )
    contexts: Mapped[List["CodeContext"]] = Relationship(
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
        back_populates="custom_spec",
    )
    solution_specs: List["SolutionSpec"] = Relationship(
        back_populates="spec",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    ai_run: "AIApplicationRun" = Relationship(back_populates="specs")
    filter_results: List["FilteringResult"] = Relationship(
        back_populates="spec",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    tags: Mapped[List["CustomSpecTag"]] = Relationship(
        back_populates="specs",
        link_model=CustomSpecTagging,
    )
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of entry creation",
        sa_column=Column(DateTime, server_default=func.now(), index=True),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last entry update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=func.now()),
    )


class CustomSpecScoreBase(BaseSQLModelWithAlias):
    type: str = Field(description="Type of score")
    absolute: float = Field(description="Absolute score of custom spec")
    absolute_relative: float = Field(description="Absolute Relative score of custom spec (fixed signed scale)")
    relative_relative: float = Field(description="Relative Relative score of custom spec (scaled to reference)")
    description: Optional[str] = Field(None, description="Description for score")
    llm_type: str = Field(description="LLM Type")
    customspec_id: UUID = Field(description="ID of concrete construct", index=True)
    refspec_id: UUID = Field(description="ID of reference spec", index=True)
    prompt_id: Optional[UUID] = Field(None, description="ID of prompt", nullable=True)


class CustomSpecScore(CustomSpecScoreBase, table=True):
    __table_args__ = (
        ForeignKeyConstraint(["customspec_id"], ["customspec.id"], ondelete="CASCADE", onupdate="CASCADE"),
        ForeignKeyConstraint(["prompt_id"], ["prompt.id"], ondelete="CASCADE", onupdate="CASCADE"),
        UniqueConstraint("customspec_id", "llm_type", "refspec_id", "prompt_id"),
    )

    id: UUID = Field(default_factory=lambda: uuid4(), primary_key=True, index=True, unique=True)
    custom_spec: "CustomSpec" = Relationship(back_populates="scores")
    prompt: "Prompt" = Relationship(back_populates="scores")

    def constraint_field(self):
        return "customspecscore_customspec_id_llm_type_refspec_id_prompt_id_key"


class CustomSpecMetricBase(BaseSQLModelWithAlias):
    """Metric for a custom spec"""

    customspec_id: UUID = Field(description="ID of custom spec", primary_key=True)
    metric: str = Field(description="Name of metric", primary_key=True)
    value: float = Field(description="Value of metric")


class CustomSpecMetric(CustomSpecMetricBase, table=True):
    __table_args__ = (
        ForeignKeyConstraint(["customspec_id"], ["customspec.id"], ondelete="CASCADE", onupdate="CASCADE"),
    )

    custom_spec: "CustomSpec" = Relationship(back_populates="custom_spec_metrics")


class ToolEnumBase(BaseSQLModelWithAlias):
    """Enum for tools"""

    tool_name: str = Field(description="Name of tool")


class ToolEnum(ToolEnumBase, table=True):

    id: UUID = Field(default_factory=uuid4, primary_key=True, index=True, unique=True)


class ToolContext(BaseModelWithAlias):
    name: str
    context: str


class CodeContextBase(BaseSQLModelWithAlias):
    """Tool context standardised by sourcekon"""

    customspec_id: UUID = Field(description="ID of custom spec", primary_key=True, index=True)
    tool_id: UUID = Field(description="ID of tool", primary_key=True, index=True)
    context: str = Field(description="context from the tool")


class CodeContext(CodeContextBase, table=True):

    __table_args__ = (
        UniqueConstraint("customspec_id", "tool_id", name="customspec_tool_key"),
        ForeignKeyConstraint(["customspec_id"], ["customspec.id"], ondelete="CASCADE", onupdate="CASCADE"),
        ForeignKeyConstraint(["tool_id"], ["toolenum.id"], ondelete="CASCADE", onupdate="CASCADE"),
    )

    tool: Mapped["ToolEnum"] = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    custom_spec: "CustomSpec" = Relationship(back_populates="contexts")


# ----------- Solution ------------ #


class HardwareInfoBase(BaseSQLModelWithAlias):
    name: Optional[str] = Field(None, description="Name of hardware")
    cloud_type: Optional[str] = Field(None, description="Type of cloud")
    cloud_region: Optional[str] = Field(None, description="Cloud region")
    cloud_size: Optional[str] = Field(None, description="Size of cloud instance")
    cpu_name: str = Field(description="Name of CPU")
    cpu_number: int = Field(description="Number of CPU threads")
    gpu_name: Optional[str] = Field(None, description="Name of GPU")
    gpu_number: Optional[int] = Field(None, description="Number of GPUs")
    ram: float = Field(description="RAM in bytes")
    cost: Optional[float] = Field(None, description="Cost of hardware")


class HardwareInfo(HardwareInfoBase, table=True):

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of hardware info",
    )


class SolutionBase(BaseSQLModelWithAlias):
    """Info about a concrete instance of a construct"""

    number: Optional[int] = Field(default=None, description="Solution number")
    file_id: Optional[str] = Field(default=None, description="File id of solution")
    log_file_id: Optional[str] = Field(default=None, description="ID of log file")
    hardware_id: Optional[UUID] = Field(None, description="ID of hardware info", foreign_key="hardwareinfo.id")
    status: SolutionStatusEnum = Field(
        SolutionStatusEnum.created,
        sa_column=Column(String(), nullable=False, index=True),
        description="Status of solution",
    )


class FullSolutionInfoBase(SolutionBase):
    """
    Extended Solution Info
    """

    ...


class SolutionTableBase(SolutionBase):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of solution",
    )
    process_id: Optional[UUID] = Field(default=None, description="ID of process", foreign_key="processstatus.id")
    optimisation_id: Optional[UUID] = Field(
        default=None,
        description="ID of optimisation",
        foreign_key="optimisationrun.id",
        index=True,
    )
    project_id: UUID = Field(description="ID of project", index=True)

    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of solution creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
        ),
    )


class Solution(SolutionTableBase, table=True):
    results: Mapped[List["SolutionResults"]] = Relationship(
        back_populates="solution",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    specs: List["SolutionSpec"] = Relationship(
        back_populates="solution",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    optimisation: "OptimisationRun" = Relationship(back_populates="solutions")
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})

    __table_args__ = (
        ForeignKeyConstraint(
            ["project_id"],
            ["projectinfo.id"],
            ondelete="CASCADE",
            onupdate="CASCADE",
        ),
    )


class SolutionSpecBase(BaseSQLModelWithAlias):
    """Info about a concrete instance of a construct"""

    spec_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("customspec.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
            index=True,
        ),
        description="ID of spec",
    )


class SolutionSpec(SolutionSpecBase, table=True):
    """Info about a concrete instance of a construct"""

    solution_id: UUID = Field(
        sa_column=Column(
            PGUUID,
            ForeignKey("solution.id", ondelete="CASCADE"),
            primary_key=True,
            nullable=False,
            index=True,
        ),
        description="ID of solution",
    )
    solution: "Solution" = Relationship(back_populates="specs")
    spec: "CustomSpec" = Relationship(back_populates="solution_specs")


class ResultsStatsModel(BaseModelWithAlias):
    mean: float
    mean_adjusted: float
    std: float
    min: float
    max: float

    @staticmethod
    def remove_outliers(data, z_threshold: float = 2):
        mean = np.mean(data)
        std_dev = np.std(data)
        # we consider 0 as outlier for any of our metrics
        return [x for x in data if std_dev == 0 or (abs(x - mean) / std_dev) < z_threshold and x != 0]


class SolutionResultsBase(BaseSQLModelWithAlias):
    runtime: List[float] = Field(
        description="Runtime of solution",
        sa_column=Column(ARRAY(Float()), nullable=False),
    )
    cpu: List[float] = Field(
        description="CPU usage of solution",
        sa_column=Column(ARRAY(Float()), nullable=False),
    )
    memory: List[float] = Field(
        description="Memory usage of solution",
        sa_column=Column(ARRAY(Float()), nullable=False),
    )

    @property
    def stats(self) -> dict[str, ResultsStatsModel]:
        z_threshold = 2

        def calc_adjusted_values(data: list[float]):
            # Calculate mean after removal of potential outliers
            if not data:
                return None
            np_data = np.array(data)
            filtered_data = ResultsStatsModel.remove_outliers(np_data, z_threshold)
            return ResultsStatsModel(
                mean=np.mean(np_data).item(),
                std=np.std(np_data).item(),
                min=np.min(np_data),
                max=np.max(data),
                mean_adjusted=np.mean(filtered_data).item(),
            )

        # Calculate CPU time as CPU percentage * runtime
        cpu_times = calculate_cpu_time(cpu_percentages=self.cpu, runtimes=self.runtime)

        res = {
            "runtime": calc_adjusted_values(self.runtime),
            "cpu": calc_adjusted_values(cpu_times),
            "memory": calc_adjusted_values(self.memory),
        }
        return {k: v for k, v in res.items() if v is not None}


class SolutionResults(SolutionResultsBase, table=True):

    solution_id: UUID = Field(
        description="ID of parent solution",
        foreign_key="solution.id",
        primary_key=True,
        ondelete="CASCADE",
    )
    solution: "Solution" = Relationship(back_populates="results")


# ----------- Runs ------------ #


class ExtractionRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of concrete construct",
    )
    include_globs: List[str] | None = Field([], sa_column=Column(ARRAY(String)), description="Type of extraction")
    exclude_globs: List[str] | None = Field([], sa_column=Column(ARRAY(String)), description="Type of extraction")
    project_id: UUID = Field(
        ..., description="Analysis of project", foreign_key="projectinfo.id", ondelete="CASCADE", index=True
    )
    process_id: UUID | None = Field(
        default=None,
        description="ID of extraction process",
        foreign_key="processstatus.id",
        ondelete="CASCADE",
    )
    log_file_id: str | None = Field(default=None, description="ID of log file")
    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of file creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
        ),
    )
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last file update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=FetchedValue()),
    )
    llm_filter: str | None = Field(default=None, description="LLM filter")
    llm_type: str | None = Field(default=None, description="LLM type")
    llm_filter_number: int | None = Field(default=None, description="Number of target extraction")
    num_of_constructs_detected: int = Field(
        default=0, description="Number of constructs detected by the extraction process"
    )
    num_of_constructs_extracted: int = Field(
        default=0,
        description="Number of constructs extracted by the extraction process (made it to the db)",
    )


class ToolExtractionRun(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=uuid4,
        primary_key=True,
        description="Primary key for ToolExtractionRun",
    )

    extraction_run_id: UUID = Field(
        foreign_key="extractionrun.id",
        unique=True,
        nullable=False,
        description="Foreign key to ExtractionRun",
    )

    filter_tool_mode: Optional[str] = Field(default=None, description="Mode of tool filtering")
    tool_filter: Optional[str] = Field(default=None, description="Tool that does filtering")
    tool_files: Optional[List[str]] = Field(
        default=None,
        description="files in order to execute filtering",
        sa_column=Column(ARRAY(String)),
    )
    main_branch: Optional[str] = Field(
        default=None,
        description="The primary branch that the pull request (PR) will be merged into, typically the main development branch of the repository.",
    )
    git_mode: Optional[str] = Field(default=None, description="Git extract functionality (diffs or user-code)")
    start_date: Optional[datetime] = Field(default=None, description="Start date for git user code search")
    end_date: Optional[datetime] = Field(default=None, description="End date for git user code search")
    contributor: Optional[str] = Field(default=None, description="Contributor of the repo")
    extractor_scope: Optional[str] = Field(default=None, description="Extractor Scope of code snippet")

    # Update relationship to point to ExtractionRun (concrete class)
    extraction_run_base: "ExtractionRun" = Relationship(back_populates="tool_extraction_run")


class ExtractionQueryLink(BaseSQLModelWithAlias, table=True):

    extraction_id: UUID = Field(
        description="ID of extraction run",
        foreign_key="extractionrun.id",
        primary_key=True,
        ondelete="CASCADE",
    )
    query_id: UUID = Field(
        description="ID of query",
        foreign_key="orionquery.id",
        primary_key=True,
        ondelete="CASCADE",
    )


class ExtractionRun(ExtractionRunBase, table=True):

    constructs: List["ConcreteConstruct"] = Relationship(
        back_populates="extraction",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    project: "ProjectInfo" = Relationship(back_populates="extractions")
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    queries: List["OrionQuery"] = Relationship(back_populates="extractions", link_model=ExtractionQueryLink)
    tool_extraction_run: Optional["ToolExtractionRun"] = Relationship(
        back_populates="extraction_run_base",
        sa_relationship_kwargs={"uselist": False, "cascade": "all, delete-orphan"},
    )

    @override
    def model_dump(self, **kwargs) -> Dict[str, Any]:
        try:
            exclude = kwargs.get("exclude", None)
            if exclude and "queries" in exclude:
                return super().model_dump(**kwargs)
            return super().model_dump(**kwargs) | {"queries": [query.query for query in self.queries]}
        except DetachedInstanceError:
            return super().model_dump(**kwargs)


class OrionQueryBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=uuid4,
        primary_key=True,
        index=True,
        description="ID of query",
    )
    query: str = Field(..., description="Query string")
    # TODO: consider having this a more global entity
    project_id: UUID = Field(
        ...,
        description="project to attach to",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )


class OrionQuery(OrionQueryBase, table=True):

    project: "ProjectInfo" = Relationship(back_populates="queries")
    extractions: List["ExtractionRun"] = Relationship(back_populates="queries", link_model=ExtractionQueryLink)


class OptimisationRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of concrete construct",
    )
    user_id: str = Field(description="User id of optimisation", index=True, unique=False)
    name: str | None = Field(default=None, description="Name of optimisation (customizable)", nullable=True)
    project_id: UUID = Field(
        ...,
        description="Analysis of project",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    custom_worker_name: Optional[str] = Field(default=None, description="Name of worker to use")
    evaluation_repetitions: int = Field(default=10, description="Number of test repetitions")
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of extraction process",
        foreign_key="processstatus.id",
    )
    created_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of file creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False, index=True),
    )
    updated_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last file update",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
            nullable=False,
        ),
    )


class OptimisationRun(OptimisationRunBase, table=True):

    project: "ProjectInfo" = Relationship(back_populates="optimisations")
    hardware_id: Optional[UUID] = Field(default=None, description="ID of hardware info", foreign_key="hardwareinfo.id")
    solutions: Mapped[List["Solution"]] = Relationship(
        back_populates="optimisation",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    constructs: List["OptimisationConstruct"] = Relationship(
        back_populates="optimisation",
        sa_relationship_kwargs={"lazy": "joined", "cascade": "all, delete-orphan"},
    )
    process: ProcessStatus = Relationship(
        sa_relationship_kwargs={"lazy": "joined"},
    )
    hardware: HardwareInfo = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    report_runs: List["ReportRun"] = Relationship(
        back_populates="optimisation",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )


class SolutionSpecModel(BaseModelWithAlias):
    spec_id: UUID
    construct_id: UUID


class SolutionResultsModel(BaseModelWithAlias):
    values: Dict[str, List[float]]
    stats: Dict[str, ResultsStatsModel]

    @classmethod
    def from_results(cls, results: SolutionResultsBase):
        values = results.model_dump(exclude={"solution_id", "log_file_id"})
        # Transform CPU percentages to CPU time in the values dict
        # we don t translate it before dumping the model because that would cause a double translation as
        # stats property below also has a translation
        values["cpu"] = calculate_cpu_time(cpu_percentages=values["cpu"], runtimes=values["runtime"])
        return cls(
            stats=results.stats,
            values=values,
        )


class SolutionItem(NamedTuple):
    id: UUID
    number: int | None
    results: SolutionResultsModel


class FullSolutionInfo(SolutionTableBase, FullSolutionInfoBase):
    specs: List[SolutionSpecModel] = None
    results: SolutionResultsModel | None = None
    optimisation: OptimisationRun | None = None
    additions: int | None = None
    deletions: int | None = None
    files_changed: int | None = None


class OptimisationConstructBase(BaseSQLModelWithAlias):
    """Info about a concrete instance of a construct"""

    construct_id: UUID = Field(
        primary_key=True,
        description="ID of construct",
        foreign_key="concreteconstruct.id",
        ondelete="CASCADE",
    )
    optimisation_id: UUID = Field(
        primary_key=True,
        description="ID of optimisation",
        foreign_key="optimisationrun.id",
        ondelete="CASCADE",
    )


class OptimisationConstruct(OptimisationConstructBase, table=True):
    """Info about a concrete instance of a construct"""

    optimisation: "OptimisationRun" = Relationship(back_populates="constructs")
    construct: "ConcreteConstruct" = Relationship()  # type: ignore
    spec_ids: Optional[List[UUID]] = Field(default=[], sa_column=Column(ARRAY(PGUUID(as_uuid=True))))


class AIApplicationRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of AI application",
    )
    source_spec_ids: List[UUID] = Field(
        default_factory=list,
        description="Constructs to be included in the run",
        sa_column=Column(ARRAY(PGUUID(as_uuid=True))),
    )
    models: List[str] = Field([], description="Models that will run", sa_column=Column(ARRAY(String())))
    method: AIApplicationMethodEnum = Field(AIApplicationMethodEnum.zero_shot, description="Method of AI application")
    align: bool = Field(False, description="Whether alignment will be performed")
    raw_output: bool = Field(False, description="Whether raw output is enabled")
    prompt_id: UUID = Field(description="LLM Query", foreign_key="prompt.id", nullable=True)
    context: Optional[dict[str, Any]] = Field(default=None, sa_column=Column(JSONB))
    project_id: UUID = Field(
        ...,
        description="Project ID of AI application",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of application process",
        foreign_key="processstatus.id",
    )
    agent_run_id: str | None = Field(
        default=None,
        description="ID for the agent run, null implies no agent was used",
    )
    created_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of entry creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )
    updated_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last entry update",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
            nullable=False,
        ),
    )


class AIApplicationRun(AIApplicationRunBase, table=True):

    project: "ProjectInfo" = Relationship(back_populates="ai_runs")
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    prompt: Prompt = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    specs: List["CustomSpec"] = Relationship(
        back_populates="ai_run",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )


class RerankRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of AI application",
    )
    spec_ids: List[UUID] = Field(
        default_factory=list,
        description="Specs to be included in the run",
        sa_column=Column(ARRAY(PGUUID(as_uuid=True))),
    )
    models: List[str] = Field(
        default_factory=list,
        description="Model to use",
        sa_column=Column(ARRAY(String)),
    )
    project_id: UUID = Field(
        ...,
        description="Project ID of rerank",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of application process",
        foreign_key="processstatus.id",
    )
    agent_run_id: str | None = Field(
        default=None,
        description="ID for the agent run, null implies no agent was used",
    )
    created_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of entry creation",
        sa_column=Column(
            DateTime,
            nullable=False,
            server_default=func.now(),
        ),
    )
    updated_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last entry update",
        sa_column=Column(
            DateTime,
            nullable=False,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
        ),
    )
    metric_prompts_ids: List[UUID] = Field(
        default_factory=list,
        description="IDs of metric prompts to be used in the rerank worker",
        sa_column=Column(ARRAY(PGUUID(as_uuid=True)), nullable=False),
    )


class RerankRun(RerankRunBase, table=True):
    project: "ProjectInfo" = Relationship(back_populates="reranks")
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})

    __table_args__ = (Index("rerankrun_spec_ids_idx", "spec_ids", postgresql_using="gin"),)


class FilteringRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of concrete construct",
    )
    constructs: Optional[Dict] = Field(default=None, sa_column=Column(JSONB))
    types: List[ValidationFilterTypeEnum] = Field(sa_column=Column(ARRAY(String), nullable=False))
    llm_type: Optional[str] = Field(default=None, description="LLM Type")

    project_id: UUID = Field(
        ...,
        description="Project ID of filter",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of extraction process",
        foreign_key="processstatus.id",
    )
    custom_worker_name: Optional[str] = Field(default=None, description="Name of worker to use")
    run_original: bool = Field(False, description="Whether the original values should be validated")
    created_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of file creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
        ),
    )
    updated_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last file update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=FetchedValue()),
    )


class FilteringRun(FilteringRunBase, table=True):

    project: "ProjectInfo" = Relationship(back_populates="filters")
    results: List["FilteringResult"] = Relationship(
        back_populates="filter",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})


class EmbeddingRunBase(BaseSQLModelWithAlias):
    """
    @TODO:
    - Embedding can have an associated prompt. Consider exposing this
    """

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of embedding process",
    )
    preset_enum: str = Field(description="Configuration for embedding")
    project_id: UUID = Field(
        ...,
        description="Project ID of AI application",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of application process",
        foreign_key="processstatus.id",
    )
    created_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of file creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )
    updated_at: Optional[datetime] = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last file update",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
            nullable=False,
        ),
    )
    include_globs: List[str] = Field(default=[], sa_column=Column(ARRAY(String)), description="Files to include")
    exclude_globs: List[str] = Field(default=[], sa_column=Column(ARRAY(String)), description="Files to exclude")
    total_files: int = Field(0, description="Total files to process")
    supported_files: int = Field(0, description="Number of supported files")
    embedded_files: int = Field(0, description="Number of files embedded")


class EmbeddingRun(EmbeddingRunBase, table=True):

    project: "ProjectInfo" = Relationship(back_populates="embedding_runs")
    process: Mapped[ProcessStatus | None] = Relationship(sa_relationship_kwargs={"lazy": "joined"})


class ReportRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of report generation process",
    )
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of application process",
        foreign_key="processstatus.id",
    )
    project_id: Optional[UUID] = Field(
        default=None,
        description="Project ID of report",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    optimisation_id: Optional[UUID] = Field(
        default=None,
        description="Optimisation ID of report",
        foreign_key="optimisationrun.id",
        index=True,
        ondelete="CASCADE",
    )
    solution_id: Optional[UUID] = Field(default=None, description="Solution ID of reports", index=True)
    format: str = Field(..., description="Format of the report")
    thor_file_id: Optional[str] = Field(default=None, description="ID of thor file")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of entry creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
        ),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last entry update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=func.now()),
    )

    @model_validator(mode="after")
    def validate_single_foreign_key(self):
        if self.project_id is not None and self.optimisation_id is not None:
            raise ValueError("Only one of project_id or optimisation_id should be set")
        if self.project_id is None and self.optimisation_id is None:
            raise ValueError("Either project_id or optimisation_id must be set")
        return self


class ReportRun(ReportRunBase, table=True):

    project: Optional["ProjectInfo"] = Relationship(back_populates="report_runs")
    optimisation: Optional["OptimisationRun"] = Relationship(back_populates="report_runs")
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})


class SummarisationRunBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of summarisation run",
    )
    project_id: UUID = Field(
        ...,
        description="Project ID of filter",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    concrete_id: UUID = Field(..., description="ID of concrete construct", foreign_key="concreteconstruct.id")
    spec_names: List[str] = Field([], sa_column=Column(ARRAY(String())))
    process_id: Optional[UUID] = Field(None, description="ID of application process", foreign_key="processstatus.id")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of entry creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
        ),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last entry update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=func.now()),
    )


class SummarisationRun(SummarisationRunBase, table=True):

    project: "ProjectInfo" = Relationship(back_populates="summarisations")
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})


class SolutionSummaryBase(BaseSQLModelWithAlias):
    """Explanation of a solution"""

    solution_id: UUID = Field(description="ID of solution", foreign_key="solution.id", primary_key=True)
    prompt_id: UUID = Field(description="ID of prompt", foreign_key="prompt.id", primary_key=True)
    body: str = Field(..., description="Explanation for the solution")
    header: Optional[str] = Field(None, description="Short summary for use as a header", nullable=True)


class SolutionSummary(SolutionSummaryBase, table=True): ...


class LanguagesData(TypedDict):
    languages: dict[str, LanguageBase]


class ConcreteConstructChild(ConcreteConstructBase):
    id: UUID
    project_id: UUID
    filter_results: Dict[UUID, bool] = Field(default_factory=dict)
    tokens: Optional[int] = None
    extraction_id: Optional[UUID] = None


class InsertionsDeletions(BaseModelWithAlias):
    """Insertions and deletions diff information"""

    insertions: int
    deletions: int


class CustomSpecChild(CustomSpecBase):
    """When the spec is returned within a construct"""

    concrete_id: UUID
    source_ids: list[UUID] | None = None
    sources: list[CustomSpecBase] = Field(default_factory=list)
    ai_run_id: UUID | None = None
    rerank_ids: list[UUID] | None = None
    contexts: CodeContextBase | None = None
    diff: InsertionsDeletions | None = None


class CustomSpecScoreModel(BaseModelWithAlias):
    type: str = Field(description="Type of score")
    score: float = Field(description="Score of custom spec")
    description: Optional[str] = Field(None, description="Description of the score")
    llm_type: str = Field(description="Type of llm score")


class CustomSpecContext(BaseModelWithAlias):
    tool: ToolEnum = Field(description="Tool name", primary_key=True)
    context: str = Field(description="Context of the spec")


class RootSpec(CustomSpecBase): ...


class CustomSpecModel(CustomSpecBase):
    concrete_id: UUID
    scores: list[CustomSpecScoreModel] = Field(default_factory=list)
    sources: list[RootSpec] = Field(default_factory=list)
    concrete: ConcreteConstructChild | None = None
    context: list[CustomSpecContext] | None = None


class CodeAIMultiOptimise(BaseModelWithAlias):
    """
    Data structure of an information group
    """

    project_id: UUID
    filter: Optional[List[GenericConstructFilter]] = None
    spec_ids: List[UUID]
    method: AIApplicationMethodEnum = AIApplicationMethodEnum.zero_shot
    models: List[str]
    prompt_id: UUID
    align: bool = False
    raw_output: bool = False
    context: str | None = None


class CodeTaskModelScore(BaseModelWithAlias):
    name: str
    score: float
    description: str
    prompt_id: UUID | None


class CodeTaskScores(BaseModelWithAlias):
    """
    Data structure of a rerank score, for a particular task & recommendation
    """

    task: str
    aggregated_score: Optional[float] = None
    models: List[CodeTaskModelScore]
    summary: Optional[str] = None


class CodeSpecScores(BaseModelWithAlias):
    """
    Data structure of a rerank score, for a particular recommendation
    """

    spec_id: str
    source_id: Optional[str] = None
    aggregated_score: Optional[float] = None
    scores: List[CodeTaskScores]


class ConfidenceIntervals(BaseModelWithAlias):
    before: List[float]
    after: List[float]


class SolutionStats(BaseModelWithAlias):
    mean: float
    first_quartile: float
    median: float
    third_quartile: float
    min: float
    max: float
    count: int
    std_dev: float


class ComparisonStats(BaseModelWithAlias):
    before: SolutionStats
    after: SolutionStats


class SolutionAnalysisResults(BaseModelWithAlias):
    statistical_significance: bool
    statistical_significance_label: str
    required_sample_size: Optional[float] = None
    test_used: str
    effect_size: float
    effect_size_label: str
    effect_direction: str
    power: float
    confidence_intervals: ConfidenceIntervals
    statistics: ComparisonStats
    labels: List[str]
    # list of values of anomalies
    outliers: List[float]


# -------------------------------- Green metrics --------------------------------


class EnvironmentalImpact(BaseModelWithAlias):
    electricityKwh: float
    carbonDioxideKg: float


class CustomSpecChildReport(CustomSpecBase):
    """Custom spec for report response"""

    id: UUID
    concrete_id: UUID
    source_ids: Optional[List[UUID]] = None
    contexts: List[CodeContext]


class ConcreteConstructReport(ConcreteConstructBase):
    id: UUID
    original_spec_id: UUID
    language: Language
    custom_specs: List[CustomSpecChildReport] = []

    @property
    def original_spec(self) -> "CustomSpecChildReport":
        return next(spec for spec in self.custom_specs if spec.id == self.original_spec_id)


class ProjectInfoReport(ProjectInfoBase):
    constructs: List[ConcreteConstructReport]


class SpecificationInfo(BaseSQLModelWithAlias, table=True):

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        description="Unique identifier for specification info",
    )
    pair_coder_run_id: UUID = Field(
        description="ID of the associated pair coder run",
        foreign_key="paircoderrun.id",
        index=True,
        ondelete="CASCADE",
    )
    type: str = Field(description="Type of specification data")
    current: list[str] = Field(
        default=[],
        sa_column=Column(ARRAY(String), nullable=False),
        description="Current specification list",
    )
    proposed: list[str] = Field(
        default=[],
        sa_column=Column(ARRAY(String), nullable=False),
        description="Proposed specification list",
    )

    pair_coder_run: "PairCoderRun" = Relationship(back_populates="specification_info")


class ActionPlanStep(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
    )
    action_plan_id: UUID = Field(..., foreign_key="actionplaninfo.id", index=True, ondelete="CASCADE")
    file_path: str = Field(..., description="File path to be modified")
    changes: List[str] = Field(
        default=[],
        sa_column=Column(ARRAY(String), nullable=False),
        description="Changes for current file",
    )

    action_plan: "ActionPlanInfo" = Relationship(back_populates="steps")


class ActionPlanInfo(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
    )
    pair_coder_run_id: UUID = Field(..., foreign_key="paircoderrun.id", index=True, ondelete="CASCADE")
    type: str = Field(description="Type of specification data")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )

    # Relationships
    pair_coder_run: "PairCoderRun" = Relationship(back_populates="action_plan_info")
    steps: List[ActionPlanStep] = Relationship(back_populates="action_plan")


class CoderOutputStep(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
    )
    coder_output_id: UUID = Field(..., foreign_key="coderoutput.id", index=True, ondelete="CASCADE")
    file_path: str = Field(..., description="File path")
    proposed: str = Field(..., description="Proposed changes in a diff format")
    file_operation: FileOperationEnum = Field(
        default=FileOperationEnum.EDIT, sa_column=Column(String(), nullable=False)
    )
    coder_output: "CoderOutput" = Relationship(back_populates="steps")


class CoderOutput(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
    )
    pair_coder_run_id: UUID = Field(..., foreign_key="paircoderrun.id", index=True, ondelete="CASCADE")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )

    # Relationships
    pair_coder_run: "PairCoderRun" = Relationship(back_populates="coder_output")
    steps: List[CoderOutputStep] = Relationship(back_populates="coder_output")


class PairCoderRunBase(BaseSQLModelWithAlias):

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of pair coder process",
    )
    parent_id: UUID | None = Field(
        default=None,
        foreign_key="paircoderrun.id",
        description="ID of parent pair coder run",
    )
    project_id: UUID = Field(
        ...,
        description="Project ID",
        foreign_key="projectinfo.id",
        index=True,
        ondelete="CASCADE",
    )
    process_id: UUID | None = Field(
        default=None,
        description="ID of application process",
        foreign_key="processstatus.id",
    )
    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last update",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
            nullable=False,
        ),
    )
    model_type: str = Field(..., description="Model type")
    task: str | None = Field(default=None, description="Task input string")
    thread_id: str | None = Field(default=None, description="Thread ID of experiment")
    checkpoint_id: str | None = Field(default=None, description="Checkpoint ID of pair coder run last visited state")
    checkpoint_ns: str | None = Field(
        default=None,
        description="Namespace of checkpoint ID of pair coder run last visited state",
    )
    stage: str = Field(description="Stage of pair coder run (specs, action plan, coder etc.)")


class PairCoderRun(PairCoderRunBase, table=True):
    parent: Optional["PairCoderRun"] = Relationship(
        back_populates="children",
        sa_relationship_kwargs={"remote_side": "[PairCoderRun.id]"},
    )
    children: List["PairCoderRun"] = Relationship(back_populates="parent")
    project: ProjectInfo = Relationship(back_populates="pair_coder_runs")
    process: ProcessStatus = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    specification_info: Optional["SpecificationInfo"] = Relationship(
        back_populates="pair_coder_run",
        sa_relationship_kwargs={"uselist": False, "cascade": "all, delete-orphan"},
    )
    action_plan_info: Optional[ActionPlanInfo] = Relationship(
        back_populates="pair_coder_run",
        sa_relationship_kwargs={"uselist": False, "cascade": "all, delete-orphan"},
    )
    coder_output: Optional[CoderOutput] = Relationship(
        back_populates="pair_coder_run",
        sa_relationship_kwargs={"uselist": False, "cascade": "all, delete-orphan"},
    )


class InternalReportData(BaseModelWithAlias):
    id_to_diff_mapping: Dict[UUID, str]
    hardware: HardwareInfo | None = None
    improvements: Dict[str, float] | None
    latest_filters: Dict
    tools_info: Dict[UUID, str]
    reranking_flag: bool
    llms_for_scoring: Dict[str, int]
    llms_for_suggestions: Dict[str, int]
    final_summary_results: Dict[UUID, CodeSpecScores]
    has_suggestion: Dict[UUID, bool]
    llm_description_map: Dict[str, str]
    eval_repetitions: Optional[int]
    specs: Dict[str, List[str]] | None = None
    solution: FullSolutionInfo | None = None
    original_solution: FullSolutionInfo | None = None
    project: ProjectInfoReport
