"""
In this module a base class is implemented with generic methods and properties
"""

from typing import Annotated, Any, Generic, TypeVar, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator
from pydantic.alias_generators import to_pascal
from sqlmodel import SQLModel
from sqlmodel.main import SQLModelMetaclass

# ──────────────────────────────────────────────────────────────────── #
#                           Base Model Class                           #
# ──────────────────────────────────────────────────────────────────── #


def to_lower_camel(value: str) -> str:
    # Helper function to convert to lower camel case
    camel_value = to_pascal(value)
    return camel_value[0].lower() + camel_value[1:] if camel_value else camel_value


class BaseModelWithAlias(BaseModel):
    """
    Base Model with enabled alias.
    Whether an aliased field may be populated by its
    name as given by the model attribute, as well as the alias
    """

    def dict(self, *args, **kwargs):
        if kwargs and kwargs.get("exclude_none") is not None:
            kwargs["exclude_none"] = True
        return super().dict(*args, **kwargs)

    def dict_alias(self, *args, **kwargs):
        """Generate a dictionary representation of the model with field alias as keys"""
        return self.dict(by_alias=True, *args, **kwargs)

    model_config = ConfigDict(
        alias_generator=to_lower_camel,
        # Convert snake_case to camelCase for JSON serialization
        populate_by_name=True,
        # Allows setting values by both the original name and the alias
        arbitrary_types_allowed=True,  # Allows arbitrary (non-Pydantic) types
        protected_namespaces=(),
    )


class MakeOptional(BaseModel):
    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:
        super().__pydantic_init_subclass__(**kwargs)

        for field in cls.model_fields.values():
            if field.is_required():
                field.default = None

        cls.model_rebuild(force=True)


class BaseSQLModelWithAlias(SQLModel, BaseModelWithAlias):
    """
    Base Model with enabled alias.
    Whether an aliased field may be populated by its name as
    given by the model attribute, as well as the alias
    """

    def constraint_field(self):
        return self.__table__.primary_key


class NullableBaseModelWithAlias(BaseModelWithAlias):
    def dict(self, *args, **kwargs):
        if kwargs and kwargs.get("exclude_none") is not None:
            kwargs["exclude_none"] = False
        return BaseModel.dict(self, *args, **kwargs)


class AllOptional(SQLModelMetaclass):
    def __new__(cls, name: str, bases: tuple[type], namespaces: dict[str, Any], **kwargs: Any):
        annotations: dict[str, Any] = namespaces.get("__annotations__", {})

        for base in bases:
            for base_ in base.__mro__:
                if base_ is BaseModel or base_ is SQLModel:
                    break

                annotations.update(base_.__annotations__)

        for field in annotations:
            if not field.startswith("__"):
                annotations[field] = Annotated[Union[annotations[field], None], Field(None)]

        namespaces["__annotations__"] = annotations

        return super().__new__(cls, name, bases, namespaces, **kwargs)


class PaginationParams(BaseModelWithAlias):
    """
    Data structure of an information group
    """

    page: int = Field(1, description="Page number", ge=1)
    per_page: int = Field(10, description="Number of items per page")

    @field_validator("per_page")
    @classmethod
    def validate_per_page(cls, value):
        if value != -1 and value <= 0:
            raise ValueError("per_page must be -1 or a positive integer")
        return value


DocTypeT = TypeVar("DataT", bound=BaseModel)


class PaginatedBase(BaseModelWithAlias, Generic[DocTypeT]):
    """
    Data structure of an information group
    """

    docs: list[DocTypeT] = Field(..., description="List of items")
    total_docs: int = Field(..., description="Total number of items")
    limit: int = Field(10, description="Number of items per page")
    total_pages: int = Field(..., description="Number of items per page")
    has_prev_page: bool = Field(..., description="Whether previous page exists")
    has_next_page: bool = Field(..., description="Whether next page exists")
    page: int = Field(..., description="Number of page")
    paging_counter: int = Field(..., description="Counter of page")
    prev_page: int | None = Field(None, description="Number of previous page")
    next_page: int | None = Field(None, description="Number of next page")
