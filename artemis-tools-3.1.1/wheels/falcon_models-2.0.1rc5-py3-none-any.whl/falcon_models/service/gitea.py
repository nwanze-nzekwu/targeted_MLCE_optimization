from enum import StrEnum

from falcon_models.service.base_data_types import BaseModelWithAlias


class TokenCreateScope(StrEnum):
    ALL = "all"  # full access
    REPO = "read:repository"  # access to repositories
    USER = "read:user"  # read/write user profile
    WRITE_PACKAGE = "write:package"  # for package registry


class GiteaToken(BaseModelWithAlias):
    id: int
    name: str
    sha1: str
    token_last_eight: str
    scopes: list[TokenCreateScope]
