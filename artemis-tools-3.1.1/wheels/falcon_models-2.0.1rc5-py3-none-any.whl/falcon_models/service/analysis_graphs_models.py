from typing import Dict, List

from falcon_models.service.base_data_types import BaseModelWithAlias


class BoxplotDataResponse(BaseModelWithAlias):
    min: float
    q1: float
    median: float
    q3: float
    max: float


class AnalysisScoreResponse(BaseModelWithAlias):
    average_score: float
    occurrences: int
    boxplot_data: BoxplotDataResponse


class AnalysisBoxplotResponse(BaseModelWithAlias):
    metrics: Dict[str, AnalysisScoreResponse]


class ValidationResponse(BaseModelWithAlias):
    filtering_type: str
    llm_type: str
    total_occurrences: int
    total_passed: int
    total_failed: int


class ValidationGraphResponse(BaseModelWithAlias):
    metrics: List[ValidationResponse]


class ModelCostResponse(BaseModelWithAlias):
    name: str
    input_cost: float
    output_cost: float


class ModelCostGraphResponse(BaseModelWithAlias):
    metrics: List[ModelCostResponse]


class ScoreRangeResponse(BaseModelWithAlias):
    high: int
    medium: int
    low: int


class ScoreRangesResponse(BaseModelWithAlias):
    metrics: Dict[str, ScoreRangeResponse]
    overall: ScoreRangeResponse
