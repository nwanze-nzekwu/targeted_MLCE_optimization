from dataclasses import dataclass
from typing import NamedTuple
from uuid import UUID

from falcon_models.service.code import CustomSpecScore


class ScoreWithTask(NamedTuple):
    spec_score: CustomSpecScore
    subtask: str | None


class GetSpecScoresOutput(NamedTuple):
    # map original id to original scores
    originals: dict[UUID, list[ScoreWithTask]]
    # map version id to version scores (variant / not original)
    variants: dict[UUID, list[ScoreWithTask]]
    # map version to original
    variants_to_original: dict[UUID, UUID]


# NOTE: the following is duplicated from the rerank worker which will move out of falcon
# Consider moving to shared location
@dataclass
class ScoringScale:
    """Scale with lower and upper bounds (inclusive)"""

    lower: float
    upper: float

    @property
    def span(self) -> float:
        """The range of a scale"""
        return self.upper - self.lower

    @property
    def midpoint(self) -> float:
        """The range of a scale"""
        return (self.upper + self.lower) / 2.0


# scale used for unified storage
STORED_SCALE = ScoringScale(lower=1.0, upper=5.0)
STORED_SCALE_DIFF = ScoringScale(lower=1.0, upper=3.0)
