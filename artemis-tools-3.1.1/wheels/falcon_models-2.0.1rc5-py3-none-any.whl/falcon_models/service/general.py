from datetime import datetime
from typing import Dict, List, Optional
from uuid import UUID, uuid4

from sqlalchemy import Column, DateTime
from sqlalchemy import Enum as SQLModelEnum
from sqlalchemy.dialects.postgresql import JSON
from sqlmodel import Field, Relationship

from falcon_models.enums.general import ExecutionStatusEnum, ExecutorTypeEnum
from falcon_models.service.base_data_types import BaseModelWithAlias, BaseSQLModelWithAlias


class ProcessStatusBase(BaseSQLModelWithAlias):
    """Base model for process status"""

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        nullable=False,
        description="ID of process",
    )
    log_id: Optional[UUID] = Field(
        None,
        index=True,
        description="Log ID of process",
    )
    type: str = Field(
        nullable=False,
        description="Type of process",
    )
    executor: ExecutorTypeEnum = Field(
        default=ExecutorTypeEnum.loki,
        nullable=False,
        description="Executor of process",
    )
    progress: int = Field(
        0,
        nullable=False,
        description="Progress of process",
    )
    progress_details: Optional[Dict] = Field(default={}, sa_column=Column(JSON))
    status: ExecutionStatusEnum = Field(
        default=ExecutionStatusEnum.created,
        description="Status of process",
        sa_column=Column(SQLModelEnum(ExecutionStatusEnum), nullable=False, index=True),
    )


class ProcessStatus(ProcessStatusBase, table=True):
    """Base model for process status"""

    ...


class StatusCount(BaseModelWithAlias):
    status: ExecutionStatusEnum
    count: int


class ProcessStatusBreakdown(BaseModelWithAlias):
    type: str
    name: str
    breakdown: List[StatusCount]


class ProcessCount(BaseModelWithAlias):
    statuses: List[ProcessStatusBreakdown]


class LogGroupBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        nullable=False,
        description="ID of process",
    )


class LogGroup(LogGroupBase, table=True):

    logs: List["LogEntry"] = Relationship(
        back_populates="log_group",
        sa_relationship_kwargs={"cascade": "all, delete-orphan"},
    )


class LogEntryBase(BaseSQLModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        nullable=False,
        description="ID of process",
    )
    message: str = Field(description="Log Message", nullable=False)
    level: str = Field(description="Log Level", nullable=False)
    timestamp: datetime = Field(
        description="Timestamp of log",
        sa_column=Column(
            DateTime,
        ),
    )
    log_group_id: UUID = Field(description="ID of log group", foreign_key="loggroup.id", index=True)


class LogEntry(LogEntryBase, table=True):

    log_group: LogGroup = Relationship(back_populates="logs")
