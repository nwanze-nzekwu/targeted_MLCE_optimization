import typing
from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import JSON, Column
from sqlalchemy import Enum as SQLModelEnum
from sqlalchemy import String, UniqueConstraint
from sqlmodel import Field, Relationship

from artemis_tools.models.git import GitProviderEnum

from falcon_models.enums.changesets import (
    ChangesetFileOperationEnum,
    ChangesetRunType,
    ChangesetStatus,
    FileStatusEnum,
    PRStatus,
)
from falcon_models.enums.general import ExecutionStatusEnum
from falcon_models.service.base_data_types import BaseModelWithAlias, BaseSQLModelWithAlias


class ChangesetDetails(BaseSQLModelWithAlias, table=True):
    __table_args__ = (UniqueConstraint("project_id", "name"),)

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        nullable=False,
        index=True,
        description="Unique identifier for the deprecation.",
    )
    name: str = Field(description="Name of changeset.")
    description: str = Field(description="Description of changeset.")
    project_id: UUID = Field(index=True, description="ID of the project this changeset belongs to.")
    status: str = Field(ChangesetStatus.UNPUBLISHED.value, description="Status of changeset.")
    type: ChangesetRunType = Field(
        default=ChangesetRunType.STANDALONE,
        description="Type of changeset (standalone or quest)",
        sa_column=Column(String, nullable=False, index=True),
    )
    base_version_sha: str | None = Field(description="SHA of the original commit created on the artemis git provider.")
    published_to_branch_name: str | None = Field(
        default=None, description="If 'Published', we store the branch name used on github."
    )
    published_version_sha: str | None = Field(
        default=None, description="SHA of the version to which the changeset was published."
    )
    last_known_sha_on_published_branch: str | None = Field(
        default=None, description="Last known SHA on the published branch, used as base for creating update branches."
    )
    pr_base_branch_name: str | None = Field(
        default=None, description="If at 'Pull Request', we store the branch name used as a base"
    )
    pr_url: str | None = Field(default=None, description="If at 'Pull Request', we store the url")
    conflict_resolution_pr_url: str | None = Field(
        default=None, description="URL of the pull request created for resolving merge conflicts"
    )
    created_at: datetime = Field(description="Timestamp when the changeset was created.")
    updated_at: datetime = Field(description="Timestamp when the changeset was last updated.")
    created_by: str = Field(description="User who created the changeset.")
    number_of_commits_ahead: int = Field(default=0, description="Number of commits ahead of the base branch.")
    number_of_commits_behind: int = Field(default=0, description="Number of commits behind the base branch.")
    specs: list["ChangesetSpecs"] = Relationship(
        sa_relationship_kwargs={
            "cascade": "all, delete-orphan",
        },
    )


class ChangesetSpecs(BaseSQLModelWithAlias, table=True):
    __table_args__ = (UniqueConstraint("changeset_id", "spec_id"),)

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        nullable=False,
        index=True,
        description="Unique identifier for the deprecation.",
    )
    changeset_id: UUID = Field(foreign_key="changesetdetails.id", nullable=False, ondelete="CASCADE")
    spec_id: UUID = Field(index=True, description="ID of the spec this changeset belongs to.")


# Service Models (non-table models for data transfer)


class ChangesetInput(BaseModelWithAlias):
    """Service model for creating a changeset."""

    name: str | None = Field(default=None, description="Name of changeset.")
    type: ChangesetRunType = Field(
        default=ChangesetRunType.STANDALONE, description="Type of changeset run (standalone or quest)"
    )
    description: str | None = Field(default=None, description="Description of changeset.")
    spec_ids: list[UUID] = Field(..., description="List of snippet IDs to include in the changeset")


class Changeset(BaseModelWithAlias):
    """Service model representing a changeset."""

    id: UUID = Field(..., description="The unique identifier of the changeset")
    name: str = Field(..., description="Name of changeset.")
    description: str | None = Field(None, description="Description of changeset.")
    project_id: UUID = Field(..., description="The ID of the project this changeset belongs to")
    status: ChangesetStatus = Field(..., description="Status of changeset.")
    type: ChangesetRunType = Field(
        default=ChangesetRunType.STANDALONE, description="Type of changeset run (standalone or quest)"
    )
    published_to_branch_name: str | None = Field(
        None, description="If 'Published', we store the branch name used on github."
    )
    base_version_sha: str | None = Field(
        default=None, description="SHA of the original version pushed to the artemis git provider"
    )
    published_version_sha: str | None = Field(
        None, description="SHA of the version to which the changeset was published."
    )
    last_known_sha_on_published_branch: str | None = Field(
        None, description="Last known SHA on the published branch, used as base for creating update branches."
    )
    pr_base_branch_name: str | None = Field(
        None, description="If at 'Pull Request', we store the branch name used as a base"
    )
    pr_url: str | None = Field(None, description="Pull Request url")
    conflict_resolution_pr_url: str | None = Field(
        None, description="URL of the pull request created for resolving merge conflicts"
    )
    created_at: datetime = Field(description="Timestamp when the changeset was created.")
    updated_at: datetime = Field(description="Timestamp when the changeset was last updated.")
    created_by: str = Field(description="User who created the changeset.")
    spec_ids: list[UUID] = Field(description="List of snippet IDs to include in the changeset")
    number_of_commits_ahead: int = Field(default=0, description="Number of commits ahead of the base branch.")
    number_of_commits_behind: int = Field(default=0, description="Number of commits behind the base branch.")
    pr_status: PRStatus | None = Field(default=None, description="Status of the pull request, if applicable")


class FileOperation(BaseModelWithAlias):
    """Service model for a file operation in a commit."""

    path: str = Field(..., description="Path of the file")
    content: str = Field(..., description="Content of the file")
    operation: ChangesetFileOperationEnum = Field(..., description="Operation to perform (create, update, delete)")


class VersionCreate(BaseModelWithAlias):
    """Service model for creating a version."""

    message: str = Field(..., description="The version message")
    file_operations: list[FileOperation] = Field(..., description="List of file operations to perform in this version")


class ChangesetVersion(BaseModelWithAlias):
    """Service model for a version in a changeset."""

    message: str = Field(..., description="The commit message for this version")
    author: str = Field(..., description="The author of this version")
    sha: str = Field(..., description="The SHA of the version")
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(), description="The timestamp when the version was created"
    )
    is_original: bool = Field(False, description="Whether this version is the original version")


class ChangesetVersions(BaseModelWithAlias):
    """Service model for a list of versions in a changeset."""

    versions: list[ChangesetVersion] = Field(..., description="List of versions in the changeset")


class ChangesetFile(BaseModelWithAlias):
    """Service model for a file in a changeset version."""

    path: str = Field(..., description="The path of the file")
    content: str | None = Field(None, description="The content of the file")
    size: int = Field(..., description="The size of the file in bytes")
    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(), description="The timestamp when the file was created"
    )
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(), description="The timestamp when the file was last updated"
    )


class Files(BaseModelWithAlias):
    """Service model for changeset files."""

    files: list[str] = Field(..., description="List of file paths")


class ChangesetFileDiff(BaseModelWithAlias):
    """Service model for a file diff in a changeset version."""

    path: str = Field(..., description="The path of the file")
    status: FileStatusEnum = Field(..., description="Status of the file (added, modified, removed, renamed)")
    additions: int = Field(..., description="Number of lines added")
    deletions: int = Field(..., description="Number of lines deleted")
    changes: int = Field(..., description="Total number of changes")
    diff: str = Field(..., description="The diff content")
    language: str | None = Field(None, description="Programming language of the file, if applicable")


class ChangesetVersionCompare(BaseModelWithAlias):
    """Service model for comparing two versions in a changeset."""

    base_version: str = Field(..., description="The base version hash that was compared from")
    head_version: str = Field(..., description="The head version hash that was compared to")
    files_changed: int = Field(..., description="The number of files that were changed")
    additions: int = Field(..., description="The total number of lines added")
    deletions: int = Field(..., description="The total number of lines deleted")
    changes: int = Field(..., description="The total number of lines changed")
    diffs: list[ChangesetFileDiff] = Field(..., description="The list of file differences")


class ChangesetKeywordMatch(BaseModelWithAlias):
    """Single match entry returned by keyword search."""

    file: str = Field(..., description="Path of the file where the keyword was found")
    line: int = Field(..., description="Line number of the match (1-based)")
    content: str = Field(..., description="Line content containing the match (trimmed)")


class GitProviderPullRequest(BaseModelWithAlias):
    """Service model for git provider pull request."""

    status: str = Field(..., description="Status of the pull request operation")
    pull_request_url: str = Field(..., description="URL of the created pull request")


class GitProviderPush(BaseModelWithAlias):
    """Service model for git provider push."""

    status: str = Field(..., description="Status of the push operation")
    branch: str = Field(..., description="Name of the branch that was pushed to")
    merge_conflict: bool = Field(False, description="Whether merge conflicts were encountered")
    merge_conflict_files: list[str] | None = Field(None, description="List of files with merge conflicts")
    message: str | None = Field(None, description="Additional message about the operation")
    conflict_resolution_pr_url: str | None = Field(
        None, description="URL of the pull request created for conflict resolution"
    )


class ChangesetCommandUpdate(BaseModelWithAlias):
    """Service model for updating a validation command with execution results."""

    log_id: UUID | None = Field(None, description="Reference to external log data.")
    exit_code: int | None = Field(None, description="Exit code of the command execution.")
    runtime: float | None = Field(None, description="Time taken to execute the command in seconds.")
    cpu: float | None = Field(None, description="CPU usage during command execution (percentage).")
    memory: float | None = Field(None, description="Memory usage during command execution (MB).")
    status: ExecutionStatusEnum = Field(..., description="Status of the validation command execution.")


class ChangesetValidationCommandCreate(BaseModelWithAlias):
    """Service model for creating a validation command."""

    order: int = Field(..., description="Execution order of the command.")
    command: str = Field(..., description="The command to execute for validation.")


class ChangesetValidationCreate(BaseModelWithAlias):
    """Service model for creating a validation."""

    changeset_id: UUID = Field(..., description="The ID of the changeset to validate.")
    version_sha: str = Field(..., description="SHA of the version this validation is for.")
    custom_worker_name: str | None = Field(None, description="Custom worker name to use for the validation job.")
    commands: list[ChangesetValidationCommandCreate] = Field(
        ..., description="List of commands to execute for validation."
    )


class ChangesetValidationData(BaseModelWithAlias):
    """Service model for a validation (non-table version)."""

    id: UUID = Field(..., description="The unique identifier of the validation.")
    process_id: UUID | None = Field(None, description="External process ID for the validation job.")
    changeset_id: UUID = Field(..., description="The ID of the changeset this validation is for.")
    version_sha: str = Field(..., description="SHA of the version this validation is for.")
    custom_worker_name: str | None = Field(None, description="Custom worker name to use for the validation job.")
    created_at: datetime = Field(..., description="Timestamp when the validation was created.")
    updated_at: datetime = Field(..., description="Timestamp when the validation was last updated.")
    commands: list["ChangesetValidationCommand"] = Field(..., description="List of commands to execute for validation.")


class SingleChangesetCoderRun(BaseModelWithAlias):
    """Service model for a single changeset coder run."""

    agent_run_id: str = Field(description="ID for the agent run (required since all changeset runs are agentic)")


class ChangesetCoderRunData(BaseModelWithAlias):
    """Service model for viewing a changeset coder run"""

    project_id: UUID = Field(description="ID the project belongs to")
    changeset_id: UUID = Field(description="ID the run belongs to")
    agent_run_id: str = Field(description="ID for the agent run (required since all changeset runs are agentic)")
    created_at: datetime = Field(description="Timestamp when the validation was created.")


# Existing models from the original file (table models)
class ChangesetValidation(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        nullable=False,
        index=True,
        description="Unique identifier for the validation process.",
    )
    process_id: UUID | None = Field(
        default=None, nullable=True, description="External process ID for the validation job."
    )
    changeset_id: UUID = Field(foreign_key="changesetdetails.id", nullable=False, index=True)
    version_sha: str = Field(index=True, description="SHA of the version this validation is for.")
    custom_worker_name: str | None = Field(
        default=None, nullable=True, description="Custom worker name to use for the validation job."
    )
    created_at: datetime = Field(default_factory=datetime.now, description="Timestamp when the validation was created.")
    updated_at: datetime = Field(
        default_factory=datetime.now, description="Timestamp when the validation was last updated."
    )

    # Relationship to commands
    commands: list["ChangesetValidationCommand"] = Relationship(
        back_populates="validation",
        sa_relationship_kwargs={
            "lazy": "select",
            "cascade": "all, delete-orphan",
            "order_by": "ChangesetValidationCommand.order",
        },
    )


class ChangesetValidationCommand(BaseSQLModelWithAlias, table=True):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        nullable=False,
        index=True,
        description="Unique identifier for the validation command.",
    )
    validation_id: UUID = Field(foreign_key="changesetvalidation.id", nullable=False, index=True)
    order: int = Field(description="Execution order of the command.")
    command: str = Field(description="The command to execute for validation.")
    log_id: UUID | None = Field(default=None, nullable=True, description="Reference to external log data.")
    exit_code: int | None = Field(default=None, nullable=True, description="Exit code of the command execution.")
    runtime: float | None = Field(
        default=None, nullable=True, description="Time taken to execute the command in seconds."
    )
    cpu: float | None = Field(
        default=None, nullable=True, description="CPU usage during command execution (percentage)."
    )
    memory: float | None = Field(default=None, nullable=True, description="Memory usage during command execution (MB).")
    status: ExecutionStatusEnum = Field(
        default=ExecutionStatusEnum.created,
        description="Status of the validation command execution.",
        sa_column=Column(SQLModelEnum(ExecutionStatusEnum), nullable=False, index=True),
    )
    completed_at: datetime | None = Field(
        default=None, nullable=True, description="Timestamp when the command execution completed."
    )

    # Relationship back to validation
    validation: "ChangesetValidation" = Relationship(back_populates="commands")


class ChangesetCoderRun(BaseSQLModelWithAlias, table=True):
    # NOTE: FK constraint omitted since this is a temporary table that will live in the agent API
    changeset_id: UUID = Field(primary_key=True, description="ID the run belongs to")
    agent_run_id: str = Field(
        primary_key=True, description="ID for the agent run (required since all changeset runs are agentic)"
    )
    project_id: UUID = Field(description="The project ID")
    created_at: datetime = Field(default_factory=datetime.now, description="Timestamp when the validation was created.")
    initial_sha: str | None = Field(default=None, description="the initial SHA (before agent has run)")
    final_sha: str | None = Field(default=None, description="the final SHA (after agent has run)")


class ChangesetAskRun(BaseSQLModelWithAlias, table=True):
    # NOTE: FK constraint omitted since this is a temporary table that will live in the agent API
    changeset_id: UUID = Field(primary_key=True, description="ID the ask belongs to")
    agent_run_id: str = Field(
        primary_key=True, description="ID for the agent ask (required since all changeset asks are agentic)"
    )
    project_id: UUID = Field(description="The project ID")
    created_at: datetime = Field(default_factory=datetime.now, description="Timestamp when the ask was created.")
    file_focus_ranges: list[dict] = Field(
        default=[],
        description="File ranges that the agent must focus on",
        sa_column=Column(JSON, nullable=False, default=list),
    )


class ChangesetPullRequestStatus(BaseModelWithAlias):
    """Service model for changeset PR status."""

    status: str | None = Field(..., description="Status of the pull request operation")


class PublishChangesetData(BaseModelWithAlias):
    version_sha: str | None = None
    branch_name: str | None = None
    commit_message: str | None = None
    provider: GitProviderEnum = GitProviderEnum.GITHUB
