from pydantic import Field

from falcon_models.service.base_data_types import BaseModelWithAlias


class UserInfo(BaseModelWithAlias):
    id: str = Field(description="Token User Id.")
    type: str = Field(description="Type of ownership.")

    @property
    def is_admin(self):
        return self.type == "admin"
