from datetime import datetime
from typing import Optional

from sqlalchemy import Column, DateTime, Float, Integer, String, func
from sqlmodel import Field

from falcon_models.service.base_data_types import BaseSQLModelWithAlias

__all__ = ["UserSettingsBase", "UserSettings"]


class UserSettingsBase(BaseSQLModelWithAlias):
    """
    User settings configuration
    """

    balance_limit: Optional[float] = Field(
        default=None, description="Balance limit for user", sa_column=Column(Float, nullable=True)
    )
    agent_turn_limit: Optional[int] = Field(
        default=None, description="Agent turn limit for user", sa_column=Column(Integer, nullable=True)
    )


class UserSettings(UserSettingsBase, table=True):
    """
    User settings table model
    """

    __tablename__ = "usersettings"

    user_id: str = Field(description="User ID for settings", sa_column=Column(String, primary_key=True, nullable=False))
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last update",
        sa_column=Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False),
    )
