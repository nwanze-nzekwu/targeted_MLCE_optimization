"""
Database models for the observation system for tracking code issues
"""

from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Optional
from uuid import UUID, uuid4

from sqlalchemy import CheckConstraint, Column, DateTime, FetchedValue, Index, String, func
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlmodel import Field, Relationship

from falcon_models.service.base_data_types import BaseSQLModelWithAlias
from falcon_models.service.general import ProcessStatus

if TYPE_CHECKING:
    from falcon_models.service.code import ProjectInfo


class ObservationSourceType(str, Enum):
    """Source type for observations"""

    FILE = "file"
    SPEC = "spec"
    CHANGESET = "changeset"


class RuleSource(str, Enum):
    """Source type for rules"""

    AI = "ai"
    USER = "user"
    FILE = "file"


class RuleBase(BaseSQLModelWithAlias):
    """Base model for audit rules"""

    project_id: UUID = Field(
        index=True, description="ID of the project", foreign_key="projectinfo.id", ondelete="CASCADE"
    )
    enabled: bool = Field(default=True, description="Whether this criterion is enabled")
    title: str = Field(description="Title of the criterion")
    description: str = Field(description="Detailed description of what to check")
    importance: float = Field(ge=0, le=10, description="Importance score (0-10)")

    tags: list[str] = Field(
        default_factory=list,
        description="Tags for categorizing and filtering rules",
        sa_column=Column(ARRAY(String), nullable=False, default=[]),
    )

    source: RuleSource = Field(
        description="Source of the rule (ai, user, or file)",
        sa_column=Column(String, nullable=False, index=True),
    )

    source_file: str | None = Field(default=None, description="Source file if rule was loaded from a file")

    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )

    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last update",
        sa_column=Column(DateTime, server_default=func.now(), server_onupdate=FetchedValue(), nullable=False),
    )


class AuditRunRule(BaseSQLModelWithAlias, table=True):
    """Junction table for many-to-many relationship between AuditRun and Rule"""

    __tablename__ = "audit_run_rules"

    audit_run_id: UUID = Field(
        foreign_key="auditruns.id", primary_key=True, description="ID of the audit run", ondelete="CASCADE"
    )
    rule_id: UUID = Field(foreign_key="rules.id", primary_key=True, description="ID of the rule", ondelete="CASCADE")


class Rule(RuleBase, table=True):
    """Rule table model"""

    __tablename__ = "rules"

    id: UUID = Field(default_factory=lambda: uuid4(), primary_key=True, description="Primary key for rule")

    # Relationships
    issues: list["Issue"] = Relationship(back_populates="rule")
    audit_runs: list["AuditRun"] = Relationship(
        back_populates="rules",
        link_model=AuditRunRule,
    )

    # Indexes and constraints for efficient querying
    __table_args__ = (
        Index("ix_rules_tags", "tags", postgresql_using="gin"),
        Index("ix_rules_project_enabled", "project_id", "enabled"),
        CheckConstraint("source IN ('ai', 'user', 'file')", name="check_rule_source"),
    )


class ObservationBase(BaseSQLModelWithAlias):
    """Base model for observations"""

    project_id: UUID = Field(
        index=True, description="ID of the project", foreign_key="projectinfo.id", ondelete="CASCADE"
    )
    file_name: str = Field(description="Name of the file")

    source_type: ObservationSourceType = Field(
        description="Type of source (file, spec, or changeset)",
        sa_column=Column(String, nullable=False, index=True),
    )
    spec_id: UUID | None = Field(
        default=None, index=True, description="ID of the spec", foreign_key="customspec.id", ondelete="CASCADE"
    )
    changeset_id: UUID | None = Field(
        default=None,
        index=True,
        description="ID of the changeset",
    )

    start_line: int = Field(description="Starting line number")
    end_line: int = Field(description="Ending line number")

    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )


class Observation(ObservationBase, table=True):
    """Observation table model"""

    __tablename__ = "observations"

    id: UUID = Field(default_factory=lambda: uuid4(), primary_key=True, description="Primary key for observation")

    # Relationships
    issues: list["Issue"] = Relationship(back_populates="observation")

    # Composite index and constraints for efficient querying
    __table_args__ = (
        Index("ix_observations_file_lines", "project_id", "file_name", "start_line", "end_line"),
        CheckConstraint("source_type IN ('file', 'spec', 'changeset')", name="check_observation_source_type"),
    )


class IssueBase(BaseSQLModelWithAlias):
    """Base model for issues"""

    observation_id: UUID = Field(
        index=True, description="ID of the observation", foreign_key="observations.id", ondelete="CASCADE"
    )

    audit_run_id: UUID | None = Field(
        default=None,
        index=True,
        description="ID of the audit run that created this issue",
        foreign_key="auditruns.id",
        ondelete="CASCADE",
    )

    model_type: str | None = Field(default=None, description="Type/name of model used to identify this issue")

    rule_id: UUID | None = Field(
        default=None,
        index=True,
        description="ID of the rule that was violated",
        foreign_key="rules.id",
        ondelete="CASCADE",
    )

    title: str = Field(description="Title of the issue")
    severity: float = Field(index=True, description="Severity of the issue (0-10)", ge=0, le=10)
    description: str | None = Field(default=None, description="Detailed description of the issue")
    fix_difficulty_score: float = Field(
        index=True, description="Score indicating the difficulty to fix the issue (0-10)", ge=0, le=10
    )

    task_id: str | None = Field(default=None, index=True, description="External task ID used to fix this issue")
    quest_id: str | None = Field(default=None, index=True, description="External quest ID associated with this issue")


class Issue(IssueBase, table=True):
    """Issue table model"""

    __tablename__ = "issues"

    id: UUID = Field(default_factory=lambda: uuid4(), primary_key=True, description="Primary key for issue")

    # Relationships
    observation: Observation | None = Relationship(back_populates="issues")
    audit_run: Optional["AuditRun"] = Relationship(back_populates="issues")
    rule: Optional["Rule"] = Relationship(back_populates="issues")


class AuditRunBase(BaseSQLModelWithAlias):
    """Base model for audit runs"""

    id: UUID = Field(default_factory=lambda: uuid4(), primary_key=True, index=True, description="ID of audit run")

    project_id: UUID = Field(
        index=True, description="Project ID for the audit", foreign_key="projectinfo.id", ondelete="CASCADE"
    )

    user_id: str = Field(index=True, description="User ID who initiated the audit run")

    # Removed rule_ids array field - will use relationship instead

    model: str = Field(description="Model to use for auditing")

    include_globs: list[str] | None = Field([], sa_column=Column(ARRAY(String)), description="Type of extraction")

    exclude_globs: list[str] | None = Field([], sa_column=Column(ARRAY(String)), description="Type of extraction")

    process_id: UUID | None = Field(default=None, description="ID of the audit process", foreign_key="processstatus.id")

    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of creation",
        sa_column=Column(DateTime, server_default=func.now(), nullable=False),
    )

    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last update",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
            nullable=False,
        ),
    )


class AuditRun(AuditRunBase, table=True):
    """Audit run table model"""

    __tablename__ = "auditruns"

    # Relationships
    project: "ProjectInfo" = Relationship(back_populates="audit_runs")
    process: ProcessStatus | None = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    issues: list["Issue"] = Relationship(back_populates="audit_run")
    rules: list["Rule"] = Relationship(
        back_populates="audit_runs",
        link_model=AuditRunRule,
    )
