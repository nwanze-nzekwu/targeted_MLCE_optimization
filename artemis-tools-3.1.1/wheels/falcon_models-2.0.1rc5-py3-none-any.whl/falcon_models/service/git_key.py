from datetime import datetime
from typing import Annotated, Any, Dict, Optional, Set, Type, TypeAlias, Union
from uuid import UUID, uuid4

from pydantic import HttpUrl, StringConstraints, UrlConstraints
from sqlalchemy import Column, DateTime, FetchedValue, ForeignKey, func
from sqlmodel import Field, Relationship

from falcon_models.enums.git import GitAuthTypeEnum
from falcon_models.service.base_data_types import BaseModelWithAlias, BaseSQLModelWithAlias


class BaseGitAuthParams(BaseModelWithAlias):
    _sensitive_fields: set[str] = set()

    def get_safe_dict(self, *args, **kwargs):
        return self.dict(exclude=self._sensitive_fields, *args, **kwargs)


HttpUrlField: TypeAlias = Annotated[HttpUrl, UrlConstraints()]
NonEmptyStringField: TypeAlias = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]


class BaseGitHubParams(BaseGitAuthParams):
    api_url: HttpUrlField | None = HttpUrl(url="https://api.github.com")


class GitHubAppAuthParams(BaseGitHubParams):
    client_id: NonEmptyStringField
    client_secret: NonEmptyStringField
    app_id: NonEmptyStringField
    private_key: NonEmptyStringField
    installation_id: int

    _sensitive_fields: set[str] = {"private_key", "client_secret"}


class SSHKeyAuthParams(BaseGitAuthParams):
    private_key: NonEmptyStringField
    password: NonEmptyStringField | None = None

    _sensitive_fields: set[str] = {"private_key", "password"}


class GitHubPATAuthParams(BaseGitHubParams):
    """Parameters for GitHub Personal Access Token authentication"""

    token: NonEmptyStringField  # The personal access token for GitHub.

    _sensitive_fields: Set[str] = {"token"}


class BitbucketAppPasswordAuthParams(BaseGitAuthParams):
    """Parameters for GitHub Personal Access Token authentication"""

    api_url: HttpUrlField | None = HttpUrl(url="https://api.bitbucket.org.")
    username: NonEmptyStringField  # The username for GitHub.
    password: NonEmptyStringField  # The personal access token for GitHub.

    _sensitive_fields: Set[str] = {"password"}


class GitHubOAuthAuthParams(BaseGitHubParams):
    """Parameters for GitHub OAuth Token authentication (user-to-server tokens)"""

    artemis_user_id: NonEmptyStringField
    github_user_id: NonEmptyStringField
    github_username: NonEmptyStringField
    oauth_token_id: NonEmptyStringField

    _sensitive_fields: Set[str] = {"oauth_token_id"}


GIT_AUTH_TYPE_MAP: Dict[GitAuthTypeEnum, Type[BaseGitAuthParams]] = {
    GitAuthTypeEnum.GITHUB_APP: GitHubAppAuthParams,
    GitAuthTypeEnum.GITHUB_PAT: GitHubPATAuthParams,
    GitAuthTypeEnum.SSH_KEY: SSHKeyAuthParams,
    GitAuthTypeEnum.BITBUCKET_APP_PASSWORD: BitbucketAppPasswordAuthParams,
    GitAuthTypeEnum.GITHUB_OAUTH_TOKEN: GitHubOAuthAuthParams,
}


class GenericGitAuthParams(BaseModelWithAlias):
    name: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=256)]
    type: GitAuthTypeEnum
    params: Union[
        dict[str, Any],
        GitHubAppAuthParams,
        GitHubPATAuthParams,
        SSHKeyAuthParams,
        BitbucketAppPasswordAuthParams,
        GitHubOAuthAuthParams,
    ]

    def get_params(self):
        return data_to_key(self.type, self.params)


def data_to_key(type: GitAuthTypeEnum, params: dict[str, Any]) -> BaseGitAuthParams:
    params_class = GIT_AUTH_TYPE_MAP.get(type)
    if params_class:
        return params_class.model_validate(params)
    raise ValueError(f"Unsupported Git authentication type: {type}")


class AddGitAuthKey(GenericGitAuthParams):
    """
    Model used for adding a new git auth key, extends GenericGitAuthParams to include default flag
    """

    default: bool = False


class GitAuthKeysBase(BaseSQLModelWithAlias):
    """
    Info about a specific project
    """

    id: UUID = Field(
        default_factory=lambda: uuid4(),
        primary_key=True,
        index=True,
        description="ID of key",
    )
    name: str = Field(description="Name of key")
    user_id: str = Field(description="User id of key", index=True, unique=False)
    type: GitAuthTypeEnum = Field(description="Type of key")
    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of key creation",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            nullable=False,
        ),
    )
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last kry update",
        sa_column=Column(
            DateTime,
            server_default=func.now(),
            server_onupdate=FetchedValue(),
            nullable=False,
        ),
    )


class GitAuthKeys(GitAuthKeysBase, table=True):

    data: bytes = Field(description="Encrypted data of key")
    projects: list["ProjectInfo"] = Relationship(
        back_populates="key",
        sa_relationship_kwargs={
            "cascade": "save-update, merge",
        },
    )
    default_for_user: Optional["UserDefaultKeys"] = Relationship(
        back_populates="key", sa_relationship_kwargs={"cascade": "all, delete-orphan"}
    )


class UserDefaultKeys(BaseSQLModelWithAlias, table=True):
    user_id: str = Field(primary_key=True, index=True, description="User ID")
    default_key_id: UUID = Field(
        sa_column=Column(
            ForeignKey("gitauthkeys.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
            unique=True,
        ),
        description="ID of the default key",
    )

    key: "GitAuthKeys" = Relationship(
        back_populates="default_for_user",
    )


class GitSingleBranchInfo(BaseModelWithAlias):
    name: str
    commit: str
