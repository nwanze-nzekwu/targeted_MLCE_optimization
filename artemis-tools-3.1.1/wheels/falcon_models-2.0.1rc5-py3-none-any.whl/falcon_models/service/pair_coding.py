from enum import Enum

from falcon_models.service.base_data_types import BaseModelWithAlias


class PairCodeStageEnum(str, Enum):
    # unified is used to signal that it is part of the unified agent run
    specs = "specs"
    action_plan = "action_plan"
    generate_changes = "generate_changes"
    action_plan_unified = "action_plan_unified"
    generate_changes_unified = "generate_changes_unified"


class Configurable(BaseModelWithAlias):
    checkpoint_id: str | None = None
    checkpoint_ns: str | None = None
    thread_id: str | None = None

    def all_different_from_none(self) -> bool:
        return all(attr is not None for attr in [self.checkpoint_id, self.checkpoint_ns, self.thread_id])
