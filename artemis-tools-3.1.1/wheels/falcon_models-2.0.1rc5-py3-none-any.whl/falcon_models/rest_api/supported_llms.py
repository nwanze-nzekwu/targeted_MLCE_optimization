from vision_models.service.llm import LLMDetails

from evoml_api_models import BaseModelWithAlias


class SupportedLLMsResponse(BaseModelWithAlias):
    llms: list[LLMDetails]
