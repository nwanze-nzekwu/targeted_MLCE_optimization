from enum import StrEnum


class GitAuthTypeEnum(StrEnum):
    """Type of Git authentication"""

    GITHUB_APP = "github_app"
    GITHUB_PAT = "github_pat"
    SSH_KEY = "ssh_key"
    BITBUCKET_APP_PASSWORD = "bitbucket_app_password"
    GITHUB_OAUTH_TOKEN = "github_oauth_token"
