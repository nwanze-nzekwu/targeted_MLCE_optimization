from enum import StrEnum


class ExecutionStatusEnum(StrEnum):
    created = "created"
    pending = "pending"
    ready = "ready"
    running = "running"
    requeued = "requeued"
    success = "success"
    failed = "failed"
    cancelled = "cancelled"
    unknown = "unknown"


class ExecutorTypeEnum(StrEnum):
    ray = "ray"
    loki = "loki"
