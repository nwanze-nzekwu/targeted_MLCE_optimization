from enum import StrEnum


class ChangesetStatus(StrEnum):
    UNPUBLISHED = "unpublished"
    PUBLISHED = "published"
    PUBLISHED_WITH_CONFLICTS = "published_with_conflicts"
    PULL_REQUEST = "pull_request"


class FileStatusEnum(StrEnum):
    """Enum for file status in a diff"""

    ADDED = "added"
    MODIFIED = "modified"
    REMOVED = "removed"
    RENAMED = "renamed"


class ChangesetFileOperationEnum(StrEnum):
    """Enum for changeset file operations"""

    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"


class PRStatus(StrEnum):
    """Enum for pull request status"""

    OPEN = "open"
    CLOSED = "closed"
    MERGED = "merged"
    DRAFT = "draft"


class ChangesetRunType(StrEnum):
    """Enum for changeset run type"""

    STANDALONE = "standalone"
    QUEST = "quest"
