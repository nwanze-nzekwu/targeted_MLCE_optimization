from enum import Enum, StrEnum


class SolutionStatusEnum(str, Enum):
    created = "created"
    success = "success"
    fail = "failed"
    running = "running"
    pending = "pending"
    cancelled = "cancelled"


class FileOperationEnum(StrEnum):
    """Enum for file operations"""

    ADD = "add"
    DELETE = "delete"
    EDIT = "edit"


class Metric(str, Enum):
    """
    Enum class for the optimisation metric
    """

    runtime = "runtime"
    cpu = "cpu"
    memory = "memory"


class ExplainerType(str, Enum):
    LINEAR = "linear"
    SVM = "svm"


class ReportFormat(str, Enum):
    PDF = "pdf"
    MD = "md"


class ProcessType(StrEnum):
    validation = "validation"  # ex-analysis
    embedding = "embedding"
    optimization = "optimization"
    recommendation = "recommendation"
    scoring = "scoring"
    ga = "ga"
    utility = "utility"
    pair_coder = "pair-coder"
    extract = "extract"
    falcon_report = "falcon-report"
    db_context = "db-context"

    # Define a mapping of labels
    @staticmethod
    def get_label_mapping():
        return {
            ProcessType.validation: "Code Validation",
            ProcessType.embedding: "Indexing",
            ProcessType.optimization: "Optimization",
            ProcessType.recommendation: "Code Suggestion",
            ProcessType.scoring: "Scoring",
            ProcessType.ga: "Artemis Intelligence",
            ProcessType.utility: "Code Download",
            ProcessType.pair_coder: "Code Agent",
            ProcessType.extract: "Code Analysis",
            ProcessType.falcon_report: "Report Generation",
            ProcessType.db_context: "Database Context",
        }

    # Helper to fetch a label for a specific task
    @classmethod
    def get_label(cls, process_type):
        mapping = cls.get_label_mapping()
        return mapping.get(process_type, "Unknown Task")


class Status(StrEnum):
    ready = "ready"
    pending = "pending"
    running = "running"
    cancelled = "cancelled"
    failed = "failed"
    success = "success"
    created = "created"


class CloudProvider(str, Enum):
    AWS = "aws"
    GOOGLE = "gcp"
    AZURE = "azure"


class InfoTypeEnum(str, Enum):
    """Information/entry type"""

    INPUT = "input"
    OUTPUT = "output"


class AIApplicationMethodEnum(StrEnum):
    zero_shot = "zero_shot"
    rag = "rag"
    web_search = "web_search"
    agent = "agent"
    ga = "ga"


class RerankMethodEnum(StrEnum):
    ZERO_SHOT = "zero_shot"
    AGENT = "agent"


class CodeOptions(str, Enum):
    SIMILAR = "similar"
    UNIT_TEST = "unit_test"
    REFERENCE = "reference"
    USAGE = "usage"
    CUSTOM = "custom"

    @classmethod
    def is_valid(cls, value: str) -> bool:
        return value in cls._value2member_map_

    @classmethod
    def from_string(cls, value: str):
        """Convert a string to the corresponding enum member."""
        try:
            return cls(value)
        except ValueError:
            return None  # or raise an exception if preferred
