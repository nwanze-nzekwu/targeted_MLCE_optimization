from enum import Enum, StrEnum


class FilterTypeEnum(StrEnum):
    location = "location"
    originalScore = "originalScore"
    tags = "tags"
    recommendations = "recommendations"
    recommendationScores = "recommendationScores"
    validated = "validated"
    snippets = "snippets"
    extraction = "extraction"


class ValidationFilterTypeEnum(str, Enum):
    """Type of filter"""

    COMPILATION = "compilation"
    UNIT = "unit"
    PERF = "perf"
    SECURITY = "security"
    CUSTOM = "custom"

    def to_display_name(self):
        match self:
            case ValidationFilterTypeEnum.COMPILATION:
                return "Compilation"
            case ValidationFilterTypeEnum.UNIT:
                return "Unit Test"
            case ValidationFilterTypeEnum.PERF:
                return "Performance"
            case ValidationFilterTypeEnum.SECURITY:
                return "Security"
            case ValidationFilterTypeEnum.CUSTOM:
                return "Custom"
