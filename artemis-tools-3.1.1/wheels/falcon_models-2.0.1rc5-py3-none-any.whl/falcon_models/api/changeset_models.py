"""
This module contains the models for changeset management
"""

from datetime import datetime
from uuid import UUID

from pydantic import Field
from vision_models.service.llm import LLMType

from falcon_models.api.base_data_types import PaginatedBase
from falcon_models.api.process_models import Status
from falcon_models.enums.changesets import (
    ChangesetFileOperationEnum,
    ChangesetRunType,
    ChangesetStatus,
    FileStatusEnum,
    PRStatus,
)
from falcon_models.enums.general import ExecutionStatusEnum
from falcon_models.service.base_data_types import BaseModelWithAlias


class ChangesetResponse(BaseModelWithAlias):
    """Response model for a changeset."""

    id: UUID = Field(..., description="The unique identifier of the changeset")
    name: str = Field(..., description="Name of changeset.")
    description: str | None = Field(None, description="Description of changeset.")
    project_id: UUID = Field(..., description="The ID of the project this changeset belongs to")
    status: ChangesetStatus = Field(..., description="Status of changeset.")
    type: ChangesetRunType = Field(
        default=ChangesetRunType.STANDALONE,
        description="Type of changeset (standalone or quest)",
    )
    published_to_branch_name: str | None = Field(
        None, description="If 'Published', we to store the branch name used on github."
    )
    base_version_sha: str | None = Field(
        default=None, description="SHA of the original version pushed to the artemis git provider"
    )
    published_version_sha: str | None = Field(
        None, description="SHA of the version to which the changeset was published."
    )
    last_known_sha_on_published_branch: str | None = Field(
        None, description="Last known SHA on the published branch, used as base for creating update branches."
    )
    pr_base_branch_name: str | None = Field(
        None, description="If at 'Pull Request', we store the branch name used as a base"
    )
    pr_url: str | None = Field(None, description="Pull Request url")
    conflict_resolution_pr_url: str | None = Field(
        default=None, description="URL of the pull request created for resolving merge conflicts"
    )
    created_at: datetime = Field(description="Timestamp when the changeset was created.")
    updated_at: datetime = Field(description="Timestamp when the changeset was last updated.")
    created_by: str = Field(description="User who created the changeset.")
    spec_ids: list[UUID] = Field(description="List of snippet IDs to include in the changeset")
    number_of_commits_ahead: int = Field(default=0, description="Number of commits ahead of the base branch.")
    number_of_commits_behind: int = Field(default=0, description="Number of commits behind the base branch.")
    pr_status: PRStatus | None = Field(
        default=None, description="Status of the pull request associated with the changeset"
    )


class PaginatedChangesetResponse(PaginatedBase[ChangesetResponse]):
    """
    Data structure for paginated changeset
    """


class ChangesetCreateRequest(BaseModelWithAlias):
    """Request model for creating a changeset."""

    name: str | None = Field(default=None, description="Name of changeset.")
    type: ChangesetRunType = Field(
        default=ChangesetRunType.STANDALONE,
        description="Type of changeset (standalone or quest)",
    )
    description: str | None = Field(default=None, description="Description of changeset")
    spec_ids: list[UUID] = Field(..., description="List of snippet IDs to include in the changeset")


class FileOperation(BaseModelWithAlias):
    """Model for a file operation in a commit."""

    path: str = Field(..., description="Path of the file")
    content: str = Field(..., description="Content of the file")
    operation: ChangesetFileOperationEnum = Field(..., description="Operation to perform (create, update, delete)")


class VersionCreateRequest(BaseModelWithAlias):
    """Request model for creating a version."""

    message: str = Field(..., description="The version message")
    fileOperations: list[FileOperation] = Field(..., description="List of file operations to perform in this version")


class ChangesetVersionResponse(BaseModelWithAlias):
    """Response model for a version in a changeset."""

    message: str = Field(..., description="The commit message for this version")
    author: str = Field(..., description="The author of this version")
    sha: str = Field(..., description="The SHA of the version")
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(), description="The timestamp when the version was created (ISO format)"
    )
    is_original: bool = Field(False, description="Whether this version is the original version")


class ChangesetVersionsResponse(BaseModelWithAlias):
    """Response model for a list of versions in a changeset."""

    versions: list[ChangesetVersionResponse] = Field(..., description="List of versions in the changeset")


class ChangesetFileResponse(BaseModelWithAlias):
    """Response model for a file in a changeset version."""

    path: str = Field(..., description="The path of the file")
    content: str | None = Field(None, description="The content of the file")
    size: int = Field(..., description="The size of the file in bytes")
    created_at: datetime | None = Field(
        default_factory=lambda: datetime.now(), description="The timestamp when the file was created (ISO format)"
    )
    updated_at: datetime | None = Field(
        default_factory=lambda: datetime.now(), description="The timestamp when the file was last updated (ISO format)"
    )


class ChangesetFilesResponse(BaseModelWithAlias):
    """Response model for a list of files in a changeset version."""

    files: list[ChangesetFileResponse] = Field(..., description="List of files in the changeset version")


class ChangesetFileDiffResponse(BaseModelWithAlias):
    """Response model for a file diff in a changeset version."""

    path: str = Field(..., description="The path of the file")
    status: FileStatusEnum = Field(..., description="Status of the file (added, modified, removed, renamed)")
    additions: int = Field(..., description="Number of lines added")
    deletions: int = Field(..., description="Number of lines deleted")
    changes: int = Field(..., description="Total number of changes")
    diff: str = Field(..., description="The diff content")
    language: str | None = Field(None, description="Programming language of the file, if applicable")


class ChangesetFileDiffsResponse(BaseModelWithAlias):
    """Response model for a list of file diffs in a changeset version."""

    diffs: list[ChangesetFileDiffResponse] = Field(..., description="List of file diffs in the changeset version")


class ChangesetVersionCompareResponse(BaseModelWithAlias):
    """
    Response model for comparing two versions in a changeset.
    """

    base_version: str = Field(..., description="The base version hash that was compared from")
    head_version: str = Field(..., description="The head version hash that was compared to")
    files_changed: int = Field(..., description="The number of files that were changed")
    additions: int = Field(..., description="The total number of lines added")
    deletions: int = Field(..., description="The total number of lines deleted")
    changes: int = Field(..., description="The total number of lines changed")
    diffs: list[ChangesetFileDiffResponse] = Field(..., description="The list of file differences")


class FilesResponse(BaseModelWithAlias):
    """Changeset Files Response."""

    files: list[str]


class FileContentResponse(BaseModelWithAlias):
    file_content: str


class GitProviderPullRequestResponse(BaseModelWithAlias):
    """GitHub Pull Request Response."""

    status: Status
    pull_request_url: str


class GitProviderPushResponse(BaseModelWithAlias):
    """GitHub Push Response."""

    status: Status
    branch: str
    merge_conflict: bool = Field(False, description="Whether merge conflicts were encountered")
    merge_conflict_files: list[str] | None = Field(None, description="List of files with merge conflicts")
    conflict_resolution_pr_url: str | None = Field(
        default=None, description="URL of the PR created to resolve conflicts"
    )
    message: str | None = Field(None, description="Additional message about the operation")


# Validation Models
class ChangesetValidationCommandRequest(BaseModelWithAlias):
    """Request model for creating a validation command."""

    order: int = Field(..., description="Execution order of the command.")
    command: str = Field(..., description="The command to execute for validation.")


class ChangesetValidationCommandResponse(BaseModelWithAlias):
    """Response model for a validation command."""

    id: UUID = Field(..., description="The unique identifier of the validation command.")
    validation_id: UUID = Field(..., description="The ID of the validation this command belongs to.")
    order: int = Field(..., description="Execution order of the command.")
    command: str = Field(..., description="The command to execute for validation.")
    log_id: UUID | None = Field(None, description="Reference to external log data.")
    exit_code: int | None = Field(None, description="Exit code of the command execution.")
    runtime: float | None = Field(None, description="Time taken to execute the command in seconds.")
    cpu: float | None = Field(None, description="CPU usage during command execution (percentage).")
    memory: float | None = Field(None, description="Memory usage during command execution (MB).")
    status: ExecutionStatusEnum = Field(
        ExecutionStatusEnum.created, description="Status of the validation command execution."
    )
    completed_at: datetime | None = Field(None, description="Timestamp when the command execution completed.")


class ChangesetValidationRequestBody(BaseModelWithAlias):
    custom_worker_name: str | None = Field(None, description="Custom worker name to use for the validation job.")
    commands: list[ChangesetValidationCommandRequest] = Field(
        ..., description="List of commands to execute for validation."
    )
    userId: str | None = Field(None, description="User ID of the custom worker selected.")


class ChangesetValidationRequest(ChangesetValidationRequestBody):
    """Request model for creating a validation."""

    changeset_id: UUID = Field(..., description="The ID of the changeset to validate.")
    version_sha: str = Field(..., description="SHA of the version this validation is for.")


class ChangesetValidationResponse(BaseModelWithAlias):
    """Response model for a validation."""

    id: UUID = Field(..., description="The unique identifier of the validation.")
    process_id: UUID | None = Field(None, description="External process ID for the validation job.")
    changeset_id: UUID = Field(..., description="The ID of the changeset this validation is for.")
    version_sha: str = Field(..., description="SHA of the version this validation is for.")
    custom_worker_name: str | None = Field(None, description="Custom worker name to use for the validation job.")
    created_at: datetime = Field(..., description="Timestamp when the validation was created.")
    updated_at: datetime = Field(..., description="Timestamp when the validation was last updated.")
    commands: list[ChangesetValidationCommandResponse] = Field(
        ..., description="List of commands to execute for validation."
    )


class PaginatedChangesetValidationResponse(PaginatedBase[ChangesetValidationResponse]):
    """
    Data structure for paginated changeset validations
    """


class ChangesetCommandUpdateRequest(BaseModelWithAlias):
    """Request model for updating a validation command with execution results."""

    log_id: UUID | None = Field(None, description="Reference to external log data.")
    exit_code: int | None = Field(None, description="Exit code of the command execution.")
    runtime: float | None = Field(None, description="Time taken to execute the command in seconds.")
    cpu: float | None = Field(None, description="CPU usage during command execution (percentage).")
    memory: float | None = Field(None, description="Memory usage during command execution (MB).")
    status: ExecutionStatusEnum = Field(..., description="Status of the validation command execution.")


class ChangesetCoderRunResponse(BaseModelWithAlias):
    """Response model for viewing a changeset coder run"""

    project_id: UUID = Field(description="ID the project belongs to")
    changeset_id: UUID = Field(description="ID the run belongs to")
    agent_run_id: str = Field(description="ID for the agent run (required since all changeset runs are agentic)")
    created_at: datetime = Field(description="Timestamp when the validation was created.")


class SingleChangesetCoderRunResponse(BaseModelWithAlias):
    agent_run_id: str = Field(description="ID for the agent run (required since all changeset runs are agentic)")
    created_at: datetime = Field(description="Timestamp when the validation was created.")


class FileFocusRange(BaseModelWithAlias):
    """Represents a file path with optional line range to focus on."""

    file_path: str = Field(description="file path to include to ask chat")
    start_line: int | None = Field(default=None, description="start line of the file that agent must be focus on")
    end_line: int | None = Field(default=None, description="end line of the file that agent must be focus on")
    version_sha: str | None = Field(default=None, description="Git SHA for the version of the file to use")


class ChangesetAskRunRequest(BaseModelWithAlias):
    """Request model for creating a changeset ask run"""

    file_focus_ranges: list[FileFocusRange] = Field(default=[], description="File ranges that the agent must focus on")
    model_type: str = Field(default="gpt-41", description="The model type to use for the agent")
    user_message: str | None = Field(default=None, description="The initial message for the agent")


class ChangesetAskRunResponse(BaseModelWithAlias):
    """Response model for viewing a changeset ask run"""

    project_id: UUID = Field(description="ID the project belongs to")
    changeset_id: UUID = Field(description="ID the ask belongs to")
    agent_run_id: str = Field(description="ID for the agent ask (required since all changeset asks are agentic)")
    created_at: datetime = Field(description="Timestamp when the ask was created.")
    file_focus_ranges: list[FileFocusRange] = Field(default=[], description="File ranges that the agent must focus on")


class SingleChangesetAskRunResponse(BaseModelWithAlias):
    """Response model for a single changeset ask run"""

    agent_run_id: str = Field(description="ID for the agent ask")
    created_at: datetime = Field(description="Timestamp when the ask was created.")
    file_focus_ranges: list[FileFocusRange] = Field(default=[], description="File ranges that the agent must focus on")


class ChangesetAskUserResponseRequest(BaseModelWithAlias):
    """Request model for user changeset ask response."""

    response: str = Field(..., description="The response from the user")


class ChangesetStoreAgentRequest(BaseModelWithAlias):
    """Request model for storing changeset agent data."""

    agent_run_id: str = Field(..., description="ID of the agent run.")


class ChangesetAskUserResponse(BaseModelWithAlias):
    """Response model for user response to agent ask conversation."""

    agent_run_id: str | None = Field(
        None, alias="agentRunId", description="ID of the new agent run created for this response"
    )
    status: str = Field(description="Current status of the agent run")
    created_at: str = Field(alias="createdAt", description="Timestamp when the response was created")
    parent_run_id: str = Field(alias="parentRunId", description="ID of the parent agent run this responds to")
    response: dict | None = Field(None, description="Optional response data if no new run was created")


class PaginatedSingleChangesetAskRunResponse(PaginatedBase[SingleChangesetAskRunResponse]):
    """
    Data structure for paginated changeset ask runs
    """


class ChangesetAskRunsResponse(BaseModelWithAlias):
    """Response model for viewing a set of changeset ask runs for a single changeset"""

    project_id: UUID = Field(description="ID the project belongs to")
    changeset_id: UUID = Field(description="ID the ask belongs to")
    runs: PaginatedSingleChangesetAskRunResponse = Field(description="The ask runs of the agent")


class PaginatedSingleChangesetCoderRunResponse(PaginatedBase[SingleChangesetCoderRunResponse]):
    """
    Data structure for paginated changeset validations
    """


class ChangesetCoderRunsResponse(BaseModelWithAlias):
    """Response model for viewing a set of changeset coder runs for a single changeset"""

    project_id: UUID = Field(description="ID the project belongs to")
    changeset_id: UUID = Field(description="ID the run belongs to")
    runs: PaginatedSingleChangesetCoderRunResponse = Field(description="The runs of the agent")


class ChangesetKeywordMatchResponse(BaseModelWithAlias):
    """Single match entry returned by keyword search."""

    file: str = Field(..., description="Path of the file where the keyword was found")
    line: int = Field(..., description="Line number of the match (1-based)")
    content: str = Field(..., description="Line content containing the match (trimmed)")


class PaginatedChangesetKeywordMatchResponse(PaginatedBase[ChangesetKeywordMatchResponse]):
    """Paginated list of keyword matches."""


class ChangesetPRDetailsRequest(BaseModelWithAlias):
    """Request model for determining PR details for a changeset."""

    base_sha: str | None = Field(
        None, description="The base commit SHA to compare from (if not provided, will be fetched from changeset)"
    )
    head_sha: str | None = Field(
        None, description="The head commit SHA to compare to (if not provided, will use latest SHA)"
    )
    model_type: LLMType = Field(default=LLMType.OPENAI_GPT_5, description="The LLM model type to use for generation")


class ChangesetPRDetailsResponse(BaseModelWithAlias):
    """Response model for PR details of a changeset."""

    new_branch_name: str = Field(..., description="The branch name for the changeset")
    pr_title: str | None = Field(None, description="The PR title (if creating PR)")
    pr_description: str | None = Field(None, description="The PR description (if creating PR)")
    create_pr: bool = Field(..., description="Whether to create a new PR")
