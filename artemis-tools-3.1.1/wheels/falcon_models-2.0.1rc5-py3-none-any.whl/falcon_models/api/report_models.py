from datetime import datetime
from typing import Optional
from uuid import UUID, uuid4

from pydantic import Field, model_validator

from falcon_models.api.base_data_types import BaseModelWithAlias, MakeOptional, PaginatedBase
from falcon_models.enums.general import ExecutionStatusEnum


class ReportRunBaseRequestResponse(BaseModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        description="ID of report generation process",
    )
    process_id: Optional[UUID] = Field(
        default=None,
        description="ID of application process",
    )
    project_id: Optional[UUID] = Field(
        default=None,
        description="Project ID of report",
    )
    optimisation_id: Optional[UUID] = Field(
        default=None,
        description="Optimisation ID of report",
    )
    solution_id: Optional[UUID] = Field(default=None, description="Solution ID of reports")
    format: str = Field(..., description="Format of the report")
    thor_file_id: Optional[str] = Field(default=None, description="ID of thor file")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of entry creation",
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(),
        description="Timestamp of last entry update",
    )

    @model_validator(mode="after")
    def validate_single_foreign_key(self):
        if self.project_id is not None and self.optimisation_id is not None:
            raise ValueError("Only one of project_id or optimisation_id should be set")
        if self.project_id is None and self.optimisation_id is None:
            raise ValueError("Either project_id or optimisation_id must be set")
        return self


class ReportCreationResponse(BaseModelWithAlias):
    process_id: UUID


class ReportRequestResponse(ReportRunBaseRequestResponse, MakeOptional):
    """
    Data model for report runs
    """

    status: ExecutionStatusEnum | None = Field(default=None)
    progress_details: str | None = Field(default=None)


class PaginatedReportResponse(PaginatedBase[ReportRequestResponse]):
    """
    Data structure for paginated report runs
    """

    ...


class ReportFinishRequest(BaseModelWithAlias):
    thor_file_id: str
