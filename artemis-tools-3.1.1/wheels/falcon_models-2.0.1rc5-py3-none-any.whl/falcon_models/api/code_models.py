import enum
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, Union
from uuid import UUID, uuid4

from pydantic import Field, RootModel, field_validator, model_validator
from typing_extensions import Self

from artemis_tools.models.generic import Language, language_by_extension
from artemis_tools.models.git import GitProviderEnum

from falcon_models.api.base_data_types import BaseModelWithAlias, MakeOptional, PaginatedBase, PaginationParams
from falcon_models.api.git_key_models import SimpleGitKeyResponse
from falcon_models.enums.code import AIApplicationMethodEnum, FileOperationEnum, RerankMethodEnum, SolutionStatusEnum
from falcon_models.enums.filters.constructs import FilterTypeEnum, ValidationFilterTypeEnum
from falcon_models.enums.general import ExecutionStatusEnum


class DbConnectionRequest(BaseModelWithAlias):
    db_host: str | None = Field(default=None)
    db_port: int | None = Field(default=None)
    db_name: str | None = Field(default=None)
    db_type: str | None = Field(default=None)
    db_username: str | None = Field(default=None)
    db_password: str | None = Field(default=None)
    db_schema: str | None = Field(default=None)

    # new field for managed-services URLs
    connection_url: Optional[str] = Field(
        default=None,
        description="A full connection URL (e.g. from AWS RDS/Azure/etc). "
        "If provided, host/port/name/username are ignored.",
    )


class DbProjectCreationRequest(DbConnectionRequest):
    name: str
    description: str | None = Field(default=None)
    db_schema: str | None = Field(default=None)


class EnvironmentalImpactResponse(BaseModelWithAlias):
    electricityKwh: float
    carbonDioxideKg: float


class ProjectIngestCreationResponse(BaseModelWithAlias):
    process_id: UUID


class ProjectIngestRunResponse(BaseModelWithAlias):
    id: UUID
    name: str
    description: str | None = Field(default=None)
    db_type: str | None = Field(default=None)
    db_host: str | None = Field(default=None)
    db_port: int | None = Field(default=None)
    db_username: str | None = Field(default=None)
    db_name: str | None = Field(default=None)
    db_schema: str | None = Field(default=None)
    process_id: UUID | None = Field(default=None)
    project_id: UUID | None = Field(default=None)
    status: ExecutionStatusEnum | None = Field(default=None)
    requested_by: str
    connection_url: str | None = Field(default=None)


class ProjectIngestPatchRequest(BaseModelWithAlias):
    project_id: UUID


class PaginatedProjectIngestRequestResponse(PaginatedBase[ProjectIngestRunResponse]):
    """Data structure of an information group."""

    ...


class ResultsStatsModelResponse(BaseModelWithAlias):
    mean: float
    mean_adjusted: float
    std: float
    min: float
    max: float


class SolutionResultsResponseBase(BaseModelWithAlias):
    runtime: List[float] = Field(
        description="Runtime of solution",
    )
    cpu: List[float] = Field(
        description="CPU usage of solution",
    )
    memory: List[float] = Field(
        description="Memory usage of solution",
    )
    stats: dict[str, ResultsStatsModelResponse] = {}


class SolutionResultsResponse(BaseModelWithAlias):
    values: dict[str, list[float]]
    stats: dict[str, ResultsStatsModelResponse]

    @classmethod
    def from_results(cls, results: SolutionResultsResponseBase):
        return cls(
            stats=results.stats,
            values=results.model_dump(exclude={"solution_id", "log_file_id"}),
        )


class FullSolutionInfoRequestResponseBase(BaseModelWithAlias):
    number: int | None = Field(default=None)
    file_id: str | None = Field(default=None)
    log_file_id: str | None = Field(default=None)
    hardware_id: UUID | None = Field(default=None)
    status: SolutionStatusEnum = Field(SolutionStatusEnum.created)


class SolutionSpecResponseBase(BaseModelWithAlias):
    spec_id: UUID


class FullSolutionInfoRequest(FullSolutionInfoRequestResponseBase):
    specs: list[SolutionSpecResponseBase]
    results: SolutionResultsResponseBase | None = Field(default=None)


class SolutionSpecResponse(BaseModelWithAlias):
    spec_id: UUID
    construct_id: UUID


class CustomSpecScoreResponse(BaseModelWithAlias):
    type: str = Field(description="Type of score")
    score: float = Field(description="Score of custom spec")
    description: str | None = Field(None, description="Description of the score")
    llm_type: str = Field(description="Type of llm score")


class CustomSpecContextResponse(BaseModelWithAlias):
    tool: str = Field(description="Tool name")
    context: str = Field(description="Context of the spec")


class TagResponse(BaseModelWithAlias):
    id: UUID
    project_id: UUID | None = None
    name: str


class TagCreationResponse(BaseModelWithAlias):
    tags: list[TagResponse]


class TagRequest(BaseModelWithAlias):
    name: str
    project_id: UUID | None = None


class TagNamesRequest(BaseModelWithAlias):
    tag_names: list[str]


class ConcreteConstructRequestResponseBase(BaseModelWithAlias):
    original_spec_id: UUID
    lineno: int
    end_lineno: int
    file: str
    enabled: bool = Field(default=True)
    deprecation_id: UUID | None = None
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class ConcreteConstructChildResponse(ConcreteConstructRequestResponseBase):
    id: UUID
    project_id: UUID
    filter_results: dict[UUID, bool] = Field(default_factory=dict)
    tokens: int | None = Field(default=None)
    extraction_id: UUID | None = Field(default=None)
    language: str


class CustomSpecReplaceRequest(BaseModelWithAlias):
    id: UUID
    content: str


class CustomSpecRequestResponseBase(BaseModelWithAlias):
    id: UUID = Field(default_factory=lambda: uuid4())
    ai_run_id: UUID | None = Field(default=None)
    name: str
    llm_model: str | None = Field(default=None)
    content: str
    imports: list[str] | None = Field(default_factory=list)
    file_operation: FileOperationEnum = Field(default=FileOperationEnum.EDIT)
    enabled: bool = Field(default=True)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())
    tags: list[TagResponse] = Field(default_factory=list)


class RootSpecResponse(CustomSpecRequestResponseBase):
    # response with no sources
    ...


class InsertionsDeletionsResponse(BaseModelWithAlias):
    insertions: int
    deletions: int


class CodeContextResponse(BaseModelWithAlias):
    customspec_id: UUID = Field(description="ID of custom spec")
    tool_id: UUID = Field(description="ID of tool")
    context: str = Field(description="context from the tool")
    tool_name: str = Field(description="The tool name")


class CustomSpecChildResponse(CustomSpecRequestResponseBase):
    """When the spec is returned within a construct."""

    concrete_id: UUID
    source_ids: list[UUID] | None = Field(default=None)
    sources: list[RootSpecResponse] = Field(default_factory=list)
    ai_run_id: UUID | None = Field(default=None)
    rerank_ids: list[UUID] | None = Field(default=None)
    contexts: list[CodeContextResponse] | None = Field(default=None)
    diff: InsertionsDeletionsResponse | None = Field(default=None)


class ConcreteConstructResponse(ConcreteConstructRequestResponseBase):
    id: UUID
    original_spec_id: UUID
    language: Language
    custom_specs: list[CustomSpecChildResponse] = Field(default_factory=list)
    tokens: int | None = Field(default=None)
    extraction_id: UUID | None = Field(default=None)
    tags: list[TagResponse] = Field(default_factory=list)
    filter_results: dict[UUID, bool] = Field(default_factory=dict)


class CodeContextModel(BaseModelWithAlias):
    """Tool context standardised by sourcekon"""

    customspec_id: UUID
    tool_id: UUID
    context: str


class CustomSpecChildReportResponse(CustomSpecRequestResponseBase):
    """Custom spec for report response."""

    concrete_id: UUID
    source_ids: list[UUID] | None = Field(default=None)
    contexts: list[CodeContextModel]


class ConcreteConstructReportResponse(ConcreteConstructRequestResponseBase):
    id: UUID
    original_spec_id: UUID
    language: Language
    custom_specs: list[CustomSpecChildReportResponse] = Field(default_factory=list)


class CustomSpecResponse(CustomSpecRequestResponseBase):
    concrete_id: UUID
    scores: list[CustomSpecScoreResponse] = Field(default_factory=list)
    sources: list[RootSpecResponse] = Field(default_factory=list)
    concrete: ConcreteConstructChildResponse | None = Field(default=None)
    context: list[CustomSpecContextResponse] | None = Field(default=None)
    tags: list["CustomSpecTagResponse"] = Field(default_factory=list)


class CustomSpecTagResponse(BaseModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        description="ID of tag",
    )
    name: str = Field(
        description="Name of tag",
    )
    specs: Optional[List[CustomSpecResponse]] = Field(default=[])

    def __eq__(self, other):
        return self.name == other.name and self.id == other.id

    def __hash__(self):
        return hash((self.name, self.id))


CustomSpecBatchResponse = RootModel[dict[UUID, CustomSpecChildResponse]]


class NewVersionsResponse(BaseModelWithAlias):
    versions: list[CustomSpecResponse]


class TagListResponse(BaseModelWithAlias):
    tags: list[str] = Field(default=[], description="List of tags")


class ConstructFileListResponse(BaseModelWithAlias):
    files: dict[str, int] = Field(
        default={},
        description="Dictionary of files and the count of constructs in them",
    )


class PaginatedConstructsResponse(PaginatedBase[ConcreteConstructResponse]):
    """Data structure of an information group."""

    ...


class PaginatedSpecsResponse(PaginatedBase[CustomSpecResponse]):
    """Data structure of an information group."""

    ...


class EmbeddingRunInfo(BaseModelWithAlias):
    """Metadata about an embedding run."""

    id: UUID
    process_id: UUID | None
    status: ExecutionStatusEnum
    total_files: int
    supported_files: int
    embedded_files: int


class CodeEmbeddingStatuses(BaseModelWithAlias):
    total: int
    statuses: list[EmbeddingRunInfo]


class ExtractionPatchRequest(BaseModelWithAlias):
    num_of_constructs_detected: int | None = Field(default=None)
    num_of_constructs_extracted: int | None = Field(default=None)


class ProjectExtractionStatuses(BaseModelWithAlias):
    total: int
    statuses: dict[str, ExecutionStatusEnum]


class IncludeExcludePatternRequestResponse(BaseModelWithAlias):
    pattern: str
    match_case: bool = False
    regex: bool = False


class LocationFilterParamsRequestResponse(BaseModelWithAlias):
    include: List[IncludeExcludePatternRequestResponse] = []
    exclude: List[IncludeExcludePatternRequestResponse] = []


class ScoreTypeRequestResponse(BaseModelWithAlias):
    name: str
    min: Optional[float]
    max: Optional[float]


class ScoreAverageRequestResponse(BaseModelWithAlias):
    min: Optional[float]
    max: Optional[float]


class OriginalScoreFilterParamsRequestResponse(BaseModelWithAlias):
    types: Optional[List[ScoreTypeRequestResponse]] = None
    average: Optional[ScoreAverageRequestResponse] = None
    llms: Optional[List[str]] = None


class TagsFilterParamsRequestResponse(BaseModelWithAlias):
    values: List[TagResponse]


class RecommendationsFilterParamsRequestResponse(BaseModelWithAlias):
    exists: Optional[bool] = None
    enabled_only: bool = False
    top_only: bool = False
    original: Optional[bool] = None
    optimisation_id: Optional[UUID] = None
    solution_id: Optional[UUID] = None
    optimisation_original: Optional[bool] = False
    recommendation_ids: Optional[List[UUID]] = None


class RecommendationScoresFilterParamsRequestResponse(BaseModelWithAlias):
    types: Optional[List[ScoreTypeRequestResponse]] = None
    average: Optional[ScoreAverageRequestResponse] = None
    llms: Optional[List[str]] = None


class ValidatedFilterParamsRequestResponse(BaseModelWithAlias):
    passed: Optional[List[str]]
    has_validation: bool | None = None


class LineLengthRequestResponse(BaseModelWithAlias):
    min: Optional[float]
    max: Optional[float]


class SnippetFilterParamsRequestResponse(BaseModelWithAlias):
    ids: Optional[List[str]] = None
    lines: Optional[LineLengthRequestResponse] = None
    enabled_only: bool = False
    deprecated: bool | None = False


class ExtractionRunFilterParamsRequestResponse(BaseModelWithAlias):
    extraction_ids: List[UUID]


FILTER_TYPE_MAP: Dict[FilterTypeEnum, Type[BaseModelWithAlias]] = {
    FilterTypeEnum.location: LocationFilterParamsRequestResponse,
    FilterTypeEnum.originalScore: OriginalScoreFilterParamsRequestResponse,
    FilterTypeEnum.tags: TagsFilterParamsRequestResponse,
    FilterTypeEnum.recommendations: RecommendationsFilterParamsRequestResponse,
    FilterTypeEnum.recommendationScores: RecommendationScoresFilterParamsRequestResponse,
    FilterTypeEnum.validated: ValidatedFilterParamsRequestResponse,
    FilterTypeEnum.snippets: SnippetFilterParamsRequestResponse,
    FilterTypeEnum.extraction: ExtractionRunFilterParamsRequestResponse,
}


class GenericConstructFilterRequestResponse(BaseModelWithAlias):
    type: FilterTypeEnum
    params: Union[
        dict,
        LocationFilterParamsRequestResponse,
        OriginalScoreFilterParamsRequestResponse,
        TagsFilterParamsRequestResponse,
        RecommendationsFilterParamsRequestResponse,
        RecommendationScoresFilterParamsRequestResponse,
        ValidatedFilterParamsRequestResponse,
        SnippetFilterParamsRequestResponse,
        ExtractionRunFilterParamsRequestResponse,
    ]

    def get_params(self):
        params_class = FILTER_TYPE_MAP.get(self.type)
        return params_class(**self.params)


class RemoveConstructsRequest(BaseModelWithAlias):
    construct_ids: list[UUID]
    filter: list[GenericConstructFilterRequestResponse] | None = Field(default=None)


class ProjectInfoRequestResponseBase(BaseModelWithAlias):
    name: str
    description: str | None = Field(default=None)
    file_id: str | None = Field(default=None)
    key_id: UUID | None = Field(default=None)
    git_url: str | None = Field(default=None)
    git_hash: str | None = Field(default=None)
    git_branch: str | None = Field(default=None)
    runner_name: str | None = Field(default=None)
    setup_command: str | None = Field(default=None)
    clean_command: str | None = Field(default=None)
    compile_command: str | None = Field(default=None)
    perf_command: str | None = Field(default=None)
    unit_test_command: str | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())
    reindex_required: bool | None = Field(default=False)
    is_auto_sync_enabled: bool | None = Field(default=False)
    agent_validate_compilation: bool | None = Field(default=False)
    agent_validate_unit_test: bool | None = Field(default=False)
    agent_validate_benchmark: bool | None = Field(default=False)
    auto_publish: bool | None = Field(default=False)


class ProjectPatchRequest(ProjectInfoRequestResponseBase, MakeOptional):
    name: str = Field(default="")
    user_id: str | None = Field(default=None, description="User id of project")


class ProjectDataAvailability(BaseModelWithAlias):
    """Information about data availability for a project."""

    has_scores: bool | None = Field(default=None, description="Whether the project has construct scores")
    has_comparison_scores: bool | None = Field(
        default=None, description="Whether the project has spec comparison scores"
    )
    has_validations: bool | None = Field(default=None, description="Whether the project has spec validations")


class GitInfo(BaseModelWithAlias):
    owner: str = Field()
    host: str = Field()
    repo: str = Field()
    provider: GitProviderEnum = Field()
    protocol: str = Field()
    branch_url: str | None = Field(None)


class ProjectInfoResponse(ProjectInfoRequestResponseBase, ProjectDataAvailability):
    id: UUID
    user_id: str
    last_extraction_id: str | None = Field(default=None)
    num_of_constructs: int | None = Field(default=None)
    num_of_specs: int | None = Field(default=None)
    extraction_statuses: ProjectExtractionStatuses | None = Field(default=None)
    embedding_statuses: CodeEmbeddingStatuses | None = Field(default=None)
    filter_results: dict[str, Any] | None = Field(default=None)
    related_projects: list[UUID] | None = Field(default=None)
    git_info: GitInfo | None = Field(default=None)


class ResetProjectInfoRequest(BaseModelWithAlias):
    branch_name: str = Field(..., description="The new branch to switch to")
    base_sha: str | None = Field(default=None, description="The SHA to base from")
    reset_artemis_git_base: bool = Field(
        default=True, description="Whether to reset master branch to match the new branch"
    )


class ProjectUpdateRequest(BaseModelWithAlias):
    commit: str | None = None  # TODO: Deprecated. UI should stop using it
    branch: str | None = None  # TODO: Deprecated. UI should stop using it
    force: bool = False

    @model_validator(mode="after")
    def check_git_or_path(self) -> Self:
        """Checks whether a Git URL or a path was provided."""
        if not self.commit and not self.branch:
            raise ValueError("Either destination branch or commit hash is required")
        return self


class ProjectGitDiffRequest(BaseModelWithAlias):
    base_branch: str


class ProjectGitDiffResponse(BaseModelWithAlias):
    file_changes: dict[str, list[str]]


class ProjectFileSearchRequest(BaseModelWithAlias):
    include_globs: list[str] = Field(default_factory=list)
    exclude_globs: list[str] = Field(default_factory=list)
    key_id: UUID | None = Field(default=None)


class SingleFileResponse(BaseModelWithAlias):
    path: str
    language: Language


class SingleLanguageResponse(BaseModelWithAlias):
    language: Language
    count: int


class ProjectFileSearchResponse(BaseModelWithAlias):
    files: list[SingleFileResponse]
    languages: list[SingleLanguageResponse]


class PaginatedProjectInfoResponse(PaginatedBase[ProjectInfoResponse]):
    """Data structure of an information group."""

    ...


class PaginatedGitKeysResponse(PaginatedBase[SimpleGitKeyResponse]):
    """Data structure of an information group."""

    ...


class ProjectInfoRequest(ProjectInfoRequestResponseBase): ...


class ProjectRelatedRequest(BaseModelWithAlias):
    related_project_ids: list[UUID]


class CodeContextRequest(CodeContextModel): ...


class CustomSpecRequest(CustomSpecRequestResponseBase):
    source_ids: list[UUID] | None = Field(default=[])
    contexts: list[CodeContextModel] | None = Field(default=None)
    tags: list[str] | None = Field(default=None)
    global_tags: list[str] | None = Field(default=None)


class CustomSpecBatchRequest(CustomSpecRequest):
    concrete_id: UUID


class NewVersionsRequest(BaseModelWithAlias):
    versions: list[CustomSpecBatchRequest]


class OriginalSpecRequest(BaseModelWithAlias):
    name: str
    content: str


class CustomSpecStandaloneRequest(CustomSpecRequestResponseBase):
    concrete_id: UUID


class CustomSpecPatchRequest(CustomSpecRequest, MakeOptional): ...


class ConcreteConstructRequest(ConcreteConstructRequestResponseBase):
    original_spec_id: UUID
    custom_specs: list[CustomSpecRequest] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    global_tags: list[str] = Field(default_factory=list)
    language: str | None = None

    @model_validator(mode="before")
    @classmethod
    def validate_language(cls, values: dict[str, Any]) -> dict[str, Any]:
        """Add language if missing from input (even though required, bit hacky)"""
        if "language" not in values:
            filepath = Path(values["file"])
            if not filepath.suffix:
                # TODO: update once tools has better file resolution capabilities
                values["language"] = Language.TEXT
            else:
                try:
                    values["language"] = language_by_extension[filepath.suffix]
                except KeyError:
                    values["language"] = Language.TEXT
        return values


class ConcreteConstructBatchRequest(BaseModelWithAlias):
    constructs: list[ConcreteConstructRequest]


class IngestConstructRequest(BaseModelWithAlias):
    file_path: str
    tags: list[str]
    global_tags: list[str]
    start_line: int | None
    end_line: int | None
    context: str


class ConstructIngestRequest(BaseModelWithAlias):
    constructs: list[IngestConstructRequest]
    tool: str


class ConcreteConstructPatchRequest(ConcreteConstructRequestResponseBase, MakeOptional):
    project_id: UUID
    language: str | None = None


class ConstructCreationResponse(BaseModelWithAlias):
    constructs: list[ConcreteConstructResponse]
    new_constructs_count: int | None = Field(default=0)
    updated_constructs_count: int | None = Field(default=0)


class ConcreteConstructScopeResponse(BaseModelWithAlias):
    content: str
    original: str | None = Field(default=None)


class FilterToolMode(enum.StrEnum):
    GENERIC = "generic"
    ARTEMIS = "artemis"
    SUPPORTED = "supported"
    GIT = "git"


class ToolFilter(enum.StrEnum):
    VTUNE = "vtune"
    SPEEDSCOPE = "speedscope"
    SONARQUBE = "sonarqube"
    COVERITY = "coverity"
    PYLINT = "pylint"
    FLAKE8 = "flake8"
    OTHER = "other"
    GIT = "git"


class GitMode(enum.StrEnum):
    DIFFS = "diffs"
    USER_CODE = "user_code"


class ExtractionScope(enum.StrEnum):
    FILE = "file"
    FUNC = "function"


class ToolExtractionRun(BaseModelWithAlias):
    filter_tool_mode: FilterToolMode | None = Field(default=None)
    tool_filter: ToolFilter | None = Field(default=None)
    tool_files: list[str] | None = Field(default_factory=list)
    main_branch: str | None = Field(default=None)
    git_mode: GitMode | None = Field(default=None)
    start_date: datetime | None = Field(default=None)
    end_date: datetime | None = Field(default=None)
    contributor: str | None = Field(default=None)
    extractor_scope: ExtractionScope | None = Field(default=None)


class ExtractCreationRequest(ToolExtractionRun):
    queries: list[str] | None = Field(default_factory=list)
    include_globs: list[str] | None = Field(default_factory=list)
    exclude_globs: list[str] | None = Field(default_factory=list)
    llm_filter: str | None = Field(default=None)
    llm_type: str | None = Field(default=None)
    llm_filter_number: int | None = Field(default=None)


class FilteringRunResponse(BaseModelWithAlias):
    id: UUID
    llm_type: str | None = Field(default="")
    types: list[ValidationFilterTypeEnum]
    project_id: UUID
    process_id: UUID | None = Field(default=None)
    constructs: dict[UUID, list[UUID] | None] | None = Field(default=None)
    custom_worker_name: str | None = Field(default=None)
    run_original: bool = Field(False)
    status: ExecutionStatusEnum | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class ExtractionRunResponse(ToolExtractionRun):
    """Model for extraction run information."""

    id: UUID
    project_id: UUID
    process_id: UUID | None = Field(default=None)
    include_globs: list[str] | None = Field(default_factory=list)
    exclude_globs: list[str] | None = Field(default_factory=list)
    log_file_id: str | None = Field(default=None)
    queries: list[str] = Field(default_factory=list)
    filters: list[FilteringRunResponse] = Field(default_factory=list)
    num_of_constructs: int | None = Field(default=None)
    status: ExecutionStatusEnum | None = Field(default=None)
    llm_filter: str | None = Field(default=None)
    llm_type: str | None = Field(default=None)
    llm_filter_number: int | None = Field(default=None)
    num_of_constructs_detected: int | None = Field(default=None)
    num_of_constructs_extracted: int | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class PaginatedExtractionResponse(PaginatedBase[ExtractionRunResponse]):
    """Data structure of an information group."""

    ...


class AIApplicationRunResponseBase(BaseModelWithAlias):
    id: UUID = Field(default_factory=lambda: uuid4())
    source_spec_ids: list[UUID] = Field(default_factory=list)
    models: list[str] = Field(default_factory=list)
    method: AIApplicationMethodEnum = Field(default=AIApplicationMethodEnum.zero_shot)
    align: bool = Field(default=False)
    raw_output: bool = Field(default=False)
    prompt_id: UUID
    context: dict[str, Any] | None = Field(default=None)
    project_id: UUID = Field(...)
    process_id: UUID | None = Field(default=None)
    agent_run_id: str | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class AIApplicationRunResponse(AIApplicationRunResponseBase):
    status: ExecutionStatusEnum | None = Field(default=None)
    progress_details: dict[str, Any] | None = Field(default_factory=dict)
    prompt: str | None = Field(default=None)


class PaginatedAIApplicationRunResponse(PaginatedBase[AIApplicationRunResponse]):
    """Data structure of an information group."""

    ...


class SpecScoreUpdateEntry(BaseModelWithAlias):
    type: str
    score: float
    description: str | None = Field(default=None)
    prompt_id: UUID | None = Field(default=None)


class SpecScoreSocketEntry(BaseModelWithAlias):
    type: str
    score: float
    description: str | None = Field(default=None)
    prompt_id: str | None


class SpecScoreUpdateRequest(BaseModelWithAlias):
    scores: list[SpecScoreUpdateEntry]
    llm_type: str


class BatchSpecScoreUpdateEntry(SpecScoreUpdateEntry):
    spec_id: UUID
    refspec_id: UUID | None = Field(default=None)


class BatchSpecScoreUpdateRequest(BaseModelWithAlias):
    scores: list[BatchSpecScoreUpdateEntry]
    llm_type: str


class RerankRunResponse(BaseModelWithAlias):
    id: UUID
    spec_ids: list[UUID] = Field(default_factory=list)
    models: list[str] = Field(default_factory=list)
    project_id: UUID
    process_id: UUID | None = Field(default=None)
    agent_run_id: str | None = Field(default=None)
    metric_prompts_ids: list[UUID] = Field(default_factory=list)
    progress_details: dict[str, Any] | None = Field(default_factory=dict)
    status: ExecutionStatusEnum | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class PaginatedRerankRunResponse(PaginatedBase[RerankRunResponse]):
    """Data structure of an information group."""

    ...


class SpecScoreResponse(BaseModelWithAlias):
    # NOTE: this is not paginated because the list output is temporary
    message: str
    docs: list[RerankRunResponse]


class PaginatedFilteringResponse(PaginatedBase[FilteringRunResponse]):
    """Data structure of an information group."""

    ...


class FilteringResultRequest(BaseModelWithAlias):
    project_id: UUID
    construct_id: UUID | None = Field(default=None)
    spec_id: UUID | None = Field(default=None)
    type: ValidationFilterTypeEnum
    passed: bool
    logs: str | None = Field(default=None)
    cpu: float | None = Field(default=None)
    memory: float | None = Field(default=None)
    runtime: float | None = Field(default=None)


class FilteringResultResponse(BaseModelWithAlias):
    filtering_id: UUID
    type: ValidationFilterTypeEnum
    passed: bool
    logs: str | None = Field(default=None)
    cpu: float | None = Field(default=None)
    cpu_time: float | None = Field(default=None)
    memory: float | None = Field(default=None)
    runtime: float | None = Field(default=None)


class PaginatedFilteringResultResponse(PaginatedBase[FilteringResultResponse]):
    """Data structure of an information group."""

    ...


class CodeLogRepairRequest(BaseModelWithAlias):
    """Data structure of an information group."""

    code: str
    log: str


class CodeLogRepairResponse(BaseModelWithAlias):
    code: str = Field(description="Repaired code")
    explanation: str = Field(description="The explanation of the fix")


class CodeAIMultiOptimiseRequest(BaseModelWithAlias):
    """Data structure of an information group."""

    project_id: UUID
    filter: list[GenericConstructFilterRequestResponse] | None = Field(default=None)
    spec_ids: list[UUID]
    method: AIApplicationMethodEnum = Field(default=AIApplicationMethodEnum.zero_shot)
    models: list[str]
    prompt_id: UUID
    align: bool = Field(default=False)
    raw_output: bool = Field(default=False)
    contexts: list[str] | None = None


class CodeAIMultiOptimiseCostRequest(BaseModelWithAlias):
    spec_ids: list[UUID]
    project_id: UUID
    filter: list[GenericConstructFilterRequestResponse] | None = Field(default=None)
    models: list[str]


class CodeAIMultiOptimiseResponse(BaseModelWithAlias):
    # NOTE: this is not paginated because the list output is temporary
    message: str
    docs: list[AIApplicationRunResponse]


class SpecsGetRequest(BaseModelWithAlias):
    spec_ids: list[UUID]


class SpecsDeleteResponse(BaseModelWithAlias):
    """Response model for spec deletion operations."""

    deleted: int = Field(description="Number of specs successfully deleted")
    not_deleted: int = Field(description="Number of specs that could not be deleted")
    deleted_spec_ids: List[str] = Field(description="List of deleted spec IDs")
    not_deleted_spec_ids: List[str] = Field(description="List of spec IDs that could not be deleted")
    message: str = Field(description="Detailed message about the deletion operation")


class SpecScoreInfoRequest(BaseModelWithAlias):
    """Request model for scores of code specifications."""

    spec_ids: list[UUID] = Field(description="The unique IDs of the code specifications to be scored.")
    models: list[str] = Field(description="The names of LLM models used for scoring.")
    prompt_ids: list[UUID] = Field(description="The unique IDs of the prompts used to obtain scores.")
    subtasks: list[str] | None = Field(
        default=None, description="Filter scores by subtask names. If empty, return only scores with non-null subtasks."
    )


class CodeTaskModelScoreResponse(BaseModelWithAlias):
    name: str
    score: float
    description: str
    prompt_id: UUID | None


class CodeTaskScoresResponse(BaseModelWithAlias):
    """
    Data structure of a rerank score, for a particular task & recommendation
    """

    task: str
    aggregated_score: float | None = None
    models: list[CodeTaskModelScoreResponse]
    summary: str | None = None


class CodeSpecScoresResponse(BaseModelWithAlias):
    """
    Data structure of a rerank score, for a particular recommendation
    """

    spec_id: str
    source_id: str | None = None
    aggregated_score: float | None = None
    scores: list[CodeTaskScoresResponse]


class SpecScoreInfoResponse(RootModel[dict[UUID, CodeSpecScoresResponse]]):
    root: dict[UUID, CodeSpecScoresResponse]


class SpecScoreRequest(SpecScoreInfoRequest):
    """Request model for scores of code specifications."""

    project_id: UUID = Field(description="The unique ID of the project.")
    method: RerankMethodEnum | None = Field(default=None)
    filter: list[GenericConstructFilterRequestResponse] | None = Field(
        default=None, description="The filters for the spec ids."
    )


class GaRequest(BaseModelWithAlias):
    # inputs
    spec_id: UUID
    models: list[str]
    contexts: list[str] = []

    # context
    use_siblings: bool = True
    use_search: bool = True

    # genetic algo
    population_size: int = 3
    generation_size: int = 3
    objective_prompt_id: UUID

    # scoring
    llm_code_scoring: bool = True
    llm_log_scoring: bool = True
    metric_prompt_ids: list[UUID]

    # execution
    custom_utility_worker_name: str | None = None
    custom_filter_worker_name: str | None = None
    run_compilation: bool = True
    run_unit_tests: bool = True
    run_benchmark: bool = False
    custom_command: str | None = None
    custom_worker_user_id: str | None = None

    @field_validator("population_size", "generation_size")
    @classmethod
    def validate_size_limits(cls, value: int) -> int:
        if value > 20:
            raise ValueError(f"Size cannot exceed 20 (got {value})")
        return value


class SpecFilterRequest(BaseModelWithAlias):
    """Data structure of an information group."""

    spec_ids: list[UUID]


class CodeCostRequest(BaseModelWithAlias):
    """Data structure of an information group."""

    project_id: UUID
    spec_ids: list[UUID]
    filter: list[GenericConstructFilterRequestResponse] | None = Field(default=None)


class CodeCostResponse(BaseModelWithAlias):
    """Data structure of an information group."""

    cost: float
    per_model_cost: dict[str, float]


class PRCreateResponse(BaseModelWithAlias):
    pull_request_url: str | None = Field(default=None)


class StatusRequestResponse(BaseModelWithAlias):
    """Data structure of an information group."""

    status: ExecutionStatusEnum | None = Field(default=None)


class HardwareInfoRequestResponseBase(BaseModelWithAlias):
    name: str | None = Field(default=None)
    cloud_type: str | None = Field(default=None)
    cloud_region: str | None = Field(default=None)
    cloud_size: str | None = Field(default=None)
    cpu_name: str
    cpu_number: int
    gpu_name: str | None = Field(default=None)
    gpu_number: int | None = Field(default=None)
    ram: float
    cost: float | None = Field(default=None)


class HardwareInfoRequest(HardwareInfoRequestResponseBase): ...


class HardwareInfoResponse(HardwareInfoRequestResponseBase):
    id: UUID


class SolutionFileUpdate(BaseModelWithAlias):
    """Data structure of an information group."""

    file_id: str


class OptimisationConstructModel(BaseModelWithAlias):
    construct_id: UUID
    spec_ids: list[UUID] = Field(default_factory=list)


class OptimisationRunResponse(BaseModelWithAlias):
    id: UUID
    name: str | None = Field(default=None)
    project_id: UUID
    user_id: str
    process_id: UUID | None = Field(default=None)
    constructs: list[OptimisationConstructModel] | None = Field(default_factory=list)
    evaluation_repetitions: int = Field(default=10)
    hardware_id: UUID | None = Field(default=None)
    hardware: HardwareInfoResponse | None = Field(default=None)
    custom_worker_name: str | None = Field(default=None)
    status: ExecutionStatusEnum | None = Field(default=None)
    num_of_solutions: int | None = Field(default=None)
    best_solutions: dict[str, Any] | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class OptimisationConstructRequest(BaseModelWithAlias):
    """Data structure of an information group."""

    construct_id: UUID
    spec_ids: list[UUID] = Field(default_factory=list)


class PaginatedOptimisationRequestResponse(PaginatedBase[OptimisationRunResponse]):
    """Data structure of an information group."""

    ...


class FullSolutionInfoResponse(FullSolutionInfoRequestResponseBase):
    id: UUID = Field(default_factory=lambda: uuid4())
    process_id: UUID | None = Field(default=None)
    optimisation_id: UUID | None = Field(default=None)
    project_id: UUID
    specs: list[SolutionSpecResponse] | None = Field(default=None)
    results: SolutionResultsResponse | None = Field(default=None)
    optimisation: OptimisationRunResponse | None = Field(default=None)
    additions: int | None = Field(default=None)
    deletions: int | None = Field(default=None)
    files_changed: int | None = Field(default=None)

    @classmethod
    def from_request(cls, request: FullSolutionInfoRequest):
        response = cls(
            **{
                **request.model_dump(
                    exclude={"results"},
                ),
            }
        )
        if request.results:
            response.results = SolutionResultsResponse.from_results(request.results)
        return response


class PaginatedSolutionResponse(PaginatedBase[FullSolutionInfoResponse]): ...


class SolutionIdResponse(BaseModelWithAlias):
    """Data structure for solution id."""

    solution_id: UUID | None


class SolutionResultsRequest(BaseModelWithAlias):
    """Request model for solution results."""

    log_file_id: str | None = Field(default=None)
    status: SolutionStatusEnum | None = Field(default=SolutionStatusEnum.pending)
    results: SolutionResultsResponseBase | None = Field(default=None)


# -------------------------------------------------------------------------------


class ConfidenceIntervalsResponse(BaseModelWithAlias):
    before: List[float]
    after: List[float]


class SolutionStatsResponse(BaseModelWithAlias):
    mean: float
    first_quartile: float
    median: float
    third_quartile: float
    min: float
    max: float
    count: int
    std_dev: float


class ComparisonStatsResponse(BaseModelWithAlias):
    before: SolutionStatsResponse
    after: SolutionStatsResponse


class SolutionAnalysisResultsResponseBase(BaseModelWithAlias):
    statistical_significance: bool
    statistical_significance_label: str
    required_sample_size: Optional[float] = None
    test_used: str
    effect_size: float
    effect_size_label: str
    effect_direction: str
    power: float
    confidence_intervals: ConfidenceIntervalsResponse
    statistics: ComparisonStatsResponse
    labels: List[str]
    # list of values of anomalies
    outliers: List[float]


class SolutionAnalysisResultsResponse(BaseModelWithAlias):
    memory: SolutionAnalysisResultsResponseBase | None = Field(default=None)
    cpu: SolutionAnalysisResultsResponseBase | None = Field(default=None)
    runtime: SolutionAnalysisResultsResponseBase | None = Field(default=None)
    green_metrics: EnvironmentalImpactResponse | None = Field(default=None)


class BestSolutionsResponse(BaseModelWithAlias):
    best_solutions: dict[str, Any]


class ConstructExplainResponse(BaseModelWithAlias):
    """Explanation of a concrete construct."""

    explanation: str


class ConstructSummariseResponse(BaseModelWithAlias):
    """Summary of a concrete construct and all associated suggestions."""

    summary: str


class SolutionSummariseResponse(BaseModelWithAlias):
    """Summary of a concrete construct and all associated suggestions."""

    summary: str
    title: str | None = Field(default=None)


class ConstructSpecExplainResponse(BaseModelWithAlias):
    """Explanation of the diff between a suggestion and the original construct."""

    explanation: str


class SummarisationRunResponseBase(BaseModelWithAlias):
    id: UUID = Field(default_factory=lambda: uuid4())
    project_id: UUID = Field(...)
    concrete_id: UUID = Field(...)
    spec_names: list[str] = Field(default_factory=list)
    process_id: UUID | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class SummarisationRunResponse(SummarisationRunResponseBase):
    status: ExecutionStatusEnum | None = Field(default=None)


class PaginatedSummarisationRunResponse(PaginatedBase[SummarisationRunResponse]):
    """Data structure of an information group."""

    ...


class TaggingRequest(BaseModelWithAlias):
    tag_ids: list[UUID]


class UntaggingRequest(BaseModelWithAlias):
    tag_id: UUID


class ConstructTaggingRequest(TaggingRequest):
    construct_id: UUID


class ConstructUntaggingRequest(UntaggingRequest):
    construct_id: UUID


class SpecTaggingRequest(TaggingRequest):
    spec_id: UUID


class SpecUntaggingRequest(UntaggingRequest):
    spec_id: UUID


class ConcreteConstructResponseBase(BaseModelWithAlias):
    """Schema for information about a block of code extracted from the original codebase. This does not store the
    contents of that block. Instead, it stores the location as specified by the file, lineno, and end_lineno fields, as
    well as a reference to the original contents of the block is stored in the original_spec_id field.
    """

    original_spec_id: UUID = Field(
        description="Unique identifier for the specification of the original code contained in the given construct.",
    )
    lineno: int = Field(
        description="The starting line number of the code block in the file.",
    )
    end_lineno: int = Field(description="The ending line number of the code block in the file.")
    file: str = Field(description="The path of the file where the code block is located.")
    enabled: bool = Field(
        default=True,
        description="Indicates whether the code construct is enabled on the UI. Defaults to True.",
    )
    language: str = Field(description="Language of construct")
    deprecation_id: Optional[UUID] = Field(
        default=None,
        description="Information about deprecation of this snippet",
    )


class ConcreteConstructTagResponse(BaseModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        description="ID of tag",
    )
    name: str = Field(
        description="Name of tag",
    )
    constructs: Optional[List[ConcreteConstructResponse]] = Field(default=[])

    def __eq__(self, other):
        return self.name == other.name and self.id == other.id

    def __hash__(self):
        return hash((self.name, self.id))


class PaginatedConcreteConstructTagsResponse(PaginatedBase[ConcreteConstructTagResponse]):
    """Data structure of ConcreteConstructTagsResponse."""


class PaginatedCustomSpecTagsResponse(PaginatedBase[CustomSpecTagResponse]):
    """Data structure of CustomSpecTagsResponse."""


class ToolContextResponse(BaseModelWithAlias):
    name: str
    context: str


class ToolsContextResponse(BaseModelWithAlias):
    tools: list[ToolContextResponse]


class PaginatedConstructFilterRequest(PaginationParams):
    sort_by: Optional[str] = None
    descending: Optional[bool] = False
    filters: list[GenericConstructFilterRequestResponse] | None = Field(default=None)


class ProjectRepoComparisonResponse(BaseModelWithAlias):
    commits_behind: int
