from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import Field

from falcon_models.api.base_data_types import BaseModelWithAlias, PaginatedBase
from falcon_models.enums.code import FileOperationEnum
from falcon_models.enums.general import ExecutionStatusEnum


class SpecGenerationInput(BaseModelWithAlias):
    task: str


class SpecificationList(BaseModelWithAlias):
    current: list[str]
    proposed: list[str]


class ActionPlanRequest(BaseModelWithAlias):
    specifications: SpecificationList
    parent_pair_coder_run_id: UUID | None = None


class PairCoderType(str, Enum):
    SPECS = "specs"
    ACTION_PLAN = "action_plan"
    GENERATE_CHANGES = "generate_changes"
    ACTION_PLAN_UNIFIED = "action_plan_unified"
    GENERATE_CHANGES_UNIFIED = "generate_changes_unified"


class SpecificationOuputRequest(BaseModelWithAlias):
    current: list[str]
    proposed: list[str]


class ActionPlanStep(BaseModelWithAlias):
    file_path: str
    changes: list[str]


class ActionPlanList(BaseModelWithAlias):
    file_changes: list[ActionPlanStep] = []


class FileChange(BaseModelWithAlias):
    proposed: str
    file_operation: FileOperationEnum = FileOperationEnum.EDIT


class GeneratedChanges(BaseModelWithAlias):
    refactored_files: dict[str, FileChange] = Field(description="mapping of file path to proposed changes")
    output_message: str


class RefactoredFiles(BaseModelWithAlias):
    refactored_files: dict[str, FileChange]


class PairCoderPatchRequest(BaseModelWithAlias):
    thread_id: str | None = None
    checkpoint_id: str | None = None
    checkpoint_ns: str | None = None
    output: SpecificationOuputRequest | ActionPlanList | GeneratedChanges


class CoderRequest(BaseModelWithAlias):
    parent_pair_coder_run_id: UUID | None = None
    action_plan: ActionPlanList


class PairCoderRun(BaseModelWithAlias):

    id: UUID
    parent_id: UUID | None = None
    project_id: UUID
    process_id: UUID | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    model_type: str
    task: str | None = None
    thread_id: str | None = None
    checkpoint_id: str | None = None
    checkpoint_ns: str | None = None
    stage: str


class PairCoderRequestResponse(PairCoderRun):
    """
    Data structure of pair coder run info
    """

    status: ExecutionStatusEnum | None = None
    progress_details: str | None = None
    output: ActionPlanList | GeneratedChanges | SpecificationList | None = None
    input: ActionPlanList | GeneratedChanges | SpecificationList | None = None


class PaginatedPairCoderResponse(PaginatedBase[PairCoderRequestResponse]):
    """
    Data structure for paginated pair coder runs
    """

    ...


class PairCoderRequestChainResponse(BaseModelWithAlias):
    chain: list[PairCoderRequestResponse]


class PairCoderResponseBase(BaseModelWithAlias):
    process_id: str
    pair_coder_run_id: UUID


class SpecificationResponse(PairCoderResponseBase):
    result: SpecificationList | None = None


class ActionPlanResponse(PairCoderResponseBase):
    result: ActionPlanList | None = None


class GenerateChangesResponse(PairCoderResponseBase):
    result: GeneratedChanges | None = None


class SaveChangesResponse(BaseModelWithAlias):
    changeset_id: UUID | None = None
    version_sha: str | None = None
    spec_ids: list[UUID] | None = None
