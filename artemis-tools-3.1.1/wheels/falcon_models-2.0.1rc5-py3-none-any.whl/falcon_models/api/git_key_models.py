from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import UUID, uuid4

from pydantic import Field

from falcon_models.api.base_data_types import BaseModelWithAlias, PaginatedBase
from falcon_models.enums.git import GitAuthTypeEnum


class GitSingleBranchInfoRequestResponse(BaseModelWithAlias):
    name: str
    commit: str
    is_default: bool = False


class GitAuthPatchRequest(BaseModelWithAlias):
    name: str | None = None
    params: dict[str, Any] | None = None
    default: bool = False


class GitAuthParamsResponse(BaseModelWithAlias):
    name: str
    type: GitAuthTypeEnum
    params: dict[str, Any]
    default: bool = False


class GitAuthKeysModel(BaseModelWithAlias):

    id: UUID = Field(default_factory=lambda: uuid4())
    name: str
    user_id: str
    type: GitAuthTypeEnum
    default: bool = False
    created_at: datetime | None = datetime.now()
    updated_at: datetime | None = datetime.now()


class SimpleGitKeyResponse(GitAuthKeysModel): ...


class GitInfoRequest(BaseModelWithAlias):
    git_url: str
    key_id: UUID | None = None


class GitBranchInfoResponse(BaseModelWithAlias):
    main_branch: str
    branches: list[GitSingleBranchInfoRequestResponse] = []


class GitProvider(str, Enum):
    GITHUB = "github"
    BITBUCKET = "bitbucket"
    SSH = "ssh"


class BitbucketCredentialValidation(BaseModelWithAlias):
    password: Optional[str] = None
    username: Optional[str] = None


class GithubCredentialValidation(BaseModelWithAlias):
    token: Optional[str] = None


class SSHCredentialValidation(BaseModelWithAlias):
    private_key: str
    password: Optional[str] = None


class GitCredentialValidationRequest(BitbucketCredentialValidation, GithubCredentialValidation):
    provider: GitProvider
    api_url: Optional[str] = None


class SSHKeyValidationRequest(BaseModelWithAlias):
    private_key: str
    password: Optional[str] = None


class GitCredentialValidationResponse(BaseModelWithAlias):
    is_valid: bool


class GitUserLinesResponse(BaseModelWithAlias):
    tool: str = Field(description="Code quality analysis tool executed.")
    output_file_path: str = Field(description="Path of the file that contains the output of the tool execution.")
    messages: list = Field(description="Output of the git tool execution.")


class GitFilter(BaseModelWithAlias):
    user_email: str | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    include: list | None = None
    exclude: list | None = None


class ContributorStatsResponse(BaseModelWithAlias):
    """Statistics for a single contributor."""

    email: str = Field(..., description="Contributor's email address")
    name: str = Field(..., description="Contributor's name")
    total_lines: int = Field(..., description="Total lines changed by the contributor")
    total_commits: int = Field(..., description="Total number of commits by the contributor")
    percentage: float = Field(..., description="Percentage of total contribution")
    first_commit: datetime = Field(..., description="Date of first commit")
    last_commit: datetime = Field(..., description="Date of last commit")


class PaginatedContributorStatsResponse(PaginatedBase[ContributorStatsResponse]):
    """Paginated Output containing contributor statistics."""


class GitHubAppKeyRequest(BaseModelWithAlias):
    """Request model for creating a GitHub App key."""

    installation_id: int = Field(..., description="GitHub App installation ID")
    account_login: Optional[str] = Field(None, description="GitHub account login name")


class GitHubAppKeyResponse(BaseModelWithAlias):
    """Response model for GitHub App key creation."""

    key_id: UUID = Field(..., description="The ID of the created GitAuthKey")
    name: str = Field(..., description="Name of the created key")
    created: bool = Field(True, description="Whether the key was successfully created")


class GitHubOAuthKeyRequest(BaseModelWithAlias):
    """Request model for creating a GitHub OAuth key."""

    artemis_user_id: str = Field(..., description="Artemis user ID")
    github_user_id: str = Field(..., description="GitHub user ID")
    github_username: str = Field(..., description="GitHub username")
    oauth_token_id: str = Field(..., description="OAuth token ID stored in GitHub connector")


class GitHubOAuthKeyResponse(BaseModelWithAlias):
    """Response model for GitHub OAuth key creation."""

    key_id: UUID = Field(..., description="The ID of the created GitAuthKey")
    name: str = Field(..., description="Name of the created key")
    created: bool = Field(True, description="Whether the key was successfully created")


class RepositoryResponse(BaseModelWithAlias):
    """Repository information model for API responses."""

    id: int = Field(..., description="Repository ID")
    name: str = Field(..., description="Repository name")
    full_name: str = Field(..., description="Full repository name including owner")
    private: bool = Field(..., description="Whether the repository is private")
    description: Optional[str] = Field(None, description="Repository description")
    url: str = Field(..., description="Repository URL")
    clone_url: str = Field(..., description="Clone URL for the repository")
    ssh_url: str = Field(..., description="SSH URL for the repository")
    default_branch: str = Field("main", description="Default branch of the repository")
    language: Optional[str] = Field(None, description="Primary language of the repository")
    permissions: Optional[dict] = Field(None, description="User permissions for the repository")


class GitKeyRepositoriesResponse(BaseModelWithAlias):
    """Response model for listing repositories accessible with a git key."""

    repositories: list[RepositoryResponse] = Field(..., description="List of repositories")
    total_count: int = Field(..., description="Total number of repositories")
