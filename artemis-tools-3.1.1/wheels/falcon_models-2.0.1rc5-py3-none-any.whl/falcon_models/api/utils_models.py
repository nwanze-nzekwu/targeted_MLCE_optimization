from datetime import datetime
from enum import Enum
from typing import Any, Dict, Literal, Optional
from uuid import UUID, uuid4

from pydantic import Field

from falcon_models.api.base_data_types import BaseModelWithAlias
from falcon_models.api.code_models import HardwareInfoRequestResponseBase
from falcon_models.enums.general import ExecutionStatusEnum, ExecutorTypeEnum


class LogEntryBaseRequestResponse(BaseModelWithAlias):
    id: UUID = Field(
        default_factory=lambda: uuid4(),
        description="ID of process",
    )
    message: str = Field(
        description="Log Message",
    )
    level: str = Field(
        description="Log Level",
    )
    timestamp: datetime = Field(
        description="Timestamp of log",
    )
    log_group_id: UUID = Field(
        description="ID of log group",
    )


class ProcessStatusResponse(BaseModelWithAlias):
    identifier: UUID = Field(description="ID of process", alias="id")
    log_id: Optional[UUID] = Field(
        None,
        description="Log ID of process",
    )
    type: str = Field(
        description="Type of process",
    )
    executor: ExecutorTypeEnum = Field(
        default=ExecutorTypeEnum.loki,
        description="Executor of process",
    )
    progress: int = Field(
        0,
        description="Progress of process",
    )
    progress_details: Optional[Dict] = Field(default={})
    status: ExecutionStatusEnum = Field(
        default=ExecutionStatusEnum.created,
        description="Status of process",
    )


class ProcessCreationRequest(BaseModelWithAlias):
    """Request to create a generic process."""

    execution_method: Literal["loki", "celery"] = Field("loki", description="Method of execution")
    task_type: str = Field(..., description="Type of task/worker to execute")
    task_params: Dict[str, Any] = Field(..., description="Parameters to pass to the task/worker")
    auto_start: bool = Field(default=True, description="Whether to automatically start the process")
    queue: str | None = Field(default=None, description="Queue to use")


class ProcessCreationResponse(BaseModelWithAlias):
    """Response after creating a process."""

    process_id: UUID = Field(..., description="ID of the created process")
    task_type: str = Field(..., description="Type of task that was created")
    status: ExecutionStatusEnum = Field(
        default=ExecutionStatusEnum.created, description="Initial status of the process"
    )


class LogGroupResponse(BaseModelWithAlias):
    logs: list[LogEntryBaseRequestResponse]


class LogGroupInfoResponse(BaseModelWithAlias):
    id: UUID


class LogAdditionRequest(BaseModelWithAlias):
    message: str
    level: str
    timestamp: datetime


class HardwareListResponse(BaseModelWithAlias):
    hardware: list[HardwareInfoRequestResponseBase] = []


class RunnerStatusEnum(str, Enum):
    """Status of a runner group."""

    online = "online"
    offline = "offline"


class RunnerInfo(BaseModelWithAlias):
    """Information about a group of runners with the same name."""

    name: str = Field(..., description="Name of the runner group")
    user_id: Optional[str] = Field(None, description="User ID associated with this runner group", alias="userId")
    status: RunnerStatusEnum = Field(..., description="Current status of the runner group (online/offline)")
    num_registered: int = Field(
        ..., description="Total number of registered workers in this runner group", alias="numRegistered"
    )
    num_online: int = Field(..., description="Number of online workers in this runner group", alias="numOnline")


class RunnersListResponse(BaseModelWithAlias):
    """Response containing list of available runners grouped by name."""

    runners: list[RunnerInfo] = Field(default_factory=list, description="List of available runner groups")
