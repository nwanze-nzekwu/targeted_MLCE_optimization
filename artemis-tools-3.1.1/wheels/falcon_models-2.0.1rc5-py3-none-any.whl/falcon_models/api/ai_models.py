from datetime import datetime
from enum import Enum, StrEnum
from typing import Any, Self
from uuid import UUID

from pydantic import Field, model_validator
from vision_models.service.llm import Capability

from falcon_models.api.base_data_types import BaseModelWithAlias, PaginatedBase
from falcon_models.api.llm import LLMDetailsResponse


class AIInferenceTask(Enum):
    """
    Enum class for AI inference type
    """

    CODE_GENERATION = "code-generation", {Capability.CODING_PROFICIENT}
    SCORING = "scoring", {Capability.STRUCTURED_OUTPUT}
    PAIR_CODER = "pair-coder", {
        Capability.STRUCTURED_OUTPUT,
        Capability.TOOL_CALLING,
        Capability.CODING_PROFICIENT,
    }
    ANALYSIS = "analysis", {Capability.STRUCTURED_OUTPUT}
    CHAT = "chat", {Capability.STRUCTURED_OUTPUT, Capability.STREAMING_OUTPUT}

    _value_: str
    capabilities: set[Capability]

    def __new__(cls, value, capabilities):
        obj = object.__new__(cls)
        obj._value_ = value
        obj.capabilities = capabilities
        return obj

    def has_capability(self, capability: Capability) -> bool:
        """Check if this task requires a specific capability"""
        return capability in self.capabilities


class AIInferenceSubtask(StrEnum):
    # NOTE: this is a subtask for SCORING

    comparison = "comparison"
    difference = "difference"


class ModelListResponse(BaseModelWithAlias):
    """Response model for a list of models"""

    models: list[LLMDetailsResponse]


class SimplePromptListResponse(BaseModelWithAlias):
    """Response model for a list of simple prompts"""

    prompts: list[dict[str, Any]]


class PromptRequestResponseBase(BaseModelWithAlias):
    name: str | None = Field(default=None)
    body: str
    task: AIInferenceTask
    subtask: str | None = Field(default=None)
    model: str | None = Field(default=None)
    source_prompt_id: UUID | None = Field(default=None)


class ProjectPromptResponse(PromptRequestResponseBase):
    """Response model for a prompt"""

    id: UUID
    created_at: datetime
    last_used_at: datetime | None = None


class PromptListResponse(BaseModelWithAlias):
    """Response model for a list of prompts"""

    prompts: list[ProjectPromptResponse]


class PaginatedPromptResponse(PaginatedBase[ProjectPromptResponse]): ...


class ProjectPromptRequest(PromptRequestResponseBase):
    """Request model for a project prompt"""

    ...


class PatchProjectPromptRequest(BaseModelWithAlias):
    """Request model for patching a project prompt"""

    body: str | None = Field(description="Prompt body", default=None)
    name: str | None = Field(description="Prompt name", default=None)

    @model_validator(mode="after")
    def check_at_least_one_field(self):
        if self.body is None and self.name is None:
            raise ValueError("At least one of 'body' or 'name' must be provided")
        return self
