from datetime import datetime
from typing import List, Optional

from pydantic import Field

from falcon_models.service.base_data_types import BaseModelWithAlias, PaginatedBase, PaginationParams

__all__ = [
    "UserSettingsRequest",
    "UserSettingsResponse",
    "UserSettingsPatchRequest",
    "PaginatedUserSettingsResponse",
    "UserSettingsSearchRequest",
]


class UserSettingsRequest(BaseModelWithAlias):
    """
    Request model for creating user settings
    """

    user_id: str = Field(description="User ID for settings")
    balance_limit: Optional[float] = Field(default=None, description="Balance limit for user")
    agent_turn_limit: Optional[int] = Field(default=None, description="Agent turn limit for user")


class UserSettingsResponse(BaseModelWithAlias):
    """
    Response model for user settings
    """

    user_id: str = Field(description="User ID for settings")
    balance_limit: Optional[float] = Field(description="Balance limit for user")
    agent_turn_limit: Optional[int] = Field(description="Agent turn limit for user")
    created_at: datetime = Field(description="Timestamp of creation")
    updated_at: datetime = Field(description="Timestamp of last update")


class UserSettingsPatchRequest(BaseModelWithAlias):
    """
    Request model for updating user settings (PUT/PATCH - partial or full update)
    """

    balance_limit: Optional[float] = Field(default=None, description="Balance limit for user")
    agent_turn_limit: Optional[int] = Field(default=None, description="Agent turn limit for user")


class PaginatedUserSettingsResponse(PaginatedBase[UserSettingsResponse]):
    """
    Paginated response for user settings
    """


class UserSettingsSearchRequest(BaseModelWithAlias):
    """
    Request model for searching user settings
    """

    user_ids: Optional[List[str]] = Field(default=None, description="List of user IDs to search for")
