from falcon_models.api.base_data_types import BaseModelWithAlias


class AgreggatedScoreResponse(BaseModelWithAlias):
    name: str
    score: float
    occurences: int


class AggregatedStatsResponse(BaseModelWithAlias):
    metrics: list[AgreggatedScoreResponse]
