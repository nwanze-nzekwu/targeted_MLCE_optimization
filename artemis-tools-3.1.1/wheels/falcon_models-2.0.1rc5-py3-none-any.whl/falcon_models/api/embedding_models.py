from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import Field
from vision_models import EmbeddingPresetEnum

from falcon_models.api.base_data_types import BaseModelWithAlias, PaginatedBase
from falcon_models.enums.general import ExecutionStatusEnum


class EmbeddingCreationRequest(BaseModelWithAlias):
    embedding_preset: EmbeddingPresetEnum
    include_globs: list[str] = Field(default_factory=list)
    exclude_globs: list[str] = Field(default_factory=list)


class EmbeddingCreationResponse(BaseModelWithAlias):
    process_id: UUID


class EmbeddingRunResponse(BaseModelWithAlias):
    id: UUID
    preset_enum: str
    project_id: UUID
    process_id: UUID | None = Field(default=None)
    include_globs: list[str]
    exclude_globs: list[str]
    total_files: int = Field(default=0)
    supported_files: int = Field(default=0)
    embedded_files: int = Field(default=0)
    status: ExecutionStatusEnum | None = Field(default=None)
    progress_details: dict[str, Any] | None = Field(default=None)
    created_at: datetime | None = Field(default_factory=lambda: datetime.now())
    updated_at: datetime | None = Field(default_factory=lambda: datetime.now())


class PaginatedEmbeddingResponse(PaginatedBase[EmbeddingRunResponse]):
    """
    Data structure of an information group
    """

    ...


class EmbeddingPatchRequest(BaseModelWithAlias):
    totalFiles: int | None = Field(default=None)
    supportedFiles: int | None = Field(default=None)
    embeddedFiles: int | None = Field(default=None)
