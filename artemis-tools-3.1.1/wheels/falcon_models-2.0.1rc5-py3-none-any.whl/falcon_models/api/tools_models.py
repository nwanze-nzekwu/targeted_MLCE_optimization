from falcon_models.api.base_data_types import BaseModelWithAlias


class ToolCreationRequestResponseBase(BaseModelWithAlias):
    tool_name: str


class ToolCreationResponse(ToolCreationRequestResponseBase):
    tool_id: str


class ToolCreationRequest(ToolCreationRequestResponseBase): ...
