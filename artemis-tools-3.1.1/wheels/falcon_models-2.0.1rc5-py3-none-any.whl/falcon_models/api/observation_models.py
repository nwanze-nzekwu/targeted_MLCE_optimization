"""
API models for the observation system
"""

from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import Field, field_validator

from falcon_models.api.base_data_types import BaseModelWithAlias, PaginatedBase, PaginationParams
from falcon_models.enums.general import ExecutionStatusEnum
from falcon_models.service.observations import ObservationSourceType, RuleSource


# Rule models
class RuleCreate(BaseModelWithAlias):
    """Model for creating a rule"""

    project_id: UUID
    enabled: bool = True
    title: str
    description: str
    importance: float = Field(ge=0, le=10, description="Importance score (0-10)")
    tags: list[str] = Field(default_factory=list, description="Tags for categorizing rules")
    source: RuleSource
    source_file: str | None = None


class RuleUpdate(BaseModelWithAlias):
    """Model for updating a rule"""

    enabled: bool | None = None
    title: str | None = None
    description: str | None = None
    importance: float | None = Field(None, ge=0, le=10)
    tags: list[str] | None = None
    source: RuleSource | None = None
    source_file: str | None = None


class RuleResponse(BaseModelWithAlias):
    """Model for rule response"""

    id: UUID
    project_id: UUID
    enabled: bool
    title: str
    description: str
    importance: float
    tags: list[str]
    source: RuleSource
    source_file: str | None
    created_at: datetime
    updated_at: datetime


class PaginatedRuleResponse(PaginatedBase[RuleResponse]):
    """Paginated response for rules"""

    pass


# Filter enums
class IssueFilterType(StrEnum):
    """Types of filters available for issues - matches column names"""

    # Issue columns
    SEVERITY = "severity"
    FIX_DIFFICULTY_SCORE = "fix_difficulty_score"
    TITLE = "title"
    MODEL_TYPE = "model_type"
    RULE_ID = "rule_id"
    AUDIT_RUN_ID = "audit_run_id"
    # Observation columns (when joined)
    FILE_NAME = "file_name"
    START_LINE = "start_line"
    END_LINE = "end_line"
    TAGS = "tags"


class IssueSortField(StrEnum):
    """Sort fields for issues"""

    SEVERITY = "severity"
    FIX_DIFFICULTY = "fix_difficulty"
    CREATED_AT = "created_at"
    FILE_NAME = "file_name"
    TITLE = "title"
    START_LINE = "start_line"
    RULE_ID = "rule_id"


class IssueGroupByField(StrEnum):
    """Sort fields for issues"""

    FILE_NAME = "file_name"
    RULE_ID = "rule_id"


# Filter parameter models
class SeverityFilterParams(BaseModelWithAlias):
    """Filter by severity"""

    eq: float | None = Field(None, ge=0, le=10)
    in_: list[float] | None = Field(None, alias="in")
    gte: float | None = Field(None, ge=0, le=10)
    lte: float | None = Field(None, ge=0, le=10)


class FixDifficultyScoreFilterParams(BaseModelWithAlias):
    """Filter by fix difficulty score"""

    eq: float | None = Field(None, ge=0, le=10)
    in_: list[float] | None = Field(None, alias="in")
    gte: float | None = Field(None, ge=0, le=10)
    lte: float | None = Field(None, ge=0, le=10)


class AuditRunIdFilterParams(BaseModelWithAlias):
    """Filter by audit run ID"""

    eq: UUID | None = None
    in_: list[UUID] | None = Field(None, alias="in")


class FileNameFilterParams(BaseModelWithAlias):
    """Filter by file name - supports exact match, patterns, and regex"""

    eq: str | None = None  # Exact match (for "show more" functionality)
    in_: list[str] | None = Field(None, alias="in")  # Multiple exact matches
    patterns: list[str] | None = None  # Multiple patterns (uses LIKE or regex)
    match_case: bool = False  # Case sensitivity for patterns
    regex: bool = False  # Use regex instead of LIKE patterns


class RuleIdFilterParams(BaseModelWithAlias):
    """Filter by rule ID"""

    eq: UUID | None = None
    in_: list[UUID] | None = Field(None, alias="in")


class ModelTypeFilterParams(BaseModelWithAlias):
    """Filter by model type"""

    eq: str | None = None
    in_: list[str] | None = Field(None, alias="in")


class CreatedAtFilterParams(BaseModelWithAlias):
    """Filter by creation date"""

    eq: datetime | None = None
    gte: datetime | None = None
    lte: datetime | None = None


class TitleFilterParams(BaseModelWithAlias):
    """Filter by title - supports exact match and fuzzy search"""

    eq: str | None = None
    in_: list[str] | None = Field(None, alias="in")
    like: str | None = None  # Fuzzy search using contains and word_similarity


# Generic filter model
class GenericIssueFilter(BaseModelWithAlias):
    """Generic filter for issues"""

    type: IssueFilterType
    params: (
        dict
        | SeverityFilterParams
        | FixDifficultyScoreFilterParams
        | AuditRunIdFilterParams
        | FileNameFilterParams
        | RuleIdFilterParams
        | ModelTypeFilterParams
        | CreatedAtFilterParams
        | TitleFilterParams
    )


class IssueFilter(BaseModelWithAlias):
    """Container for multiple issue filters"""

    filters: list[GenericIssueFilter] | None = Field(default=[])


class PaginatedIssueFilter(IssueFilter, PaginationParams):
    """Paginated issue filter with sorting"""

    sort_by: list[IssueSortField] | IssueSortField | None = Field(default=[IssueSortField.SEVERITY])
    group_by: IssueGroupByField | None = Field(default=None)
    descending: bool = True


# Observation models
class ObservationCreate(BaseModelWithAlias):
    """Model for creating an observation"""

    project_id: UUID
    file_name: str
    source_type: ObservationSourceType
    spec_id: UUID | None = None
    changeset_id: UUID | None = None
    start_line: int
    end_line: int

    @field_validator("spec_id", "changeset_id")
    @classmethod
    def validate_ids_by_source_type(cls, v, info):
        """Validate spec_id and changeset_id based on source_type"""
        values = info.data
        source_type = values.get("source_type")
        field_name = info.field_name

        if not source_type:
            return v

        # SPEC type: requires spec_id
        if source_type == ObservationSourceType.SPEC and field_name == "spec_id" and v is None:
            raise ValueError("spec_id is required for SPEC source type")

        # CHANGESET type: requires changeset_id
        if source_type == ObservationSourceType.CHANGESET and field_name == "changeset_id" and v is None:
            raise ValueError("changeset_id is required for CHANGESET source type")

        return v


class ObservationResponse(BaseModelWithAlias):
    """Model for observation response"""

    id: UUID
    project_id: UUID
    file_name: str
    source_type: ObservationSourceType
    spec_id: UUID | None = None
    changeset_id: UUID | None = None
    start_line: int
    end_line: int
    created_at: datetime


# Issue models
class IssueCreate(BaseModelWithAlias):
    """Model for creating an issue"""

    observation_id: UUID
    audit_run_id: UUID | None = None
    model_type: str | None = None
    rule_id: UUID | None = None
    title: str
    severity: float = Field(ge=0, le=10, description="Severity of the issue (0-10)")
    description: str | None = None
    fix_difficulty_score: float = Field(ge=0, le=10, description="Difficulty to fix the issue (0-10)")
    task_id: str | None = Field(default=None, description="External task ID used to fix this issue")
    quest_id: str | None = Field(default=None, description="External quest ID associated with this issue")


class IssuesCreateBulk(BaseModelWithAlias):
    """Model for creating multiple issues at once"""

    issues: list[IssueCreate]


class IssuesDeleteBulk(BaseModelWithAlias):
    """Model for deleting multiple issues at once"""

    issue_ids: list[UUID]


class IssuesAssociateBulk(BaseModelWithAlias):
    """Model for associating multiple issues with task_id or quest_id"""

    issue_ids: list[UUID] = Field(description="List of issue UUIDs to update")
    task_id: str | None = Field(None, description="External task ID to associate with issues")
    quest_id: str | None = Field(None, description="External quest ID to associate with issues")


class IssueResponse(BaseModelWithAlias):
    """Model for issue response"""

    id: UUID
    observation_id: UUID
    audit_run_id: UUID | None = None
    model_type: str | None = None
    rule_id: UUID | None = None
    title: str
    severity: float
    description: str | None = None
    fix_difficulty_score: float
    task_id: str | None = None
    quest_id: str | None = None


class IssueWithObservationResponse(IssueResponse):
    """Model for issue response with observation"""

    observation: ObservationResponse


# Paginated responses
class PaginatedIssuesResponse(PaginatedBase[IssueResponse]):
    """Paginated response for issues"""

    pass


class PaginatedIssuesWithObservationResponse(PaginatedBase[IssueWithObservationResponse]):
    """Paginated response for issues with observations"""

    group_counts: dict[str, int] | None = Field(
        default=None, description="Count of issues for each unique value when grouping is applied"
    )


# Stats response models
class IssueStatsResponse(BaseModelWithAlias):
    """Response model for issue statistics

    Extensible for additional filter sidebar information
    """

    files: dict[str, int]  # file_name -> issue_count mapping
    tags: list[str]  # unique tags from rules linked to matching issues
    rule_ids: list[UUID]  # unique rule IDs linked to matching issues


# AuditRun models
class AuditRunCreate(BaseModelWithAlias):
    """Model for creating an audit run"""

    project_id: UUID
    rule_ids: list[UUID]
    model: str
    include_globs: list[str] | None = None
    exclude_globs: list[str] | None = None


class AuditRunResponse(BaseModelWithAlias):
    """Model for audit run response"""

    id: UUID
    project_id: UUID
    user_id: str
    rule_ids: list[UUID]
    model: str
    include_globs: list[str] | None = None
    exclude_globs: list[str] | None = None
    process_id: UUID | None = None
    status: ExecutionStatusEnum | None = None
    progress_details: dict | None = None
    created_at: datetime
    updated_at: datetime


class AuditCostEstimateRequest(BaseModelWithAlias):
    """Request model for audit cost estimation"""

    project_id: UUID
    rule_ids: list[UUID]
    models: list[str] = Field(description="List of model names to estimate costs for")
    include_globs: list[str] | None = None
    exclude_globs: list[str] | None = None


class AuditCostEstimateResponse(BaseModelWithAlias):
    """Response model for audit cost estimation"""

    per_model_cost: dict[str, float] = Field(description="Cost per model if run individually in USD")


class PaginatedAuditRunsResponse(PaginatedBase[AuditRunResponse]):
    """Paginated response for audit runs"""

    pass
