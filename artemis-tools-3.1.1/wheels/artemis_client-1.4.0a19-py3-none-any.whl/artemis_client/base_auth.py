import functools
import json
import logging
import mimetypes
import os
import ssl
import time
from pathlib import Path
from typing import (
    IO,
    Any,
    AsyncIterator,
    Awaitable,
    Callable,
    NotRequired,
    Optional,
    Tuple,
    TypedDict,
    TypeVar,
    Union,
    Unpack,
)

import httpx
import httpx._client as httpx_client
import httpx._types as types
from httpx import URL, Headers, Response
from pydantic import Json
from typing_extensions import ParamSpec, override

from turing_task_manager.clients import ApiAddress
from turing_task_manager.clients.core import ApiSettings
from turing_task_manager.clients.core.utils import to_json

from evoml_services.clients.thanos import ThanosClient
from evoml_services.clients.thanos.models import JWTToken, LoginForm

# Source imports
from artemis_client.utils import HTTPMethod, response_json

# Get the loggers for 'httpx'
httpx_logger = logging.getLogger("httpx")
http11_logger = logging.getLogger("httpcore")

# Set the logging level to WARNING to ignore INFO and DEBUG logs
httpx_logger.setLevel(logging.WARNING)
http11_logger.setLevel(logging.WARNING)

T = TypeVar("T")
P = ParamSpec("P")
SettingsT = TypeVar("SettingsT", bound=ApiSettings)

try:  # requests can raise simplejson.JSONDecodeError if it's available
    import simplejson

    JsonDecodeErrors = (json.JSONDecodeError, simplejson.JSONDecodeError)
except ImportError:
    JsonDecodeErrors = (json.JSONDecodeError,)


# ──────────────────────────────── decorators ──────────────────────────────── #


def authenticated(method: Callable[..., T]) -> Callable[..., T]:
    """Decorator that authenticates before running a method (of an ApiClient
    class) if the client is not yet authenticated.
    """

    @functools.wraps(method)
    def auth_restricted(client: BaseAuthClient, *args: P.args, **kwargs: P.kwargs) -> T:
        if not client.is_authenticated():
            client.authenticate()
        return method(client, *args, **kwargs)

    return auth_restricted


def async_authenticated(
    method: Callable[..., Awaitable[T]],
) -> Callable[..., Awaitable[T]]:
    """
    Decorator that authenticates before running a method (of an ApiClient
    class) if the client is not yet authenticated.
    """

    @functools.wraps(method)
    async def auth_restricted(client: BaseAuthAsyncClient, *args: P.args, **kwargs: P.kwargs) -> T:
        if not client.is_authenticated():
            client.authenticate()
        return await method(client, *args, **kwargs)

    return auth_restricted


def astream_authenticated(
    method: Callable[..., AsyncIterator[T]],
) -> Callable[..., AsyncIterator[T]]:
    """
    Decorator that authenticates before running a method (of an ApiClient
    class) if the client is not yet authenticated.
    """

    @functools.wraps(method)
    async def auth_restricted(client: BaseAuthAsyncClient, *args: P.args, **kwargs: P.kwargs) -> AsyncIterator[T]:
        if not client.is_authenticated():
            client.authenticate()
        async for res in method(client, *args, **kwargs):
            yield res

    return auth_restricted


class RequestKwargs(TypedDict):
    content: NotRequired[types.RequestContent | None]
    data: NotRequired[types.RequestData | None]
    files: NotRequired[types.RequestFiles | None]
    json: NotRequired[Any | None]  # pylint: disable=redefined-outer-name
    params: NotRequired[types.QueryParamTypes | None]
    headers: NotRequired[types.HeaderTypes | None]
    cookies: NotRequired[types.CookieTypes | None]
    auth: NotRequired[types.AuthTypes | httpx_client.UseClientDefault | None]
    follow_redirects: NotRequired[bool | httpx_client.UseClientDefault]
    timeout: NotRequired[types.TimeoutTypes | httpx_client.UseClientDefault]
    extensions: NotRequired[types.RequestExtensions | None]
    stream: NotRequired[bool]


class AsyncRequestKwargs(TypedDict):
    content: NotRequired[types.RequestContent | None]
    data: NotRequired[types.RequestData | None]
    files: NotRequired[types.RequestFiles | None]
    json: NotRequired[Any | None]  # pylint: disable=redefined-outer-name
    params: NotRequired[types.QueryParamTypes | None]
    headers: NotRequired[types.HeaderTypes | None]
    cookies: NotRequired[types.CookieTypes | None]
    auth: NotRequired[types.AuthTypes | httpx_client.UseClientDefault | None]
    follow_redirects: NotRequired[bool | httpx_client.UseClientDefault]
    timeout: NotRequired[types.TimeoutTypes | httpx_client.UseClientDefault]
    extensions: NotRequired[types.RequestExtensions | None]


class ArtemisApiAddress(ApiAddress):
    read_timeout: float = 300.0  # override to a higher value to ensure timeout issues don't occur

    def ssl_verify_to_httpx(self) -> bool | ssl.SSLContext:
        """
        Convert the ssl_verify attribute to a format that httpx can use.
        httpx expects an SSLContext instead of a string.
        """
        if self.ssl_verify is None:
            # ssl_verify path if exists, else REQUESTS_CA_BUNDLE content if not None, otherwise None
            ssl_verify_value = (
                self.ssl_verify if self.ssl_verify is not None else os.environ.get("REQUESTS_CA_BUNDLE", None)
            )
        elif isinstance(self.ssl_verify, bool):
            return self.ssl_verify
        else:
            ssl_verify_value = self.ssl_verify

        return ssl.create_default_context(cafile=ssl_verify_value)


def timeout_precedence(
    client_settings: ArtemisApiAddress,
    method_timeout: types.TimeoutTypes | httpx_client.UseClientDefault,
) -> tuple[float | None, float | None, float | None, float | None]:
    if method_timeout == httpx_client.USE_CLIENT_DEFAULT:
        return (
            client_settings.connect_timeout,
            client_settings.read_timeout,
            None,
            None,
        )
    elif method_timeout is None:
        return (
            client_settings.connect_timeout,
            None,
            None,
            None,
        )
    elif isinstance(method_timeout, (int, float)):
        return (
            client_settings.connect_timeout,
            (max(client_settings.read_timeout, method_timeout) if client_settings.read_timeout is not None else None),
            None,
            None,
        )
    elif isinstance(method_timeout, tuple):
        connect_timeout, read_timeout, write_timeout, pool_timeout = method_timeout
        return (
            (
                max(client_settings.connect_timeout, connect_timeout)
                if connect_timeout is not None and client_settings.connect_timeout is not None
                else None
            ),
            (
                max(client_settings.read_timeout, read_timeout)
                if read_timeout is not None and client_settings.read_timeout is not None
                else None
            ),
            write_timeout,
            pool_timeout,
        )
    return None, None, None, None


class ThanosSettings(ArtemisApiAddress, LoginForm):
    pass


class BaseAuthClient(httpx.Client):

    def __init__(
        self,
        client_settings: ArtemisApiAddress,
        thanos_settings: ThanosSettings | None = None,
    ):
        super().__init__(
            base_url=f"http://{client_settings.get_adress()}",
            timeout=300,
            verify=(
                client_settings.ssl_verify_to_httpx()
                if (client_settings.https and client_settings.ssl_verify)
                else False
            ),
        )

        self.client_settings = client_settings
        self.thanos_settings = thanos_settings or ThanosSettings.with_env_prefix("thanos")
        self.thanos_client = ThanosClient(self.thanos_settings)
        self.token: JWTToken | None = None
        self.token_expires = time.time()
        self.headers = Headers()

    def authenticate(self):
        request_time = time.time()
        self.token = JWTToken.parse_obj(
            self.thanos_client.post(
                "/auth/login",
                json=LoginForm.parse_obj(self.thanos_client.settings),
            )
        )
        self.token_expires = request_time + self.token.expires_in
        self.headers["Authorization"] = f"Bearer {self.token.access_token}"

    def is_authenticated(self) -> bool:
        return self.token is not None and self.token_expires > time.time()

    def build_url(self, url: URL | str) -> str:
        protocol = "https://" if self.client_settings.https else "http://"
        host_url = self.client_settings.get_adress()
        return f"{protocol}{host_url}{url}"

    @override
    def request(
        self,
        method: str,
        url: URL | str,
        *,
        content: types.RequestContent | None = None,
        data: types.RequestData | None = None,
        files: types.RequestFiles | None = None,
        json: Any | None = None,  # pylint: disable=redefined-outer-name
        params: types.QueryParamTypes | None = None,
        headers: types.HeaderTypes | None = None,
        cookies: types.CookieTypes | None = None,
        auth: types.AuthTypes | httpx_client.UseClientDefault | None = httpx_client.USE_CLIENT_DEFAULT,
        follow_redirects: bool | httpx_client.UseClientDefault = httpx_client.USE_CLIENT_DEFAULT,
        timeout: types.TimeoutTypes | httpx_client.UseClientDefault = httpx_client.USE_CLIENT_DEFAULT,
        extensions: types.RequestExtensions | None = None,
        stream: bool = False,
    ) -> httpx.Response:
        """Send the request and raise an exception for error status responses"""
        converted_json: Optional[Json[Any]] = to_json(json)
        func_to_use = super().stream if stream else super().request

        response = func_to_use(
            method=method,
            url=self.build_url(url),
            content=content,
            data=data,
            files=files,
            json=converted_json,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth,
            follow_redirects=follow_redirects,
            timeout=timeout_precedence(self.client_settings, timeout),
            extensions=extensions,
        )
        if response.is_error:
            try:
                message = response.json().get("message", response.text)
            except JsonDecodeErrors:
                message = response.text
            raise httpx.HTTPStatusError(message, request=response.request, response=response)

        return response

    # --------------------------------- json --------------------------------- #

    def get(self, url: URL | str, **kwargs: Unpack[RequestKwargs]) -> Json[Any]:
        """Wrapper sending a get through the _request method, returns a json"""
        return response_json(self.request(url=url, method=HTTPMethod.GET, **kwargs))

    def post(self, url: URL | str, **kwargs: Unpack[RequestKwargs]) -> Json[Any]:
        """Wrapper sending a get through the _request method, returns a json"""
        return response_json(self.request(url=url, method=HTTPMethod.POST, **kwargs))

    def put(self, url: URL | str, **kwargs: Unpack[RequestKwargs]) -> Json[Any]:
        """Wrapper sending a put through the _request method, returns a json"""
        return response_json(self.request(url=url, method=HTTPMethod.PUT, **kwargs))

    def patch(self, url: URL | str, **kwargs: Unpack[RequestKwargs]) -> Json[Any]:
        """Wrapper sending a patch through the _request method, returns a json"""
        return response_json(self.request(url=url, method=HTTPMethod.PATCH, **kwargs))

    def delete(self, url: URL | str, **kwargs: Unpack[RequestKwargs]) -> Json[Any]:
        """Wrapper sending a put through the _request method, returns a json"""
        return response_json(self.request(url=url, method=HTTPMethod.DELETE, **kwargs))

    # -------------------------------- files --------------------------------- #

    def upload_file(
        self,
        url: httpx.URL | str,
        filepath: tuple[str, IO[str]] | str | Path,
        method: HTTPMethod = HTTPMethod.POST,
        **kwargs: Any,
    ) -> list[Any] | dict[str, Any]:
        """Wrapper uploading a file or a stream to an endpoint
        :param path: Endpoint to use for upload
        :param filepath: Path, str or Tuple of (filename, File-like object) to upload
        :param method: REST method to use for upload
        """

        if isinstance(filepath, (tuple, list)):
            filename, fileobj = filepath  # we're getting a tuple (name, binary)
        else:
            filepath = Path(filepath)
            if not filepath.exists():
                raise FileNotFoundError(f"Path {filepath} was not found")
            filename = filepath.name
            fileobj = filepath.open("rb")

        mime_type, _ = mimetypes.guess_type(filename)
        with fileobj:
            kwargs["files"] = {"file": (filename, fileobj, mime_type)}
            return response_json(self.request(url=url, method=method, **kwargs))

    def download_file(
        self,
        url: str,
        filepath: str | Path | None,
        method: HTTPMethod = HTTPMethod.GET,
        stream: bool = False,
        chunk_size: int = 128,
        **kwargs,
    ) -> Response | None:
        """Wrapper downloading or streaming a file from an endpoint to a path"""
        response = self.request(method, url, stream=stream, **kwargs)
        if stream:
            return response
        if filepath:
            with open(filepath, "wb") as fobj:
                for chunk in response.iter_bytes(chunk_size):
                    fobj.write(chunk)
        else:
            raise ValueError(f"File path is required when stream is False. Received {filepath}")
        return None


class BaseAuthAsyncClient(httpx.AsyncClient):

    def __init__(
        self,
        client_settings: ArtemisApiAddress,
        thanos_settings: Optional[ThanosSettings] = None,
    ):
        self.client_settings = client_settings

        super().__init__(
            base_url=f"http://{client_settings.get_adress()}",
            timeout=300,
            verify=(
                client_settings.ssl_verify_to_httpx()
                if (client_settings.https and client_settings.ssl_verify)
                else False
            ),
        )

        if thanos_settings is None:
            if isinstance(client_settings, ThanosSettings):
                self.thanos_client = ThanosClient(client_settings)
            else:
                raise ValueError("Missing argument: ThanosSettings is required")
        else:
            self.thanos_client = ThanosClient(thanos_settings)

        self.thanos_client = ThanosClient(thanos_settings or client_settings)
        self.token = None
        self.token_expires = time.time()
        self.headers = Headers()

    def authenticate(self):
        request_time = time.time()
        self.token = JWTToken.parse_obj(
            self.thanos_client.post(
                "/auth/login",
                json=LoginForm.parse_obj(self.thanos_client.settings),
            )
        )
        self.token_expires = request_time + self.token.expires_in
        self.headers["Authorization"] = f"Bearer {self.token.access_token}"

    def is_authenticated(self) -> bool:
        return self.token is not None and self.token_expires > time.time()

    def build_url(self, url: URL | str) -> str:
        protocol = "https://" if self.client_settings.https else "http://"
        host_url = self.client_settings.get_adress()
        return f"{protocol}{host_url}{url}"

    @override
    async def request(
        self,
        method: str,
        url: URL | str,
        *,
        content: types.RequestContent | None = None,
        data: types.RequestData | None = None,
        files: types.RequestFiles | None = None,
        json: Any | None = None,  # pylint: disable=redefined-outer-name
        params: types.QueryParamTypes | None = None,
        headers: types.HeaderTypes | None = None,
        cookies: types.CookieTypes | None = None,
        auth: types.AuthTypes | httpx_client.UseClientDefault | None = httpx_client.USE_CLIENT_DEFAULT,
        follow_redirects: bool | httpx_client.UseClientDefault = httpx_client.USE_CLIENT_DEFAULT,
        timeout: types.TimeoutTypes | httpx_client.UseClientDefault = httpx_client.USE_CLIENT_DEFAULT,
        extensions: types.RequestExtensions | None = None,
    ) -> Response:
        """Send the request and raise an exception for error status responses"""
        converted_json: Optional[Json[Any]] = to_json(json)

        response = await super().request(
            method=method,
            url=self.build_url(url),
            content=content,
            data=data,
            files=files,
            json=converted_json,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth,
            follow_redirects=follow_redirects,
            timeout=timeout_precedence(self.client_settings, timeout),
            extensions=extensions,
        )
        response.raise_for_status()
        return response

    # --------------------------------- json --------------------------------- #

    async def get(self, url: URL | str, **kwargs: Unpack[AsyncRequestKwargs]) -> Json[Any]:
        """Wrapper sending a get through the _request method, returns a json"""
        return response_json(await self.request(url=url, method=HTTPMethod.GET, **kwargs))

    async def post(self, url: URL | str, **kwargs: Unpack[AsyncRequestKwargs]) -> Json[Any]:
        """Wrapper sending a get through the _request method, returns a json"""
        return response_json(await self.request(url=url, method=HTTPMethod.POST, **kwargs))

    async def put(self, url: URL | str, **kwargs: Unpack[AsyncRequestKwargs]) -> Json[Any]:
        """Wrapper sending a put through the _request method, returns a json"""
        return response_json(await self.request(url=url, method=HTTPMethod.PUT, **kwargs))

    async def patch(self, url: URL | str, **kwargs: Unpack[AsyncRequestKwargs]) -> Json[Any]:
        """Wrapper sending a patch through the _request method, returns a json"""
        return response_json(await self.request(url=url, method=HTTPMethod.PATCH, **kwargs))

    async def delete(self, url: URL | str, **kwargs: Unpack[AsyncRequestKwargs]) -> Json[Any]:
        """Wrapper sending a put through the _request method, returns a json"""
        return response_json(await self.request(url=url, method=HTTPMethod.DELETE, **kwargs))

    # -------------------------------- files --------------------------------- #

    async def upload_file(
        self,
        path: str,
        filepath: Union[Tuple[str, IO], Union[str, Path]],
        method: HTTPMethod = HTTPMethod.POST,
        **kwargs,
    ) -> Json[Any]:
        """Wrapper uploading a file or a stream to an endpoint
        :param path: Endpoint to use for upload
        :param filepath: Path, str or Tuple of (filename, File-like object) to upload
        :param method: REST method to use for upload
        """
        if isinstance(filepath, (tuple, list)):
            filename, fileobj = filepath  # we're getting a tuple (name, binary)
        else:
            filepath = Path(filepath)
            if not filepath.exists():
                raise FileNotFoundError(f"Path {filepath} was not found")
            filename = filepath.name
            fileobj = filepath.open("rb")

        mime_type, _ = mimetypes.guess_type(filename)
        with fileobj:
            kwargs["files"] = {"file": (filename, fileobj, mime_type)}
            return response_json(await self.request(path, method, **kwargs))

    async def download_file(
        self,
        url: str,
        filepath: str | Path | None,
        method: HTTPMethod = HTTPMethod.GET,
        stream: bool = False,
        chunk_size: int = 128,
        **kwargs,
    ) -> Response | None:
        """Wrapper downloading or streaming a file from an endpoint to a path"""
        response = await self.request(method, url, **kwargs)
        if stream:
            return response
        if filepath:
            with open(filepath, "wb") as fobj:
                for chunk in response.iter_bytes(chunk_size):  # A chunk of 128 bytes
                    fobj.write(chunk)
        else:
            raise ValueError(f"File path is required when stream is False. Received {filepath}")
        return None
