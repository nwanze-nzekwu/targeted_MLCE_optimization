"""Implements an HTTP client for Falcon API"""

# pylint: disable=too-many-public-methods
# pylint: disable=too-many-lines

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
import time
from pathlib import Path
from typing import Any, Dict, Literal
from uuid import UUID

import orjson
from falcon_models import (
    AIApplicationRunResponse,
    BatchSpecScoreUpdateRequest,
    ChangesetCommandUpdateRequest,
    ChangesetValidationCommandResponse,
    ChangesetValidationRequest,
    ChangesetValidationResponse,
    CodeAIMultiOptimiseRequest,
    ConcreteConstruct,
    ConcreteConstructBatchRequest,
    ConcreteConstructResponse,
    ConstructCreationResponse,
    CustomSpecBatchResponse,
    CustomSpecRequest,
    CustomSpecResponse,
    EmbeddingCreationRequest,
    EmbeddingCreationResponse,
    EmbeddingPatchRequest,
    EmbeddingRunResponse,
    ExtractionRunResponse,
    FilteringResultResponse,
    FilteringRunResponse,
    FullSolutionInfoRequest,
    FullSolutionInfoResponse,
    GitProviderPullRequest,
    GitProviderPush,
    HardwareInfoRequest,
    HardwareInfoResponse,
    InternalReportData,
    LogAdditionRequest,
    LogGroupInfoResponse,
    LogGroupResponse,
    NewVersionsRequest,
    NewVersionsResponse,
    OptimisationRunResponse,
    PaginatedBase,
    PaginatedConstructFilter,
    PaginatedConstructsResponse,
    PaginatedEmbeddingResponse,
    PaginatedProjectInfoResponse,
    PaginatedSolutionResponse,
    PaginatedUserSettingsResponse,
    PairCoderRequestResponse,
    ProcessStatusResponse,
    ProjectFileSearchRequest,
    ProjectFileSearchResponse,
    ProjectGitDiffRequest,
    ProjectGitDiffResponse,
    ProjectInfoRequest,
    ProjectInfoResponse,
    ProjectIngestRunResponse,
    ProjectPromptRequest,
    ProjectPromptResponse,
    PromptListResponse,
    ReportRequestResponse,
    RerankRunResponse,
    SolutionResultsRequest,
    SpecFilterRequest,
    SpecScoreInfoResponse,
    SpecScoreRequest,
    SpecScoreResponse,
    SpecScoreUpdateRequest,
    Status,
    ToolCreationResponse,
    UserSettingsPatchRequest,
    UserSettingsRequest,
    UserSettingsResponse,
    ValidationFilterTypeEnum,
)
from falcon_models.api.changeset_models import (
    ChangesetCreateRequest,
    ChangesetPRDetailsRequest,
    ChangesetPRDetailsResponse,
    ChangesetResponse,
    ChangesetVersionCompareResponse,
    ChangesetVersionResponse,
    ChangesetVersionsResponse,
    FileContentResponse,
    FilesResponse,
    GitProviderPullRequestResponse,
    GitProviderPushResponse,
    VersionCreateRequest,
)

# Third-party Libraries
from falcon_models.api.code_models import CodeAIMultiOptimiseResponse, CustomSpecChildResponse
from falcon_models.api.git_key_models import GitFilter, GitUserLinesResponse
from falcon_models.api.observation_models import (
    IssuesCreateBulk,
    IssuesDeleteBulk,
    IssueStatsResponse,
    IssueWithObservationResponse,
    ObservationCreate,
    ObservationResponse,
    PaginatedIssueFilter,
    PaginatedIssuesWithObservationResponse,
    PaginatedRuleResponse,
    RuleCreate,
    RuleResponse,
    RuleUpdate,
)
from falcon_models.api.utils_models import LogEntryBaseRequestResponse
from falcon_models.enums.code import RerankMethodEnum
from falcon_models.enums.general import ExecutionStatusEnum
from falcon_models.service.base_data_types import PaginationParams
from falcon_models.service.filters.constructs import ConstructFilter
from starlette.requests import Request

from evoml_services.clients.thor import FileId

# Source imports
from artemis_client.artemis_logging import setup_logging
from artemis_client.auth.thanos_auth_mixin_client import ThanosSettings
from artemis_client.base_auth import (
    ArtemisApiAddress,
    BaseAuthAsyncClient,
    BaseAuthClient,
    async_authenticated,
    authenticated,
)
from artemis_client.utils import HTTPMethod
from artemis_tools.models.generic import orjson_dumps

# __all__ = ["FalconClient", "FalconAsyncClient", "FalconSettings"]

setup_logging()


# ───────────────────────────────────────────────────────────────────────────── #
class FalconSettings(ArtemisApiAddress):
    """Settings for Falcon API"""

    user_override: str | None = None


# ───────────────────────────────── Clients ─────────────────────────────────── #
class FalconClient(BaseAuthClient):
    """This is a client implementation for Falcon API"""

    def __init__(
        self,
        falcon_settings: FalconSettings,
        thanos_settings: ThanosSettings | None = None,
    ):
        self.falcon_settings = falcon_settings
        super().__init__(falcon_settings, thanos_settings)

        self.token = None
        self.token_expires = time.time()
        if self.falcon_settings.user_override:
            self.headers.update({"x-user-override": self.falcon_settings.user_override})

    def __reduce__(self):
        return self.__class__, (self.falcon_settings, self.thanos_settings)

    # ──────────────────────────── regular files ───────────────────────────── #

    @authenticated
    def search_project_files(
        self, project_id: str, request: ProjectFileSearchRequest | None = None
    ) -> ProjectFileSearchResponse:
        """Retrieves the model describing a project by id"""
        request = request or ProjectFileSearchRequest()
        return ProjectFileSearchResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/file-search",
                json=request.model_dump(mode="json"),
            )
        )

    @authenticated
    def get_project_file(self, project_id: str, file_name: str) -> str:
        """Retrieves the file content from a project"""
        response = self.request(method=HTTPMethod.GET, url=f"/code/projects/{project_id}/file?name={file_name}")
        return response.text

    # ──────────────────────────── projects ───────────────────────────── #

    @authenticated
    def create_project(self, request: ProjectInfoRequest) -> ProjectInfoResponse:
        """
        Create a new project.
            Request body
                - project       Info of project to create
            Response
                             Id of the created project
        """

        return ProjectInfoResponse.model_validate(self.post("/code/projects", json=request.model_dump(mode="json")))

    @authenticated
    def get_project(self, project_id: str) -> ProjectInfoResponse:
        """Retrieves the model describing a project by id"""
        return ProjectInfoResponse.model_validate(self.get(f"/code/projects/{project_id}"))

    @authenticated
    def init_project(self, project_id: str) -> ProjectInfoResponse:
        """Initialises project"""
        return ProjectInfoResponse.model_validate(self.post(f"/code/projects/{project_id}/init", timeout=60.0))

    @authenticated
    def get_project_diff(self, project_id: str, request: ProjectGitDiffRequest) -> ProjectGitDiffResponse:
        """Gets diff between a specific branch and the current branch of the project"""
        return ProjectGitDiffResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/diff",
                json=request.model_dump(mode="json"),
            )
        )

    @authenticated
    def get_project_user_lines(self, project_id: str, git_filter: GitFilter | None = None) -> GitUserLinesResponse:
        """Gets user code of the current branch of the project"""
        params = {}
        if git_filter:
            params = git_filter.model_dump(mode="json", by_alias=True, exclude_none=True)
        return GitUserLinesResponse.model_validate(
            self.get(
                f"/code/projects/{project_id}/user-code",
                params=params,
            )
        )

    @authenticated
    def patch_project(self, project_id: str, updated_info: dict[str, Any]) -> ProjectInfoResponse:
        """Updates a project's details"""
        return ProjectInfoResponse.model_validate(self.patch(f"/code/projects/{project_id}", json=updated_info))

    @authenticated
    def patch_project_run(self, project_run_id: str, updated_info: dict[str, Any]) -> ProjectIngestRunResponse:
        """Updates a project run's details"""
        return ProjectIngestRunResponse.model_validate(
            self.patch(f"/code/projects/run/{project_run_id}", json=updated_info)
        )

    @authenticated
    def get_projects(self, search: str | None = None, is_embedded: bool | None = None) -> PaginatedProjectInfoResponse:
        """Retrieves a list of all projects."""
        url = f"/code/projects?search={search}" if search else "/code/projects"
        extra_params: dict[str, str] = {}
        if search is not None:
            extra_params["search"] = search
        if is_embedded is not None:
            extra_params["isEmbedded"] = str(is_embedded).lower()
        return PaginatedProjectInfoResponse.model_validate(self.get(url, params=extra_params))

    @authenticated
    def get_extraction(self, extraction_id: str) -> ExtractionRunResponse:
        """Retrieves the model describing an extraction run by id"""
        return ExtractionRunResponse.model_validate(self.get(f"/code/extraction/{extraction_id}"))

    @authenticated
    def patch_extraction(self, extraction_id: str, updated_info: dict[str, Any]) -> ExtractionRunResponse:
        """Updates an extractions' details"""
        return ExtractionRunResponse.model_validate(self.patch(f"/code/extraction/{extraction_id}", json=updated_info))

    @authenticated
    def patch_embedding_run(self, embedding_id: str, updated_info: EmbeddingPatchRequest) -> None:
        self.patch(
            f"/code/projects/embeddings/{embedding_id}",
            json=updated_info.model_dump(mode="json"),
        )

    @authenticated
    def add_extraction_log(self, extraction_id: str, file_id: str) -> dict[str, str]:
        """Retrieves the model describing an extraction run by id"""
        return self.post(f"/code/extraction/{extraction_id}/log?file_id={file_id}")

    @authenticated
    def get_filtering(self, project_id: str) -> FilteringRunResponse:
        """Retrieves the model describing a project by id"""
        return FilteringRunResponse.model_validate(self.get(f"/code/filtering/{project_id}"))

    @authenticated
    def get_spec_filtering_results(self, spec_ids: list[str]) -> dict[UUID, list[FilteringResultResponse]]:
        """Retrieves the model describing a project by id"""
        request = SpecFilterRequest(spec_ids=[UUID(id_) for id_ in spec_ids])
        response = self.post("/code/versions/validation/list", json=request.model_dump(mode="json"))
        deserialized_response: dict[UUID, list[FilteringResultResponse]] = {}
        for key, values in response.items():
            deserialized_response[UUID(key)] = [FilteringResultResponse.model_validate(value) for value in values]
        return deserialized_response

    @authenticated
    def get_rerank(self, rerank_id: str) -> RerankRunResponse:
        """Retrieves the model describing a project by id"""
        return RerankRunResponse.model_validate(self.get(f"/code/projects/rerank/{rerank_id}"))

    @authenticated
    def create_embedding(self, project_id: str, request: EmbeddingCreationRequest) -> EmbeddingCreationResponse:
        """Create embeddings for a project"""
        return EmbeddingCreationResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/embeddings/async",
                json=request.model_dump(mode="json"),
            )
        )

    @authenticated
    def get_embedding(self, embedding_run_id: str) -> EmbeddingRunResponse:
        """Retrieves the model describing a project by id"""
        return EmbeddingRunResponse.model_validate(self.get(f"/code/projects/embeddings/{embedding_run_id}"))

    @authenticated
    def get_embeddings(
        self,
        project_id: str,
        successful_only: bool = False,
        page: int = 1,
        per_page: int = 10,
    ) -> PaginatedEmbeddingResponse:
        """Get the list of constructs to a project."""
        return PaginatedEmbeddingResponse.model_validate(
            self.get(
                f"/code/projects/{project_id}/embeddings",
                params={
                    "page": page,
                    "perPage": per_page,
                    "successfulOnly": successful_only,
                },
            )
        )

    @authenticated
    def get_optimisation(self, optimisation_id: str) -> OptimisationRunResponse:
        """Retrieves the model describing an extraction run by id"""
        return OptimisationRunResponse.model_validate(self.get(f"/code/optimisations/{optimisation_id}"))

    @authenticated
    def patch_optimisation(self, optimisation_id: str, updated_info: dict[str, Any]) -> OptimisationRunResponse:
        """Updates a project's details"""
        return OptimisationRunResponse.model_validate(
            self.patch(f"/code/optimisations/{optimisation_id}", json=updated_info)
        )

    @authenticated
    def get_ai_application(self, apply_id: UUID) -> AIApplicationRunResponse:
        """Retrieves the model describing an ai application run by id"""
        return AIApplicationRunResponse.model_validate(self.get(f"/code/ai-applications/{apply_id}"))

    @authenticated
    def get_db_project_run(self, db_project_run_id: str) -> ProjectIngestRunResponse:
        """Retrieves the model describing a process for a DB project by id"""
        return ProjectIngestRunResponse.model_validate(self.get(f"/code/projects/db/{db_project_run_id}"))

    # ──────────────────────────── regular files ───────────────────────────── #
    @authenticated
    def get_solution(self, solution_id: str) -> FullSolutionInfoResponse:
        """Retrieves the model describing a project by id"""
        return FullSolutionInfoResponse.model_validate(self.get(f"/code/solutions/{solution_id}"))

    @authenticated
    def get_solutions(self, optimisation_id: str, page: int = 1, per_page: int = 10) -> PaginatedSolutionResponse:
        """Retrieves a paginated list of solutions for an optimisation.

        Args:
            optimisation_id: Unique id of the optimisation
            page: Page number (default: 1)
            per_page: Number of items per page, -1 for all (default: 10)
        """
        return PaginatedSolutionResponse.model_validate(
            self.get(
                f"/code/optimisations/{optimisation_id}/solutions",
                params={"page": page, "perPage": per_page},
            )
        )

    # ────────────────────────────   Process Utils  ───────────────────────────── #

    @authenticated
    def create_log_group(self) -> LogGroupInfoResponse:
        """Retrieves the model describing a project by id"""
        return LogGroupInfoResponse.model_validate(self.post("/utils/logs"))

    @authenticated
    def get_log_group(self, log_group_id: str) -> LogGroupResponse:
        """Retrieves the model describing a project by id"""
        return LogGroupResponse.model_validate(self.get(f"/utils/logs/{log_group_id}"))

    @authenticated
    def send_process_details(self, process_id: UUID, details: dict[str, Any]):
        """Retrieves the model describing a project by id"""
        return self.post(
            f"/utils/process/{process_id}/details",
            data=orjson_dumps(details),
            headers={"Content-Type": "application/json"},
        )

    @authenticated
    def update_process_status(self, process_id: UUID, status: ExecutionStatusEnum):
        """Retrieves the model describing a project by id"""
        return self.post(f"/utils/process/{process_id}/status", json={"status": status})

    @authenticated
    def update_process_progress(self, process_id: UUID, progress: float):
        """Retrieves the model describing a project by id"""
        return self.post(f"/utils/process/{process_id}/progress", json={"progress": progress})

    @authenticated
    def get_process(self, process_id: UUID) -> ProcessStatusResponse:
        """Retrieves the model describing a project by id"""
        return ProcessStatusResponse.model_validate(self.get(f"/utils/process/{process_id}"))

    @authenticated
    async def get_process_logs(self, process_id: UUID) -> LogGroupResponse:
        """Retrieves the model describing a project by id"""
        return LogGroupResponse.model_validate((self.get(f"/utils/process/{process_id}/logs")))

    # ──────────────────────────── columns infos ───────────────────────────── #

    @authenticated
    def verify_construct(
        self,
        project_id: str,
        filtering_id: str,
        construct_id: str | None,
        spec_id: str | None,
        filter_type: ValidationFilterTypeEnum,
        passed: bool,
        logs: str = "",
        cpu: float | None = None,
        memory: float | None = None,
        runtime: float | None = None,
    ) -> None:
        """Verifies a construct"""
        body = {
            "projectId": project_id,
            "specId": spec_id,
            "constructId": construct_id,
            "passed": passed,
            "type": filter_type,
            "cpu": cpu,
            "memory": memory,
            "runtime": runtime,
        }
        if logs:
            body["logs"] = logs
        self.post(
            f"/code/filtering/{str(filtering_id)}/result",
            data=orjson_dumps(body),
        )

    @authenticated
    def get_construct(self, construct_id: str) -> ConcreteConstructResponse:
        """Retrieves a construct by id"""
        return ConcreteConstructResponse.model_validate(self.get(f"/code/constructs/{construct_id}"))

    @authenticated
    def get_spec(
        self,
        spec_id: str,
        sources: Literal["none", "root", "sources"],
        construct: bool = False,
    ) -> CustomSpecResponse:
        """Retrieves a construct by id"""
        return CustomSpecResponse.model_validate(
            self.get(f"/code/versions/{spec_id}?sources={sources}&construct={construct}")
        )

    @authenticated
    def post_log(self, log_id: str, log_addition: LogAdditionRequest) -> None:
        self.post(f"/utils/logs/{log_id}", data=orjson_dumps(log_addition.model_dump()))

    @authenticated
    def add_constructs(
        self,
        project_id: str,
        extraction_id: str,
        constructs: ConcreteConstructBatchRequest,
    ):
        """Appends a construct to a project."""
        endpoint = f"/code/projects/{project_id}/constructs"
        if extraction_id:
            endpoint += f"?extractionId={extraction_id}"
        res = self.post(endpoint, data=orjson_dumps(constructs.model_dump()))
        return ConstructCreationResponse.model_validate(res)

    @authenticated
    def ingest_constructs(self, project_id: str, request: Request) -> ConstructCreationResponse:
        """Ingest a list of constructs to a project."""
        return ConstructCreationResponse.model_validate(
            self.post(f"/code/projects/{project_id}/constructs/ingest", json=request)
        )

    @authenticated
    def get_constructs(
        self, project_id: str, filters: PaginatedConstructFilter | None = None
    ) -> PaginatedConstructsResponse:
        """Get the list of constructs to a project."""
        filters = filters or PaginatedConstructFilter(page=1, per_page=10)
        return PaginatedConstructsResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/constructs/search",
                json=filters.model_dump(mode="json"),
            )
        )

    @authenticated
    def new_specs(self, versions: NewVersionsRequest) -> NewVersionsResponse:
        """Appends specs to constructs."""
        response = self.post(
            "/code/versions",
            json=versions.model_dump(mode="json"),
        )
        return NewVersionsResponse.model_validate(response)

    @authenticated
    def add_solution(
        self,
        project_id: str,
        optimisation_id: str | None,
        solution: FullSolutionInfoRequest,
    ):
        """Appends a construct to a project."""
        return self.post(
            "/code/solutions",
            data=orjson_dumps(
                {
                    "solution": solution.model_dump(),
                    "optimisationId": optimisation_id,
                    "projectId": project_id,
                }
            ),
        )

    @authenticated
    def evaluate_solution(
        self,
        solution_id: UUID,
        evaluation_repetitions: int = 1,
        custom_worker_name: str | None = None,
        custom_command: str | None = None,
        unit_test: bool = False,
        user_id: str | None = None,
    ) -> None:
        """Appends a construct to a project."""
        user_id = user_id or self.headers.get("x-user-override", None)
        if user_id is None:
            raise ValueError(
                "Client has no way to populate `user_id`. Needs to be setup in the client settings or passed into the function."
            )
        return self.post(
            f"/code/solutions/{solution_id}/evaluate",
            params={
                "customWorkerName": custom_worker_name,
                "evaluationRepetitions": evaluation_repetitions,
                "forceRun": True,
                "unitTest": unit_test,
                "customCommand": custom_command,
                "userId": user_id,
            },
        )

    @authenticated
    def execute_scoring_task(
        self,
        project_id: str,
        spec_ids: list[str],
        models: list[str],
        prompt_ids: list[str],
        method: RerankMethodEnum | str = RerankMethodEnum.ZERO_SHOT,
    ) -> SpecScoreResponse:
        """Retrieves the model describing a project by id"""
        return SpecScoreResponse.model_validate(
            self.post(
                "/code/versions/scores",
                json={
                    "spec_ids": spec_ids,
                    "models": models,
                    "prompt_ids": prompt_ids,
                    "project_id": project_id,
                    "method": method,
                },
            )
        )

    @authenticated
    def get_scores(
        self, spec_ids: list[str], models: list[str] | None = None, prompt_ids: list[str] | None = None
    ) -> SpecScoreInfoResponse:
        """Retrieves the model describing a project by id"""
        models = models or []
        prompt_ids = prompt_ids or []
        return SpecScoreInfoResponse.model_validate(
            self.post(
                "/code/versions/scores/list",
                json={"spec_ids": spec_ids, "models": models, "prompt_ids": prompt_ids},
            )
        )

    @authenticated
    def add_scores(self, spec_id: str, source_id: str | None, scores: SpecScoreUpdateRequest):
        """Appends a construct to a project."""
        endpoint = f"/code/versions/{spec_id}/scores"
        if source_id:
            endpoint += f"/{source_id}"
        return self.post(endpoint, json=scores.model_dump(mode="json"))

    @authenticated
    def add_scores_batch(self, scores: BatchSpecScoreUpdateRequest):
        """Appends a construct to a project."""
        return self.post("/code/versions/scores/list/update", json=scores.model_dump(mode="json"))

    @authenticated
    def execute_recommendation_task(
        self, request: CodeAIMultiOptimiseRequest, create_process: bool = True
    ) -> CodeAIMultiOptimiseResponse:
        """Create a recommendation task"""
        return CodeAIMultiOptimiseResponse.model_validate(
            self.post(
                "/code/versions/recommend/async",
                json=request.model_dump(mode="json"),
                params={"createProcess": create_process},
            )
        )

    @authenticated
    def add_hardware(self, hardware: HardwareInfoRequest) -> HardwareInfoResponse:
        """Appends a construct to a project."""
        return HardwareInfoResponse.model_validate(self.post("/code/hardware", json=hardware.model_dump(mode="json")))

    @authenticated
    def add_solution_file(self, solution_id: str, file: FileId):
        """Appends a construct to a project."""
        self.post(f"/code/solutions/{solution_id}/file", json={"file_id": file})

    @authenticated
    def add_solution_results(self, solution_id: str, results: SolutionResultsRequest):
        """Appends a construct to a project."""
        self.post(
            f"/code/solutions/{solution_id}/results",
            json=results.model_dump(mode="json"),
        )

    @authenticated
    def get_constructs_info(
        self, project_id: str, construct_ids: list[str] | None = None
    ) -> dict[UUID, ConcreteConstructResponse]:
        """Retrieves a list of selected constructs information for a given project.

        Args:
            project_id:
                Unique id of a Falcon extraction run.
            construct_ids (Optional[List[UUID]]):
                A subset of ids. If not provided (None), selects all
                available columns. If provided, only downloads the given
                indexes.

        Returns:
            construct_info (Dict[UUID, ConcreteConstruct]):
                A dictionary of information for each selected column.
        """

        body: dict[str, Any] = {"perPage": -1}
        if construct_ids:
            body["filters"] = [{"type": "snippets", "params": {"ids": construct_ids}}]

        construct_info = (
            PaginatedBase[ConcreteConstructResponse]
            .model_validate(
                self.post(
                    f"/code/projects/{project_id}/constructs/search",
                    data=orjson_dumps(body),
                )
            )
            .docs
        )
        return {c.id: c for c in construct_info}

    @authenticated
    def get_specs(
        self,
        spec_ids: list[str | UUID],
        with_context: bool = False,
        sources: Literal["none", "root", "sources"] = "none",
    ) -> dict[UUID, CustomSpecChildResponse]:
        """Retrieves a paginated list of constructs"""
        return CustomSpecBatchResponse.model_validate(
            self.post(
                "/code/versions/list",
                json={"spec_ids": [str(id_) for id_ in spec_ids]},
                params={"with_context": with_context, "sources": sources},
            )
        ).root

    @authenticated
    def get_metric_prompts(self, metric_prompt_ids: list[str]) -> PromptListResponse:
        """Retrieves a list of metric prompts"""

        return PromptListResponse.model_validate(
            self.post("/code/ai/prompts/project/list", data=orjson_dumps(metric_prompt_ids))
        )

    @authenticated
    def get_global_prompts(self, task: str, page: int = 1, per_page: int = 10) -> PromptListResponse:
        return PromptListResponse.model_validate(
            {
                "prompts": self.get(
                    "/code/ai/globalprompts",
                    params={
                        "task_type": task,
                        "page": page,
                        "perPage": per_page,
                    },
                )["docs"]
            }
        )

    @authenticated
    def get_project_prompts(self, project_id: str, task: str, page: int = 1, per_page: int = 10) -> PromptListResponse:
        return PromptListResponse.model_validate(
            {
                "prompts": self.get(
                    f"/code/ai/prompts/{project_id}",
                    params={
                        "task_type": task,
                        "page": page,
                        "perPage": per_page,
                    },
                )["docs"]
            }
        )

    @authenticated
    def get_prompt(self, prompt_id: str) -> ProjectPromptResponse:
        return ProjectPromptResponse.model_validate(self.get(f"/code/ai/prompt/{prompt_id}"))

    @authenticated
    def add_prompt(self, prompt: ProjectPromptRequest, project_id: str) -> ProjectPromptResponse:
        return ProjectPromptResponse.model_validate(
            self.post(f"/code/ai/prompts/{project_id}", data=orjson_dumps(prompt.model_dump()))
        )

    @authenticated
    def clear_constructs(self, extraction_id: str):
        """Clears all constructs related to a project"""
        self.delete(f"/code/extraction/{extraction_id}/constructs")

    @authenticated
    def patch_construct_specs(self, construct_id: str, updated_info: list[Any]):
        """Updates a project's details"""
        return self.patch(f"/code/constructs/{construct_id}/custom", json=updated_info)

    @authenticated
    def patch_version(self, version_id: str, updated_info: list[Any]):
        """Updates a project's details"""
        return self.patch(f"/code/versions/{version_id}", json=updated_info)

    @authenticated
    def filter_project(
        self,
        project_id: str,
        types: list[ValidationFilterTypeEnum],
        custom_worker_name: str | None,
        create_process: bool,
        constructs: dict[str, list[str]],
        custom_command: str | None = None,
        user_id: str | None = None,
    ) -> FilteringRunResponse:
        """Add a filtering run"""
        return FilteringRunResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/filter",
                params={
                    "customWorkerName": custom_worker_name,
                    "createProcess": create_process,
                    "userId": user_id,
                },
                json={
                    "types": types,
                    "constructs": constructs,
                    "customCommand": custom_command,
                },
            )
        )

    @authenticated
    def put_tool(self, tool_name: str) -> ToolCreationResponse:
        """Updates a project's details"""
        return ToolCreationResponse.model_validate(self.put("/code/tools", json={"tool_name": tool_name}))

    @authenticated
    def get_pair_coder_run(self, pair_coder_run_id: str) -> PairCoderRequestResponse:
        """Retrieves the model describing a pair coder run by id"""
        return PairCoderRequestResponse.model_validate(self.get(f"/code/pair-code-runs/{pair_coder_run_id}"))

    @authenticated
    def finish_pair_coder_run(self, pair_coder_run_id: str, updated_info: Dict[str, Any]) -> PairCoderRequestResponse:
        """Updates a pair coder run's details and completes it"""
        return PairCoderRequestResponse.model_validate(
            self.post(f"/code/pair-code-runs/{pair_coder_run_id}/finish", json=updated_info)
        )

    @authenticated
    def get_report_data(
        self,
        construct_filter: ConstructFilter | None = None,
        project_id: UUID | None = None,
        solution_id: UUID | None = None,
        nr_diffs: int = 10,
    ) -> InternalReportData:
        """Get report run data needed to render the report file.

        Args:
            construct_filter: Filter criteria for constructs
            project_id: Optional UUID of the project
            solution_id: Optional UUID of the solution
            nr_diffs: Number of diff explanations to include (default: 10)

        Returns:
            InternalReportData containing all the report information
        """
        params = {}
        if project_id:
            params["project_id"] = str(project_id)
        if solution_id:
            params["solution_id"] = str(solution_id)
        params["nr_diffs"] = str(nr_diffs)

        if not construct_filter:
            construct_filter = ConstructFilter(filters=[])
        return InternalReportData.model_validate(
            self.post("/code/reports/data", params=params, json=construct_filter.dict())
        )

    @authenticated
    def get_report_run(self, report_run_id: str) -> ReportRequestResponse:
        """Retrieves the model describing a report run by id"""
        return ReportRequestResponse.model_validate(self.get(f"/code/reports/{report_run_id}"))

    @authenticated
    def finish_report_run(self, report_run_id: str, updated_info: Dict[str, Any]) -> ReportRequestResponse:
        """Updates a report run's details and completes it"""
        response = self.post(f"/code/reports/{report_run_id}/finish", json=updated_info)
        return ReportRequestResponse.model_validate(response)

    @authenticated
    def download_version(self, project_id: str, changeset_id: str, version_sha: str, output_path: Path):
        """
        Download a specific version of a project as a ZIP file.

        Args:
            project_id: ID of the project
            version_sha: SHA of the version to download

        Returns:
            bytes: ZIP file content
        """
        self.download_file(
            f"/code/projects/{project_id}/changesets/{changeset_id}/versions/{version_sha}/download",
            output_path,
            HTTPMethod.POST,
        )

    @authenticated
    def create_changeset(
        self, project_id: str, name: str, description: str = "", spec_ids: list[str] = []
    ) -> ChangesetResponse:
        """Create new changeset

        Args:
            project_id: ID of the project
            name: name of changeset
            description: description of changeset

        Returns:
            ChangesetResponse: the changeset
        """
        return ChangesetResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/changesets",
                json=ChangesetCreateRequest(
                    name=name, description=description, spec_ids=[UUID(spec_id) for spec_id in spec_ids]
                ).model_dump(mode="json"),
            )
        )

    @authenticated
    def get_changeset(self, project_id: str, changeset_id: str) -> ChangesetResponse:
        """
        Get a changeset by ID.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset

        Returns:
            ChangesetResponse: Details of the changeset
        """
        return ChangesetResponse.model_validate(self.get(f"/code/projects/{project_id}/changesets/{changeset_id}"))

    @authenticated
    def get_changeset_versions(self, project_id: str, changeset_id: str) -> ChangesetVersionsResponse:
        """
        Get all version SHAs in a changeset branch.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset

        Returns:
            FilesResponse: the files
        """
        return ChangesetVersionsResponse.model_validate(
            self.get(f"/code/projects/{project_id}/changesets/{changeset_id}/versions")
        )

    @authenticated
    def compare_changeset_versions(
        self, project_id: str, changeset_id: str, base_version_sha: str, head_version_sha: str
    ) -> ChangesetVersionCompareResponse:
        """
        Compare two version SHAs in a changeset branch.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            base_version_sha: SHA of commit to compare against
            head_version_sha: SHA of commit to compare from

        Returns:
            FilesResponse: the files
        """
        return ChangesetVersionCompareResponse.model_validate(
            self.get(
                f"/code/projects/{project_id}/changesets/{changeset_id}/{base_version_sha}/diff/{head_version_sha}"
            )
        )

    @authenticated
    def get_changeset_files(self, project_id: str, version_sha: str) -> FilesResponse:
        """
        Get all file paths in a changeset branch.

        Args:
            project_id: ID of the project
            version_sha: SHA of the version to download

        Returns:
            FilesResponse: the files
        """
        return FilesResponse.model_validate(self.get(f"/code/projects/{project_id}/changesets/{version_sha}/files"))

    @authenticated
    def get_file_content(self, project_id: str, version_sha: str, file_path: str) -> FileContentResponse:
        """
        Get file content from a selected file.

        Args:
            project_id: ID of the project
            version_sha: SHA of the version to download

        Returns:
            FileContentResponse: the content of the file
        """
        return FileContentResponse.model_validate(
            self.get(f"/code/projects/{project_id}/changesets/{version_sha}/content", params={"file_path": file_path})
        )

    @authenticated
    def create_changeset_version(
        self, project_id: str, changeset_id: str, request: VersionCreateRequest
    ) -> ChangesetVersionResponse:
        """
        Create a new changeset version

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            request: request (contains commit msg and changes)

        Returns:
            ChangesetVersionResponse: changeset info for version (with sha)
        """
        return ChangesetVersionResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/changesets/{changeset_id}/versions",
                json=request.model_dump(mode="json"),
            )
        )

    @authenticated
    def patch_changeset_agent_run(self, project_id: str, changeset_id: str, agent_run_id: str, final_sha: str) -> None:
        """
        Patch a changeset coder run with the final sha

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            agent_run_id: ID of the agent run
            final_sha: the SHA of the output version from the agent
        """
        self.patch(
            f"/code/projects/{project_id}/changesets/{changeset_id}/agent",
            json={"agent_run_id": agent_run_id, "final_sha": final_sha},
        )

    @authenticated
    def push_changeset_to_git_provider(
        self,
        project_id: UUID | str,
        changeset_id: UUID | str,
        version_sha: str,
        branch_name: str,
        commit_message: str,
        provider: str,
    ) -> GitProviderPushResponse:
        """
        Push a changeset branch to a git provider (e.g., GitHub).

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            version_sha: SHA of the version to push
            branch_name: Name of the branch to create/push to
            commit_message: Commit message for the push
            provider: Git provider

        Returns:
            GitProviderPushResponse: Response containing push status and details
        """
        push_request_data = {
            "version_sha": version_sha,
            "branch_name": branch_name,
            "commit_message": commit_message,
            "provider": provider,
        }

        result = self.post(
            f"/code/projects/{project_id}/changesets/{changeset_id}/push-to-git-provider",
            json=push_request_data,
        )

        return GitProviderPushResponse(
            status=Status(result["status"]),
            branch=result["branch"],
            merge_conflict=result.get("merge_conflict", False),
            merge_conflict_files=result.get("merge_conflict_files", []),
            message=result.get("message", ""),
            conflict_resolution_pr_url=result.get("conflict_resolution_pr_url"),
        )

    @authenticated
    def create_git_provider_pull_request(
        self,
        project_id: UUID | str,
        changeset_id: UUID | str,
        title: str,
        body: str,
        branch: str,
        base_branch: str,
        provider: str,
    ) -> GitProviderPullRequestResponse:
        """
        Create a pull request on a git provider for a changeset branch.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            title: Title of the pull request
            body: Body/description of the pull request
            branch: Source branch for the PR
            base_branch: Target/base branch for the PR
            provider: Git provider

        Returns:
            GitProviderPullRequestResponse: Response containing PR creation status and URL
        """
        pr_request_data = {
            "title": title,
            "body": body,
            "head": branch,
            "base": base_branch,
            "provider": provider,
        }

        result = self.post(
            f"/code/projects/{project_id}/changesets/{changeset_id}/create-git-provider-pr",
            json=pr_request_data,
        )

        return GitProviderPullRequestResponse(
            status=Status(result["status"]),
            pull_request_url=result.get("pullRequestUrl"),
        )

    @authenticated
    def determine_changeset_pr_details(
        self,
        project_id: str,
        changeset_id: str,
        request: ChangesetPRDetailsRequest,
    ) -> ChangesetPRDetailsResponse:
        """
        Generate PR details for a changeset based on its current state.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            request: Request containing context for PR details generation

        Returns:
            ChangesetPRDetailsResponse: Generated branch name, PR title, and description
        """
        return ChangesetPRDetailsResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/changesets/{changeset_id}/pr-details",
                json=request.model_dump(mode="json"),
            )
        )

    # ───────────────────────── changeset validations ────────────────────────── #

    @authenticated
    def create_changeset_validation(
        self,
        project_id: str,
        changeset_id: str,
        version_sha: str,
        commands: list[dict[str, Any]],
        custom_worker_name: str,
        user_id: str,
    ) -> ChangesetValidationResponse:
        """
        Create a new validation for a changeset version.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            version_sha: SHA of the version to validate
            commands: List of command details (order and command)
            custom_worker_name: name of worker to run validation
            user_id: id of the user

        Returns:
            ChangesetValidationResponse: Details of the created validation
        """
        validation_request = ChangesetValidationRequest(
            changeset_id=changeset_id,
            version_sha=version_sha,
            commands=commands,
            custom_worker_name=custom_worker_name,
            userId=user_id,
        )

        return ChangesetValidationResponse.model_validate(
            self.post(
                f"/code/projects/{project_id}/changesets/{changeset_id}/versions/{version_sha}/validate",
                json=validation_request.model_dump(mode="json"),
            )
        )

    @authenticated
    def get_changeset_validation(self, project_id: str, validation_id: str) -> ChangesetValidationResponse:
        """
        Get a validation by ID.

        Args:
            project_id: ID of the project
            validation_id: ID of the validation

        Returns:
            ChangesetValidationResponse: Details of the validation
        """
        return ChangesetValidationResponse.model_validate(
            self.get(f"/code/projects/{project_id}/changesets/validations/{validation_id}")
        )

    @authenticated
    def update_validation_command(
        self,
        project_id: str,
        command_id: str,
        log_id: UUID | None,
        exit_code: int | None = None,
        runtime: float | None = None,
        cpu: float | None = None,
        memory: float | None = None,
        status: ExecutionStatusEnum = ExecutionStatusEnum.pending,
    ) -> ChangesetValidationCommandResponse:
        """
        Update a command with execution results.

        Args:
            project_id: ID of the project
            command_id: ID of the command
            log_id: Optional reference to external log data
            passed: Whether the command execution passed validation
            exit_code: Exit code of the command execution
            runtime: Time taken to execute the command in seconds
            cpu: CPU usage during command execution (percentage)
            memory: Memory usage during command execution (MB)
            status: Status of the validation command execution

        Returns:
            ChangesetValidationCommandResponse: The updated command
        """
        result_request = ChangesetCommandUpdateRequest(
            log_id=log_id, exit_code=exit_code, runtime=runtime, cpu=cpu, memory=memory, status=status
        )

        return ChangesetValidationCommandResponse.model_validate(
            self.patch(
                f"/code/projects/{project_id}/changesets/validations/commands/{command_id}",
                json=result_request.model_dump(mode="json"),
            )
        )

    @authenticated
    def get_validation_commands(self, project_id: str, validation_id: str) -> list[ChangesetValidationCommandResponse]:
        """
        Get commands for a validation.

        Args:
            project_id: ID of the project
            validation_id: ID of the validation

        Returns:
            List[ChangesetValidationCommandResponse]: The validation commands
        """
        response = self.get(f"/code/projects/{project_id}/changesets/validations/{validation_id}/commands")
        return [ChangesetValidationCommandResponse.model_validate(cmd) for cmd in response]

    # ───────────────────────── issues and observations ────────────────────────── #

    @authenticated
    def create_observation(self, observation: ObservationCreate) -> ObservationResponse:
        """
        Create a new observation.

        Args:
            observation: Observation creation details

        Returns:
            ObservationResponse: The created observation
        """
        return ObservationResponse.model_validate(
            self.post("/code/observations", json=observation.model_dump(mode="json"))
        )

    @authenticated
    def create_issues(self, bulk_issues: IssuesCreateBulk) -> None:
        """
        Create multiple issues at once.

        Args:
            bulk_issues: Bulk issue creation request containing list of issues
        """
        self.post("/code/issues", json=bulk_issues.model_dump(mode="json"))

    @authenticated
    def delete_issue(self, issue_id: str) -> dict:
        """
        Delete an issue.

        Args:
            issue_id: ID of the issue to delete

        Returns:
            dict: Success message
        """
        return self.delete(f"/code/issues/{issue_id}")

    @authenticated
    def get_issues_paginated(
        self,
        project_id: str,
        page: int = 1,
        per_page: int = 10,
        min_severity: float | None = None,
        max_severity: float | None = None,
        audit_run_id: str | None = None,
    ) -> PaginatedIssuesWithObservationResponse:
        """
        Get paginated list of issues with optional filters.

        Args:
            project_id: Project ID to filter by
            page: Page number (default: 1)
            per_page: Items per page (default: 10)
            min_severity: Minimum severity filter (0-10)
            max_severity: Maximum severity filter (0-10)
            audit_run_id: Filter by audit run ID

        Returns:
            PaginatedIssuesWithObservationResponse: Paginated issues response
        """
        params = {
            "projectId": project_id,
            "page": page,
            "perPage": per_page,
        }
        if min_severity is not None:
            params["minSeverity"] = min_severity
        if max_severity is not None:
            params["maxSeverity"] = max_severity
        if audit_run_id is not None:
            params["auditRunId"] = audit_run_id

        return PaginatedIssuesWithObservationResponse.model_validate(self.get("/code/issues", params=params))

    @authenticated
    def get_issue(self, issue_id: str) -> IssueWithObservationResponse:
        """
        Get a single issue with its observation.

        Args:
            issue_id: ID of the issue

        Returns:
            IssueWithObservationResponse: Issue with observation details
        """
        return IssueWithObservationResponse.model_validate(self.get(f"/code/issues/{issue_id}"))

    @authenticated
    def search_issues(self, filter: PaginatedIssueFilter, project_id: str) -> PaginatedIssuesWithObservationResponse:
        """
        Search issues with advanced filtering, sorting, and grouping.

        Args:
            filter: Advanced filter parameters
            project_id: Project ID to scope the search

        Returns:
            PaginatedIssuesWithObservationResponse: Filtered issues response
        """
        return PaginatedIssuesWithObservationResponse.model_validate(
            self.post(
                f"/code/issues/search?projectId={project_id}",
                json=filter.model_dump(mode="json"),
            )
        )

    @authenticated
    def get_issue_stats(self, filter: PaginatedIssueFilter, project_id: str) -> IssueStatsResponse:
        """
        Get issue statistics for filter sidebar.

        Args:
            filter: Filter parameters
            project_id: Project ID to scope the stats

        Returns:
            IssueStatsResponse: Issue statistics
        """
        return IssueStatsResponse.model_validate(
            self.post(
                f"/code/issues/stats?projectId={project_id}",
                json=filter.model_dump(mode="json"),
            )
        )

    @authenticated
    def delete_issues_bulk(self, issue_ids: list[str], project_id: str) -> dict:
        """
        Delete multiple issues at once.

        Args:
            issue_ids: List of issue IDs to delete
            project_id: Project ID that the issues belong to

        Returns:
            dict: Deletion result with count of deleted issues
        """
        request = IssuesDeleteBulk(issue_ids=[UUID(id_) for id_ in issue_ids])
        return self.post(
            f"/code/issues/delete?projectId={project_id}",
            json=request.model_dump(mode="json"),
        )

    # ───────────────────────── rules ────────────────────────── #

    @authenticated
    def create_rule(self, rule: RuleCreate) -> RuleResponse:
        """
        Create a new audit rule.

        Args:
            rule: Rule creation details

        Returns:
            RuleResponse: The created rule
        """
        return RuleResponse.model_validate(self.post("/code/rules", json=rule.model_dump(mode="json")))

    @authenticated
    def get_rule(self, rule_id: str) -> RuleResponse:
        """
        Get a single rule by ID.

        Args:
            rule_id: ID of the rule

        Returns:
            RuleResponse: Rule details
        """
        return RuleResponse.model_validate(self.get(f"/code/rules/{rule_id}"))

    @authenticated
    def update_rule(self, rule_id: str, update_data: RuleUpdate) -> RuleResponse:
        """
        Update an existing rule.

        Args:
            rule_id: ID of the rule to update
            update_data: Rule update data

        Returns:
            RuleResponse: The updated rule
        """
        return RuleResponse.model_validate(self.put(f"/code/rules/{rule_id}", json=update_data.model_dump(mode="json")))

    @authenticated
    def delete_rule(self, rule_id: str) -> dict:
        """
        Delete a rule.

        Args:
            rule_id: ID of the rule to delete

        Returns:
            dict: Success message
        """
        return self.delete(f"/code/rules/{rule_id}")

    @authenticated
    def get_rules_paginated(
        self,
        project_id: str,
        page: int = 1,
        per_page: int = 10,
        enabled_only: bool = False,
        tags: list[str] | None = None,
    ) -> PaginatedRuleResponse:
        """
        Get paginated list of rules with filters.

        Args:
            project_id: Project ID to filter by
            page: Page number (default: 1)
            per_page: Items per page (default: 10)
            enabled_only: Only return enabled rules (default: False)
            tags: Filter by tags (returns rules with any of these tags)

        Returns:
            PaginatedRuleResponse: Paginated rules response
        """
        params = {
            "projectId": project_id,
            "page": page,
            "perPage": per_page,
            "enabledOnly": enabled_only,
        }
        if tags:
            params["tags"] = tags

        return PaginatedRuleResponse.model_validate(self.get("/code/rules", params=params))

    # ──────────────────────────── user settings ───────────────────────────── #

    @authenticated
    def create_user_settings(self, request: UserSettingsRequest) -> UserSettingsResponse:
        """
        Create new user settings.

        Args:
            request: UserSettingsRequest containing the settings data

        Returns:
            UserSettingsResponse with the created settings
        """
        return UserSettingsResponse.model_validate(
            self.post(
                "/code/user_settings",
                json=request.model_dump(mode="json"),
            )
        )

    @authenticated
    def get_user_settings(self, user_id: str) -> UserSettingsResponse:
        """
        Get user settings by user ID.

        Args:
            user_id: The user ID to retrieve settings for

        Returns:
            UserSettingsResponse with the settings
        """
        return UserSettingsResponse.model_validate(self.get(f"/code/user_settings/{user_id}"))

    @authenticated
    def search_user_settings(
        self,
        pagination_params: PaginationParams | None = None,
        user_ids: list[str] | None = None,
    ) -> PaginatedUserSettingsResponse:
        """
        Search user settings with optional filtering and pagination.

        Args:
            pagination_params: Pagination parameters
            user_ids: Optional list of user IDs to filter by

        Returns:
            PaginatedUserSettingsResponse with the settings
        """
        params = {}
        if pagination_params:
            params.update(pagination_params.model_dump())
        if user_ids:
            params["user_ids"] = user_ids

        return PaginatedUserSettingsResponse.model_validate(self.get("/code/user_settings", params=params))

    @authenticated
    def update_user_settings(self, user_id: str, request: UserSettingsPatchRequest) -> UserSettingsResponse:
        """
        Update user settings (full update).

        Args:
            user_id: The user ID
            request: UserSettingsPatchRequest with new data

        Returns:
            UserSettingsResponse with updated settings
        """
        return UserSettingsResponse.model_validate(
            self.put(
                f"/code/user_settings/{user_id}",
                json=request.model_dump(mode="json"),
            )
        )

    @authenticated
    def patch_user_settings(self, user_id: str, request: UserSettingsPatchRequest) -> UserSettingsResponse:
        """
        Patch user settings (partial update).

        Args:
            user_id: The user ID
            request: UserSettingsPatchRequest with fields to update

        Returns:
            UserSettingsResponse with updated settings
        """
        return UserSettingsResponse.model_validate(
            self.patch(
                f"/code/user_settings/{user_id}",
                json=request.model_dump(mode="json"),
            )
        )

    @authenticated
    def delete_user_settings(self, user_id: str) -> None:
        """
        Delete user settings.

        Args:
            user_id: The user ID to delete settings for
        """
        self.delete(f"/code/user_settings/{user_id}")


class FalconAsyncClient(BaseAuthAsyncClient):
    def __init__(
        self,
        falcon_settings: FalconSettings,
        thanos_settings: ThanosSettings,
    ):
        self.falcon_settings = falcon_settings
        super().__init__(falcon_settings, thanos_settings)

        self.token = None
        self.token_expires = time.time()
        if self.falcon_settings.user_override:
            self.headers.update({"x-user-override": self.falcon_settings.user_override})

    # ──────────────────────────── regular files ───────────────────────────── #

    @async_authenticated
    async def search_project_files(
        self, project_id: str, request: ProjectFileSearchRequest
    ) -> ProjectFileSearchResponse:
        """Retrieves the model describing a project by id"""
        return ProjectFileSearchResponse.model_validate(
            (
                await self.post(
                    f"/code/projects/{project_id}/file-search",
                    json=request.model_dump(mode="json"),
                )
            )
        )

    @async_authenticated
    async def get_project_file(self, project_id: str, file_name: str) -> str:
        """Retrieves the file content from a project"""
        response = await self.request(method=HTTPMethod.GET, url=f"/code/projects/{project_id}/file?name={file_name}")
        return response.text

    @async_authenticated
    async def get_project(self, project_id: str) -> ProjectInfoResponse:
        """Retrieves the model describing a project by id"""
        return ProjectInfoResponse.model_validate((await self.get(f"/code/projects/{project_id}")))

    @async_authenticated
    async def init_project(self, project_id: str) -> ProjectInfoResponse:
        """Initialises project"""
        return ProjectInfoResponse.model_validate((await self.post(f"/code/projects/{project_id}/init", timeout=60.0)))

    @async_authenticated
    async def get_project_diff(self, project_id: str, request: ProjectGitDiffRequest) -> ProjectGitDiffResponse:
        """Gets diff between a specific branch and the current branch of the project"""
        return ProjectGitDiffResponse.model_validate(
            (
                await self.post(
                    f"/code/projects/{project_id}/diff",
                    json=request.model_dump(mode="json"),
                )
            )
        )

    @async_authenticated
    async def get_project_user_lines(
        self, project_id: str, git_filter: GitFilter | None = None
    ) -> GitUserLinesResponse:
        """Gets user code of the current branch of the project"""
        params = {}
        if git_filter:
            params = git_filter.model_dump(mode="json", by_alias=True, exclude_none=True)
        return GitUserLinesResponse.model_validate(
            await self.get(
                f"/code/projects/{project_id}/user-code",
                params=params,
            )
        )

    @async_authenticated
    async def get_projects(
        self, search: str | None = None, is_embedded: bool | None = None
    ) -> PaginatedProjectInfoResponse:
        """Retrieves a list of all projects."""
        url = f"/code/projects?search={search}" if search else "/code/projects"
        extra_params: dict[str, str] = {}
        if search is not None:
            extra_params["search"] = search
        if is_embedded is not None:
            extra_params["isEmbedded"] = str(is_embedded).lower()
        return PaginatedProjectInfoResponse.model_validate((await self.get(url, params=extra_params)))

    @async_authenticated
    async def patch_project(self, project_id: str, updated_info: dict[str, Any]) -> ProjectInfoResponse:
        """Updates a project's details"""
        return ProjectInfoResponse.model_validate((await self.patch(f"/code/projects/{project_id}", json=updated_info)))

    @async_authenticated
    async def patch_project_run(self, project_run_id: str, updated_info: dict[str, Any]) -> ProjectIngestRunResponse:
        """Updates a project run's details"""
        res = await self.patch(f"/code/projects/run/{project_run_id}", json=updated_info)
        return ProjectIngestRunResponse.model_validate(res)

    @async_authenticated
    async def get_extraction(self, extraction_id: str) -> ExtractionRunResponse:
        """Retrieves the model describing an extraction run by id"""
        return ExtractionRunResponse.model_validate((await self.get(f"/code/extraction/{extraction_id}")))

    @async_authenticated
    async def patch_extraction(self, extraction_id: str, updated_info: dict[str, Any]) -> ExtractionRunResponse:
        """Updates an extractions' details"""
        return ExtractionRunResponse.model_validate(
            (await self.patch(f"/code/extraction/{extraction_id}", json=updated_info))
        )

    @async_authenticated
    async def add_extraction_log(self, extraction_id: str, file_id: str) -> dict[str, str]:
        """Retrieves the model describing an extraction run by id"""
        return await self.post(f"/code/extraction/{extraction_id}/log?file_id={file_id}")

    @async_authenticated
    async def get_filtering(self, project_id: str) -> FilteringRunResponse:
        """Retrieves the model describing a project by id"""
        return FilteringRunResponse.model_validate((await self.get(f"/code/filtering/{project_id}")))

    @async_authenticated
    async def get_spec_filtering_results(self, spec_ids: list[str]) -> dict[UUID, list[FilteringResultResponse]]:
        """Retrieves the model describing a project by id"""
        request = SpecFilterRequest(spec_ids=[UUID(id_) for id_ in spec_ids])
        response = await self.post("/code/versions/validation/list", json=request.model_dump(mode="json"))
        deserialized_response: dict[UUID, list[FilteringResultResponse]] = {}
        for key, values in response.items():
            deserialized_response[UUID(key)] = [FilteringResultResponse.model_validate(value) for value in values]
        return deserialized_response

    @async_authenticated
    async def get_rerank(self, rerank_id: str) -> RerankRunResponse:
        """Retrieves the model describing a project by id"""
        return RerankRunResponse.model_validate((await self.get(f"/code/projects/rerank/{rerank_id}")))

    @async_authenticated
    async def get_embedding(self, embedding_run_id: str) -> EmbeddingRunResponse:
        """Retrieves the model describing a project by id"""
        return EmbeddingRunResponse.model_validate((await self.get(f"/code/projects/embeddings/{embedding_run_id}")))

    @async_authenticated
    async def get_optimisation(self, optimisation_id: str) -> OptimisationRunResponse:
        """Retrieves the model describing an extraction run by id"""
        return OptimisationRunResponse.model_validate((await self.get(f"/code/optimisations/{optimisation_id}")))

    @async_authenticated
    async def patch_optimisation(self, optimisation_id: str, updated_info: dict[str, Any]) -> OptimisationRunResponse:
        """Updates a project's details"""
        return OptimisationRunResponse.model_validate(
            (await self.patch(f"/code/optimisations/{optimisation_id}", json=updated_info))
        )

    # ──────────────────────────── regular files ───────────────────────────── #
    @async_authenticated
    async def get_solution(self, solution_id: str) -> FullSolutionInfoResponse:
        """Retrieves the model describing a project by id"""
        return FullSolutionInfoResponse.model_validate((await self.get(f"/code/solutions/{solution_id}")))

    @async_authenticated
    async def get_solutions(self, optimisation_id: str, page: int = 1, per_page: int = 10) -> PaginatedSolutionResponse:
        """Retrieves a paginated list of solutions for an optimisation.

        Args:
            optimisation_id: Unique id of the optimisation
            page: Page number (default: 1)
            per_page: Number of items per page, -1 for all (default: 10)
        """
        return PaginatedSolutionResponse.model_validate(
            await self.get(
                f"/code/optimisations/{optimisation_id}/solutions",
                params={"page": page, "perPage": per_page},
            )
        )

    # ────────────────────────────   Process Utils  ───────────────────────────── #

    @async_authenticated
    async def create_log_group(self) -> LogGroupInfoResponse:
        """Retrieves the model describing a project by id"""
        return LogGroupInfoResponse.model_validate((await self.post("/utils/logs")))

    @async_authenticated
    async def get_log_group(self, log_group_id: str) -> LogGroupResponse:
        """Retrieves the model describing a project by id"""
        return LogGroupResponse.model_validate((await self.get(f"/utils/logs/{log_group_id}")))

    @async_authenticated
    async def send_process_details(self, process_id: UUID, details: dict[str, Any]):
        """Retrieves the model describing a project by id"""
        return await self.post(f"/utils/process/{process_id}/details", data=orjson_dumps(details))

    @async_authenticated
    async def update_process_status(self, process_id: UUID, status: ExecutionStatusEnum):
        """Retrieves the model describing a project by id"""
        return (await self.post(f"/utils/process/{process_id}/status", json={"status": status})).json()

    @async_authenticated
    async def update_process_progress(self, process_id: UUID, progress: float):
        """Retrieves the model describing a project by id"""
        return (await self.post(f"/utils/process/{process_id}/progress", json={"progress": progress})).json()

    @async_authenticated
    async def get_process(self, process_id: UUID) -> ProcessStatusResponse:
        """Retrieves the model describing a project by id"""
        return ProcessStatusResponse.model_validate((await self.get(f"/utils/process/{process_id}")))

    @async_authenticated
    async def get_process_logs(self, process_id: UUID) -> LogGroupResponse:
        """Retrieves the model describing a project by id"""
        return LogGroupResponse.model_validate((await self.get(f"/utils/process/{process_id}/logs")))

    # ──────────────────────────── columns infos ───────────────────────────── #

    @async_authenticated
    async def verify_construct(
        self,
        project_id: str,
        filtering_id: str,
        construct_id: str | None,
        spec_id: str | None,
        filter_type: ValidationFilterTypeEnum,
        passed: bool,
        logs: str = "",
    ) -> dict[str, Any]:
        """Verifies a construct"""
        body = {
            "projectId": project_id,
            "specId": spec_id,
            "constructId": construct_id,
            "passed": passed,
            "type": filter_type,
        }
        if logs:
            body["logs"] = logs
        return await self.post(
            f"/code/filtering/{str(filtering_id)}/result",
            data=orjson_dumps(body),
        )

    @async_authenticated
    async def get_construct(self, construct_id: str) -> ConcreteConstructResponse:
        """Retrieves a construct by id"""
        return ConcreteConstructResponse.model_validate((await self.get(f"/code/constructs/{construct_id}")))

    @async_authenticated
    async def get_spec(self, spec_id: str, sources: str, construct: bool = False) -> CustomSpecResponse:
        """Retrieves a construct by id"""
        return CustomSpecResponse.model_validate(
            (await self.get(f"/code/versions/{spec_id}?sources={sources}&construct={construct}"))
        )

    @async_authenticated
    async def post_log(self, log_id: str, log_addition: LogAdditionRequest) -> None:
        await self.post(f"/utils/logs/{log_id}", data=orjson_dumps(log_addition.model_dump()))

    @async_authenticated
    async def add_constructs(
        self,
        project_id: str,
        extraction_id: str,
        construct: ConcreteConstructBatchRequest,
    ) -> ConstructCreationResponse:
        """Appends a construct to a project."""
        endpoint = f"/code/projects/{project_id}/constructs"
        if extraction_id:
            endpoint += f"?extractionId={extraction_id}"
        return ConstructCreationResponse.model_validate(
            (
                await self.post(
                    endpoint,
                    data=orjson_dumps({"constructs": construct.model_dump()}).encode(),
                )
            )
        )

    @async_authenticated
    async def new_spec(self, construct_id: UUID, spec: CustomSpecRequest):
        """Appends a construct to a project."""
        (
            await self.post(
                f"/code/constructs/{construct_id}/version",
                data=orjson_dumps(spec.model_dump()).encode(),
            )
        )

    @async_authenticated
    async def new_specs(self, versions: NewVersionsRequest) -> NewVersionsResponse:
        """Appends specs to constructs."""
        return NewVersionsResponse.model_validate(
            (
                await self.post(
                    "/code/versions",
                    data=orjson_dumps({"versions": versions}),
                )
            )
        )

    @async_authenticated
    async def add_solution(self, project_id: str, optimisation_id: str, solution: FullSolutionInfoRequest):
        """Appends a construct to a project."""
        return await self.post(
            "/code/solutions",
            data=orjson_dumps(
                {
                    "solution": solution.model_dump(),
                    "optimisationId": optimisation_id,
                    "projectId": project_id,
                }
            ),
        )

    @async_authenticated
    async def evaluate_solution(
        self,
        solution_id: UUID,
        evaluation_repetitions: int = 1,
        custom_worker_name: str | None = None,
        custom_command: str | None = None,
        unit_test: bool = False,
        user_id: str | None = None,
    ) -> None:
        """Appends a construct to a project."""
        user_id = user_id or self.headers.get("x-user-override", None)
        if user_id is None:
            raise ValueError(
                "Client has no way to populate `user_id`. Needs to be setup in the client settings or passed into the function."
            )
        return await self.post(
            f"/code/solutions/{solution_id}/evaluate",
            params={
                "customWorkerName": custom_worker_name,
                "evaluationRepetitions": evaluation_repetitions,
                "forceRun": True,
                "unitTest": unit_test,
                "customCommand": custom_command,
                "userId": user_id,
            },
        )

    @async_authenticated
    async def add_scores(self, spec_id: str, source_id: str | None, scores: SpecScoreUpdateRequest):
        """Appends a construct to a project."""
        endpoint = f"/code/versions/{spec_id}/scores"
        if source_id:
            endpoint += f"/{source_id}"
        return await self.post(endpoint, json=scores.model_dump(mode="json"))

    @async_authenticated
    async def execute_scoring_task(self, scores: SpecScoreRequest) -> SpecScoreResponse:
        """Create a scoring task."""
        return SpecScoreResponse.model_validate(
            (await self.post("/code/versions/scores", json=scores.model_dump(mode="json")))
        )

    @async_authenticated
    async def execute_recommendation_task(
        self, request: CodeAIMultiOptimiseRequest, create_process: bool = True
    ) -> CodeAIMultiOptimiseResponse:
        """Create a recommendation task"""
        return CodeAIMultiOptimiseResponse.model_validate(
            await self.post(
                "/code/versions/recommend/async",
                json=request.model_dump(mode="json"),
                params={"createProcess": create_process},
            )
        )

    @async_authenticated
    async def add_hardware(self, hardware: HardwareInfoRequest) -> HardwareInfoResponse:
        """Appends a construct to a project."""
        return HardwareInfoResponse.model_validate(
            (await self.post("/code/hardware", json=hardware.model_dump(mode="json")))
        )

    @async_authenticated
    async def add_solution_file(self, solution_id: str, file: FileId):
        """Appends a construct to a project."""
        _ = await self.post(f"/code/solutions/{solution_id}/file", json={"file_id": file})

    @async_authenticated
    async def add_solution_results(self, solution_id: str, results: SolutionResultsRequest):
        """Appends a construct to a project."""
        _ = await self.post(
            f"/code/solutions/{solution_id}/results",
            json=results.model_dump(mode="json"),
        )

    @async_authenticated
    async def get_constructs_info(
        self, project_id: str, ids: list[UUID] | None = None
    ) -> dict[UUID, ConcreteConstruct]:
        """Retrieves a list of selected constructs information for a given project.

        Args:
            project_id:
                Unique id of a Falcon extraction run.
            ids (Optional[List[UUID]]):
                A subset of ids. If not provided (None), selects all
                available columns. If provided, only downloads the given
                indexes.

        Returns:
            construct_info (List[ConcreteConstruct]):
                A list of information for each selected column.
        """

        body: dict[str, Any] = {"perPage": -1}
        if ids:
            body["filters"] = [{"type": "snippets", "params": {"ids": ids}}]
        construct_info = (
            PaginatedBase[ConcreteConstruct]
            .model_validate(
                (
                    await self.post(
                        f"/code/projects/{project_id}/constructs/search",
                        data=orjson_dumps(body),
                    )
                )
            )
            .docs
        )
        return {c.id: c for c in construct_info}

    @async_authenticated
    async def get_specs(
        self, spec_ids: list[str | UUID], with_context: bool = False
    ) -> dict[UUID, CustomSpecChildResponse]:
        """Retrieves a paginated list of specs"""
        return CustomSpecBatchResponse.model_validate(
            (
                await self.post(
                    "/code/versions/list",
                    json={"spec_ids": [str(id_) for id_ in spec_ids]},
                    params={"with_context": with_context},
                )
            )
        ).root

    @async_authenticated
    async def get_metric_prompts(self, metric_prompt_ids: list[str]) -> PromptListResponse:
        """Retrieves a list of metric prompts"""

        return PromptListResponse.model_validate(
            orjson.loads(
                (
                    await self.post(
                        "/code/ai/prompts/project/list",
                        data=orjson_dumps(metric_prompt_ids),
                    )
                )
            )
        )

    @async_authenticated
    async def get_global_prompts(self, task: str, page: int = 1, per_page: int = 10) -> PromptListResponse:
        return PromptListResponse.model_validate(
            {
                "prompts": (
                    await self.get(
                        "/code/ai/globalprompts",
                        params={
                            "task_type": task,
                            "page": page,
                            "perPage": per_page,
                        },
                    )
                )["docs"]
            }
        )

    @async_authenticated
    async def get_project_prompts(
        self, project_id: str, task: str, page: int = 1, per_page: int = 10
    ) -> PromptListResponse:
        return PromptListResponse.model_validate(
            {
                "prompts": (
                    await self.get(
                        f"/code/ai/prompts/{project_id}",
                        params={
                            "task_type": task,
                            "page": page,
                            "perPage": per_page,
                        },
                    )
                )["docs"]
            }
        )

    @async_authenticated
    async def add_prompt(self, prompt: ProjectPromptRequest, project_id: str) -> ProjectPromptResponse:
        return ProjectPromptResponse.model_validate(
            (
                await self.post(
                    f"/code/ai/prompts/{project_id}",
                    data=orjson_dumps(prompt.model_dump()),
                )
            )
        )

    @async_authenticated
    async def clear_constructs(self, extraction_id: str):
        """Clears all constructs related to a project"""
        _ = await self.delete(f"/code/extraction/{extraction_id}/constructs")

    @async_authenticated
    async def patch_construct_specs(self, construct_id: str, updated_info: list[Any]):
        """Updates a project's details"""
        return await self.patch(f"/code/constructs/{construct_id}/custom", json=updated_info)

    @async_authenticated
    async def patch_version(self, version_id: str, updated_info: list[Any]):
        """Updates a project's details"""
        return await self.patch(f"/code/versions/{version_id}", json=updated_info)

    @async_authenticated
    async def filter_project(
        self,
        project_id: str,
        types: list[ValidationFilterTypeEnum],
        custom_worker_name: str | None,
        create_process: bool,
        constructs: dict[str, list[str]],
        custom_command: str | None = None,
        user_id: str | None = None,
    ) -> FilteringRunResponse:
        """Add a filtering run"""
        return FilteringRunResponse.model_validate(
            (
                await self.post(
                    f"/code/projects/{project_id}/filter",
                    params={
                        "customWorkerName": custom_worker_name,
                        "createProcess": create_process,
                        "userId": user_id,
                    },
                    json={
                        "types": types,
                        "constructs": constructs,
                        "customCommand": custom_command,
                    },
                )
            )
        )

    @async_authenticated
    async def put_tool(self, tool_name: str) -> ToolCreationResponse:
        """Updates a project's details"""
        return ToolCreationResponse.model_validate((await self.put("/code/tools", json={"tool_name": tool_name})))

    @async_authenticated
    async def get_pair_coder_run(self, pair_coder_run_id: str) -> PairCoderRequestResponse:
        """Retrieves the model describing a pair coder run by id"""
        return PairCoderRequestResponse.model_validate((await self.get(f"/code/pair-code-runs/{pair_coder_run_id}")))

    @async_authenticated
    async def finish_pair_coder_run(
        self, pair_coder_run_id: str, updated_info: dict[str, Any]
    ) -> PairCoderRequestResponse:
        """Updates a pair coder run's details and completes it"""
        return PairCoderRequestResponse.model_validate(
            (
                await self.post(
                    f"/code/pair-code-runs/{pair_coder_run_id}/finish",
                    json=updated_info,
                )
            )
        )

    @async_authenticated
    async def get_report_data(
        self,
        construct_filter: ConstructFilter | None = None,
        project_id: UUID | None = None,
        solution_id: UUID | None = None,
        nr_diffs: int = 10,
    ) -> InternalReportData:
        """Get report run data needed to render the report file.

        Args:
            construct_filter: Filter criteria for constructs
            project_id: Optional UUID of the project
            solution_id: Optional UUID of the solution
            nr_diffs: Number of diff explanations to include (default: 10)

        Returns:
            InternalReportData containing all the report information
        """
        params = {}
        if project_id:
            params["project_id"] = str(project_id)
        if solution_id:
            params["solution_id"] = str(solution_id)
        params["nr_diffs"] = str(nr_diffs)

        if not construct_filter:
            construct_filter = ConstructFilter(filters=[])
        response = await self.post("/code/reports/data", params=params, json=construct_filter.dict())
        return InternalReportData.model_validate(response.json())

    @async_authenticated
    async def get_report_run(self, report_run_id: str) -> ReportRequestResponse:
        """Retrieves the model describing a report run by id"""
        response = await self.get(f"/code/reports/{report_run_id}")
        return ReportRequestResponse.model_validate(response.json())

    @async_authenticated
    async def finish_report_run(self, report_run_id: str, updated_info: Dict[str, Any]) -> ReportRequestResponse:
        """Updates a report run's details and completes it"""
        response = await self.post(f"/code/reports/{report_run_id}/finish", json=updated_info)
        return ReportRequestResponse.model_validate(response)

    # ───────────────────────── changeset validations ────────────────────────── #

    @async_authenticated
    async def create_changeset_validation(
        self,
        project_id: str,
        changeset_id: str,
        version_sha: str,
        commands: list[dict[str, Any]],
        custom_worker_name: str,
        user_id: str,
    ) -> ChangesetValidationResponse:
        """
        Create a new validation for a changeset version.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            version_sha: SHA of the version to validate
            commands: List of command details (order and command)
            custom_worker_name: name of worker to run validation
            user_id: ID of the user

        Returns:
            ChangesetValidationResponse: Details of the created validation
        """

        validation_request = ChangesetValidationRequest(
            changeset_id=changeset_id,
            version_sha=version_sha,
            commands=commands,
            custom_worker_name=custom_worker_name,
            userId=user_id,
        )

        return ChangesetValidationResponse.model_validate(
            await self.post(
                f"/code/projects/{project_id}/changesets/{changeset_id}/versions/{version_sha}/validate",
                json=validation_request.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def get_changeset_validation(self, project_id: str, validation_id: str) -> ChangesetValidationResponse:
        """
        Get a validation by ID.

        Args:
            project_id: ID of the project
            validation_id: ID of the validation

        Returns:
            ChangesetValidationResponse: Details of the validation
        """
        return ChangesetValidationResponse.model_validate(
            await self.get(f"/code/projects/{project_id}/changesets/validations/{validation_id}")
        )

    @async_authenticated
    async def update_validation_command(
        self,
        project_id: str,
        command_id: str,
        log_id: UUID | None,
        exit_code: int | None = None,
        runtime: float | None = None,
        cpu: float | None = None,
        memory: float | None = None,
        status: ExecutionStatusEnum = ExecutionStatusEnum.pending,
    ) -> ChangesetValidationCommandResponse:
        """
        Update a command with execution results.

        Args:
            project_id: ID of the project
            command_id: ID of the command
            log_id: Optional reference to external log data
            passed: Whether the command execution passed validation
            exit_code: Exit code of the command execution
            runtime: Time taken to execute the command in seconds
            cpu: CPU usage during command execution (percentage)
            memory: Memory usage during command execution (MB)
            status: Status of the validation command execution

        Returns:
            ChangesetValidationCommandResponse: The updated command
        """
        result_request = ChangesetCommandUpdateRequest(
            log_id=log_id, exit_code=exit_code, runtime=runtime, cpu=cpu, memory=memory, status=status
        )

        return ChangesetValidationCommandResponse.model_validate(
            await self.patch(
                f"/code/projects/{project_id}/changesets/validations/commands/{command_id}",
                json=result_request.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def get_validation_commands(
        self, project_id: str, validation_id: str
    ) -> list[ChangesetValidationCommandResponse]:
        """
        Get commands for a validation.

        Args:
            project_id: ID of the project
            validation_id: ID of the validation

        Returns:
            List[ChangesetValidationCommandResponse]: The validation commands
        """
        response = await self.get(f"/code/projects/{project_id}/changesets/validations/{validation_id}/commands")
        return [ChangesetValidationCommandResponse.model_validate(cmd) for cmd in response]

    @async_authenticated
    async def download_version(self, project_id: str, changeset_id: str, version_sha: str, output_path: Path):
        """
        Download a specific version of a project as a ZIP file.

        Args:
            project_id: ID of the project
            version_sha: SHA of the version to download

        Returns:
            bytes: ZIP file content
        """
        await self.download_file(
            f"/code/projects/{project_id}/changesets/{changeset_id}/versions/{version_sha}/download",
            output_path,
            HTTPMethod.POST,
        )

    @async_authenticated
    async def create_changeset(
        self, project_id: str, name: str, description: str = "", spec_ids: list[str] = []
    ) -> ChangesetResponse:
        """Create new changeset

        Args:
            project_id: ID of the project
            name: name of changeset
            description: description of changeset

        Returns:
            ChangesetResponse: the changeset
        """
        return ChangesetResponse.model_validate(
            await self.post(
                f"/code/projects/{project_id}/changesets",
                json=ChangesetCreateRequest(
                    name=name, description=description, spec_ids=[UUID(spec_id) for spec_id in spec_ids]
                ).model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def get_changeset(self, project_id: str, changeset_id: str) -> ChangesetResponse:
        """
        Get a changeset by ID.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset

        Returns:
            ChangesetResponse: Details of the changeset
        """
        return ChangesetResponse.model_validate(
            await self.get(f"/code/projects/{project_id}/changesets/{changeset_id}")
        )

    @async_authenticated
    async def get_changeset_versions(self, project_id: str, changeset_id: str) -> ChangesetVersionsResponse:
        """
        Get all version SHAs in a changeset branch.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset

        Returns:
            FilesResponse: the files
        """
        return ChangesetVersionsResponse.model_validate(
            await self.get(f"/code/projects/{project_id}/changesets/{changeset_id}/versions")
        )

    @async_authenticated
    async def compare_changeset_versions(
        self, project_id: str, changeset_id: str, base_version_sha: str, head_version_sha: str
    ) -> ChangesetVersionCompareResponse:
        """
        Compare two version SHAs in a changeset branch.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            base_version_sha: SHA of commit to compare against
            head_version_sha: SHA of commit to compare from

        Returns:
            FilesResponse: the files
        """
        return ChangesetVersionCompareResponse.model_validate(
            await self.get(
                f"/code/projects/{project_id}/changesets/{changeset_id}/{base_version_sha}/diff/{head_version_sha}"
            )
        )

    @async_authenticated
    async def get_changeset_files(self, project_id: str, version_sha: str) -> FilesResponse:
        """
        Get all file paths in a changeset branch.

        Args:
            project_id: ID of the project
            version_sha: SHA of the version to download

        Returns:
            FilesResponse: the files
        """
        return FilesResponse.model_validate(
            await self.get(f"/code/projects/{project_id}/changeset/{version_sha}/files")
        )

    @async_authenticated
    async def get_file_content(self, project_id: str, version_sha: str) -> FileContentResponse:
        """
        Get file content from a selected file.

        Args:
            project_id: ID of the project
            version_sha: SHA of the version to download

        Returns:
            FileContentResponse: the content of the file
        """
        return FileContentResponse.model_validate(
            await self.get(f"/code/projects/{project_id}/changeset/{version_sha}/content")
        )

    @async_authenticated
    async def create_changeset_version(
        self, project_id: str, changeset_id: str, request: VersionCreateRequest
    ) -> ChangesetVersionResponse:
        """
        Create a new changeset version

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            request: request (contains commit msg and changes)

        Returns:
            ChangesetVersionResponse: changeset info for version (with sha)
        """
        return ChangesetVersionResponse.model_validate(
            await self.post(
                f"/code/projects/{project_id}/changesets/{changeset_id}/versions",
                json=request.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def patch_changeset_agent_run(
        self, project_id: str, changeset_id: str, agent_run_id: str, final_sha: str
    ) -> None:
        """
        Patch a changeset coder run with the final sha

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            agent_run_id: ID of the agent run
            final_sha: the SHA of the output version from the agent
        """
        await self.patch(
            f"/code/projects/{project_id}/changesets/{changeset_id}/agent",
            json={"agent_run_id": agent_run_id, "final_sha": final_sha},
        )

    # ───────────────────────── issues and observations ────────────────────────── #

    @async_authenticated
    async def create_observation(self, observation: ObservationCreate) -> ObservationResponse:
        """
        Create a new observation.

        Args:
            observation: Observation creation details

        Returns:
            ObservationResponse: The created observation
        """
        return ObservationResponse.model_validate(
            await self.post("/code/observations", json=observation.model_dump(mode="json"))
        )

    @async_authenticated
    async def create_issues(self, bulk_issues: IssuesCreateBulk) -> None:
        """
        Create multiple issues at once.

        Args:
            bulk_issues: Bulk issue creation request containing list of issues
        """
        await self.post("/code/issues", json=bulk_issues.model_dump(mode="json"))

    @async_authenticated
    async def delete_issue(self, issue_id: str) -> dict:
        """
        Delete an issue.

        Args:
            issue_id: ID of the issue to delete

        Returns:
            dict: Success message
        """
        return await self.delete(f"/code/issues/{issue_id}")

    @async_authenticated
    async def get_issues_paginated(
        self,
        project_id: str,
        page: int = 1,
        per_page: int = 10,
        min_severity: float | None = None,
        max_severity: float | None = None,
        audit_run_id: str | None = None,
    ) -> PaginatedIssuesWithObservationResponse:
        """
        Get paginated list of issues with optional filters.

        Args:
            project_id: Project ID to filter by
            page: Page number (default: 1)
            per_page: Items per page (default: 10)
            min_severity: Minimum severity filter (0-10)
            max_severity: Maximum severity filter (0-10)
            audit_run_id: Filter by audit run ID

        Returns:
            PaginatedIssuesWithObservationResponse: Paginated issues response
        """
        params = {
            "projectId": project_id,
            "page": page,
            "perPage": per_page,
        }
        if min_severity is not None:
            params["minSeverity"] = min_severity
        if max_severity is not None:
            params["maxSeverity"] = max_severity
        if audit_run_id is not None:
            params["auditRunId"] = audit_run_id

        return PaginatedIssuesWithObservationResponse.model_validate(await self.get("/code/issues", params=params))

    @async_authenticated
    async def get_issue(self, issue_id: str) -> IssueWithObservationResponse:
        """
        Get a single issue with its observation.

        Args:
            issue_id: ID of the issue

        Returns:
            IssueWithObservationResponse: Issue with observation details
        """
        return IssueWithObservationResponse.model_validate(await self.get(f"/code/issues/{issue_id}"))

    @async_authenticated
    async def search_issues(
        self, filter: PaginatedIssueFilter, project_id: str
    ) -> PaginatedIssuesWithObservationResponse:
        """
        Search issues with advanced filtering, sorting, and grouping.

        Args:
            filter: Advanced filter parameters
            project_id: Project ID to scope the search

        Returns:
            PaginatedIssuesWithObservationResponse: Filtered issues response
        """
        return PaginatedIssuesWithObservationResponse.model_validate(
            await self.post(
                f"/code/issues/search?projectId={project_id}",
                json=filter.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def get_issue_stats(self, filter: PaginatedIssueFilter, project_id: str) -> IssueStatsResponse:
        """
        Get issue statistics for filter sidebar.

        Args:
            filter: Filter parameters
            project_id: Project ID to scope the stats

        Returns:
            IssueStatsResponse: Issue statistics
        """
        return IssueStatsResponse.model_validate(
            await self.post(
                f"/code/issues/stats?projectId={project_id}",
                json=filter.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def delete_issues_bulk(self, issue_ids: list[str], project_id: str) -> dict:
        """
        Delete multiple issues at once.

        Args:
            issue_ids: List of issue IDs to delete
            project_id: Project ID that the issues belong to

        Returns:
            dict: Deletion result with count of deleted issues
        """
        request = IssuesDeleteBulk(issue_ids=[UUID(id_) for id_ in issue_ids])
        return await self.post(
            f"/code/issues/delete?projectId={project_id}",
            json=request.model_dump(mode="json"),
        )

    # ───────────────────────── rules ────────────────────────── #

    @async_authenticated
    async def create_rule(self, rule: RuleCreate) -> RuleResponse:
        """
        Create a new audit rule.

        Args:
            rule: Rule creation details

        Returns:
            RuleResponse: The created rule
        """
        return RuleResponse.model_validate(await self.post("/code/rules", json=rule.model_dump(mode="json")))

    @async_authenticated
    async def get_rule(self, rule_id: str) -> RuleResponse:
        """
        Get a single rule by ID.

        Args:
            rule_id: ID of the rule

        Returns:
            RuleResponse: Rule details
        """
        return RuleResponse.model_validate(await self.get(f"/code/rules/{rule_id}"))

    @async_authenticated
    async def update_rule(self, rule_id: str, update_data: RuleUpdate) -> RuleResponse:
        """
        Update an existing rule.

        Args:
            rule_id: ID of the rule to update
            update_data: Rule update data

        Returns:
            RuleResponse: The updated rule
        """
        return RuleResponse.model_validate(
            await self.put(f"/code/rules/{rule_id}", json=update_data.model_dump(mode="json"))
        )

    @async_authenticated
    async def delete_rule(self, rule_id: str) -> dict:
        """
        Delete a rule.

        Args:
            rule_id: ID of the rule to delete

        Returns:
            dict: Success message
        """
        return await self.delete(f"/code/rules/{rule_id}")

    @async_authenticated
    async def get_rules_paginated(
        self,
        project_id: str,
        page: int = 1,
        per_page: int = 10,
        enabled_only: bool = False,
        tags: list[str] | None = None,
    ) -> PaginatedRuleResponse:
        """
        Get paginated list of rules with filters.

        Args:
            project_id: Project ID to filter by
            page: Page number (default: 1)
            per_page: Items per page (default: 10)
            enabled_only: Only return enabled rules (default: False)
            tags: Filter by tags (returns rules with any of these tags)

        Returns:
            PaginatedRuleResponse: Paginated rules response
        """
        params = {
            "projectId": project_id,
            "page": page,
            "perPage": per_page,
            "enabledOnly": enabled_only,
        }
        if tags:
            params["tags"] = tags

        return PaginatedRuleResponse.model_validate(await self.get("/code/rules", params=params))

    @async_authenticated
    async def push_changeset_to_git_provider(
        self,
        project_id: UUID | str,
        changeset_id: UUID | str,
        version_sha: str,
        branch_name: str,
        commit_message: str,
        provider: str,
    ) -> GitProviderPushResponse:
        """
        Push a changeset branch to a git provider (e.g., GitHub).

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            version_sha: SHA of the version to push
            branch_name: Name of the branch to create/push to
            commit_message: Commit message for the push
            provider: Git provider

        Returns:
            GitProviderPushResponse: Response containing push status and details
        """
        push_request_data = {
            "version_sha": version_sha,
            "branch_name": branch_name,
            "commit_message": commit_message,
            "provider": provider,
        }

        result = await self.post(
            f"/code/projects/{project_id}/changesets/{changeset_id}/push-to-git-provider",
            json=push_request_data,
        )

        return GitProviderPushResponse(
            status=Status(result["status"]),
            branch=result["branch"],
            merge_conflict=result.get("merge_conflict", False),
            merge_conflict_files=result.get("merge_conflict_files", []),
            message=result.get("message", ""),
            conflict_resolution_pr_url=result.get("conflict_resolution_pr_url"),
        )

    @async_authenticated
    async def create_git_provider_pull_request(
        self,
        project_id: UUID | str,
        changeset_id: UUID | str,
        title: str,
        body: str,
        branch: str,
        base_branch: str,
        provider: str,
    ) -> GitProviderPullRequestResponse:
        """
        Create a pull request on a git provider for a changeset branch.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            title: Title of the pull request
            body: Body/description of the pull request
            branch: Source branch for the PR
            base_branch: Target/base branch for the PR
            provider: Git provider

        Returns:
            GitProviderPullRequestResponse: Response containing PR creation status and URL
        """
        pr_request_data = {
            "title": title,
            "body": body,
            "head": branch,
            "base": base_branch,
            "provider": provider,
        }

        result = await self.post(
            f"/code/projects/{project_id}/changesets/{changeset_id}/create-git-provider-pr",
            json=pr_request_data,
        )

        return GitProviderPullRequestResponse(
            status=Status(result["status"]),
            pull_request_url=result.get("pullRequestUrl"),
        )

    @async_authenticated
    async def determine_changeset_pr_details(
        self,
        project_id: str,
        changeset_id: str,
        request: ChangesetPRDetailsRequest,
    ) -> ChangesetPRDetailsResponse:
        """
        Generate PR details for a changeset based on its current state.

        Args:
            project_id: ID of the project
            changeset_id: ID of the changeset
            request: Request containing context for PR details generation

        Returns:
            ChangesetPRDetailsResponse: Generated branch name, PR title, and description
        """
        return ChangesetPRDetailsResponse.model_validate(
            await self.post(
                f"/code/projects/{project_id}/changesets/{changeset_id}/pr-details",
                json=request.model_dump(mode="json"),
            )
        )

    # ──────────────────────────── user settings ───────────────────────────── #

    @async_authenticated
    async def create_user_settings(self, request: UserSettingsRequest) -> UserSettingsResponse:
        """
        Create new user settings.

        Args:
            request: UserSettingsRequest containing the settings data

        Returns:
            UserSettingsResponse with the created settings
        """
        return UserSettingsResponse.model_validate(
            await self.post(
                "/code/user_settings",
                json=request.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def get_user_settings(self, user_id: str) -> UserSettingsResponse:
        """
        Get user settings by user ID.

        Args:
            user_id: The user ID to retrieve settings for

        Returns:
            UserSettingsResponse with the settings
        """
        return UserSettingsResponse.model_validate(await self.get(f"/code/user_settings/{user_id}"))

    @async_authenticated
    async def search_user_settings(
        self,
        pagination_params: PaginationParams | None = None,
        user_ids: list[str] | None = None,
    ) -> PaginatedUserSettingsResponse:
        """
        Search user settings with optional filtering and pagination.

        Args:
            pagination_params: Pagination parameters
            user_ids: Optional list of user IDs to filter by

        Returns:
            PaginatedUserSettingsResponse with the settings
        """
        params = {}
        if pagination_params:
            params.update(pagination_params.model_dump())
        if user_ids:
            params["user_ids"] = user_ids

        return PaginatedUserSettingsResponse.model_validate(await self.get("/code/user_settings", params=params))

    @async_authenticated
    async def update_user_settings(self, user_id: str, request: UserSettingsPatchRequest) -> UserSettingsResponse:
        """
        Update user settings (full update).

        Args:
            user_id: The user ID
            request: UserSettingsPatchRequest with new data

        Returns:
            UserSettingsResponse with updated settings
        """
        return UserSettingsResponse.model_validate(
            await self.put(
                f"/code/user_settings/{user_id}",
                json=request.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def patch_user_settings(self, user_id: str, request: UserSettingsPatchRequest) -> UserSettingsResponse:
        """
        Patch user settings (partial update).

        Args:
            user_id: The user ID
            request: UserSettingsPatchRequest with fields to update

        Returns:
            UserSettingsResponse with updated settings
        """
        return UserSettingsResponse.model_validate(
            await self.patch(
                f"/code/user_settings/{user_id}",
                json=request.model_dump(mode="json"),
            )
        )

    @async_authenticated
    async def delete_user_settings(self, user_id: str) -> None:
        """
        Delete user settings.

        Args:
            user_id: The user ID to delete settings for
        """
        await self.delete(f"/code/user_settings/{user_id}")
