"""Implements an HTTP client for Vision API"""

# ───────────────────────────────── imports ────────────────────────────────── #
import json
import time
from collections.abc import AsyncIterator, Iterator
from http.client import HTTPException
from pathlib import Path
from typing import Any, overload
from uuid import UUID

import httpx
from httpx_sse import aconnect_sse, connect_sse
from vision_models import (
    BatchRequest,
    BatchResponse,
    CodeAIResponse,
    EmbeddingModelListResponse,
    EmbeddingPresetEnum,
    EmbedDocumentRequest,
    EmbedFileRequest,
    EmbedQueryRequest,
    EmbedQueryResponse,
    GetProjectIndexesRequest,
    GetProjectIndexesResponse,
    LLMAskInferenceRequest,
    LLMCapabilitiesRequest,
    LLMInferenceRequest,
    LLMResponse,
    LLMSingleInferenceRequest,
    LLMStructuredInferenceRequest,
    LLMStructuredResponse,
    LLMSummariseRequest,
    LLMSummariseResponse,
    ModelListResponse,
    SearchResultsResponse,
    SourceRequest,
    SourceResponse,
    StructuredBatchRequest,
    StructuredBatchResponse,
    TokeniseBatchCountResponse,
    TokeniseBatchRequest,
    TokeniseCountResponse,
    TokeniseRequest,
    TokeniseResponse,
)

from evoml_services.clients.thanos import ThanosClient

from artemis_client.artemis_logging import setup_logging
from artemis_client.auth.thanos_auth_mixin_client import ThanosSettings
from artemis_client.base_auth import (
    ArtemisApiAddress,
    BaseAuthAsyncClient,
    BaseAuthClient,
    astream_authenticated,
    async_authenticated,
    authenticated,
)

setup_logging()


# ───────────────────────────────────────────────────────────────────────────── #
class VisionSettings(ArtemisApiAddress):
    """Settings for Vision API"""

    user_override: str | None = ""


# ───────────────────────────────── Clients ─────────────────────────────────── #
class VisionClient(BaseAuthClient):
    """This is a client implementation for Vision API"""

    def __init__(
        self,
        vision_settings: VisionSettings,
        thanos_settings: ThanosSettings | None = None,
    ):
        self.vision_settings = vision_settings
        super().__init__(self.vision_settings, thanos_settings)

        self.token = None
        self.token_expires = time.time()
        if self.vision_settings.user_override:
            self.headers.update({"x-user-override": self.vision_settings.user_override})

    def __reduce__(self):
        return self.__class__, (self.vision_settings, self.thanos_settings)

    # ──────────────────────────── LLM ───────────────────────────── #

    @overload
    def ask(self, request: LLMAskInferenceRequest) -> LLMResponse: ...

    @overload
    def ask(self, request: BatchRequest) -> BatchResponse: ...

    @authenticated
    def ask(self, request: LLMAskInferenceRequest | BatchRequest) -> LLMResponse | BatchResponse:
        """Retrieves the model describing a project by id"""
        res = self.post("/ai/ask", json=request.model_dump(mode="json"))
        if isinstance(request, BatchRequest):
            return BatchResponse.model_validate(res)
        return LLMResponse.model_validate(res)  # type is LLMResponse

    @authenticated
    def ask_stream(self, request: LLMInferenceRequest) -> Iterator[str]:
        """Retrieves the model describing a project by id"""
        with connect_sse(
            client=self,
            method="POST",
            url="/ai/ask-stream",
            json=request.model_dump(mode="json"),
        ) as event_source:
            for sse in event_source.iter_sse():
                if sse.event == "output-tokens":
                    yield json.loads(sse.data)["tool_data"]["token"]

    @overload
    def ask_structured(self, request: LLMStructuredInferenceRequest) -> LLMStructuredResponse:
        """Retrieves the model describing a project by id"""

    @overload
    def ask_structured(self, request: StructuredBatchRequest) -> StructuredBatchResponse:
        """Retrieves the model describing a project by id"""

    @authenticated
    def ask_structured(
        self, request: LLMStructuredInferenceRequest | StructuredBatchRequest
    ) -> LLMStructuredResponse | StructuredBatchResponse:
        """Retrieves the model describing a project by id"""
        res = self.post("/ai/ask-structured", json=request.model_dump(mode="json"), timeout=40)
        if isinstance(request, LLMStructuredInferenceRequest):
            return LLMStructuredResponse.model_validate(res)

        return StructuredBatchResponse.model_validate(res)

    @authenticated
    def ask_single(self, request: LLMSingleInferenceRequest) -> CodeAIResponse:
        """Retrieves the model describing a project by id"""
        return CodeAIResponse.model_validate(self.post("/ai/ask-single", json=request.model_dump(mode="json")))

    @authenticated
    def ask_sources(self, request: LLMInferenceRequest) -> Iterator[str]:
        with connect_sse(
            client=self,
            method="POST",
            url="/ai/ask-sources",
            json=request.model_dump(mode="json", exclude_none=True),
        ) as event_source:
            if event_source.response.status_code != 200:
                raise HTTPException(event_source.response.read().decode())
            for sse in event_source.iter_sse():
                if sse.event == "output-tokens":
                    yield json.loads(sse.data)["tool_data"]["token"]

    @authenticated
    def sources_query(self, request: SourceRequest) -> SourceResponse:
        """Retrieves the model describing a project by id"""
        return SourceResponse.model_validate(self.post("/ai/sources/query", json=request.model_dump(mode="json")))

    @authenticated
    def summarise(self, request: LLMSummariseRequest) -> LLMSummariseResponse:
        """Summarises a document with an LLM"""
        return LLMSummariseResponse.model_validate(self.post("/ai/summarise", json=request.model_dump(mode="json")))

    @authenticated
    def get_models(self, request: LLMCapabilitiesRequest | None = None) -> ModelListResponse:
        """Retrieves the model describing a project by id"""
        if request:
            return ModelListResponse.model_validate(
                self.get(
                    "/ai/models",
                    params=request.model_dump(mode="json", exclude_none=True),
                )
            )
        return ModelListResponse.model_validate(self.get("/ai/models"))

    # ──────────────────────────── Embedding ───────────────────────────── #

    @authenticated
    def embed_query(self, request: EmbedQueryRequest) -> EmbedQueryResponse:
        """Return embeddings for query"""
        return EmbedQueryResponse.model_validate(self.post("/embeddings/query", json=request.model_dump(mode="json")))

    @authenticated
    def embed_document(self, request: EmbedDocumentRequest) -> None:
        """Retrieves the model describing a project by id"""
        _ = self.post("/embeddings/document", json=request.model_dump(mode="json"))

    @authenticated
    def embed_file(self, embed_file_path: Path, request: EmbedFileRequest) -> None:
        """Retrieves the model describing a project by id"""
        _ = self.upload_file(
            "/embeddings/file",
            embed_file_path,
            data=request.model_dump(mode="json"),
        )

    @authenticated
    def delete_embeddings_for_project_id(self, project_id: str) -> None:
        """Retrieves the model describing a project by id"""
        self.delete(f"/embeddings/{project_id}")

    @authenticated
    def get_embedding_models(self) -> EmbeddingModelListResponse:
        """Return metadata for an embedding model"""
        return EmbeddingModelListResponse.model_validate(self.get("/embeddings/models"))

    # ──────────────────────────── Tokenize ───────────────────────────── #

    @authenticated
    def tokenize_query(self, request: TokeniseRequest) -> TokeniseResponse:
        """Tokenize a query"""
        return TokeniseResponse.model_validate(self.post("/tokenise/query", json=request.model_dump(mode="json")))

    @authenticated
    def count_tokens(self, request: TokeniseRequest) -> TokeniseCountResponse:
        """Count tokens in a query"""
        return TokeniseCountResponse.model_validate(self.post("/tokenise/count", json=request.model_dump(mode="json")))

    @authenticated
    def count_tokens_batch(self, request: TokeniseBatchRequest) -> TokeniseBatchCountResponse:
        """Count tokens in a batch query"""
        return TokeniseBatchCountResponse.model_validate(
            self.post("/tokenise/count/batch", json=request.model_dump(mode="json"))
        )

    # ──────────────────────────── Search ───────────────────────────── #

    @authenticated
    def search_projects(
        self,
        query: str,
        project_ids: list[str],
        model_preset: EmbeddingPresetEnum | None = None,
        limit: int | None = None,
        threshold: float | None = None,
    ) -> SearchResultsResponse:
        """Search for projects"""

        if limit is None and threshold is None:
            threshold = 0.5

        params: dict[str, Any] = {}
        if limit:
            params["limit"] = limit
        if threshold:
            params["threshold"] = threshold

        return SearchResultsResponse.model_validate(
            self.post(
                "/search/projects",
                params=params,
                json={
                    "model_preset": model_preset,
                    "query": query,
                    "project_ids": project_ids,
                },
            )
        )

    @authenticated
    def get_used_models_for_projects(self, project_ids: list[str]) -> list[str]:
        """Get used indexing presets for projects

        This is a bit awkward because the model vision uses has UUID, but it's more
        consistent for the client to deal with serialized UUID.
        """

        return GetProjectIndexesResponse.model_validate(
            self.post(
                "/embeddings/project/presets",
                json=GetProjectIndexesRequest(project_ids=[UUID(pid) for pid in project_ids]).model_dump(mode="json"),
            )
        ).indexes


class VisionAsyncClient(BaseAuthAsyncClient):
    def __init__(
        self,
        vision_settings: VisionSettings,
        thanos_settings: ThanosSettings,
    ):
        self.vision_settings = vision_settings
        super().__init__(vision_settings, thanos_settings)

        self.thanos_client = ThanosClient(thanos_settings)
        self.token = None
        self.token_expires = time.time()
        self.headers = httpx.Headers()
        if self.vision_settings.user_override:
            self.headers.update({"x-user-override": self.vision_settings.user_override})

    # ──────────────────────────── LLM ───────────────────────────── #

    @overload
    async def ask(self, request: LLMAskInferenceRequest) -> LLMResponse: ...

    @overload
    async def ask(self, request: BatchRequest) -> BatchResponse: ...

    @async_authenticated
    async def ask(self, request: LLMAskInferenceRequest | BatchRequest) -> LLMResponse | BatchResponse:
        """Retrieves the model describing a project by id"""
        res = await self.post("/ai/ask", json=request.model_dump(mode="json"))
        if isinstance(request, BatchRequest):
            return BatchResponse.model_validate(res)

        return LLMResponse.model_validate(res)

    @astream_authenticated
    async def ask_stream(self, request: LLMInferenceRequest) -> AsyncIterator[str]:
        """Retrieves the model describing a project by id"""
        async with aconnect_sse(
            client=self,
            method="POST",
            url="/ai/ask-stream",
            json=request.model_dump(mode="json"),
        ) as event_source:
            async for sse in event_source.aiter_sse():
                if sse.event == "output-tokens":
                    yield json.loads(sse.data)["tool_data"]["token"]

    @overload
    async def ask_structured(self, request: LLMStructuredInferenceRequest) -> LLMStructuredResponse:
        """Retrieves the model describing a project by id using structured inference
        request."""

    @overload
    async def ask_structured(self, request: StructuredBatchRequest) -> StructuredBatchResponse:
        """Retrieves the model describing a project by id using structured batch
        request."""

    @async_authenticated
    async def ask_structured(
        self, request: LLMStructuredInferenceRequest | StructuredBatchRequest
    ) -> LLMStructuredResponse | StructuredBatchResponse:
        """Retrieves the model describing a project by id"""
        res = await self.post("/ai/ask-structured", json=request.model_dump(mode="json"), timeout=40)
        if isinstance(request, LLMStructuredInferenceRequest):
            return LLMStructuredResponse.model_validate(res)

        return StructuredBatchResponse.model_validate(res)

    @async_authenticated
    async def ask_single(self, request: LLMSingleInferenceRequest) -> CodeAIResponse:
        """Retrieves the model describing a project by id"""
        return CodeAIResponse.model_validate((await self.post("/ai/ask-single", json=request.model_dump(mode="json"))))

    @async_authenticated
    async def sources_query(self, request: SourceRequest) -> SourceResponse:
        """Retrieves the model describing a project by id"""
        json_resp = await self.post("/ai/sources/query", json=request.model_dump(mode="json"))
        return SourceResponse.model_validate(json_resp)

    @async_authenticated
    async def summarise(self, request: LLMSummariseRequest) -> LLMSummariseResponse:
        """Summarises a document with an LLM"""
        return LLMSummariseResponse.model_validate(
            (await self.post("/ai/summarise", json=request.model_dump(mode="json")))
        )

    @async_authenticated
    async def get_models(self, request: LLMCapabilitiesRequest | None = None) -> ModelListResponse:
        """Retrieves the model describing a project by id"""
        if request:
            return ModelListResponse.model_validate(
                (
                    await self.get(
                        "/ai/models",
                        params=request.model_dump(mode="json", exclude_none=True),
                    )
                )
            )
        return ModelListResponse.model_validate((await self.get("/ai/models")))

    # ──────────────────────────── Embedding ───────────────────────────── #

    @async_authenticated
    async def embed_query(self, request: EmbedQueryRequest) -> EmbedQueryResponse:
        """Retrieves the model describing a project by id"""
        return EmbedQueryResponse.model_validate(
            (await self.post("/embeddings/query", json=request.model_dump(mode="json")))
        )

    @async_authenticated
    async def embed_document(self, request: EmbedDocumentRequest) -> None:
        """Retrieves the model describing a project by id"""
        _ = await self.post("/embeddings/document", json=request.model_dump(mode="json"))

    @async_authenticated
    async def embed_file(self, embed_file_path: Path, request: EmbedFileRequest) -> None:
        """Retrieves the model describing a project by id"""
        _ = self.upload_file(
            "/embeddings/file",
            embed_file_path,
            data=request.model_dump(),
        )

    @async_authenticated
    async def delete_embeddings_for_project_id(self, project_id: str) -> None:
        """Retrieves the model describing a project by id"""
        await self.delete(f"/embeddings/{project_id}")

    @async_authenticated
    async def get_embedding_models(self) -> EmbeddingModelListResponse:
        """Return metadata for an embedding model"""
        return EmbeddingModelListResponse.model_validate((await self.get("/embeddings/models")))

    # ──────────────────────────── Tokenize ───────────────────────────── #

    @async_authenticated
    async def tokenize_query(self, request: TokeniseRequest) -> TokeniseResponse:
        """Tokenize a query"""
        return TokeniseResponse.model_validate(
            (await self.post("/tokenise/query", json=request.model_dump(mode="json")))
        )

    @async_authenticated
    async def count_tokens(self, request: TokeniseRequest) -> TokeniseCountResponse:
        """Count tokens in a query"""
        return TokeniseCountResponse.model_validate(
            (await self.post("/tokenise/count", json=request.model_dump(mode="json")))
        )

    # ──────────────────────────── Search ───────────────────────────── #

    @async_authenticated
    async def search_projects(
        self,
        query: str,
        project_ids: list[str],
        model_preset: EmbeddingPresetEnum | None = None,
        limit: int | None = None,
        threshold: float | None = None,
    ) -> SearchResultsResponse:

        if limit is None and threshold is None:
            threshold = 0.5

        params: dict[str, Any] = {}
        if limit:
            params["limit"] = limit
        if threshold:
            params["threshold"] = threshold

        return SearchResultsResponse.model_validate(
            (
                await self.post(
                    "/search/projects",
                    params=params,
                    json={
                        "model_preset": model_preset,
                        "query": query,
                        "project_ids": project_ids,
                    },
                )
            )
        )

    @async_authenticated
    async def get_used_models_for_projects(self, project_ids: list[str]) -> list[str]:
        """Get used indexing presets for projects

        This is a bit awkward because the model vision uses has UUID, but it's more
        consistent for the client to deal with serialized UUID.
        """

        return GetProjectIndexesResponse.model_validate(
            (
                await self.post(
                    "/embeddings/project/presets",
                    json=GetProjectIndexesRequest(project_ids=[UUID(pid) for pid in project_ids]).model_dump(
                        mode="json"
                    ),
                )
            )
        ).indexes
