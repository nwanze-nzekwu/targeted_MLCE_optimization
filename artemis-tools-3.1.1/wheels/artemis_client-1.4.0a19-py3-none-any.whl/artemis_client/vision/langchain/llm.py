# pylint: disable=R0801
import os
from typing import Any, AsyncIterator, Iterator, List, Optional

from langchain_core.callbacks import AsyncCallbackManagerForLLMRun, CallbackManagerForLLMRun
from langchain_core.language_models import LLM
from langchain_core.outputs import Generation, GenerationChunk, LLMResult
from typing_extensions import override
from vision_models import BatchPart, BatchRequest, LLMConversationMessage, LLMInferenceRequest, LLMRole

from evoml_services.clients.thanos import ThanosSettings

# Source imports
from artemis_client.vision.client import VisionAsyncClient, VisionClient, VisionSettings


class VisionLangchainLLMWrapper(LLM):

    llm_type: str
    json_mode: bool = False
    vision_client: VisionClient
    vision_async_client: VisionAsyncClient

    def __init__(self, llm_type: str, json_mode: bool = False, **kwargs: Any):
        _env_file = kwargs.pop("env_file", os.environ.get("ENV_FILE_LOCATION", ".env"))
        kwargs.update(
            llm_type=llm_type,
            json_mode=json_mode,
            vision_client=VisionClient(
                VisionSettings.with_env_prefix("vision", _env_file=_env_file),
                ThanosSettings.with_env_prefix("thanos", _env_file=_env_file),
            ),
            vision_async_client=VisionAsyncClient(
                VisionSettings.with_env_prefix("vision", _env_file=_env_file),
                ThanosSettings.with_env_prefix("thanos", _env_file=_env_file),
            ),
        )
        super().__init__(**kwargs)

    @override
    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:

        return (
            self.vision_client.ask(
                LLMInferenceRequest(
                    model_type=self.llm_type,
                    messages=[LLMConversationMessage(role=LLMRole.USER, content=prompt)],
                )
            )
            .messages[-1]
            .content
        )

    @override
    async def _acall(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        return (
            (
                await self.vision_async_client.ask(
                    LLMInferenceRequest(
                        model_type=self.llm_type,
                        messages=[LLMConversationMessage(role=LLMRole.USER, content=prompt)],
                    )
                )
            )
            .messages[-1]
            .content
        )

    @override
    def _stream(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[GenerationChunk]:
        for chunk in self.vision_client.ask_stream(
            LLMInferenceRequest(
                model_type=self.llm_type,
                messages=[LLMConversationMessage(role=LLMRole.USER, content=prompt)],
            )
        ):
            # TODO: use chat generation but need structured ask stream output
            yield GenerationChunk(text=chunk)

    @override
    async def _astream(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> AsyncIterator[GenerationChunk]:
        async for chunk in self.vision_async_client.ask_stream(
            LLMInferenceRequest(
                model_type=self.llm_type,
                messages=[LLMConversationMessage(role=LLMRole.USER, content=prompt)],
            )
        ):
            yield GenerationChunk(text=chunk)

    @override
    def _generate(
        self,
        prompts: List[str],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> LLMResult:
        batch_result = self.vision_client.ask(
            BatchRequest(
                parts=[
                    BatchPart(
                        id=str(i),
                        messages=[LLMConversationMessage(role=LLMRole.USER, content=prompt)],
                    )
                    for i, prompt in enumerate(prompts)
                ],
                model_type=self.llm_type,
            )
        )
        return LLMResult(generations=[[Generation(text=part.messages[-1].content)] for part in batch_result.parts])

    @override
    async def _agenerate(
        self,
        prompts: List[str],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> LLMResult:
        batch_result = await self.vision_async_client.ask(
            BatchRequest(
                parts=[
                    BatchPart(
                        id=str(i),
                        messages=[LLMConversationMessage(role=LLMRole.USER, content=prompt)],
                    )
                    for i, prompt in enumerate(prompts)
                ],
                model_type=self.llm_type,
            )
        )
        return LLMResult(generations=[[Generation(text=part.messages[-1].content)] for part in batch_result.parts])

    @property
    @override
    def _llm_type(self) -> str:
        return self.llm_type
