# pylint: disable=R0801
import os
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional

from langchain_core.callbacks import AsyncCallbackManagerForLLMRun, CallbackManagerForLLMRun
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessageChunk, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from langchain_core.tools import BaseTool
from typing_extensions import override
from vision_models import LLMConversationMessage, LLMInferenceRequest, LLMStructuredInferenceRequest, LLMTool

from artemis_client.base_auth import ThanosSettings

# Source imports
from artemis_client.vision.client import VisionAsyncClient, VisionClient, VisionSettings


def from_langchain(tool_call: BaseTool) -> LLMTool:
    return LLMTool(
        name=tool_call.name,
        description=tool_call.description,
        parameters=(tool_call.args_schema.schema() if tool_call.args_schema is not None else {}),
    )


class VisionLangchainChatWrapper(BaseChatModel):
    """Simple Chat Model."""

    llm_type: str
    json_mode: bool = False
    vision_client: VisionClient
    vision_async_client: VisionAsyncClient

    def __init__(self, llm_type: str, json_mode: bool = False, **kwargs: Any):
        _env_file = kwargs.pop("env_file", os.environ.get("ENV_FILE_LOCATION", ".env"))
        kwargs.update(
            llm_type=llm_type,
            json_mode=json_mode,
            vision_client=VisionClient(
                VisionSettings.with_env_prefix("vision", _env_file=_env_file),
                ThanosSettings.with_env_prefix("thanos", _env_file=_env_file),
            ),
            vision_async_client=VisionAsyncClient(
                VisionSettings.with_env_prefix("vision", _env_file=_env_file),
                ThanosSettings.with_env_prefix("thanos", _env_file=_env_file),
            ),
        )
        super().__init__(**kwargs)

    @property
    @override
    def _llm_type(self) -> str:
        return self.llm_type

    @override
    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        tools: Optional[List[BaseTool]] = None,
        schema: Optional[Dict[str, object]] = None,
        example: Optional[Dict[str, object]] = None,
        **kwargs: Any,
    ) -> ChatResult:
        vision_messages = [LLMConversationMessage.from_langchain(msg) for msg in messages]
        vision_tools = [from_langchain(tool) for tool in tools] if tools is not None else None
        if self.json_mode:
            response = self.vision_client.ask_structured(
                LLMStructuredInferenceRequest(
                    model_type=self.llm_type,
                    messages=vision_messages,
                    tools=vision_tools,
                    response_schema=schema,
                    example=example,
                )
            )
        else:
            response = self.vision_client.ask(
                LLMInferenceRequest(
                    model_type=self.llm_type,
                    messages=vision_messages,
                    tools=vision_tools,
                )
            )

        msg = response.messages[-1].to_langchain()
        return ChatResult(generations=[ChatGeneration(message=msg)])

    @override
    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        tools: Optional[List[BaseTool]] = None,
        schema: Optional[Dict[str, object]] = None,
        example: Optional[Dict[str, object]] = None,
        **kwargs: Any,
    ) -> ChatResult:
        vision_messages = [LLMConversationMessage.from_langchain(msg) for msg in messages]
        vision_tools = [from_langchain(tool) for tool in tools] if tools else None
        if self.json_mode:
            response = await self.vision_async_client.ask_structured(
                LLMStructuredInferenceRequest(
                    model_type=self.llm_type,
                    messages=vision_messages,
                    tools=vision_tools,
                    response_schema=schema,
                    example=example,
                )
            )
            msg = response.messages[-1].to_langchain()
        else:
            response = await self.vision_async_client.ask(
                LLMInferenceRequest(
                    model_type=self.llm_type,
                    messages=vision_messages,
                    tools=vision_tools,
                )
            )
        msg = response.messages[-1].to_langchain()
        generation = ChatGeneration(message=msg)
        return ChatResult(generations=[generation])

    @override
    def _stream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[ChatGenerationChunk]:
        if self.json_mode:
            response = self._generate(messages, stop)
            yield ChatGenerationChunk(message=AIMessageChunk(content=response.generations[0].text))
            if run_manager:
                run_manager.on_llm_new_token(
                    response.generations[0].text,
                    verbose=self.verbose,
                )
        else:
            vision_messages = [LLMConversationMessage.from_langchain(msg) for msg in messages]
            for stream_resp in self.vision_client.ask_stream(
                LLMInferenceRequest(model_type=self.llm_type, messages=vision_messages)
            ):
                if stream_resp:
                    chunk = ChatGenerationChunk(message=AIMessageChunk(content=stream_resp))
                    yield chunk
                    if run_manager:
                        run_manager.on_llm_new_token(
                            chunk.text,
                            verbose=self.verbose,
                        )

    @override
    async def _astream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatGenerationChunk]:
        if self.json_mode:
            response = await self._agenerate(messages, stop)
            yield ChatGenerationChunk(message=AIMessageChunk(content=response.generations[0].text))
            if run_manager:
                await run_manager.on_llm_new_token(
                    response.generations[0].text,
                    verbose=self.verbose,
                )
        else:
            vision_messages = [LLMConversationMessage.from_langchain(msg) for msg in messages]
            async for stream_resp in self.vision_async_client.ask_stream(
                LLMInferenceRequest(model_type=self.llm_type, messages=vision_messages)
            ):
                if stream_resp:
                    chunk = ChatGenerationChunk(message=AIMessageChunk(content=stream_resp))
                    yield chunk
                    if run_manager:
                        await run_manager.on_llm_new_token(
                            chunk.text,
                            verbose=self.verbose,
                        )
