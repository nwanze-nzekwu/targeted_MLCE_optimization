# pylint: disable=too-many-ancestors

from evoml_services.clients.thor import ThorClient

# Source imports
from artemis_client.auth.thanos_auth_mixin_client import ThanosAuthMixin
from artemis_client.base_auth import ArtemisApiAddress


class ThorSettings(ArtemisApiAddress):
    pass


class AuthThorClient(ThanosAuthMixin[ThorSettings], ThorClient): ...
