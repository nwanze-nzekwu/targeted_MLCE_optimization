# pylint: disable=too-many-ancestors

from turing_task_manager.clients import LokiClient

from artemis_client.auth.task_bound_loki_client import LokiSettings

# Source imports
from artemis_client.auth.thanos_auth_mixin_client import ThanosAuthMixin


class AuthLokiClient(ThanosAuthMixin[LokiSettings], LokiClient): ...
