from turing_task_manager.clients import TaskBoundLoki
from turing_task_manager.clients.loki import TaskInformation

from artemis_client.auth.thanos_auth_mixin_client import ThanosAuthMixin, ThanosSettings
from artemis_client.base_auth import ArtemisApiAddress


class LokiSettings(ArtemisApiAddress):
    pass


class AuthTaskBoundLokiClient(ThanosAuthMixin[LokiSettings], TaskBoundLoki):

    def __init__(self, settings: LokiSettings, task: TaskInformation, thanos_settings: ThanosSettings | None = None):
        """Each instance is bound to a specific task"""
        # Init is needed here because MRO is resolved differently now that both
        # ThanosAuthMixin and TaskBoundLoki are not descended from JsonClient
        super().__init__(settings=settings, thanos_settings=thanos_settings)
        self.task = task
