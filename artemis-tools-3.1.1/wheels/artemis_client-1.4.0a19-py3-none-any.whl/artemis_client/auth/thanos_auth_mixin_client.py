import time
import typing

from turing_task_manager.clients.core import ApiSettings

from evoml_services.clients.thanos import ThanosClient

# Source imports
from artemis_client.base_auth import BaseAuthClient, ThanosSettings

SettingsT = typing.TypeVar("SettingsT", bound=ApiSettings)


class ThanosAuthMixin(BaseAuthClient, typing.Generic[SettingsT]):
    def __init__(
        self,
        settings: SettingsT,
        thanos_settings: ThanosSettings | None = None,
    ):
        thanos_settings = thanos_settings or ThanosSettings.with_env_prefix("thanos")
        super().__init__(client_settings=settings, thanos_settings=thanos_settings)
        self.thanos_client = ThanosClient(thanos_settings)
        self.token = None
        self.token_expires = time.time()
