"""Implements a worker with all of the basic functionality that should be shared between all the Artemis related
workers."""

import logging
import os
import zipfile
from abc import ABC
from pathlib import Path

import psutil
from cpuinfo import get_cpu_info
from falcon_models import HardwareInfoRequest
from git import Repo
from GPUtil import GPUtil

import turing_task_manager as ttm
from turing_task_manager import WorkingEnv
from turing_task_manager.clients import LokiClient

from evoml_services.clients.thor import ThorClient, ThorSettings

from artemis_client.auth.loki_client import AuthLokiClient
from artemis_client.auth.task_bound_loki_client import AuthTaskBoundLokiClient
from artemis_client.auth.thor_client import AuthThorClient
from artemis_client.falcon.client import FalconClient, FalconSettings


class ArtemisWorker(ttm.BaseWorker, ABC):
    """Base for Artemis related workers"""

    logger = logging.getLogger(__name__)
    inputs_logger = logging.getLogger(__name__ + ".inputs_download")

    thor_client: ThorClient = None
    falcon_client: FalconClient = None
    falcon_settings: FalconSettings = None
    loki_client: LokiClient
    loki_client_class = AuthLokiClient
    task_bound_loki_client_class = AuthTaskBoundLokiClient

    def get_hardware_info(self):
        cpu_info = get_cpu_info()

        try:
            gpus_info = GPUtil.getGPUs()
        except BaseException:
            gpus_info = []

        return HardwareInfoRequest(
            cpu_number=psutil.cpu_count() or 1,
            cpu_name=cpu_info["brand_raw"],
            gpu_name=gpus_info[0].name if len(gpus_info) > 0 else None,
            gpu_number=len(gpus_info),
            ram=psutil.virtual_memory().total / (1024**3),
        )

    def download_file_from_thor(self, env: WorkingEnv, file_id: str) -> Path:
        """Downloads a project archive from thor and sets it up in working directory"""
        file = self.thor_client.get_file(file_id)
        if file is None:
            raise Exception(f"file {file_id} doesn't exist")
        file_path = env.input_dir / file.originalFilename
        self.thor_client.download_simple_file(file_id, file_path)
        if not file_path.exists():
            raise Exception(f"Failed to download file {file_id} to {file_path}")  # Raise an exception
        return file_path

    def download_project_from_thor(self, env: WorkingEnv, file_id: str) -> Path:
        """Downloads a project archive from thor and sets it up in working directory"""
        file = self.thor_client.get_file(file_id)
        if not file.originalFilename.endswith(".zip"):
            raise Exception("File provided should be a zip file")
        zip_path = env.input_dir / "source.zip"
        extract_path = env.input_dir / file_id
        self.thor_client.download_simple_file(file_id, zip_path)
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_path)
            # try to restore permissions as extractall doesn't preserve them
            for zip_info in zip_ref.infolist():
                # Get the external attributes (permissions are in the upper 16 bits)
                external_attr = zip_info.external_attr >> 16
                if external_attr > 0:
                    extracted_path = extract_path / zip_info.filename
                    if not os.path.isdir(extracted_path):
                        os.chmod(extracted_path, external_attr)
        zip_path.unlink(missing_ok=True)
        return extract_path

    def init_project(self, env: WorkingEnv, project_id: str) -> Path:
        """Downloads a project archive from thor and sets it up in working directory"""
        project = self.falcon_client.get_project(project_id)
        if project.file_id:
            file_id = project.file_id
            return self.download_project_from_thor(env, file_id)
        else:
            file_id = self.falcon_client.init_project(project_id).file_id
            return self.download_project_from_thor(env, file_id)

    @classmethod
    def setup(cls):
        """Class method setting up static attributes (here, mostly clients) as
        singletons.
        """
        if cls.thor_client is None:
            thor_settings = ThorSettings.with_env_prefix("thor")
            cls.thor_client = AuthThorClient(thor_settings)
            cls.logger.debug("Thor configuration:\n%s", thor_settings.json())
        if cls.falcon_settings is None:
            falcon_settings = FalconSettings.with_env_prefix("falcon")
            cls.falcon_client = FalconClient(falcon_settings)
            cls.logger.debug("Falcon configuration:\n%s", falcon_settings.json())

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setup()
