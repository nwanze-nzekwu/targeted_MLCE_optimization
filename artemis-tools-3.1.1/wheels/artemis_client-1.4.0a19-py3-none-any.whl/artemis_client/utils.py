import json
from contextlib import suppress
from enum import StrEnum

from httpx import Response

try:  # requests can raise simplejson.JSONDecodeError if it's available
    import simplejson

    JsonDecodeErrors = (json.JSONDecodeError, simplejson.JSONDecodeError)
except ImportError:
    JsonDecodeErrors = (json.JSONDecodeError,)


class HTTPMethod(StrEnum):
    """Enum of HTTP methods"""

    POST = "post"
    GET = "get"
    PUT = "put"
    HEAD = "head"
    PATCH = "patch"
    DELETE = "delete"


def response_json(response: Response) -> dict:
    """Safe function opening the content of a response while catching different
    kind of exceptions:
    - If the content is a json, return it
    - If the content is a string, decode it and set it as {'message': '...'}
    """
    with suppress(*JsonDecodeErrors):
        return response.json()
    return {"message": response.text}
