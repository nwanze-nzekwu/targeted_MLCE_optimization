LOGGING_CONFIG = {
    "version": 1,
    "handlers": {
        "default": {
            "class": "logging.StreamHandler",
            "formatter": "http",
            "stream": "ext://sys.stderr",
        }
    },
    "formatters": {
        "http": {
            "format": "%(levelname)s [%(asctime)s] %(name)s - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        }
    },
    "loggers": {
        "httpx": {
            "handlers": ["default"],
            "level": "ERROR",
        },
        "httpcore": {
            "handlers": ["default"],
            "level": "ERROR",
        },
    },
}


def setup_logging():
    # logging.config.dictConfig(LOGGING_CONFIG)
    ...  # do nothing for now, but we might want to configure it here
