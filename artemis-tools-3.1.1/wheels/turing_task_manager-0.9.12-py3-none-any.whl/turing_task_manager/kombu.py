# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
import time
from asyncio import AbstractEventLoop
from typing import Optional, List, Type, TypeVar
import logging
from enum import Enum
from typing import Callable

# Dependencies
from kombu import Connection, Message, Queue, Exchange
from kombu.compat import Consumer
from kombu.entity import PERSISTENT_DELIVERY_MODE
from kombu.transport.virtual import AbstractChannel
from kombu.mixins import ConsumerProducerMixin

# Module
from turing_task_manager.clients.core.config import SettingsFromEnv

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logging.getLogger("kombu.mixins").setLevel(logging.ERROR)

DEFAULT_EXCHANGE = ""


class MQAction(Enum):
    ACK = 1
    NACK = 2
    REQUEUE = 3


# ────────────────────────────── configuration ─────────────────────────────── #
class RabbitmqConfig(SettingsFromEnv):
    """Config class for RabbitMQ"""

    # Set aliases for config keys
    _alias_keys = [
        ("vhost", "virtual_host"),
        ("username", "userid"),
        ("host", "hostname"),
    ]
    # Generic service connection info
    host: str
    port: int

    # RabbitMQ specific
    vhost: str
    username: str
    password: str

    heartbeat: int = 20

    def to_kombu_params(self) -> dict:
        """Creates a kombu connection config dict from this config"""
        config = self.dict()
        config.update(hostname=self.host if self.host.rfind("://") == 0 else "amqp://" + self.host)
        return config


# ──────────────────────────────────────────────────────────────────────────── #
ConsumerT = TypeVar("ConsumerT", bound=Consumer)


class KombuMQConsumer(ConsumerProducerMixin):
    """This is an example consumer that will handle unexpected interactions
    with RabbitMQ such as channel and connection closures.

    If RabbitMQ closes the connection, this class will stop and indicate
    that reconnection is necessary. You should look at the output, as
    there are limited reasons why the connection may be closed, which
    usually are tied to permission related issues or socket timeouts.

    If the channel is closed, it will indicate a problem with one of the
    commands that were issued and that should surface in the output as well.
    """

    def __init__(
        self,
        queue: str,
        consume_func: Callable[[Message], MQAction],
        loop: AbstractEventLoop,
        connection: Connection,
        consumer_tag: Optional[str] = None,
    ):
        """Create a new instance of the consumer class, passing in the AMQP
        URL used to connect to RabbitMQ.
        """
        self.connection = connection
        channel = self.connection.channel()
        self.exchange = Exchange(
            name="loki",
            type="topic",
            channel=channel,
            delivery_mode=PERSISTENT_DELIVERY_MODE,
        )
        self.exchange.declare()
        logger.info(f"Subscribing to {queue}")
        self.queues: List[Queue] = [Queue(name=queue, routing_key=queue, exchange=self.exchange, channel=channel)]
        self.loop = loop
        self.consume_func = consume_func
        self._consumer_tag = consumer_tag

        # In production, experiment with higher prefetch values
        # for higher consumer throughput
        self._prefetch_count = 1

    def get_consumers(
        self,
        consumer_class: Type[ConsumerT],
        channel: AbstractChannel,
    ) -> List[ConsumerT]:
        return [
            consumer_class(
                queues=self.queues,
                prefetch_count=self._prefetch_count,
                callbacks=[self.on_message],
                tag_prefix=f"{self._consumer_tag}_",
                no_ack=False,
            )
        ]

    def on_message(self, body: bytes, message: Message):
        """Wrapper for executing function in another thread and performing
        appropriate callback relative to its output
        """
        message.ack()
        action_to_perform: MQAction = self.consume_func(message)
        if action_to_perform == MQAction.ACK:
            message.ack()
        elif action_to_perform == MQAction.NACK:
            message.reject()
        elif action_to_perform == MQAction.REQUEUE:
            time.sleep(1)
            self.producer.publish(
                body,
                routing_key=self.queues[0].name,
                delivery_mode=Exchange.PERSISTENT_DELIVERY_MODE,
                retry=True,
            )

    def run(self, **kwargs):
        logger.info("Starting consumption!")
        logger.info(self._consumer_tag)
        super().run(**kwargs)
