#!/usr/bin/env python3
# encoding: utf-8
"""
This file defines classes that can create a suitable environment to call the
different executables
"""
# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import Any
from pathlib import Path
from contextlib import contextmanager
from abc import abstractmethod, ABC
import os, sys, shutil, subprocess, logging, zipfile

import sentry_sdk
from pydantic.v1 import BaseSettings

# ---------------------------------------------------------------------------- #
# Module
from turing_task_manager.models import QueuedTask
from turing_task_manager.utils import zipdir
from turing_task_manager.exceptions import format_trace

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger(__name__)

RED = "\x1b[31m"
RESET = "\x1b[0m"


# ────────────────────────────── Settings ──────────────────────────────────── #
class EnvSettings(BaseSettings):
    """Settings for the environment"""

    preserve_output: bool = False

    class Config:
        env_prefix = "TTM_"


# ──────────────────────────── Public Interfaces ───────────────────────────── #
class WorkingEnv(ABC):
    """This class provide a working environment with different available paths,
    suitable for the execution of a worker
    """

    @property
    @abstractmethod
    def root_dir(self) -> Path:  # pylint: disable=C0116
        ...

    @property
    @abstractmethod
    def input_dir(self) -> Path:  # pylint: disable=C0116
        ...

    @property
    @abstractmethod
    def output_dir(self) -> Path:  # pylint: disable=C0116
        ...

    @property
    @abstractmethod
    def work_dir(self) -> Path:  # pylint: disable=C0116
        ...


# ────────────────────────────── Private Object ────────────────────────────── #
class EnvBuilder(WorkingEnv):
    def __init__(self, task: QueuedTask[Any], root="~"):
        self._root: Path = Path(root).expanduser()
        self._workdir: Path = self.root_dir / "task-{task_id}".format(task_id=task.id)
        self._input_dir: Path = self.work_dir / "input"
        self._output_dir: Path = self.work_dir / "output"
        self.task = task

        self.silenced_exception = False

        self.is_docker = Path("/.dockerenv").exists()

        # Dev specific watcher to copy files
        self.watcher = None

        self.env_settings = EnvSettings()

    # ──────────────────────────────────────────────────────────────────────── #
    @property
    def dev_docker(self):  # pylint: disable=C0116
        # In the dev environment, watchexec is available in the root of docker
        watchexec = Path("/watchexec")
        return watchexec.exists()

    # ──────────────────────────────────────────────────────────────────────── #
    def __enter__(self):
        """
        Sets up the environment:
            - create a specific folder to work into
                > tasks_envs/{userId}/{taskId}
            - create an empty input folder
            - create an empty output folder
            - change the path?
        """
        logger.debug("⛁ env setup")
        self.work_dir.mkdir(exist_ok=True)

        self.clean_dir(self.work_dir)
        self.input_dir.mkdir()
        self.output_dir.mkdir()

        # In dev mode, copy everything to the output dir
        if self.dev_docker:
            logger.debug("⎘ starting dev output-copy watcher")
            self.watcher = subprocess.Popen(
                f'/watchexec --watch {self.work_dir} "cp -r {self.work_dir} /shared"',
                shell=True,
            )
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """
        Tears down the environment:
            - remove the input dir
            - remove the output dir
            - empty the root dir
        """
        # In dev mode, kill the subprocess watching
        if self.dev_docker:
            logger.debug("⎘ stopping dev watcher")
            self.watcher.kill()

        # Delete everything in this environment
        if self.env_settings.preserve_output:
            logger.debug("⛁ preserved output: %s", self.work_dir)
        else:
            self.clean_dir(self.work_dir)

        # Catch some exceptions
        if exc_type is not None:
            # sentry_sdk.capture_exception(exc_value)
            raise exc_value
        logger.debug("⛁ clean teardown")

    def clean_dir(self, directory: str):
        """Recursively removes everything from a directory, if it exists.

        Arguments:
            directory (str):
                Path to the directory

        Raises:
            AssertionError: if the given path is not a directory
        """
        directory_path = Path(directory)
        if directory_path.exists():
            assert directory_path.is_dir()
            shutil.rmtree(directory_path, ignore_errors=True)
            directory_path.mkdir(exist_ok=True)

    # ───────────────── debug informations - on forced exit ────────────────── #
    def _pip_infos(self, path: Path):
        """Saves a debug file giving information about the current python
        environment. Currently using `pip list`
        """
        with path.open("wb") as fobj:
            pip_list = subprocess.run(["pip", "list"], stdout=fobj)

    def _env_infos(self, path: Path):
        """Saves a debug file giving information about the current environment
        variables.
        """
        VARS_LIST = [
            "COMMIT_HASH",
            "NOTIFICATION_HOST",
            "ENIGMA_HOST",
            "ENIGMA_PORT",
            "ENIGMA_POSTFIX",
            "NOTIFICATION_PORT",
            "NOTIFICATION_POSTFIX",
            "CLUSTER_ID",
            "RABBITMQ_HOST",
            "RABBITMQ_VHOST",
            "RABBITMQ_PORT",
            "RABBITMQ_USERNAME",
            "RABBITMQ_PASSWORD",
            "ENV_TAG",
        ]
        with path.open("w") as fobj:
            fobj.write(
                "\n".join(
                    "{name}={value}".format(
                        name=var_name,
                        value=os.environ.get(var_name),
                    )
                    for var_name in VARS_LIST
                )
            )

    # ────────────────────────── exception silencer ────────────────────────── #
    @contextmanager
    def exceptions_silencer(self):
        try:
            yield
        except BaseException as exc:
            self.silenced_exception = True
            sentry_sdk.capture_exception(exc)
            exc_type, exc_value, exc_traceback = sys.exc_info()
            logger.error(
                f"{RED}(%s){RESET} [%s] %s\n%s",
                "Silenced Exception",
                exc_type.__name__,
                str(exc_value).splitlines()[:1],
                format_trace(exc_type, exc_value, exc_traceback),
            )

    # ──────────────────────────────────────────────────────────────────────── #
    # We want to resolve (follow symlink, replace '.' and '..' syntax, ...) for
    # most path. The executable will be a symlink, by
    # design, so we should keep it that way (not resolving).
    @property
    def root_dir(self) -> Path:  # pylint: disable=C0116
        return self._root.resolve()

    @property
    def input_dir(self) -> Path:  # pylint: disable=C0116
        return self._input_dir.resolve()

    @property
    def output_dir(self) -> Path:  # pylint: disable=C0116
        return self._output_dir.resolve()

    @property
    def work_dir(self) -> Path:  # pylint: disable=C0116
        return self._workdir.resolve()


__all__ = ["WorkingEnv"]
