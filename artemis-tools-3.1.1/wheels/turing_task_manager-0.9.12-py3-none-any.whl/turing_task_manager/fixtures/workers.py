"""This module provides fixtures and util functions to test the workers locally
(in a static environment, without rabbitmq and loki)
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import Callable, Union, List, Dict, Type, TypeVar
from pathlib import Path
import json

# Dependencies
import pytest
from pydantic.v1 import BaseModel
from pytest_mock import MockFixture

# Module
from turing_task_manager import BaseWorker
from turing_task_manager.clients.loki.models import SyncCache, TaskId
from turing_task_manager.env_builder import WorkingEnv, EnvBuilder
from turing_task_manager.models import QueuedTask

# ──────────────────────────────────────────────────────────────────────────── #

__all__ = ["tmp_env", "make_worker", "MakeWorker"]


# ──────────────────────────────────────────────────────────────────────────── #
class MockLokiClient:
    """Temporary code mocking loki client. The long term solution should be to
    mock Loki itself
    """

    def __init__(self):
        self.notifications: Dict[str, List[dict]] = {}
        self.results: Dict[TaskId, SyncCache] = {}

    def notify_output(self, _type: str, _json: Union[BaseModel, dict]):
        """Sink method saving all incoming notifications to a map:
        {notif_type → [notifications]}
        """
        notification = _json.dict() if isinstance(_json, BaseModel) else _json
        self.notifications.setdefault(_type, [])
        self.notifications[_type].append(notification)

    def post_result(self, task_id: TaskId, result: SyncCache):
        """Sink method saving all incoming results (cache for synchronous
        workers) to a map: {task_id → result}
        """
        self.results[task_id] = result

    def get_result(self) -> SyncCache:
        """Retrieves the results sent by this client. Even though we support
        multiple results (as per the interface), there should only be 1 per
        client
        """
        assert len(self.results) == 1
        for key in self.results:
            return self.results[key]


# ──────────────────────────────────────────────────────────────────────────── #
@pytest.fixture
def tmp_env(tmp_path: Path) -> WorkingEnv:
    """Provides a temporary worker environment"""
    test_task = QueuedTask(
        id="test-env",
        processId="arbitrary",
        taskType="env_task",
        taskParams={},
        metadata={},
    )
    with EnvBuilder(test_task, tmp_path) as env:
        yield env


WorkerT = TypeVar("WorkerT", bound=BaseWorker)
MakeWorker = Callable[[Type[WorkerT], dict], WorkerT]


@pytest.fixture
def make_worker(tmp_env: WorkingEnv, mocker: MockFixture) -> MakeWorker:
    """Returns a function that creates a test worker instance (for a given
    class, task) in an isolated environment. This does not require loki or
    rabbitmq. This allows for testing of the `download_inputs` and
    `process_output` methods.
    """

    def make_test_worker(worker_class: Type[WorkerT], task: dict) -> WorkerT:
        """Builds a worker instance in a temporary directory"""
        queued_task = QueuedTask(
            id="arbitrary",
            processId="arbitrary",
            taskType="test",
            taskParams=task,
            metadata={},
        )
        worker = worker_class(queued_task)
        worker.env = tmp_env

        worker.task_loki = MockLokiClient()
        return worker

    return make_test_worker


def print_notifications(mocked_worker: BaseWorker):
    """Prints the notifications cached by a mocked worker"""
    assert isinstance(mocked_worker.task_loki, MockLokiClient)
    mock_client = mocked_worker.task_loki
    for notif_type in mock_client.notifications:
        print(f" {notif_type} ".center(80, "-"))
        for notif in mock_client.notifications[notif_type]:
            print(json.dumps(notif, indent=2))


def print_results(mocked_worker: BaseWorker):
    """Prints the notifications cached by a mocked worker"""
    assert isinstance(mocked_worker.task_loki, MockLokiClient)
    mock_client = mocked_worker.task_loki
    print(f" results ".center(80, "-"))
    print(mock_client.get_result().json(indent=2))
