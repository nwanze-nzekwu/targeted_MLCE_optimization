#!/usr/bin/env python3
# encoding: utf-8
"""
This file defines custom exceptions, as well as Exception handling context
managers, that are supposed to catch every exception in a controlled manner.
"""
# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from datetime import timedelta
from contextlib import AbstractContextManager
from collections import deque
import logging
from multiprocessing import Process
from subprocess import Popen
import sys
import traceback

# Module imports
import sentry_sdk
from turing_task_manager.clients.loki.models import ExecutionStatus
from turing_task_manager.clients import HttpException

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger(__name__)

READY_TIMEOUT = timedelta(minutes=30)
NOT_READY_TIMEOUT = timedelta(hours=4)


# ────────────────────────────────── utils ─────────────────────────────────── #
def format_trace(exc_type, exc_value, exc_traceback) -> str:
    # This is strictly some hacky manipulation to have nice looking errors
    trace_list = (
        "\n"
        + "\n".join(
            traceback.format_exception(
                exc_type,
                exc_value,
                exc_traceback,
            )
        ).strip()
    )
    trace = "\n │ ".join(line for line in trace_list.split("\n"))
    return trace


# ──────────────────────────────────────────────────────────────────────────── #
#                              Custom Exceptions                               #
# ──────────────────────────────────────────────────────────────────────────── #
# Custom exceptions are (most of the time) meant to decorate existing
# exceptions: the error should be catched by some other exception mechanism, we
# just want to rename it to give a more meaningfull context. Sometimes, we know
# some behavior might not cause any existing exception, but is still problematic
# -- we might then raise the exception ourselve, without wrapping another
# exception.
class WrappedExceptionStack(Exception):
    """This wrapped exception class is supposed to be raised when catching an
    existing exception, to give it some context and categorise the type of
    behavior to follow.
    If an exception exists at instanciation, it will remember it and display
    according informations, using a stack -- if the exception went through
    several level of handlers, and was wrapped several times.
    """

    def __init__(self, *args):
        super().__init__(*args)

        # exc_type, exc_value, traceback
        self.exception = _exc_type, exc_value, _traceback = sys.exc_info()

        self.exc_stack = deque()
        if isinstance(exc_value, WrappedExceptionStack):
            self.exc_stack.extend(exc_value.exc_stack)
        self.exc_stack.append(self.exception)

    @property
    def exc_type(self):  # pylint: disable=C0116
        return self.exception[0]

    @property
    def exc_value(self):  # pylint: disable=C0116
        return self.exception[1]

    @property
    def traceback(self):  # pylint: disable=C0116
        return self.exception[2]


# ---------------------------- Custom Exceptions ----------------------------- #
class TaskDependencyMissing(WrappedExceptionStack):
    """This (runtime) exception means that we started executing a task, but some
    of the resources required were not found. This specific exception means that
    we expect those resources to be provided by an independant process."""

    ...


class TaskDependencyFailed(WrappedExceptionStack):
    """This (setup) exception means that an parent in the dependency-tree has
    failed."""

    ...


class TaskNotReadyError(WrappedExceptionStack):
    """This (setup) exception means that this exception is not ready to be run
    (and should be requeued)."""

    ...


class TaskCancelledError(WrappedExceptionStack):
    """This (runtime,setup) exception means that this task or one of its parents
    has been cancelled."""

    ...


class TaskAlreadyCompletedError(WrappedExceptionStack):
    """This (runtime,setup) exception means that this task or its parent process
    has been already completed."""

    ...


class TaskAlreadyRunningError(WrappedExceptionStack):
    """This (runtime,setup) exception means that this task or its parent process
    has been already completed."""

    ...


class EarlyExit(WrappedExceptionStack):
    """This exception is not really an exception, it can be used to exit
    a compatible context manager"""

    ...


class ExecutableError(WrappedExceptionStack):
    """Shows an exception taken from the stderr of another program (probably
    executed using subprocess)."""

    def __init__(self, message: str, return_code: int, stderr: str):
        super().__init__(message)
        self.return_code = return_code
        self.stderr = stderr

    def __str__(self):
        _str = super().__str__()
        return "exit [{1}] {0}\n\n\x1b[1mStderr:\x1b[0m{2}".format(
            _str,
            self.return_code,
            "\n  ‖ ".join([""] + self.stderr.strip().split("\n")),
        )


# ──────────────────────────────────────────────────────────────────────────── #
#                          Abstract Exception Handler                          #
# ──────────────────────────────────────────────────────────────────────────── #
class TaskExceptionHandler(AbstractContextManager):
    """This abstract class just defines the __init__ method of all exception
    handlers used in the context of task processing: they will be instantiated
    according to the listener using them, and to the task currently being
    processed.
    """

    def __init__(self, listener: "AbstractListener", queued_task: "QueuedTask"):
        self.listener = listener
        self.queued_task = queued_task

    def __exit__(self, exc_type, exc_value, exc_trace): ...


# ──────────────────────────────────────────────────────────────────────────── #
#                            Sub Exception Handlers                            #
# ──────────────────────────────────────────────────────────────────────────── #
# Sub-Exception Handlers are just here to wrap some exceptions that happened in
# a specific context: some HTTP error codes (like 404 not found) might be
# expected in some sections of the logic, but not others.
#
# Those handler should be really simple, and just raise exceptions in their
# __exit__ method.
class InputsExceptionHandler(TaskExceptionHandler):
    """Exception Handler specifically for the inputs retrieval step."""

    def __exit__(self, exc_type, exc_value, exc_trace):
        status_code = exc_value.code if exc_type is HttpException else -1
        if status_code == 404:
            raise TaskDependencyMissing("[404] during input downloads -- Missing dependency?")
        if exc_type is not None:
            raise exc_value
        return True


# ──────────────────────────────────────────────────────────────────────────── #
#                            Main Exception Handler                            #
# ──────────────────────────────────────────────────────────────────────────── #
class ExceptionHandler(TaskExceptionHandler):
    """Exception Handlers will be used throughout the execution of the core
    worker logic to intercept any exception raised during execution, and cleanly
    handle then with the appropriate behavior:
    - discard (fail) / requeue the task
    - send notifications
    - cleanly exit

    One of the main goal is to document clearly where exception happen and
    identify the part of the logic responsible. To maximise this concept, we
    will use sub-handlers specialised in some sections of the worker (e.g. an
    HTTP 404 during input download might be handled differently than inside the
    output monitoring)
    """

    # ------------------------------------------------------------------------ #
    def __init__(self, listener: "AbstractListener", queued_task: "QueuedTask"):
        """This exception handler is created in the specific context of
        a `listener` (or worker) processing a `queued_task`.

        The exit method means the end of a task processing. This object has
        attributes to indicate every necessary information regarding to what
        happened during processing. Namely, three scenarios are covered:
        - [success]: Everything is fine
        - [requeued]: Minor issue, we should retry that task
        - [failed]: Critical issue, the task has been dropped

        Additional information can be acquired about the task:
        - [not ready]: The task was not ready to be processed

        Args:
            listener (AbstractListener):
                The listener, or worker, currently processing the task
            queued_task (QueuedTask[Any]):
                The task being processed
        """
        super().__init__(listener, queued_task)
        self.sub_handlers = {}

        self.exited = False

        # Three ways to end a task:
        # - not ready → (requeue, failed if requeued too long)
        # - cancelled → cancelled by user
        # - requeue (and ready) = minor issue
        # - failed (and ready) = critical issue
        # - already completed = task or parent process was successful or failed
        self.ready = True
        self.failed = False
        self.requeued = False
        self.cancelled = False
        self.already_completed = False
        self.already_running = False

    # ------------------------------------------------------------------------ #
    #                    cached properties for sub-handlers                    #
    # ------------------------------------------------------------------------ #
    @property
    def inputs(self):
        """cached property to create a sub-handler if it doesn't exist"""
        if "inputs" not in self.sub_handlers:
            self.sub_handlers["inputs"] = InputsExceptionHandler(
                self.listener,
                self.queued_task,
            )
        return self.sub_handlers["inputs"]

    # ------------------------------------------------------------------------ #
    #                                main logic                                #
    # ------------------------------------------------------------------------ #
    def __exit__(self, exc_type, exc_value, exc_traceback):
        """This method gathers the behavior to handle any exception, and
        populates three important attributes:
        - self.ready, self.requeued, self.failed
        """
        self.exited = True
        early_exit: bool = False
        # ───────────────────── closing resources logic ────────────────────── #
        # Two resources can be open:
        # - self.listener.monitor: Optional[Popen]
        # - self.listener.process: Optional[StoppableThread]
        # If they are None, they have been closed.
        monitor = self.listener.monitor
        if monitor is not None:
            monitor.kill()  # Asking 'not nicely' to stop -- it means that the
            monitor.join()  # thread still executes teardown code [logging]

        process = self.listener.process
        if process is not None:
            process.kill()
            if isinstance(process, Process):
                process.join()
            elif isinstance(process, Popen):
                _ = process.communicate()
            else:
                raise TypeError(f"Unknown process type: {type(process)}")
            # Past this line, the process exited

        # ─────────────────────── handling exceptions ──────────────────────── #
        # No exception / early exit → return immediately
        if exc_type is None or exc_type is EarlyExit:
            early_exit = True

        if not early_exit:
            logger.debug("Exception detected, starting teardown process")

            # If we didn't return above, an exception was raised, and we fail. We
            # did not automatically drop the task though: it depends on the
            # self.requeued attribute.
            self.failed = True

            # ───────────────────── expected errors [minor] ────────────────────── #
            expected = True
            if isinstance(exc_value, TaskDependencyFailed):
                # A parent of the task was failed, so this task is failed as well
                self.cancelled = True
            elif isinstance(exc_value, TaskCancelledError):
                # TODO @mike decide what to do when task is cancelled
                # Send to ucizi's api that the task was cancelled succesfully
                # Ucizi then can aggregate all the tasks that were cancelled
                # and decide if a process was cancelled.
                # Send a final cancel confirmation to Nikos.
                self.cancelled = True
            elif isinstance(exc_value, TaskNotReadyError):
                # If task is not ready, requeue
                self.requeued = True
            elif isinstance(exc_value, TaskAlreadyCompletedError):
                # If task is not ready, requeue
                self.failed = False
                self.already_completed = True
            elif isinstance(exc_value, TaskAlreadyRunningError):
                # If task is not ready, requeue
                self.failed = False
                self.already_running = True
            else:
                expected = False

            # ──────────────────── unexpected errors [major] ───────────────────── #

            if not expected:
                sentry_sdk.capture_exception(exc_value)

            # ────────────────────────── logging logic ─────────────────────────── #
            # Set a higher log level if we dropped (got rid of) the task.
            log_method = logger.error if not self.requeued else logger.info
            severity = "major" if not self.requeued else "minor"

            trace = format_trace(exc_type, exc_value, exc_traceback)

            # Log the error
            log_method(
                "%s[%s] %s: %s\n%s",
                "" if expected else "\x1b[1mUnexpected error\x1b[m\n",
                severity,
                exc_type.__name__,
                str(exc_value).splitlines()[:1],
                trace,
            )

        return True

    def get_task_status(self):
        """Gets the status of a task after the handler performed the __exit__ method"""
        # Find the status of the processed task
        if not self.ready:
            # If a task is not ready, it is still pending
            return ExecutionStatus.pending
        elif self.requeued:
            # An exception occurred, but we decided to requeue the task
            return ExecutionStatus.requeued
        elif self.cancelled:
            # The task has been cancelled
            return ExecutionStatus.cancelled
        elif self.failed:
            # An exception occurred, and we dropped the task
            return ExecutionStatus.failed
        elif self.already_completed or self.already_running:
            return None
        else:
            # The task finished without exception
            return ExecutionStatus.success
