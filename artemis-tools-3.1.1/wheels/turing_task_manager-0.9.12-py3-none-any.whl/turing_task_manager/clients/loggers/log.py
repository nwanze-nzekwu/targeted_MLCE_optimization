import os
import logging


def setup_custom_logger(name: str):
    formatter = logging.Formatter(
        fmt="%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s] {%(pathname)s:%(lineno)d} %(message)s"
    )

    logs_folder = "."
    if not os.path.exists(logs_folder):
        os.makedirs(logs_folder, exist_ok=True)

    handlers = [
        logging.FileHandler("{0}/{1}.log".format(logs_folder, "logs")),
        logging.StreamHandler(),
    ]

    for handler in handlers:
        handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handlers[0])
    logger.addHandler(handlers[1])
    return logger
