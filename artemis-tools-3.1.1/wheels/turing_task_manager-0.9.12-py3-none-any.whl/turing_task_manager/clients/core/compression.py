"""This module defines functions to compress to and from different formats of
file/folder compression
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from io import BytesIO
import gzip
import zlib

# ──────────────────────────────────────────────────────────────────────────── #


# ────────────────────────── Compression Comparison ────────────────────────── #
#               zlib                GZIP                ZIP
# Headers       0x78(01/9C/DA)      1F8B                504B0304
# Format        DEFLATE             DEFLATE             DEFLATE
# Checksum      None                CRC-32              CRC-32
# Lossless?     Yes                 Yes                 Yes
# Data          Stream/single file  Stream/single file  Archive files/directories
# ──────────────────────────────────────────────────────────────────────────── #


# ─────────────────────────────────── gzip ─────────────────────────────────── #
def gzip_data(data: bytes, compress_level=9) -> bytes:
    """GZIP format can not compress several files or directories, it just
    compresses a single file or stream of data.
    That's why it's frequently combined with the tar utility which can create an
    archive of files, directories and their attributes in a single file which is
    then compressed with GZIP.

    It has a GZIP wrapper on the compressed data with the filename and other
    system information, and a CRC-32 checksum at the end to check the integrity
    of the data.
    On the other hand, the final size is usually smaller than zip since it does
    take advantage of redundancy across files.
    """
    out = BytesIO()
    with gzip.GzipFile(fileobj=out, mode="wb", compresslevel=compress_level) as fobj:
        fobj.write(data)
    return out.getvalue()


def gzip_decompress_data(data: bytes):  # pylint: disable=C0116
    return gzip.decompress(data)


# ─────────────────────────────────── zlib ─────────────────────────────────── #
def zlib_data(data: bytes, compress_level: int = 6) -> bytes:
    """The authors of GZIP later extracted its DEFLATE implementation into
    a library named zlib so it could be reused by other formats, most notably
    PNG images.
    PNG images replaced the GIF format that was plagued with the same patent
    issues as unix compress.  It is the most popular DEFLATE implementation and
    is used by many existing programs.

    Most HTTP servers use zlib to compress their data.

    zlib has the option to use a GZIP wrapper on the compressed data or
    a lighter zlib wrapper.  This means that apart from being a library, zlib
    can also be considered a compression format that has separate headers from
    other formats.  This is the reason why our files were compatible with GZIP
    encoding but Snowflake couldn't auto detect them as GZIP, since they had
    zlib headers.

    This format is a light wrapper over raw deflate and does not contain a CRC
    checksum.
    """
    return zlib.compress(data, level=compress_level)


def zlib_decompress_data(data: bytes) -> bytes:
    """A compressed string of data can be easily decompressed by using the
    decompress() function.  This function decompresses the bytes in the data
    argument.

    The wbits argument can be used to manage the size of the history buffer. The
    default value matches the largest window size. It also asks for the
    inclusion of the header and trailer of the compressed file.
    """
    return zlib.decompress(data)


def zlib_data_stream(
    data: bytes,
    compress_level: int = zlib.Z_DEFAULT_COMPRESSION,
    wbits: int = zlib.MAX_WBITS,
) -> bytes:
    """Large data streams can be managed with the compressobj() function, which
    returns a compression object.

    The main difference between the arguments of this function and the
    compress() function is the wbits argument, which controls the window size,
    and whether or not the header and trailer are included in the output.
    """
    compress = zlib.compressobj(compress_level, zlib.DEFLATED, wbits)
    return compress.compress(data) + compress.flush()


def zlib_large_file(
    file_path: str,
    compress_level: int = zlib.Z_DEFAULT_COMPRESSION,
    wbits: int = zlib.MAX_WBITS,
    chunk_size: int = 1024,
) -> bytes:
    """Generator that reads a file in chunks and compresses them"""
    compress = zlib.compressobj(compress_level, zlib.DEFLATED, wbits)
    compression_incomplete = True
    with open(file_path, "rb") as fobj:
        # The zlib might not give us any data back, so we have nothing to yield, just
        # run another loop until we get data to yield.
        while compression_incomplete:
            plain_data = fobj.read(chunk_size)
            if plain_data:
                compressed_data = compress.compress(plain_data)
            else:
                compressed_data = compress.flush()
                compression_incomplete = False
            if compressed_data:
                yield compressed_data


__all__ = [
    "gzip_data",
    "gzip_decompress_data",
    "zlib_data",
    "zlib_decompress_data",
    "zlib_data_stream",
    "zlib_large_file",
]
