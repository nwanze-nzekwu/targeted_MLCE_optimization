"""Module defining convenience type aliases such as `Json `PathLike`, ..."""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import TypeVar, Union, Optional, Tuple
from pathlib import Path

# Dependencies
from pydantic.v1 import BaseModel

# ─────────────────────────────── common types ─────────────────────────────── #
# Json is more explicit than dict
Json = Union[list, dict]

# StatusCode is more explicit than int
StatusCode = TypeVar("StatusCode", bound=int)

# Shorthand for OptionalTuple (OTuple)
T = TypeVar("T")  # pylint: disable=C0103
OTuple = Tuple[Optional[T]]

# Typing that allows either string or Path
PathLike = Union[str, Path]

# Models is any class subclassing pydantic's BaseModel
Model = TypeVar("Model", bound=BaseModel)
