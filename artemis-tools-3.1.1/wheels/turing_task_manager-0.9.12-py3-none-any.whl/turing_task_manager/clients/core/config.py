"""This module exposes generic ways to configure an API client. It specifically
handles the core case of configuring the API adress. Each API client should
subclass those config classes to add specific attributes (passwords, auth, ...)
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from __future__ import annotations

import os
import ssl
from typing import TypeVar, Type, Optional, List, Tuple, Union
from enum import Enum
import logging

# Dependencies
from pydantic.v1 import BaseSettings, validator

# Module
from .types import PathLike

# ──────────────────────────────────────────────────────────────────────────── #
SettingsT = TypeVar("SettingsT", bound=BaseSettings)


class SettingsFromEnv(BaseSettings):
    """Generic class allowing to load a setting class model from the environment
    with a variable prefix (as opposed to the default fixed prefix)
    """

    _alias_keys: Optional[List[Tuple[str, str]]] = None

    @classmethod
    def with_env_prefix(cls: Type[SettingsT], prefix: str, _env_file: PathLike = ".env") -> SettingsT:
        """Loads an instance of this class from environment variables (or an env
        file at the given path) using a given prefix.

        Most environment variables ("HOST", "PORT", ...) are common to multiple
        services at once. A common pattern is to prefix those variables with the
        name of the service it configures (e.g. KAKFA_HOST).

        This method allows to control the prefix to load such variables
        dynamically.
        """

        # We need a throw-away class to load the config from the environment
        class FromEnv(cls):  # type: ignore
            "To leverage pydantic[dotenv] capability, we need to create a class"

            class Config(cls.Config):  # type: ignore
                "Configures pydantic[dotenv] to use a prefix and env_file"
                env_prefix = prefix + ("_" if prefix[-1] != "_" else "")
                env_file = _env_file

        # Once loaded, FromEnv has the exact same attributes as cls (whatever
        # those might be)
        from_env = FromEnv()
        # We return an instance of the actual cls to simplify typing
        return cls.parse_obj(from_env)

    def dict(self, **kwargs):
        """Override default dictionary conversion function in order to apply
        aliases if set
        """
        _dict = super().dict(**kwargs)
        if self._alias_keys is not None:
            for original_key, aliased_key in self._alias_keys:
                _dict[aliased_key] = _dict[original_key]
                del _dict[original_key]
        return _dict


# ──────────────────────────────────────────────────────────────────────────── #
class LogLevel(str, Enum):
    """Standard library logging levels, from lowest to highest"""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class ApiAddress(SettingsFromEnv):
    """Represents the address of an API with host, port and postfix.
    Strips the trailing / of host and postfix, and adds leading / to postfix.
    """

    https: bool = False
    ssl_verify: Optional[Union[bool, str]] = None
    host: str = "0.0.0.0"
    port: int = 80
    postfix: str = ""
    log_level: LogLevel = LogLevel.INFO
    connect_timeout: float = 5  # Connection timeout in seconds (default 5 seconds)
    read_timeout: float = 5  # Read timeout in seconds (default 5 seconds)

    def ssl_verify_to_httpx(self) -> bool | ssl.SSLContext:
        """
        Convert the ssl_verify attribute to a format that httpx can use.
        httpx expects an SSLContext instead of a string.
        """
        if self.ssl_verify is None:
            # ssl_verify path if exists, else REQUESTS_CA_BUNDLE content if not None, otherwise None
            ssl_verify_value = (
                self.ssl_verify if self.ssl_verify is not None else os.environ.get("REQUESTS_CA_BUNDLE", None)
            )
        elif isinstance(self.ssl_verify, bool):
            return self.ssl_verify
        else:
            ssl_verify_value = self.ssl_verify

        return ssl.create_default_context(cafile=ssl_verify_value)

    @validator("postfix", allow_reuse=True)
    def leading_slash(cls, v: str) -> str:  # pylint: disable=E0213,C0103,R0201
        """We want a leading slash if v is not the empty string"""
        return v if (not v) or v.startswith("/") else ("/" + v)

    @validator("host", "postfix", allow_reuse=True)
    def no_trailing_slash(cls, v: str) -> str:  # pylint: disable=E0213,C0103,R0201
        """For both host and postfix, we want to remove any trailing slash"""
        return v[:-1] if v.endswith("/") else v

    class Config:
        """Config to disable casing: most env variables use UPPER CASE"""

        case_sensitive = False

    # ──────────────────────────────── utils ───────────────────────────────── #
    def get_adress(self) -> str:
        """Returns the adress of the API, not including protocol (http/https),
        without trailing /.
        The choice of removing the trailing / is to make the 'root' subpath
        '/' valid.
        """
        return f"{self.host}:{self.port}{self.postfix}"


# ApiSettings represents any subtype of ApiAddress, more specific to a given API
ApiSettingsT = TypeVar("ApiSettingsT", bound=ApiAddress)
ApiSettings = ApiAddress


__all__ = ["ApiAddress", "ApiSettings", "ApiSettingsT", "LogLevel", "SettingsFromEnv"]
