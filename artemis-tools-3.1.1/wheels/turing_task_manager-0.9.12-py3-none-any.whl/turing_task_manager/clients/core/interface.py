"""Generic interface definition for an API Client class"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path
from typing import Optional, Sequence, Union, Tuple, BinaryIO
from abc import ABC, ABCMeta, abstractmethod
from enum import Enum
from dataclasses import dataclass
import logging

# Dependencies
from requests import Response, Session

# Module
from .types import PathLike, Json, Model
from .config import ApiSettings

# ────────────────────────────────── logger ────────────────────────────────── #
logger = logging.getLogger("ttm.clients")

# ─────────────────────────────── data classes ─────────────────────────────── #
VALID_CODES = (200, 201, 202, 203, 204, 205, 205, 207, 208, 226)


class HTTPMethod(str, Enum):
    """Enum of HTTP methods"""

    POST = "post"
    GET = "get"
    PUT = "put"
    HEAD = "head"
    PATCH = "patch"
    DELETE = "delete"


@dataclass
class RetryConfiguration:
    """Configuration to retry an http request to an endpoint on failure"""

    tries: int = 5
    delay: float = 1.0


@dataclass
class CompressedJson:
    """Dataclass to capture the output of a json compression function. The data
    is the compressed bytes, the header is the additional metadata to include in
    any http request sending those bytes as data.
    """

    data: bytes
    header: Json


# ──────────────────────────────── interface ───────────────────────────────── #
class ApiClient(ABC, metaclass=ABCMeta):
    """Interface of an API client handling json, files and compressed files.
    Offers more explicit exceptions, logging and authentication / retry
    capabilities.
    """

    @abstractmethod
    def __init__(self, settings: ApiSettings):
        """Constructor using a custom ApiSettings for each API implementation"""

    # Note: instance attribute are safe because they should be defined in each
    # instance anyway, so linters/LSP will not complain

    # Mutables (attributes, set by instance)
    settings: ApiSettings
    session: Session

    # --------------------------- static constants --------------------------- #
    # To satisfy pylint, static constants have to be declared as abstract in the
    # following way. Simply writing `CONSTANT: int` would work just fine for
    # runtime and jumping to definition.
    @property
    @staticmethod
    @abstractmethod
    def AUTH_RETRY() -> Optional[RetryConfiguration]:  # pylint: disable=C0103
        """Configuration for the retry mechanism on failed authentication.
        Optional: the value None disables this mechanism
        """

    @property
    @staticmethod
    @abstractmethod
    def CONNECTION_RETRY() -> Optional[RetryConfiguration]:  # pylint: disable=C0103
        """Configuration for the retry mechanism on failed connections. Usefull
        if your server sometimes disconnects you, and you don't know why
        Optional: the value None disables this mechanism
        """

    @property
    @staticmethod
    @abstractmethod
    def JSON_MAX_BYTES() -> Optional[int]:  # pylint: disable=C0103
        """Threshold on json sizes for compression. Any json with a size (in
        bytes) above the threshold will be compressed.
        Optional: the value None disables automatic compression of jsons.
        """

    @property
    @staticmethod
    @abstractmethod
    def LOGGER() -> logging.Logger:  # pylint: disable=C0103
        """Logger to be used by this class' instances. Defaults to a generic
        logger of `ttm.clients`.

        This instance allows you to log using your current client's name
        (e.g. 'google.client') even within the generic functions.
        """

    # -------------------------------- utils --------------------------------- #
    @abstractmethod
    def log_request(self, response: Response):
        """Logs a request, showing the request (method, path, body) and response
        (body).
        """

    # ---------------------------- authentication ---------------------------- #
    @abstractmethod
    def authenticate(self):
        """Performs authentication using existing attributes"""

    @abstractmethod
    def is_authenticated(self) -> bool:
        """Checks if the client is currently authenticated"""

    # ------------------------ communication methods ------------------------- #
    @abstractmethod
    def compress_json(self, json_data: Json) -> CompressedJson:
        """Compresses a json, returns a dataclass with bytes and a header"""

    @abstractmethod
    def build_url(self, path: str) -> str:
        """Builds a complete url for a given path, including host url and
        protocol
        """

    @abstractmethod
    def request(
        self,
        path: str,
        method: HTTPMethod,
        *,
        valid_codes: Sequence[int] = VALID_CODES,
        compress_json: bool = True,
        log_response: bool = False,
        retry_auth: bool = True,
        json: Union[Json, Model, None] = None,
        **kwargs,
    ) -> Response:
        """Method wrapping requests library to send any kind of http request.
        Handles raising explicit exceptions on unexpected status code.

        Supports passing pydantic Models to the json keyword argument (converts
        them to a dictionary).

        If the static AUTH_RETRY exists and try_auth is true, it will
        authenticate then retry (on configured error codes, usually 401).
        """

    # --------------------------------- json --------------------------------- #
    @abstractmethod
    def get(self, path: str, **kwargs) -> Json:
        """Wrapper sending a get through the request method, returns a json"""

    @abstractmethod
    def post(self, path: str, **kwargs) -> Json:
        """Wrapper sending a get through the request method, returns a json"""

    @abstractmethod
    def put(self, path: str, **kwargs) -> Json:
        """Wrapper sending a put through the request method, returns a json"""

    @abstractmethod
    def patch(self, path: str, **kwargs) -> Json:
        """Wrapper sending a patch through the request method, returns a json"""

    @abstractmethod
    def delete(self, path: str, **kwargs):
        """Wrapper sending a put through the request method, returns a json"""

    # -------------------------------- files --------------------------------- #
    @abstractmethod
    def upload_file(
        self, path: str, filepath: Union[Tuple[str, BinaryIO], Path], method: HTTPMethod = HTTPMethod.POST, **kwargs
    ) -> Json:
        """Wrapper uploading a file to an endpoint"""

    @abstractmethod
    def download_file(
        self, path: str, filepath: PathLike, method: HTTPMethod = HTTPMethod.GET, **kwargs
    ) -> Optional[Response]:
        """Wrapper downloading a file from an endpoint to a path"""


__all__ = [
    "ApiClient",
    "HTTPMethod",
    "RetryConfiguration",
    "VALID_CODES",
    "CompressedJson",
]
