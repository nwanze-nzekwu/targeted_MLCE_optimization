"""Exposes generic utils related to API calls and the requests library
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import List, Union, Optional
from contextlib import suppress
import logging
import json
import re

try:  # requests can raise simplejson.JSONDecodeError if it's available
    import simplejson

    JsonDecodeErrors = (json.JSONDecodeError, simplejson.JSONDecodeError)
except ImportError:
    JsonDecodeErrors = (json.JSONDecodeError,)

# Dependencies
from requests import Response, Request

# This could be Pydantic v1 or v2, needed for model type check
from pydantic import BaseModel as NativeBaseModel
from pydantic.v1 import BaseModel

# Module
from .types import Json, Model

logger = logging.getLogger("client")


# ──────────────────────────────────────────────────────────────────────────── #
def reset_request(request: Request):
    """Function to reset the I/O pointer to the begining of a file in a prepared
    request. Acts on mutable I/O readers, does not return anything.
    """
    if isinstance(request.files, dict):  # {'filename' → file-like-objects}
        files = request.files.values()
    elif isinstance(request.files, list):
        files = request.files
    else:
        return  # unhandled case

    for file_like in files:
        fileobj = file_like[1]  # tuple: (name, obj) or (name, obj, mimetype)
        if hasattr(fileobj, "seekable") and fileobj.seekable():
            fileobj.seek(0)


def response_json(response: Response) -> dict:
    """Safe function opening the content of a response while catching different
    kind of exceptions:
    - If the content is a json, return it
    - If the content is a string, decode it and set it as {'message': '...'}
    """
    with suppress(*JsonDecodeErrors):
        return response.json()
    return {"message": response.text}


def get_json_size(_json: Json) -> int:
    """Returns the size in bytes of a json (dict) instance"""
    # Note: this code is in a separate function to make it testable
    return len(json.dumps(_json).encode("utf-8"))


def limit_size(json_string: str, max_chars: int = 5000) -> str:
    """Limits the size of a json string to ± max_chars (default: 5000)
    characters, showing the begining and the end. Anything more than that is
    probably noise anyway.

    Note that it inserts a message (single line if the text is a single line,
     on a new line otherwise) where it cuts content, so the resulting string
     would be <= max_chars + 100
    """
    if len(json_string) < max_chars:
        return json_string
    half_size = max_chars // 2
    separator = "\n" if "\n" in json_string else " "
    return "{header}{s}{message}{s}{tail}".format(
        header=json_string[:half_size],
        message=f" - [ ... ] (size limited to first and last {half_size} characters) - ",
        tail=json_string[-half_size:],
        s=separator,
    )


def to_json(model_or_json: Union[Model, List[Model], Json, None]) -> Optional[Json]:
    """Converts a json or pydantic model (including list of models) to json.

    This function does not support lists of mixed types (models & non-models)

    Args:
        model_or_json (Union[Model, List[Model], Json]):
            Json-like object that can be either a valid json (list, dict) or
            a pydantic model (BaseModel, List[BaseModel])

    Returns:
        Json:
            A valid json (list or dict)

    Raises:
        TypeError: If the given argument is not a (list, dict, BaseModel)
    """
    if model_or_json is None or isinstance(model_or_json, dict):
        return model_or_json
    if isinstance(model_or_json, BaseModel) or isinstance(model_or_json, NativeBaseModel):
        return model_or_json.dict()
    if isinstance(model_or_json, list):
        are_models = [isinstance(x, BaseModel) for x in model_or_json]
        if all(are_models):
            return [model.dict() for model in model_or_json]
        if not any(are_models):
            return model_or_json
        raise TypeError("Mixed types (Model & non-model) not supported in top level lists")

    raise TypeError("Expected an instance of (dict, list, BaseModel), received {type}".format(type=type(model_or_json)))


# ───────────────────────────── case conversion ────────────────────────────── #
def snake_to_camel(snake_case: str) -> str:
    """Converts a snake case string 'hello_world' or 'HELLO_WORD' to a camelCase
    string 'helloWorld'
    """
    enum_split = enumerate(snake_case.split("_"))
    return "".join(word.lower() if i == 0 else word.capitalize() for (i, word) in enum_split)


CAMEL_SNAKE_RE = re.compile(r"(?<!^)(?=[A-Z])")


def camel_to_snake(camel: str) -> str:
    """Converts a camel or pascal case string 'helloWorld' or 'HelloWorld' to
    a lowercase snake case string 'hello_world'
    """
    return CAMEL_SNAKE_RE.sub("_", camel).lower()
