"""This module provides custom exceptions for HTTP status code errors, adding
more informations to logs.
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import Union, Optional
from textwrap import dedent
import json

# Dependencies
from requests import Request, PreparedRequest, Response
from .utils import limit_size, response_json, JsonDecodeErrors

# ──────────────────────────────────────────────────────────────────────────── #


class HttpException(ValueError):
    """
    This error shows an easier to understand message for failed requests. It is
    created using a response request, directly received from an API call.
    This provides mainly two benefits:
    - Have a specific exception type for try/except blocks
    - Have an easier to understand exception message
    """

    TEMPLATE = dedent(
        """\
        [{code}] {reason}{sep} {message}

        Request: [{method}] {url}
            ↑ {request_str}
        Response: [{code}] {reason}
            → {response_str}\
        """
    )
    code: int
    response: Response

    def __init__(
        self,
        response: Response,
        message: Optional[str] = None,
    ):
        """
        A StatusCodeError is created from a response that failed (returned the
        wrong status code), and an optional, context-specific message.
        """
        super().__init__(message)
        self.response = response
        self.code = self.response.status_code
        self.message = message or f"Invalid status code ({self.code})"

    def __str__(self):
        """
        Returns an improved error message, stating the meaning of the status
        code in REST Apis, along with the error message sent in the response.
        """
        request: Union[PreparedRequest, Request, None] = getattr(self.response, "request", None)

        request_content: str
        if isinstance(request, PreparedRequest) and request.body is not None:
            try:
                request_json = json.loads(request.body)
            except JsonDecodeErrors:
                request_content = "-- binary data --"
            except UnicodeDecodeError:
                request_content = "-- binary data --"
            else:  # content is a json
                request_content = limit_size(json.dumps(request_json))
        elif isinstance(request, Request):
            if request.json is not None:
                request_content = limit_size(json.dumps(request.json))
            elif request.data:  # defaults to [], which evaluates to false
                request_content = "-- binary data --"
            else:
                request_content = "{}"
        else:
            request_content = "{}"

        # This is a ALL CAPS SENTENCE or None
        reason = self.response.reason or "---"

        return self.TEMPLATE.format(
            code=self.response.status_code,
            reason=" ".join(map(str.capitalize, reason.split(" "))),
            sep=":" if self.message else "",
            message=self.message,
            method=(request.method or "none").upper(),
            url=request.url if request is not None else "-- no url available --",
            response_str=limit_size(json.dumps(response_json(self.response))),
            request_str=request_content,
        )

    def __reduce__(self):
        # This is needed to make sure that the exception can be pickled
        # https://stackoverflow.com/questions/49715881/how-to-pickle-inherited-exceptions
        return type(self), (self.response, self.message)
