"""Exposes a generic API client that implements login functionality, hides most
of the requests behind a few generic method and allows more explicit errors.
"""

import os

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import IO, Callable, TypeVar, Sequence, Union, Optional, Tuple
from typing_extensions import ParamSpec, Concatenate
from pathlib import Path
from json import dumps as json_dumps
import logging
import mimetypes
import functools
import time

# Dependencies
from requests import Request, PreparedRequest, Response, Session
from requests.exceptions import ConnectionError

# Module
from .types import PathLike, Json, Model
from .config import ApiSettings
from .interface import (
    ApiClient,
    CompressedJson,
    HTTPMethod,
    RetryConfiguration,
    VALID_CODES,
)
from .exceptions import HttpException
from .compression import gzip_data
from .utils import response_json, get_json_size, to_json, reset_request

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger(__name__)

# Callable shorthand
T = TypeVar("T")
P = ParamSpec("P")

# Callable response -> bool
FilterResponse = Callable[[Response], bool]

ClientT = TypeVar("ClientT", bound=ApiClient)


# ──────────────────────────────── decorators ──────────────────────────────── #
def authenticated(method: Callable[P, T]) -> Callable[P, T]:
    """Decorator that authenticates before running a method (of an ApiClient
    class) if the client is not yet authenticated.
    """

    @functools.wraps(method)
    def auth_restricted(*args: P.args, **kwargs: P.kwargs) -> T:
        # Should always decorate a method of an ApiClient instance
        instance: ApiClient = args[0]  # type: ignore
        assert isinstance(instance, ApiClient)
        if not instance.is_authenticated():
            instance.authenticate()
        return method(*args, **kwargs)

    return auth_restricted


# ─────────────────────────── generic json client ──────────────────────────── #
class JsonClient(ApiClient):
    """Generic implementation of the abstract ApiClient"""

    LOGGER: logging.Logger = logger
    JSON_MAX_BYTES: int = 100 * 1024
    AUTH_RETRY: RetryConfiguration = RetryConfiguration(tries=5, delay=0.0)
    CONNECTION_RETRY: RetryConfiguration = RetryConfiguration(tries=5, delay=0.5)

    def __init__(self, settings: ApiSettings):  # pylint: disable=W0231
        r"""Constructor only responsible for building the host_url
        attribute. Host url will never end with a /, and follows the pattern:

            (?P<host>)[a-z\.-_]+:(?P<port>[0-9]+)(?P<postfix>(/[a-z_-]+)+)?
        """
        self.settings = settings
        self.session = Session()

    # ──────────────────────────────── utils ───────────────────────────────── #
    def log_request(self, response: Response):
        request_json: Optional[Json] = getattr(response.request, "json", None)
        if request_json is not None:
            self.LOGGER.debug(
                "[%s] %s\n↑ %s\n→ %s",
                response.request.method,
                response.request.url,
                json_dumps(request_json),
                json_dumps(response_json(response)),
            )
        else:
            self.LOGGER.debug(
                "[%s] %s\n→ %s",
                response.request.method,
                response.request.url,
                json_dumps(response_json(response)),
            )

    # ──────────────────────────── authentication ──────────────────────────── #
    def authenticate(self):
        raise NotImplementedError()  # abstract

    def is_authenticated(self) -> bool:
        raise NotImplementedError()

    # ──────────────────────── communication methods ───────────────────────── #
    def build_url(self, path: str) -> str:
        protocol = "https://" if self.settings.https else "http://"
        host_url = self.settings.get_adress()
        return f"{protocol}{host_url}{path}"

    def compress_json(self, json_data: Json) -> CompressedJson:
        """Compresses jsons using the gzip encoding"""
        encoded_json = json_dumps(json_data).encode("utf-8")
        data_bytes = gzip_data(encoded_json)
        header = {
            "Content-Encoding": "gzip",
            "Content-Length": str(len(data_bytes)),
            "Content-Type": "application/json",
        }
        return CompressedJson(data=data_bytes, header=header)

    def __retry_request(
        self,
        request: Request,
        retry_auth: RetryConfiguration,
        retry_conn: RetryConfiguration,
        log: bool = False,
        stream: bool = False,
    ) -> Response:
        """Encapsulates the authentication retry logic. Sends a request and
        retries on 401 Non Authenticated error & Connection Errors.
        Returns a response that might have any status code (including 401 if the
        authentication & retry strategy didn't work).
        """
        # This is a private method, and the only calls to this method should
        # make sure that tries is strictly positive (i.e. non empty loop)
        max_try = max(retry_auth.tries, retry_conn.tries)
        response: Optional[Response] = None
        for i in range(max_try):
            reset_request(request)
            prepared: PreparedRequest = self.session.prepare_request(request)

            is_last_try = (i + 1) == max_try

            # We might face unstable servers that give us minor connection
            # errors. This *does* count as a retry
            try:
                self.settings.ssl_verify = (
                    os.environ.get("REQUESTS_CA_BUNDLE")
                    if self.settings.ssl_verify is None
                    else self.settings.ssl_verify
                )
                response = self.session.send(
                    prepared,
                    timeout=(self.settings.connect_timeout, self.settings.read_timeout),
                    stream=stream,
                    verify=self.settings.ssl_verify if (self.settings.https and self.settings.ssl_verify) else False,
                )
            except ConnectionError as ce:
                if is_last_try:
                    raise ce
                # --------------------- connection retry --------------------- #
                logger.warning("(%s) Connection error, retrying: %s", self.__class__.__name__, ce)
                time.sleep(retry_conn.delay)
            else:  # No connection error, response exists
                if log:
                    self.log_request(response)

                # Successfull request
                if response.status_code != 401:
                    return response

                # ------------------- authentication retry ------------------- #
                # Authenticate and sleep on 401
                self.authenticate()
                time.sleep(retry_auth.delay)

        if response is None:
            raise RuntimeError("This should never happen")

        # If we didn't succeed after trying `tries` times, return the request
        return response

    def request(
        self,
        path: str,
        method: HTTPMethod,
        *,
        valid_codes: Sequence[int] = VALID_CODES,
        compress_json: bool = True,
        log_response: bool = False,
        json: Union[Json, Model, None] = None,
        stream: bool = False,
        **kwargs,
    ) -> Response:

        assert len(path) > 0 and path[0] == "/", f"'{path}' should start with /"
        # Note: we add 'json' as an explicit keyword argument to provide typing
        # (dict & Model)
        converted_json: Optional[Json] = to_json(json)

        # Create the request instance (used no matter the logic afterwards)
        request = Request(method, self.build_url(path), json=converted_json, **kwargs)

        # Json compression logic (working with kwargs now, not 'json')
        compress = compress_json and request.json and not request.data
        compress = compress and self.JSON_MAX_BYTES is not None
        if compress and get_json_size(request.json) > self.JSON_MAX_BYTES:
            compressed = self.compress_json(request.json)  # compress it
            request.headers.update(compressed.header)
            request.data = compressed.data
            request.json = None

        # Replace 'None' RetryConfiguration by a Configuration with 0 retries
        auth_retry = self.AUTH_RETRY or RetryConfiguration(tries=0)
        conn_retry = self.CONNECTION_RETRY or RetryConfiguration(tries=0)

        if max(auth_retry.tries, conn_retry.tries) > 0:
            # This will log every intermediate call if `log_response` is True
            response = self.__retry_request(request, auth_retry, conn_retry, log_response, stream)
        else:
            self.settings.ssl_verify = (
                os.environ.get("REQUESTS_CA_BUNDLE") if self.settings.ssl_verify is None else self.settings.ssl_verify
            )
            response = self.session.send(
                self.session.prepare_request(request),
                timeout=(self.settings.connect_timeout, self.settings.read_timeout),
                stream=stream,
                verify=self.settings.ssl_verify if (self.settings.https and self.settings.ssl_verify) else False,
            )
            if log_response:
                self.log_request(response)

        if response.status_code in valid_codes:
            return response
        raise HttpException(response)

    # --------------------------------- json --------------------------------- #
    def get(self, path: str, **kwargs) -> Json:
        """Wrapper sending a get through the _request method, returns a json"""
        return response_json(self.request(path, method=HTTPMethod.GET, **kwargs))

    def post(self, path: str, **kwargs) -> Json:
        """Wrapper sending a get through the _request method, returns a json"""
        return response_json(self.request(path, method=HTTPMethod.POST, **kwargs))

    def put(self, path: str, **kwargs) -> Json:
        """Wrapper sending a put through the _request method, returns a json"""
        return response_json(self.request(path, method=HTTPMethod.PUT, **kwargs))

    def patch(self, path: str, **kwargs) -> Json:
        """Wrapper sending a patch through the _request method, returns a json"""
        return response_json(self.request(path, method=HTTPMethod.PATCH, **kwargs))

    def delete(self, path: str, **kwargs) -> Json:
        """Wrapper sending a put through the _request method, returns a json"""
        return response_json(self.request(path, method=HTTPMethod.DELETE, **kwargs))

    # -------------------------------- files --------------------------------- #
    def upload_file(
        self,
        path: str,
        filepath: Union[Tuple[str, IO], PathLike],
        method: HTTPMethod = HTTPMethod.POST,
        **kwargs,
    ) -> Json:
        """Wrapper uploading a file or a stream to an endpoint

        :param path: Endpoint to use for upload
        :param filepath: Path, str or Tuple of (filename, File-like object) to upload
        :param method: REST method to use for upload
        """
        if isinstance(filepath, (tuple, list)):
            filename, fileobj = filepath  # we're getting a tuple (name, binary)
        else:
            filepath = Path(filepath)
            if not filepath.exists():
                raise FileNotFoundError(f"Path {filepath} was not found")
            filename = filepath.name
            fileobj = filepath.open("rb")

        mime_type, _ = mimetypes.guess_type(filename)
        with fileobj:
            kwargs["files"] = {"file": (filename, fileobj, mime_type)}
            return response_json(self.request(path, method, **kwargs))

    def download_file(
        self,
        path: str,
        filepath: Optional[PathLike],
        method: HTTPMethod = HTTPMethod.GET,
        stream: bool = False,
        **kwargs,
    ) -> Optional[Response]:
        """Wrapper downloading or streaming a file from an endpoint to a path"""
        if filepath is None and not stream:  # !stream ⇒ filepath
            raise ValueError("File path is required when stream is False")
        response = self.request(path, method, stream=stream, **kwargs)
        if stream:
            return response
        with open(filepath, "wb") as fobj:
            for chunk in response:  # A chunk of 128 bytes
                fobj.write(chunk)


__all__ = [
    "ApiClient",
    "HTTPMethod",
    "RetryConfiguration",
    "VALID_CODES",
    "authenticated",
]
