"""Module providing type aliases (static typing) and type definitions for
pydantic
"""

import re
from typing import Union
from datetime import datetime


# See https://pydantic-docs.helpmanual.io/usage/types/#custom-data-types
class IsoTimestamp(str):
    """Custom type for string timestamps following the ISO 8601 format. It
    accepts both `datetime` and `str`, and performs validation and conversion.
    """

    ISO_PATTERN = r"\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z)"
    ISO_REGEX = re.compile(ISO_PATTERN)

    FRACTIONAL_SECONDS_PATTERN = r"\d\.\d+"
    FRACTIONAL_SECONDS_REGEX = re.compile(FRACTIONAL_SECONDS_PATTERN)

    TIME_ZONE_PATTERN = r"([+-][0-2]\d:[0-5]\d|Z)"
    TIME_ZONE_REGEX = re.compile(TIME_ZONE_PATTERN)

    # ──────────────────────────────────────────────────────────────────────── #
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def __modify_schema__(cls, field_schema: dict):
        """Provides default information on any field of this type"""
        field_schema.update(
            pattern=cls.ISO_PATTERN,
            examples=["2021-11-09T10:12:54.383Z"],
        )

    @classmethod
    def validate(cls: "IsoTimestamp", timestamp: Union[str, datetime]) -> str:
        """Validates any given value to be one of:
        - a string following the ISO 8601 format
        - a datetime, to be converted to an ISO 8601 string

        Note: accepts strings without UTC time offsets and assumes they follow
        the GMT +00 (Z).

        Args:
            timestamp(Union[str, datetime]):
                A timestamp as an ISO 8501 string or as a datetime instance.

        Returns:
            str:
                A validated timestamp string following the ISO 8601 format.

        Raises:
            ValueError: if the given string does not follow ISO format
            TypeError: if the given input is not str or datetime
        """
        if isinstance(timestamp, datetime):
            return timestamp.isoformat()  # wrap the str in our class
        if isinstance(timestamp, str):
            if len(re.findall(cls.TIME_ZONE_REGEX, timestamp)) == 0:
                # Where no timezone is specified assume Zulu time - UTC+0
                timestamp += "Z"
            if not len(re.findall(cls.FRACTIONAL_SECONDS_REGEX, timestamp)) == 1:
                no_timezone, timezone_info = re.split(cls.TIME_ZONE_REGEX, timestamp)[:2]
                # without timezone info, the final value in no_timezone will be seconds
                # timestamp = '2021-11-09T10:12:54' + .000 + '+01:20' = 2021-11-09T10:12:54.000+01:20
                timestamp = no_timezone + ".000" + timezone_info
            if not cls.ISO_REGEX.fullmatch(timestamp.upper()):
                raise ValueError("invalid ISO format")
            return timestamp
        raise TypeError(f"datetime or string required, found {type(timestamp)}")

    def __repr__(self):
        return f"IsoTimestamp({super().__repr__()})"
