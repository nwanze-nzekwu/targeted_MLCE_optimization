"""Models for Loki's Http Client"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Libraries
from typing import TypeVar, Union, Optional, Generic, List, Any
from enum import Enum

# Dependencies
from pydantic.v1 import BaseModel, Field
from pydantic.v1.generics import GenericModel

from evoml_api_models.utils import use_alias

# Module
from .types import IsoTimestamp

# ──────────────────────────────────────────────────────────────────────────── #
# Generic types
Json = Union[dict, list]
ProcessMetadata = Optional[Json]

LinuxEpoch = float

# Ids
ProcessId = TypeVar("ProcessId", bound=str)
TaskId = TypeVar("TaskId", bound=str)
Id = TypeVar("Id", bound=str)
WorkerId = TypeVar("WorkerId", bound=str)
ClusterId = TypeVar("ClusterId", bound=str)


class IdType(str, Enum):
    """Differentiates between task and process when both ids are equally valid"""

    task = "tasks"
    process = "processes"


# ────────────────────────────────── tasks ─────────────────────────────────── #
# Statuses
class ExecutionStatus(str, Enum):
    """Different states (status) of a task/process"""

    pending = "pending"
    created = "created"
    ready = "ready"
    running = "running"
    requeued = "requeued"
    success = "success"
    failed = "failed"
    cancelled = "cancelled"
    unknown = "unknown"


class Status(BaseModel):
    """Generic status information model"""

    status: ExecutionStatus


class ProcessStatus(Status):
    """Status of a process"""


class TaskStatus(Status):
    """Status of a task"""


# Progress
class Progress(BaseModel):
    """Progress of a task or process"""

    value: float = Field(..., ge=0, le=1)


# Queues
class Queue(BaseModel):
    name: str


# ────────────────────────────── notifications ─────────────────────────────── #
# Paths enum
class NotificationType(str, Enum):
    """Notification types supported by Loki, each corresponds to a subpath of
    {loki}/notifications/
    """

    output = "output"
    status = "status"
    log = "log"


# Output notification
class Output(BaseModel):
    """Very generic notification sending produced output for live rendering.
    Those output might or might not have been uploaded to a database beforehand.
    """

    outputType: str
    outputJson: Json


class LogLevel(str, Enum):
    critical = "critical"
    error = "error"
    warning = "warning"
    info = "info"
    debug = "debug"
    unknown = "unknown"


# ---------------------------- temporary feature ----------------------------- #
class LogNotification(BaseModel):
    message: str
    level: LogLevel
    timestamp: IsoTimestamp


class Parameter(BaseModel):
    name: str
    value: str


class LogModelStatus(BaseModel):
    pipelineId: str
    status: str
    log: LogNotification


class LogModelStart(BaseModel):
    id: str
    mlModelName: str
    name: str
    parameters: List[Parameter]


class ModelOutputType(str, Enum):
    PIPELINE = "pipeline"
    PIPELINE_STATUS = "pipelineStatus"


# ---------------------------------------------------------------------------- #


# Generic notification
NotifT = TypeVar("NotifT", Status, Output, LogNotification)


class TaskInformation(BaseModel):
    processId: ProcessId
    taskId: TaskId
    metadata: ProcessMetadata = None
    taskType: str


class Notification(GenericModel, Generic[NotifT], TaskInformation):
    # Notification content
    notification: NotifT


# ───────────────────────── workers status/requests ────────────────────────── #
# Statuses
class WorkerStatus(str, Enum):
    """Different states (status) of a worker"""

    booting = "booting"
    ready = "ready"
    processing = "processing"
    stopped = "stopped"
    unreachable = "unreachable"


class WorkerCurrentStatus(BaseModel):
    """Response of a worker status query"""

    status: WorkerStatus
    statusChangedAt: str


@use_alias
class WorkerStatusChange(BaseModel):
    """Payload of a worker status change"""

    status: WorkerStatus = Field(..., alias="newStatus")
    current_task: Optional[TaskId] = Field(..., alias="currentTask")


class WorkerAvailableRequests(WorkerCurrentStatus):
    availableRequests: bool


# Requests
class RequestType(str, Enum):
    # Act on the worker
    killWorker = "killWorker"
    stopWorker = "stopWorker"
    # Act on the task
    killTask = "killTask"
    stopTask = "stopTask"


class Request(BaseModel):
    "Requests are cached instructions to be executed by workers when possible"

    type: RequestType


class RequestQuery(BaseModel):
    workerId: WorkerId
    taskId: Optional[TaskId] = None
    processId: Optional[ProcessId] = None


class RequestList(BaseModel):
    requests: List[Request]


# Registering workers
class CpuFrequency(BaseModel):
    minHz: int
    maxHz: int


class CpuInfo(BaseModel):
    count: int
    frequencies: List[CpuFrequency]


class GpuInfo(BaseModel):
    id: int
    name: str
    memoryInBytes: int
    driver: str


class CodeDependency(BaseModel):
    name: str
    version: str


class Label(BaseModel):
    """A label that can be attached to a worker."""

    name: str
    value: str


class WorkerInfo(BaseModel):
    type: str
    queue: str


class WorkerRegistration(BaseModel):
    clusterId: ClusterId
    workers: List[WorkerInfo]
    # Hardware
    cpus: CpuInfo
    gpus: List[GpuInfo] = []
    memoryInBytes: int
    # Software
    hostname: str = "unknown"
    databaseUrl: str
    rabbitmqUrl: str
    # Versioning
    version: Optional[str]
    pythonVersion: Optional[str]
    commit: Optional[str] = "unknown"
    codeDependencies: List[CodeDependency] = []
    labels: List[Label] = []


class RegisteredWorker(WorkerRegistration):
    id: str = Field(..., alias="id")
    status: WorkerStatus = WorkerStatus.booting
    requests: List[Request] = []
    createdAt: IsoTimestamp
    lastStatusChangeEpoch: LinuxEpoch
    lastInteractionEpoch: LinuxEpoch


# ─────────────────────── results / synchronous cache ──────────────────────── #
class SyncCache(BaseModel):
    """This data srutcture holds a single json generated by a synchronous
    worker, and helps cache it to allow a synchronous return in the API.

    Note: this is used for the /results/... endpoints.
    """

    resultType: str = Field(..., example="foo")
    content: Any = Field(..., example=dict(foo="bar"))
