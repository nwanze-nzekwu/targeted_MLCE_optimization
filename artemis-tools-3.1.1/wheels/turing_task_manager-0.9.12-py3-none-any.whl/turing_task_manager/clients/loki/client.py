"""Implementation of two Api Clients for Loki. The first one, `LokiClient`. is
generic. The second one, `TaskBoundLoki`, is instantiated bound to a specific
task and provides convenience interfaces to send notifications without passing
recurrent data (i.e. data known on the task level)
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Libraries
from typing import TypeVar, Union, List, Optional
from enum import Enum
import logging

# Dependencies
from pydantic.v1 import BaseModel

# Modules
from .. import core, authenticated
from .models import (  # Type aliases (mainly XyzId → str)
    Id,
    Json,
    NotifT,
    ProcessId,
    TaskId,
    WorkerId,
    LogNotification,
)
from .models import (
    ExecutionStatus,
    IdType,
    Notification,
    NotificationType,
    Output,
    Progress,
    Queue,
    RegisteredWorker,
    Request,
    RequestList,
    RequestQuery,
    Status,
    SyncCache,
    TaskInformation,
    WorkerAvailableRequests,
    WorkerCurrentStatus,
    WorkerRegistration,
    WorkerStatus,
    WorkerStatusChange,
    Label,
)

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger("loki")

Model = TypeVar("Model", bound=BaseModel)


# ───────────────────────────────── settings ───────────────────────────────── #
class LokiSettings(core.ApiAddress):
    """Loki Specific settings (for auth config)"""


class NotificationSubpath(str, Enum):
    """Subpaths in Loki API's `/notifications/...` endpoints. Each corresponds
    to a speficific type of notification
    """

    status = "status"
    output = "output"
    progress = "progress"


# ────────────────────────────────── client ────────────────────────────────── #
class LokiClient(core.JsonClient):
    """Base client to interact with Loki API"""

    LOGGER = logger
    AUTH_RETRY = None  # No authentication mechanism yet
    JSON_MAX_BYTES = None  # No compression support
    settings: LokiSettings

    def __init__(self, settings: LokiSettings):
        super().__init__(settings)

    def authenticate(self):
        return  # No authentication mechanism yet

    def is_authenticated(self) -> bool:
        return True  # No authentication mechanism yet

    # ──────────────────────────── notifications ───────────────────────────── #
    @authenticated
    def notify(self, subpath: NotificationType, notification: Notification):
        """Sends a notification to one of the several subpath of /notifications"""
        # Convert the notification to a json
        self.post(f"/notifications/{subpath.value}", json=notification)

    # ─────────────────────────────── progress ─────────────────────────────── #
    @authenticated
    def get_progress(self, _type: IdType, _id: Id) -> float:
        """Gets the progress of a task or process by id"""
        progress = Progress.parse_obj(self.get(f"{_type.value}/{_id}/progress"))
        return progress.value

    @authenticated
    def set_progress(self, task_id: TaskId, progress: float):
        """Sets the progress of a task (can't set a process' progress)"""
        self.put(f"/tasks/{task_id}/progress", json=Progress(value=progress))

    # ──────────────────────────────── status ──────────────────────────────── #
    @authenticated
    def _get_status(self, _type: IdType, _id: Id) -> ExecutionStatus:
        """Gets the status of a task or process by id"""
        return Status.parse_obj(self.get(f"/{_type.value}/{_id}/status")).status

    @authenticated
    def get_process_status(self, process_id: ProcessId) -> ExecutionStatus:
        """Gets the status of a task by id"""
        return self._get_status(IdType.process, process_id)

    @authenticated
    def get_task_status(self, task_id: TaskId) -> ExecutionStatus:
        """Gets the status of a task by id"""
        return self._get_status(IdType.task, task_id)

    @authenticated
    def set_task_status(self, task_id: TaskId, status: ExecutionStatus):
        """Sets the status of a task (can't set a process' status)"""
        self.put(f"/tasks/{task_id}/status", json=Status(status=status))

    # ─────────────────────────────── results ──────────────────────────────── #
    @authenticated
    def post_result(self, task_id: TaskId, result: SyncCache):
        """Caches the result of a synchronous task so that it can be returned in
        the API
        """
        self.post(f"/results/{task_id}", json=result)

    # ─────────────────────────────── workers ──────────────────────────────── #
    @authenticated
    def register_worker(self, form: WorkerRegistration) -> RegisteredWorker:
        """Registers a worker to a cluster and return its new worker id"""
        return RegisteredWorker.parse_obj(self.post("/workers/register", json=form))

    @authenticated
    def unregister_worker(self, worker_id: WorkerId):
        """Removes a worker from the cluster.

        Args:
            worker_id: ID of the worker to remove
        """
        self.delete(f"/workers/{worker_id}")

    @authenticated
    def get_worker_status(self, worker_id: WorkerId) -> WorkerStatus:
        """Gets the status of a worker by id"""
        return WorkerCurrentStatus.parse_obj(self.get(f"/workers/{worker_id}/status")).status

    @authenticated
    def set_worker_status(
        self,
        worker_id: WorkerId,
        status: WorkerStatus,
        current_task: Optional[TaskId] = None,
    ) -> WorkerAvailableRequests:
        """Sets the status of a worker by id, returns a model including the new
        status and available requests
        """
        update = WorkerStatusChange(status=status, current_task=current_task)
        return WorkerAvailableRequests.parse_obj(self.put(f"/workers/{worker_id}/status", json=update))

    @authenticated
    def perform_heartbeat(self, worker_id: WorkerId):
        """Notifies API that the worker is still alive"""
        self.get(f"/workers/{worker_id}/heartbeat")

    @authenticated
    def get_requests(
        self,
        worker_id: WorkerId,
        task_id: Optional[TaskId] = None,
        process_id: Optional[ProcessId] = None,
    ) -> List[Request]:
        """Retrieves the current list of requests for a worker. Requests are
        instructions sent by the central API (Loki) to workers. As Loki does not
        have a way to contact the workers, they should query the list of
        requests themselve.
        """
        query = RequestQuery(
            workerId=worker_id,
            taskId=task_id,
            processId=process_id,
        )
        request_list = self.get("/workers/requests", json=query)
        return RequestList.parse_obj(request_list).requests

    @authenticated
    def get_queue_name(self, task_type: str) -> str:
        """Get the name of the RMQ queue associated with a task type"""
        return Queue.parse_obj(self.get(f"/queue_name/task/{task_type}")).name

    @authenticated
    def get_workers_by_labels(self, labels: List[Label], cluster_id: Optional[str] = None) -> List[RegisteredWorker]:
        """Get all workers that have all the specified labels.

        Args:
            labels: List of labels to filter workers by. A worker must have ALL the provided labels
                  (with matching name and value) to be included in the result.
            cluster_id: Optional cluster ID to filter workers by.

        Returns:
            A list of workers that have all the specified labels.
        """
        # Convert labels to query parameter format
        label_params = [f"{label.name}:{label.value}" for label in labels]

        # Build query parameters
        params = {"label": label_params}
        if cluster_id is not None:
            params["clusterId"] = cluster_id

        response = self.get("/workers", params=params)
        return [RegisteredWorker.parse_obj(worker) for worker in response["workers"]]

    @authenticated
    def get_worker(self, worker_id: WorkerId) -> RegisteredWorker:
        """Gets a worker by its ID.

        Args:
            worker_id: ID of the worker to get

        Returns:
            The worker information including its current labels.
        """
        return RegisteredWorker.parse_obj(self.get(f"/workers/{worker_id}"))

    @authenticated
    def add_worker_labels(self, worker_id: WorkerId, labels: List[Label]) -> RegisteredWorker:
        """Adds labels to a worker.

        Args:
            worker_id: ID of the worker to add labels to
            labels: List of labels to add. Duplicate labels (same name and value) will be ignored.

        Returns:
            The updated worker with the new labels added.
        """
        # First get current labels
        current_worker = self.get_worker(worker_id)
        current_labels = current_worker.labels or []

        # Add new labels, avoiding duplicates
        new_labels = current_labels.copy()
        for label in labels:
            if not any(l.name == label.name and l.value == label.value for l in current_labels):
                new_labels.append(label)

        # Update all labels at once
        return RegisteredWorker.parse_obj(self.put(f"/workers/{worker_id}/labels", json=new_labels))

    @authenticated
    def remove_worker_labels(self, worker_id: WorkerId, labels: List[Label]) -> RegisteredWorker:
        """Removes labels from a worker.

        Args:
            worker_id: ID of the worker to remove labels from
            labels: List of labels to remove. Both name and value must match for a label to be removed.

        Returns:
            The updated worker with the specified labels removed.
        """
        # First get current labels
        current_worker = self.get_worker(worker_id)
        current_labels = current_worker.labels or []

        # Remove specified labels
        new_labels = [
            label
            for label in current_labels
            if not any(l.name == label.name and l.value == label.value for l in labels)
        ]

        # Update all labels at once
        return RegisteredWorker.parse_obj(self.put(f"/workers/{worker_id}/labels", json=new_labels))

    @authenticated
    def set_worker_labels(self, worker_id: WorkerId, labels: List[Label]) -> RegisteredWorker:
        """Replaces all labels on a worker with the provided labels.

        Args:
            worker_id: ID of the worker to set labels for
            labels: List of labels to set. This will completely replace any existing labels.

        Returns:
            The updated worker with the new labels set.
        """
        return RegisteredWorker.parse_obj(self.put(f"/workers/{worker_id}/labels", json=labels))


class TaskBoundLoki(LokiClient):
    """Specialised instance of Loki Client instantiated with a given task's
    information to providing a simpler interface for notifications.
    """

    def __init__(self, settings: LokiSettings, task: TaskInformation):
        """Each instance is bound to a specific task"""
        super().__init__(settings)
        self.task = task

    @authenticated
    def notify(self, subpath: NotificationType, content: Union[NotifT, Notification]):  # pylint: disable=W0221
        """Sends a notification to one of the several subpath of /notifications.
        Accepts either a Notification (see LokiClient) or only the content of
        the notification (Status, Output), using this instance's context to fill
        the remaining field.
        """
        if isinstance(content, Notification):
            notification = content
        else:
            notification = Notification(notification=content, **self.task.dict())
        return super().notify(subpath, notification)

    @authenticated
    def notify_output(self, _type: str, _json: Union[Model, Json]):
        """Sends an output notification (using this instance's context)"""
        return self.notify(
            NotificationType.output,
            Output(outputType=_type, outputJson=_json),
        )

    @authenticated
    def notify_status(self, status: ExecutionStatus):
        """Sends a status notification (using this instance's context)"""
        return self.notify(NotificationType.status, Status(status=status))

    @authenticated
    def notify_log(self, *logs: LogNotification):
        """Sends any number of log notifications to Loki

        Args:
            logs: Any number of log notifications
        """
        for log in logs:
            self.notify(NotificationType.log, log)
