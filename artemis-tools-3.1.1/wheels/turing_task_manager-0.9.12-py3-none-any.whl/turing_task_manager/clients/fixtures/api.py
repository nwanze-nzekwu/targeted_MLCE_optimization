"""Module offering utilities to deploy a FastAPI instance as a fixture"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import Callable, Any, Optional
from io import StringIO
from pathlib import Path
from dataclasses import dataclass
from multiprocessing import Process
from functools import cached_property
from socket import socket
from uuid import uuid4
from time import sleep
from datetime import datetime
import os
import requests

# Dependencies
from fastapi import FastAPI
from pytest_cov.embed import cleanup_on_sigterm
import uvicorn


# ──────────────────────────────────────────────────────────────────────────── #
F = Callable[..., Any]


def redirect_process_std(capture: StringIO):
    """Decorator that redirects the stderr/stdout of a function to the given
    StringIO like object
    """

    def redirected(function: F) -> F:
        """Decorator for a function running in a separate process that will
        redirect its stdout/stderr.

        Do not use on a method in the main process, as this redirects the
        *entire* stdout/stderr (even after the end of the function).
        """

        def decorated(*args, **kwargs):
            """Sets the entire sys' stdout/stderr as we're running in
            a dedicated process
            """
            import sys

            sys.stderr = capture
            sys.stdout = capture
            return function(*args, **kwargs)

        return decorated

    return redirected


def set_subprocess_workdir(workdir: Path):
    """Decorator that sets the working directory of a subprocess to the given
    path. Should be used to decorate a function run with some kind of
    multi-threading / multi-processing.
    """

    # See this answer: https://stackoverflow.com/a/51755835
    def set_workdir(function: F) -> F:
        """Decorator for a function running in a separate process that will
        set its working directory.
        """

        def decorated(*args, **kwargs):
            """Sets the entire sys' stdout/stderr as we're running in
            a dedicated process
            """
            import os

            os.chdir(workdir)
            return function(*args, **kwargs)

        return decorated

    return set_workdir


# ──────────────────────────────────────────────────────────────────────────── #
@dataclass
class Server:
    """Simple dataclass containing all important elements about an API running
    in the background (host, url, stdout/stderr redirection)
    """

    host: str
    port: int
    std_file: Path
    name: str = "server"

    @cached_property
    def logs_enabled(self) -> bool:
        env_var = f"mock_{self.name}_logs".upper()
        return bool(os.environ.get(env_var, False))

    def get_logs(self) -> str:
        """Gets the content of server logs in the std redirection"""
        return self.std_file.read_text()

    def clear_logs(self):
        """Clears the content of server logs in the std redirection"""
        self.std_file.write_text("")

    def print_logs(self, title: Optional[str] = None) -> None:
        """Gets the content of server logs in the std redirection, and prints
        it with the given title.
        """
        if not self.logs_enabled:
            return
        logs = self.get_logs()
        title = title or f"{self.name} logs"
        if len(logs) > 0:
            print(f" {title} ".center(80, "-"))
            print(logs, end="")
            print("-" * 80)
        self.clear_logs()


class ApiFixture:
    """Class offering the methods needed to declare a generic fixture running
    any starlette/fastapi API in the background and redirecting its output to an
    isolated StringIO.

    This is a class to easily allow specific APIs to defined a clear, named
    fixture with all the necessary context. An instance then provides all the
    generic functionalities needed.
    """

    HOST_ENV_VAR = "MOCK_SERVICES_HOST"
    HEALTH_CHECK_ENDPOINT_PATH = "/health-check"
    MAX_SPINUP_WAITING_TIME = 10

    app: FastAPI
    workdir: Path
    std_file: Path
    process: Process
    server_name: str

    def __init__(self, app: FastAPI, workdir: Path = Path(), server_name: str = "server"):
        self.app = app
        self.server_name = server_name
        uuid = str(uuid4()).replace("-", "")[:16]
        self.workdir = workdir or Path()
        self.std_file = workdir / f"{server_name}-{uuid}.out"
        self.std_file.touch()
        self.process = None

    @staticmethod
    def get_free_port() -> int:
        """Gets a free port on the current system"""
        with socket() as s:
            s.bind(("", 0))
            port = s.getsockname()[1]
        return port

    def setup(self) -> Server:
        """Performs the fixture's setup, starting the server and returning
        a Server config
        """
        # This call allows pytest-cov to follow up the coverage of the API run
        # in multiprocessing, even though we kill it with `Process.terminate`
        # see: https://pytest-cov.readthedocs.io/en/v2.6.1/mp.html
        cleanup_on_sigterm()

        self.register_health_check_endpoint(self.app)

        # Server configuration
        port = self.get_free_port()
        host = os.environ.get(self.HOST_ENV_VAR, "127.0.0.1")
        config = Server(host=host, port=port, std_file=self.std_file, name=self.server_name)

        # Decorator to set the working directory (if we run in a pytest tmp dir)
        set_workdir = set_subprocess_workdir(self.workdir)

        # Decorator to redirect the stderr/stdout to a file
        redirect = redirect_process_std(open(self.std_file, "a"))

        # Run the server in a process and decorate the main function
        self.process = Process(
            target=set_workdir(redirect(uvicorn.run)),
            args=(self.app,),
            kwargs={"host": config.host, "port": config.port},
            daemon=True,
        )
        self.process.start()
        self.wait_for_fastapi_spinup(host, port)

        config.print_logs(f"{self.server_name} setup")
        return config  # Config to connect to the server & follow the logs

    def teardown(self):
        """Performs the fixture's teardown, stopping the server and cleaning the
        stdout/stderr redirection resources
        """
        assert self.process is not None
        self.process.terminate()
        self.process.join()
        self.std_file.unlink()

    def register_health_check_endpoint(self, app: FastAPI):
        """Registers a health check endpoint with FastAPI"""
        app.add_api_route(self.HEALTH_CHECK_ENDPOINT_PATH, lambda: {"status": "ok"}, methods=["GET"])

    def wait_for_fastapi_spinup(self, host: str, port: int, timeout: int = MAX_SPINUP_WAITING_TIME) -> None:
        """Waits for a FastAPI instance to spin up, by checking its health check.

        Args:
            host (str): the host url of the FastAPI instance
            port (int): the port of the FastAPI instance
            timeout (int, optional): the amount of time until it stops waiting. Defaults to MAX_SPINUP_WAITING_TIME.

        Raises:
            Exception: When the server does not start in time
        """

        start_time = datetime.now()
        health_check_url = f"http://{host}:{port}{self.HEALTH_CHECK_ENDPOINT_PATH}"

        while True:
            sleep(0.1)

            try:
                response = requests.get(health_check_url, timeout=0.2)
                if response.status_code == 200:
                    break
            except Exception:
                pass

            if (datetime.now() - start_time).seconds > timeout:
                raise Exception("Server did not start in time")
