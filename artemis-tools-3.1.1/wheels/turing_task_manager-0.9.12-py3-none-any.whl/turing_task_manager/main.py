""" """

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
import logging

# Dependencies
import requests

# Module
from . import logger as log
from .listener import RMQListener


# ──────────────────────────────────────────────────────────────────────────── #
def log_start():
    """Logs that the main program started, and finds some context to add for all
    of the process duration on the root logger.
    """
    log.setup_root_logger()  # Setup the root logger

    # ------------------- setting up a descriptive logger -------------------- #
    root = logging.getLogger()

    # Gets the docker info once
    try:
        with open("/proc/1/cpuset") as proc:
            docker_id = proc.read().strip().split("-")[-1]
    except FileNotFoundError:
        docker_id = "docker_id_not_found"

    # We add some context to the logger for all of execution. Every message
    # logged to a file will contain this context as keys in a json format.

    # Note: by convention, the last element of the queue name is the task type
    log.add_context(
        root,
        docker_id=docker_id,
    )


def start(worker_class, task_type: str):
    """Starts the task-manager using a custom worker, handling the task-specific
    behaviors for the task you're trying to solve.

    Arguments:
        worker_class:
            Subclass of BaseWorker, defining all of the specific behaviors to
            handle a specific task.

        queue (str):
            Name of the queue you should be connecting to.
    """
    # Start logging process and run the worker
    log_start()
    listener = RMQListener("/tmp", worker_class, task_type)
    listener.listen()
