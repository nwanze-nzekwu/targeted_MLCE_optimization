#!/usr/bin/env python3
# encoding: utf-8
"""
This file defines classes that can monitor a folder, and execute a piece of code
on each new file added to that folder.
This class is intended to be runnable as a thread, depending on a shared
variable to stop execution.
"""
# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from __future__ import annotations

import ctypes
import typing
from datetime import datetime
from json.decoder import JSONDecodeError
from typing import List, Generator, Optional, Callable, Iterable, Set
from pathlib import Path
import time, threading, logging
import json

# Module
from pydantic.v1 import ValidationError
from turing_task_manager.clients.loki.client import TaskBoundLoki
from turing_task_manager.clients.loki.models import (
    LogNotification,
    LogModelStart,
    LogModelStatus,
    ModelOutputType,
    LogLevel,
)
from turing_task_manager.clients.loki.types import IsoTimestamp

if typing.TYPE_CHECKING:
    from turing_task_manager import BaseWorker

# ──────────────────────────────────────────────────────────────────────────── #
logger = logging.getLogger(__name__)

PathSorter = Callable[[Iterable[Path]], Iterable[Path]]


# ──────────────────────────────────────────────────────────────────────────── #
class StoppableThread(threading.Thread):
    """Builds on top `threading.Thread` and provides a mechanism to safely
    stop/kill a thread from the main process or another thread.

    Stopping a thread safely (and killing it) in Python is not a builtin. The
    following stackoverflow thread offers several options to implement such
    a behavior. The one chose is to use a shared thread-safe attribute and
    communicate between threads using this attribute. It also means that the
    thread is responsible for checking periodically the value of that shared
    attribute.

    https://www.geeksforgeeks.org/python-different-ways-to-kill-a-thread/
    """

    def __init__(self, *args_, **kwargs_):
        super().__init__(*args_, **kwargs_)
        self._stopevent = threading.Event()
        self._nice = None

    def stop(self, nicely=True):
        """Uses a thread-safe attribute (see `threading.Event`) to stop
        a thread, either nicely (trigerring a teardown routine that might take
        time) or not nicely (equivalent of kill, stopping as quickly as
        possible)
        """
        if nicely:
            logger.debug("\x1b[34m[stop]\x1b[0m signal received")
        else:
            logger.debug("\x1b[30m[kill]\x1b[0m signal received")
        self._nice = nicely
        self._stopevent.set()

    def kill(self):
        """Kills the threads, and makes it exit as quickly as possible. See the
        stop method for more informations
        """
        self.stop(nicely=False)

    def stopped(self):
        """Checks a thread-safe variable to know if the thread has been stopped
        externaly by another thread"""
        return self._stopevent.isSet()

    def async_raise(self, exception):
        """Raises an asynchronous exception in another thread.
        Read http://docs.python.org/c-api/init.html#PyThreadState_SetAsyncExc
        for further enlightenments.
        :param exception: Exception class to be raised in that thread
        """
        # Ensuring and releasing GIL are useless since we're not in C
        # gil_state = ctypes.pythonapi.PyGILState_Ensure()
        ret = None
        if self.is_alive():
            ret = ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(self.ident), ctypes.py_object(exception))
            # ctypes.pythonapi.PyGILState_Release(gil_state)
            if ret == 0:
                raise ValueError("Invalid thread ID {}".format(self.ident))
            elif ret > 1:
                ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(self.ident), None)
                raise SystemError("PyThreadState_SetAsyncExc failed")
        return ret == 1


# ──────────────────────────────────────────────────────────────────────────── #
class ExceptionThread(StoppableThread):
    """Builds on top of a stoppable thread and provides a mechanism to raise an
    exception from a thread into the main process.

    There's no builtin way to do this in python, so this class provides
    a minimal implementation, caching the exception in a private variable that
    can be retrieved by the main thread.

    The following stack-overflow thread offers other implementation options, but
    the current one is simple and covers the use-case.

    Note: use the _run method for the main code of this type of threads.

    https://stackoverflow.com/questions/2829329/catch-a-threads-exception-in-the-caller-thread-in-python
    """

    def __init__(self, *args_, **kwargs_):
        super().__init__(*args_, **kwargs_)
        self._exception = None

    def _run(self):
        """This private run must implement the main behavior of the thread, as
        the public `run` defines a generic behavior catching exceptions.
        """
        super().run()

    def run(self):
        """Public run wrapping around the private run method to catch any
        exception.
        """
        try:
            self._run()
        except BaseException as e:  # pylint: disable=broad-except
            logger.error("exception triggered in thread")
            self._exception = e

    def get_exception(self) -> Optional[BaseException]:
        """Returns the exception that occurred in that thread, if any. Only
        accurate if the thread actually exited.
        """
        return self._exception


# ──────────────────────────── Pulblic Interfaces ──────────────────────────── #
class FolderMonitor(ExceptionThread):
    """
    Generic class monitoring a folder, and executing arbitrary code everytime a
    new file appears in that folder.

    By design, this class must be executable in a thread.
    """

    # ------------------------------------------------------------------------ #
    def __init__(self, folder: str, sort_function: PathSorter, *args, **kwargs):
        """Constructs a folder monitor

        Args:
            folder (str):
                The folder to monitor
            sort_function (PathSorter):
                Function that sorts a list of paths and returns the sorted list.
            stop_condition (Callable[None, bool]):
                A callable without arguments returning a boolean, used to stop
                the thread.
        """
        kwargs["name"] = kwargs.get("name", "Folder Monitor")  # Default name
        super().__init__(*args, **kwargs)
        self.already_processed: Set[Path] = set()
        self.sort_function = sort_function
        self.folder = Path(folder)

    # ──────────────────────────────────────────────────────────────────────── #
    #                               main methods                               #
    # ──────────────────────────────────────────────────────────────────────── #
    def _get_files(self) -> List[Path]:
        """Local function getting (and sorting) all non-processed files"""
        # we use this loop to avoid FileNotFound errors happening in
        # evoml worker
        while True:
            try:
                all_paths = set(map(Path.absolute, self.folder.rglob("*")))
                filtered_paths = all_paths.difference(self.already_processed)
            except FileNotFoundError:
                continue
            sorted_paths = self.sort_function(filtered_paths)
            return list(sorted_paths)

    def check_new_files(self) -> Generator[Path, None, None]:
        """Generator returning every new files in the folder"""
        new_files = self._get_files()
        while len(new_files) > 0:
            for file_path in new_files:
                self.already_processed.add(file_path)
                self.update_logs()
                self.send_logs()
                yield file_path.absolute()
            new_files = self._get_files()

    def process_new_files_batch(self, new_files: Iterable[Path]):
        """Handles processing many files one by one"""
        for file in new_files:
            self.process(file, self.already_processed)

    def _run(self):
        """Starts monitoring a folder. For each new files, process will be
        called
        """
        logger.info("\x1b[0;32m⊚\x1b[0m thread instantiated")
        while not self.stopped():  # see StoppableThread
            new_files = list(self.check_new_files())
            if new_files:
                self.process_new_files_batch(new_files)
            self.update_logs()
            self.send_logs()
            time.sleep(0.5)
        if not self._nice:
            # On [kill] stop, just quit
            logger.info("\x1b[31m⊚\x1b[0m thread exits [killed]")
            return

        # On [nice] stop, check one last time that everything is fine
        self.process_new_files_batch(self.check_new_files())

        self.process_on_exit(self.already_processed)
        logger.info("\x1b[31m⊚\x1b[0m thread exits [stopped]")

    # ──────────────────────────────────────────────────────────────────────── #
    #                         Not Implemented methods                          #
    # ──────────────────────────────────────────────────────────────────────── #
    def process(self, file_path: Path, processed_paths: Set[Path]):  # pylint: disable=no-self-use,unused-argument
        """Processes a file (arbitrary behavior).
        Receives as well the list of already processed files, to account for
        dependency in the processing of some output.

        Args:
            file_path (Path):
                Complete path to a file to process
            processed_paths (List[Path]):
                List of files already processed by this thread. No guarantee of
                ordering. The current file (file_path) is always included.
        """
        raise NotImplementedError

    def update_logs(self):
        raise NotImplementedError

    def send_logs(self, force: bool = False):
        raise NotImplementedError

    def process_on_exit(self, paths_list: Set[Path]):  # pylint: disable=no-self-use,unused-argument
        """
        This function is called on thread exit, and is given all of the files
        in the folder.
        It can be used as an exit-hook to execute some arbitrary code that needs
        all of the inputs of the directory.
        Does nothing by default.

        Args:
            paths_list (Path):
                List of paths to every file in the monitored folder
        """
        ...


# ──────────────────────────────────────────────────────────────────────────── #
class TaskMonitor(FolderMonitor):
    """
    Extends the folder monitor, but provides the specific behavior to handle
    files created by a task specific executable and also defines behaviour
    for reading logs and sending them through loki.
    """

    def __init__(self, worker: "BaseWorker", folder: str, *args, **kwargs):
        super().__init__(folder, worker.sort_files, *args, **kwargs)
        self.worker = worker
        self.logs_count = 0  # count of the number of logs seen so far
        self.logs_threshold = 1
        self.logs_buffer: List[LogNotification] = []
        self.model_logs_count = 0  # count of the number of model logs seen so far
        self.model_logs_buffer: List = []
        self.model_logs_path = Path(folder) / "model.json"
        self.log_path = Path(folder) / ".log"

    def process_new_files_batch(self, new_files: Iterable[Path]):
        """Handles processing many files one by one"""
        # Run on thread
        self.worker.monitored_run(super().process_new_files_batch, new_files)

    def process(self, file_path: Path, processed_paths: Set[Path]):
        """
        Process method for the Task Monitor. In this class, the processing of
        each file depends on the task given in the constructor.
        We then use a private method, :func:`_process`, that is given that task
        as first input to allow for single-dispatching the method to several
        implementation, depending on the task type.

        Args:
            file_path (Path): complete path to a file to process
        """
        self.worker.process_outputs(file_path, processed_paths)

    def process_on_exit(self, paths_list: Set[Path]):
        """On exit process method for the Task Monitor. In this class, the
        processing on exit depends on the task given in the constructor.
        We then use a private method, :func:`_process_on_exit`, that is given
        that task as first input to allow for single-dispatching the method to
        several implementation, depending on the task type.

        Args:
            paths_list (Path):
                List of paths to every file in the monitored folder
        """
        logger.debug("→ process files on exit")
        self.worker.monitored_run(self.worker.process_outputs_on_exit, paths_list)
        self.update_logs()
        self.send_logs(force=True)

    # --------------------------------- logs --------------------------------- #
    def update_logs(self):
        """
        Checks the new lines in the log file that were written by the
        executable and updates the logs_buffer with the new logs.
        """
        if not self.log_path.is_file():
            return

        # Local buffer of new log lines
        log_lines = []
        with self.log_path.open() as fobj:
            for i, line in enumerate(fobj):
                if i >= self.logs_count:
                    log_lines.append(line)

        self.logs_count += len(log_lines)

        for log_line in log_lines:
            try:
                self.logs_buffer.append(LogNotification.parse_obj(json.loads(log_line, strict=False)))
            except JSONDecodeError as e:
                logger.debug(f"Error decoding log line : {e}")
                self.logs_buffer.append(
                    LogNotification(
                        message="Error decoding log line",
                        level=LogLevel.debug,
                        timestamp=IsoTimestamp.validate(datetime.utcnow()),
                    )
                )

        # -------------------------------------------------------------------- #
        # Code to support the temporary feature of sending notifications about
        # models
        if not self.model_logs_path.is_file():
            return

        # Local buffer of new model log lines
        model_log_lines = []
        with self.model_logs_path.open() as fobj:
            for i, line in enumerate(fobj):
                if i >= self.model_logs_count:
                    model_log_lines.append(line)

        self.model_logs_count += len(model_log_lines)

        for log_line in model_log_lines:
            try:
                self.model_logs_buffer.append(LogModelStart.parse_obj(json.loads(log_line, strict=False)))
            except ValidationError:
                self.model_logs_buffer.append(LogModelStatus.parse_obj(json.loads(log_line, strict=False)))

    def send_logs(self, force: bool = False):
        """Sends the new logs generated if there are more then the set threshold
        or if we are at the end of the executable run and empties the logs
        buffer
        """
        loki_client: TaskBoundLoki = self.worker.task_loki

        if force or len(self.logs_buffer) >= self.logs_threshold:
            loki_client.notify_log(*self.logs_buffer)
            self.logs_buffer = []

        if force or len(self.model_logs_buffer) >= self.logs_threshold:
            for model_notif in self.model_logs_buffer:
                if isinstance(model_notif, LogModelStart):
                    loki_client.notify_output(ModelOutputType.PIPELINE, model_notif)
                else:
                    loki_client.notify_output(ModelOutputType.PIPELINE_STATUS, model_notif)
            self.model_logs_buffer = []
