# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from typing import List, Any, Dict, Generic, TypeVar, Optional, NewType, Union
from enum import Enum

# Dependencies
from pydantic.v1 import BaseModel, Field, BaseSettings
from pydantic.v1.generics import GenericModel

from evoml_api_models import BaseModelWithAlias

# Module
from turing_task_manager.clients.loki.models import (
    ProcessMetadata,
    TaskId,
    ProcessId,
)

Pipe = int
"""Type for file descriptors, as returned by `os.pipe()`."""

# ────────────────────────────── queuing tasks ─────────────────────────────── #
TaskT = TypeVar("TaskT")


class CachingOptions(BaseModel):
    read: bool = False
    write: bool = False


class QueuedTask(BaseModelWithAlias, GenericModel, Generic[TaskT]):
    """Json sent to every workers through rabbitmq, including informations for
    the processing.
    The exact format of taskParams is defined in each worker.
    """

    id: TaskId = Field(..., alias="_id")
    processId: ProcessId
    taskType: str
    taskParams: TaskT
    metadata: ProcessMetadata
    dependencies: List[str] = []
    cache: CachingOptions = CachingOptions()


class ReQueuedTask(QueuedTask[TaskT], Generic[TaskT]):
    """Specific message for a task that failed for some reason, and has been put
    back in the queue; Provides additional informations:
    - The Exception that caused the last re-queuing
    - The number of time that task has been re-queued
    - The timestamp of the first time that task has been re-queued
    """

    exception: str
    numRequeued: int
    lastRequeuedAt: str
    firstRequeuedAt: str
    retryDelaySeconds: int = 10


# ─────────────────────────── Resource Allocation ──────────────────────────── #
class ResourceAllocation(BaseSettings):
    """Env variables to provide CPU and RAM allocation values.

    ONLY to be set where Cgroup values are unavailable.

    These should be set carefully as they'll be taken as true
    even if they do not agree with Cgroup or python built in values"""

    cpus: Optional[int]
    memory_bytes: Optional[int]

    class Config:
        env_prefix = "allocated_"
