"""Ficture for Loki's mock Api, exposing a server that runs in a subprocess,
settings to access this server and an Http Client
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path

# Dependencies
import pytest
from _pytest.tmpdir import TempPathFactory

# Module
from turing_task_manager.mock.loki.api import app as loki_app
from turing_task_manager.clients.loki.client import LokiClient, LokiSettings
from turing_task_manager.clients.fixtures import ApiFixture, Server


# ─────────────────────────── API client & server ──────────────────────────── #
@pytest.fixture(scope="module")
def loki_api(tmp_path_factory: TempPathFactory) -> Server:
    """Runs Loki File API in the background. The Server object provided the
    address/port of the server and allows access to the logs redirection
    """
    tmp_dir: Path = tmp_path_factory.mktemp("loki")
    fixture = ApiFixture(loki_app, tmp_dir, server_name="Loki")
    server = fixture.setup()
    yield server
    fixture.teardown()


@pytest.fixture
def loki_settings(loki_api: Server) -> LokiSettings:
    """Fixture providing settings for a Loki API mock instance running in the
    background. Also provides groupped print of the logs/prints of this API
    instance
    """
    loki_api.print_logs()
    yield LokiSettings(host=loki_api.host, port=loki_api.port)
    loki_api.print_logs()


@pytest.fixture
def loki_client(loki_settings: LokiSettings) -> LokiClient:
    """Fixture providing a Loki API client instance connected to a mock API
    running in the background
    """
    yield LokiClient(loki_settings)
