"""Utils functions for the Loki mock Api"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from uuid import uuid4

# Dependencies

# Module


# ──────────────────────────────────────────────────────────────────────────── #
def get_id() -> str:
    """Returns a random id containing lowercase letters and numbers"""
    return str(uuid4()).replace("-", "")[:16]
