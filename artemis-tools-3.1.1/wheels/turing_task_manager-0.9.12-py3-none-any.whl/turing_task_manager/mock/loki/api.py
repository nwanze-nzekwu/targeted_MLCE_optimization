"""Mock Api for Loki, mainly directed at allowing mock workers to run in a unit
testing setting
"""

# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
from pathlib import Path
import logging

# Dependencies
from fastapi import FastAPI
from tinydb import TinyDB

# Module
from .utils import get_id

# ──────────────────────────────────────────────────────────────────────────── #
app = FastAPI()
logger = logging.getLogger("uvicorn")


# ───────────────────────────────── database ───────────────────────────────── #
BASE_DIR = Path()
DB_PATH: Path
JSON_DATABASE: TinyDB


@app.on_event("startup")
def startup():
    """Setup the mock database"""
    global JSON_DATABASE, DB_PATH  # pylint: disable=W0603
    logger.info("Working directory: %s", BASE_DIR.absolute())
    DB_PATH = BASE_DIR / f"database-{get_id()}"
    JSON_DATABASE = TinyDB(DB_PATH)
    logger.info("Json database: %s", JSON_DATABASE)


@app.on_event("shutdown")
def shutdown():
    """Tear down the mock database"""
    global JSON_DATABASE, DB_PATH  # pylint: disable=W0603
    DB_PATH.unlink()
    del JSON_DATABASE


# ──────────────────────────────────────────────────────────────────────────── #
