#!/usr/bin/env python3
# encoding: utf-8
"""
This file defines a logger used to monitor the execution of tasks and the
running of a worker
"""
# ───────────────────────────────── imports ────────────────────────────────── #
import re, json, os, uuid
from logging import (  # Directly import classes
    addLevelName,
    basicConfig,
    CRITICAL,
    DEBUG,
    ERROR,
    FileHandler,
    Filter,
    Formatter,
    getLogger,
    INFO,
    Logger,
    LoggerAdapter,
    LogRecord,
    StreamHandler,
    WARNING,
)
from pathlib import Path
import logging.handlers as handlers
import logging

# ──────────────────────────────────────────────────────────────────────────── #
EXEC = 5  # Custom logging level

STRIP_REGEX = re.compile(r"\x1b\[[;\d]*[A-Za-z]")


def strip_ansi(string: str) -> str:
    """Strips ansi characters from a message"""
    return STRIP_REGEX.sub("", string)


# ──────────────────────────────────────────────────────────────────────────── #
class ConsoleFormatter(Formatter):
    """Console-specific formating, including ansi-colored severity levels and
    shortened logger names.
    """

    default_time_format = "%H:%M:%S"

    def format(self, record: LogRecord):
        """Classic formatting: we just change the color depending on the
        severity
        """
        if record.levelno == EXEC:
            level = "\x1b[1m" + r"[%(levelname)s] " + "\x1b[0m"
        elif record.levelno == DEBUG:
            level = "\x1b[35m" + r"[%(levelname)s]" + "\x1b[0m"
        elif record.levelno == INFO:
            level = "\x1b[34m" + r"[%(levelname)s] " + "\x1b[0m"
        elif record.levelno == WARNING:
            level = "\x1b[33m" + r"[%(levelname)s]" + "\x1b[0m"
        elif record.levelno == ERROR:
            level = "\x1b[31m" + r"[%(levelname)s]" + "\x1b[0m"
        elif record.levelno == CRITICAL:
            level = "\x1b[1;31m" + r"[%(levelname)s]" + "\x1b[0m"
        else:
            level = "[nolevel]"

        # We only keep the last element of a dotted name
        record.name = record.name.split(".")[-1]

        self._style._fmt = f"{level} %(asctime)s [%(name)s] %(message)s"  # pylint: disable=protected-access
        return Formatter.format(self, record)


class JsonFormatter(ConsoleFormatter):
    """File-specific handler, targeted at Kibana. Uses json format to add as
    many contextual informations as possible (as Kibana, or other automated log
    tools, allow to easily display/filter specific fields)
    """

    # Attributes of the record object that should not be included in the log as
    # independant fields.
    EXCLUDE_ATTRS = (
        "created",
        "message",
        "args",
        "process",
        "thread",
        "path",
        "msg",
        "stack_info",
        "exc_info",
        "exc_text",
        "lineno",
        "relativeCreated",
        "msecs",
        "filename",
        "levelno",
        "levelname",
    )

    def format(self, record: LogRecord):
        """
        This formatting will dump messages as a json. It doesn't work through
        the _fmt style option, as python's logger doesn't directly support
        json. We instead use the different values of the record object to
        construct a dictionnary, then encoded to json.

        To reuse the concept of logging's `extra` keyword argument, that allow
        users to easily add new attribute to a record, we automatically dump
        every attribute, and maintain a list of blacklisted attributes
        (`JsonFormatter.EXCLUDE_ATTRS`).
        """
        content = {name: value for (name, value) in record.__dict__.items() if name not in self.EXCLUDE_ATTRS}
        # This from the record class includes the arguments given using
        # % placeholders (ex: logging.error('Size too big: %d > 10', n))
        content["message"] = strip_ansi(record.getMessage())

        # More descriptive name for level-name
        content["severity"] = record.levelname

        # Full names are interesting for the record, but unreadable.
        content["shortname"] = record.name.split(".")[-1]

        # Including exceptions info when it makes sense
        if record.exc_info:
            content["exc_info"] = self.formatException(record.exc_info)

        content["stdout"] = super().format(record)

        # We need a basic structure to support Kibana's log conventions
        time = self.formatTime(record, datefmt="%Y-%m-%dT%H:%M:%S")
        return json.dumps(
            {
                "time": "{0}.{msecs:03}".format(time, msecs=int(record.msecs)),
                "stream": "stderr",
                "log": content,
            }
        )


# ──────────────────────────────────────────────────────────────────────────── #
# See https://docs.python.org/3/howto/logging-cookbook.html#filters-contextual
class ContextFilter(Filter):
    """This is a filter which injects contextual information into the log
    record. That contextual information is expected as a dict given as the
    keyword argument 'extra', as it could be passed on a logging call.

    The given extra dictionary will have priority over arguments given at call
    time.

    Note that attempting to overwrite an existing record attribute will have no
    effect.
    """

    def __init__(self, name: str, extra: dict):
        assert isinstance(extra, dict)
        super().__init__(name)
        self.extra = extra

    def filter(self, record):
        for key, value in self.extra.items():
            if not hasattr(record, key):
                setattr(record, key, value)
        return True


def add_context(logger: Logger, **context):
    """Adds context to a logger through a filter. Works with the ContextFilter
    class.
    Every named argument is passed as extra attributes to each records.
    Doesn't have effect on handlers added after the call.
    """
    _filter = ContextFilter(logger.name, extra=context)

    for handler in logger.handlers:
        handler.addFilter(_filter)


def remove_context(logger: Logger, *keys):
    """Removes context (added with 'add_context') from a logger. Each argument
    must be a (string) key given as context.

    Note that if you added several keys at the same time, you need to remove
    them at the same time as well.
    """
    is_context = lambda _filter: isinstance(_filter, ContextFilter)
    for handler in logger.handlers:
        for _filter in filter(is_context, handler.filters):
            if all(key in _filter.extra.keys() for key in keys):
                handler.removeFilter(_filter)


def update_context(logger: Logger, **context):
    """Updates the value of a context variable (added with 'add_context') from
    a logger. Each argument must be a (string) key given as context.
    """
    is_context = lambda _filter: isinstance(_filter, ContextFilter)
    for handler in logger.handlers:
        for _filter in filter(is_context, handler.filters):
            for key, value in context.items():
                if key in _filter.extra:
                    _filter.extra[key] = value


# ──────────────────────────────────────────────────────────────────────────── #
def setup_root_logger() -> None:
    """
    Create a custom logger for the workers codebase
    """
    root = getLogger()
    root.setLevel(EXEC)
    if root.handlers:
        return

    # Add a new level named EXEC for executable out
    addLevelName(EXEC, "EXEC")

    IS_DEV = os.environ.get("ENV_TAG") == "develop"

    logs_volume = Path("/volumes/logs")
    if logs_volume.exists() and logs_volume.is_dir() and IS_DEV:
        # File handler: logs as json to a file named with a unique postfix
        # If env variable exists use that instead (useful for testing)
        random_unique = str(uuid.uuid4()).replace("-", "")[:15]  # 15 char random string
        unique = os.environ.get("CUSTOM_WORKER_LOG_PREFIX", random_unique)
        file_handler = handlers.TimedRotatingFileHandler(
            logs_volume / "{unique}-{ppid}-{pid}.log".format(pid=os.getpid(), ppid=os.getppid(), unique=unique),
            atTime="midnight",
            backupCount=1,
        )
        file_handler.setFormatter(JsonFormatter())
        file_handler.setLevel(EXEC)

        # Quickfix to prevent too many requests to Kibana. We don't log to the
        # filesystem if 'running' is False (not set and True are OK)
        file_handler.addFilter(lambda record: getattr(record, "running", True))

        root.addHandler(file_handler)

    # Stream handler: logs to console as short messages, using ansi colors
    stream_handler = StreamHandler()
    stream_handler.setFormatter(ConsoleFormatter() if IS_DEV else JsonFormatter())
    stream_handler.setLevel(EXEC)

    root.addHandler(stream_handler)
