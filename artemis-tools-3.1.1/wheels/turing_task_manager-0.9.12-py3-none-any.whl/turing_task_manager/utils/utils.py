"""Utils that do not fit in existing utils submodules."""

from typing import Dict, Any, Iterator, Optional
import threading
import traceback
import contextlib, logging

import sentry_sdk

logger = logging.getLogger(__name__)

__all__ = [
    "RepeatingTimer",
    "dict_to_camelcase",
    "_to_camelcase",
    "cli_opt",
    "short_id",
    "silence_errors",
    "hide_fields",
]


class RepeatingTimer(threading.Thread):
    """
    Class to run a function periodically
    """

    def __init__(self, function, interval, *args_, **kwargs_):
        super(RepeatingTimer, self).__init__()
        self.args = args_
        self.kwargs = kwargs_
        self.stop_event = threading.Event()
        self.function = function
        self.interval = interval

    def run(self):
        while not self.stop_event.wait(self.interval):
            self.callback()

    def stop(self):
        self.stop_event.set()

    def callback(self):
        """Handles running the repeating function"""
        try:
            self.function(*self.args, **self.kwargs)
        except:
            traceback.print_exc()


def _to_camelcase(string: str):
    """Converts a snake_case string to camelCase"""
    split = string.split("_")  # len(split) >= 1
    return split[0] + "".join(x.capitalize() or "_" for x in split[1:])


def dict_to_camelcase(dictionary: dict):
    """Takes a dictionary and returns a copy of that dictionary where every key
    is converted to camelCase, recursively.
    """
    new = {}
    for key, value in dictionary.items():
        if isinstance(value, dict):
            value = dict_to_camelcase(value)
        new[_to_camelcase(key)] = value
    return new


def short_id(long_id: str):
    """Sends a shorter id with an arbitrary algorithm"""
    return long_id[:8]


@contextlib.contextmanager
def silence_errors(message: str = "{}", _logger: Optional[logging.Logger] = None) -> Iterator[None]:
    """Small context manager silencing the first exception occuring inside the
    with statement, then quiting. Make sure when using it that no code outside
    of the statement depends on code inside the statement.

    Args:
        message (str):
            A python3's format template string. It must include a '{}'
            placeholder that will be replaced by the error silenced.
            By default, the error is logged as is.

        _logger (logging.Logger):
            The logger used to log the silenced error. A global variable named
            logger will be used by default, and if it doesn't exist, the root
            logger will be used.
    """
    # Note: this is similar to contextlib.suppress, but it logs systematically.
    local_logger = _logger or globals().get("logger", logging.getLogger())

    try:
        yield
    except BaseException as exc:
        sentry_sdk.capture_exception(exc)
        local_logger.error(message.format(exc))


def hide_fields(dictionary: dict, **fields_mapping: Dict[str, int]) -> dict:
    """Takes a dictionary and a mapping of {field name (str) → max count (int)},
    and (recursively), for every occurence of the given 'field name', limits its
    content length to the associated 'max count'.
    This creates a (shallow) copy of the dictionary.
    """
    new_dict = {}
    for field_name, value in dictionary.items():
        # First, check for nested dictionaries
        is_list = isinstance(value, (list, tuple)) and len(value) > 0
        if isinstance(value, dict):
            new_dict[field_name] = hide_fields(value, **fields_mapping)
        elif is_list and isinstance(value[0], dict):
            new_dict[field_name] = [hide_fields(v, **fields_mapping) for v in value]
        # Then, limit the size of fields in the mapping
        elif is_list and field_name in fields_mapping:
            upper_bound = max(0, min(fields_mapping[field_name], len(value)))
            new_dict[field_name] = value[:upper_bound]
            if upper_bound == fields_mapping[field_name]:
                new_dict[field_name] += ["..."]
        elif field_name in fields_mapping:
            new_dict[field_name] = "..."
        else:
            new_dict[field_name] = value
    return new_dict


def cli_opt(prefix: str, value: Any) -> str:
    """Shortcut handling the case of CLI options (short: -x, long: --option)
    that should only be included if they have a non null (None) value.

    Example:

        cli_opt("-t", 8)
        >> "-t 8"

        cli_opt("-t", None)
        >> ""
    """
    if value is None:
        return ""
    return f"{prefix} {value}"
