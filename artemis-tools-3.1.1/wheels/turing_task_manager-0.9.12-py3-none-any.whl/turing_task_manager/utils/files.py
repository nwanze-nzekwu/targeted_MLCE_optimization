"""Utils around filesystem and paths."""

from typing import Optional, List
from pathlib import Path
from fnmatch import fnmatch
import time
import json
import logging
import os


logger = logging.getLogger("ttm.utils")

__all__ = [
    "open_large_json",
    "find_path",
    "zipdir",
    "is_python_executable",
]


def open_large_json(path: Path, timeout_s: int = 5, interval: float = 0.1) -> dict:
    """
    This function specifically tries to open a large json that might we
    currently being written. We use an interesting property of json: if the json
    is not finished, it should actually be incorrectly parsed (which might not
    be true for other file-types that might be valid, even if incomplete).

    Args:
        path (Path):
            Path to the json that shall be oppened
        timeout_s (int, optional):
            Timeout, in seconds: how long should we keep trying
        interval (float, optional):
            How often should we try

    Returns:
        Returns the content of the json (python list or dict).
    """
    now = first_try = time.time()
    while (now - first_try) < timeout_s:
        try:
            with path.open("r") as file_object:
                return json.load(file_object)
        except FileNotFoundError as fe:
            raise fe
        except BaseException as e:
            logger.warning(
                "When trying to open %s, this exception was silenced:\n%s",
                path,
                e,
            )
        time.sleep(interval)
        now = time.time()
    raise TimeoutError("Timed out while trying to open a json file")


def find_path(path_list: List[Path], name: str) -> Path:
    """Finds a single path inside a path list with a given name. Raises an
    exception if the path is missing or if multiple paths with the same name
    exist.

    It accepts Unix-Shell style wildcards:
    - *       matches everything
    - ?       matches any single character
    - [seq]   matches any character in seq
    - [!seq]  matches any character not in seq

    Args:
        path_list (List[Path]):
            A list of paths.
        name (str):
            Name of the folder or file find in the list of paths.

    Returns:
        The path to the specific folder or file that matches the given name.

    Raises:
        FileNotFoundError: if 0 or 2+ files matches.
    """
    # Note: it's difficult to use fnmatch.filter here (more optimised) because
    # we handle pathlib's Path and look at names.
    matches = [path for path in path_list if fnmatch(path.name, name)]
    if len(matches) != 1:
        raise FileNotFoundError
    return matches[0]


def zipdir(base: Path, ziph, zip_name: Optional[str] = None):
    """Zips a directory and preserves the exact layout and naming of files.
    Optionally pass zip file name to ensure it is excluded from zip procedure.
    """
    # ziph is zipfile handle
    for root, _, files in os.walk(str(base)):
        for file_name in files:
            if not zip_name or zip_name != file_name:
                ziph.write(Path(root) / file_name, Path(root).relative_to(base) / file_name)


def is_python_executable(path: Path) -> bool:
    """Tests if a file is a Python executable. Currently means:
    - file ending in ".py"
    - folder with a "__main__.py" file
    """
    if path.is_dir():
        return (path / "__main__.py").exists()
    return path.suffix == ".py"
