"""Module providing a logging handler to connect logs to Loki."""

from datetime import datetime
import os
import logging
from typing import Optional

from turing_task_manager.constants import TASK_ID_ENV_VAR, PROCESS_ID_ENV_VAR
from turing_task_manager.clients import loki


class NotificationLogHandler(logging.Handler):
    """Logging handler that sends logs to Loki as notifications."""

    def __init__(self, loki_settings: Optional[loki.LokiSettings] = None) -> None:
        """Initialize the handler."""
        super().__init__()
        assert TASK_ID_ENV_VAR in os.environ, f"Missing {TASK_ID_ENV_VAR} environment variable"
        assert PROCESS_ID_ENV_VAR in os.environ, f"Missing {PROCESS_ID_ENV_VAR} environment variable"
        loki_settings = loki_settings or loki.LokiSettings.with_env_prefix("loki")
        self.loki_client = loki.TaskBoundLoki(
            loki_settings,
            loki.TaskInformation(
                taskId=os.environ[TASK_ID_ENV_VAR], processId=os.environ[PROCESS_ID_ENV_VAR], taskType="logger"
            ),
        )

    def emit(self, record: logging.LogRecord) -> None:
        """Send a log record to Loki."""
        self.loki_client.notify_log(self.record_to_log(record))

    def record_to_log(self, record: logging.LogRecord) -> loki.LogNotification:
        """Convert a log record to a log notification."""
        return loki.LogNotification(
            level=loki.LogLevel(record.levelname.lower()),
            timestamp=datetime.fromtimestamp(record.created),  # type: ignore
            message=record.getMessage(),
        )
