"""Utils around configuration of workers."""

# @TODO: find a better location
from typing import Optional
from pathlib import Path
import psutil
import logging

from pydantic.v1.env_settings import BaseSettings
from pydantic.v1 import root_validator
import sentry_sdk
from sentry_sdk.integrations.logging import LoggingIntegration

from turing_task_manager.models import ResourceAllocation
from turing_task_manager.exceptions import ExecutableError, WrappedExceptionStack

__all__ = ["WorkerConfig", "get_cpu_count", "get_memory_bytes", "init_sentry"]


class WorkerConfig(BaseSettings):
    """Config class containing the cluster id needed to register a worker to the
    API, along with debug metadata.
    """

    cluster_id: str
    rabbitmq_host: str
    thanos_host: str
    sentry_sample_rate: float = 0.2
    sentry_environment: str = "develop"
    sentry_dsn: Optional[str]
    sentry_enabled: bool = False

    @root_validator
    def dsn_set_if_sentry_enabled(cls, values: dict) -> dict:
        if values.get("sentry_enabled") and values.get("sentry_dsn") is None:
            raise ValueError("dsn must be set if sentry is enabled")
        return values

    class Config:
        env_file = ".env"
        case_sensitive = False


def get_cpu_count() -> int:
    """
    Tries to get the accurate available CPU count. This is needed due to
    Python's limitations when it comes to identifying CPU count from inside
    a container, all built in methods, report the CPU count of the host system
    instead of the container.

    Order of preference, method will use the first one in this order that is available:
    ALLOCATED_CPUS env var --> Cgroup properties --> Built in cpus (host system)
    """
    cpu_count: int = 0
    quota_path = Path("/sys/fs/cgroup/cpu/cpu.cfs_quota_us")
    period_path = Path("/sys/fs/cgroup/cpu/cpu.cfs_period_us")
    explicit_allocations = ResourceAllocation()  # pyright: ignore

    if explicit_allocations.cpus is not None:
        cpu_count = explicit_allocations.cpus
    elif quota_path.is_file() and period_path.is_file():  # is_file => exists
        cfs_quota_us = int(quota_path.read_text())
        cfs_period_us = int(period_path.read_text())
        cpu_count = cfs_quota_us // cfs_period_us
    if cpu_count <= 0:
        cpu_count = psutil.cpu_count()
    return cpu_count


def get_memory_bytes() -> int:
    """
    Tries to get the accurate available memory. This is needed due to Python's
    limitations when it comes to identifying available resources from inside
    a container, all built in methods, report the memory byts of the host system
    instead of the container.

    Order of preference, method will use the first one in this order that is available:
    ALLOCATED_MEMORY_BYTES env var --> Cgroup properties --> Built in memory (host system)
    """
    memory_bytes = 0
    memory_bytes_builtin = psutil.virtual_memory().total
    limit_path = Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")
    explicit_allocations = ResourceAllocation()  # pyright: ignore

    if explicit_allocations.memory_bytes is not None:
        memory_bytes = explicit_allocations.memory_bytes
    elif limit_path.exists() and limit_path.is_file():
        memory_bytes = int(limit_path.read_text())
    if memory_bytes_builtin < memory_bytes or memory_bytes <= 0:
        return memory_bytes_builtin
    return memory_bytes


def init_sentry():
    """Initializes the Sentry SDK."""
    worker_config = WorkerConfig()  # pyright: ignore
    if worker_config.sentry_enabled:
        sentry_sdk.init(
            worker_config.sentry_dsn,
            traces_sample_rate=worker_config.sentry_sample_rate,
            environment=worker_config.sentry_environment,
            ignore_errors=[ExecutableError, KeyboardInterrupt, WrappedExceptionStack],
            integrations=[LoggingIntegration(level=logging.FATAL, event_level=logging.FATAL)],
            attach_stacktrace=True,
            auto_enabling_integrations=False,
        )
