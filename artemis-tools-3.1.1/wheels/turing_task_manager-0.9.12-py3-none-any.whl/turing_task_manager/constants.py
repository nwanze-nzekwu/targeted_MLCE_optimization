"""File for constant definition that do not fit in a specific module."""

TASK_ID_ENV_VAR = "TTM_TASK_ID"
PROCESS_ID_ENV_VAR = "TTM_PROCESS_ID"
