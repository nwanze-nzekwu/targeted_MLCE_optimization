"""Contains functionality for performing the optimisation process based on an existing project."""

import hashlib
from contextlib import nullcontext
from pathlib import Path
from traceback import print_exc
from typing import Any, Dict, Generic, List, Tuple
from uuid import UUID

import plotext as plt
from loguru import logger
from optuna import Study, Trial

from artemisopt.compilation.build import BuildSystem
from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.models.code import ConstructMapping
from artemisopt.models.executor import EvaluationResults
from artemisopt.models.solution import Solution, SolutionEntry, SolutionStatus
from artemisopt.optimiser.engine.engine import run_optimisation
from artemisopt.optimiser.engine.models import (
    InputParameterDict,
    OptimisationConfig,
    OptimisationConfigDict,
    OptimisationSolution,
    OptimiserType,
)
from artemisopt.optimiser.engine.utils import trial_to_solution_details
from artemisopt.substitution.substitutor import Substitutor
from artemisopt.util import shutil
from artemisopt.util.basemodel import ArtemisBaseModel, orjson_dumps
from artemisopt.util.general import loguru_falcon_wrapper, orjson_dumps
from artemisopt.util.output import OutputManager


class MockTrial(ArtemisBaseModel):
    number: int
    user_attrs: Dict = {}
    params: Dict = {}

    def set_user_attr(self, key, value):
        self.user_attrs[key] = value


class Optimiser:
    """This class contains acts as a bridge between Artemis and
    the optimisation engine and handles all the optimisation process."""

    constructs: ConstructMapping
    input_config: ArtemisTaskConfig
    evaluated: dict[str, tuple[float, float, float]] = {}

    def __init__(self, constructs: ConstructMapping, input_config: ArtemisTaskConfig):
        self.constructs = constructs
        self.input_config = input_config

    def generate_substitution(
        self, solution: Solution, original_project_path: Path, mutated_path: str
    ) -> Path:
        sub = Substitutor(
            constructs=self.constructs,
            project_path=original_project_path,
            project_output_path=conf_mgr.artemis_settings.output_path,
        )
        return sub.substitute(solution, folder_name=mutated_path)

    def run_perf_test(
        self,
        test_id: str | None = None,
        raise_exc: bool = True,
        trial: Trial | None = None,
        extra: dict[str, Any] | None = None,
        unit_test: bool = True,
        create_in_db: bool = True,
        trial_number: int | None = None,
        study: Study | None = None,
        **constructs: Any,
    ) -> tuple[float, float, float]:
        """Function provided to EnigmaOpt that orchestrates the evaluation of
        a solution returned by it."""
        test_id = test_id or hashlib.md5(orjson_dumps(constructs).encode()).hexdigest()
        solution = Solution(
            constructs=[
                SolutionEntry(construct_id=UUID(construct_id), spec_id=spec_id)
                for construct_id, spec_id in constructs.items()
            ]
        )
        log_id = None
        if trial:
            trial.set_user_attr("status", SolutionStatus.running)
            trial_number = trial_number or trial.number
            if create_in_db:
                sol = trial_to_solution_details(trial, trial_number=trial_number)
                log_id = OutputManager.get_new_log_id()
                sol.log_id = log_id
                sol_id = OutputManager.create_solution(sol)
                trial.set_user_attr("sol_id", sol_id)
                trial.set_user_attr("log_id", log_id)

        backup_exists = conf_mgr.artemis_settings.build_backup_dir.exists()
        og_project = (
            conf_mgr.artemis_settings.build_backup_dir
            if backup_exists and conf_mgr.artemis_settings.incremental_build
            else self.input_config.project_path
        )
        if og_project is None:
            raise ValueError("Could not infer project path")
        mutated_path = conf_mgr.artemis_settings.output_path / "mutated" / test_id
        build_path = self.generate_substitution(solution, og_project, "build")

        log_wrapper = loguru_falcon_wrapper(log_id) if log_id else nullcontext()

        with log_wrapper:
            try:
                build_system = BuildSystem(self.input_config, project_path=build_path, trial_number=trial_number)
                logger.debug("Building project...")
                build = build_system.build()
                if build is not None:
                    if build.status_code != 0:
                        if raise_exc:
                            raise Exception(
                                f"Build failed with status code: {build.status_code}"
                            )

                if unit_test:
                    if build_system.unit_test_command != build_system.perf_test_command:
                        logger.debug("Running unit test...")
                        unit = build_system.unit_test()
                        if unit is not None:
                            if unit.status_code != 0:
                                if raise_exc:
                                    raise Exception(
                                        "Unit testing failed with status code:"
                                        f" {unit.status_code}"
                                    )

                        logger.debug("Running performance test... (Warmup)")
                    else:
                        logger.debug("Running unit test / performance test... (Warmup)")
                else:
                    logger.debug("Running performance test... (Warmup)")

                results: list[EvaluationResults] = []
                assert conf_mgr.artemis_settings.artemis_task is not None
                for i in range(
                    conf_mgr.artemis_settings.artemis_task.evaluation_repetitions
                ):
                    logger.debug(
                        "Running performance test..."
                        + f" ({i + 1}/{conf_mgr.artemis_settings.artemis_task.evaluation_repetitions})"
                    )
                    result = build_system.perf_test()
                    if result is not None:
                        if result.status_code != 0:
                            if raise_exc:
                                raise Exception(
                                    "Performance testing failed with status code:"
                                    f" {result.status_code}"
                                )
                        elif result.evaluation is not None:
                            results.append(result.evaluation)

                all_results: dict[str, list[float]] = {
                    "runtime": [],
                    "cpu": [],
                    "memory": [],
                }

                for r in results:
                    all_results["runtime"] += [r.runtime]
                    all_results["cpu"] += [r.cpu_avg]
                    all_results["memory"] += [r.mem_avg]

                if results:
                    solution.metrics = EvaluationResults(
                        runtime=sum(all_results["runtime"]) / len(results),
                        cpu_avg=sum(all_results["cpu"]) / len(results),
                        mem_avg=sum(all_results["memory"]) / len(results),
                    )
                else:
                    solution.metrics = EvaluationResults(
                        runtime=0, cpu_avg=0, mem_avg=0
                    )

            finally:
                if build_path.exists():
                    if conf_mgr.artemis_settings.delete_mutated and trial_number != 0:
                        shutil.rmtree(build_path)
                    else:
                        shutil.move(build_path, mutated_path)

        if trial:
            trial.set_user_attr("full_results", all_results)
        if extra is not None:
            extra["full_results"] = all_results

        return tuple(solution.metrics.model_dump().values())

    def constructs_to_params(self) -> OptimisationConfigDict:
        """Converts an Artemis constructs to an EnigmaOpt optimisation parameters"""
        input_params: list[InputParameterDict] = []
        for construct_id, construct in self.constructs.root.items():
            input_params.append(
                {
                    "parameterName": str(construct_id),
                    "parameterType": "list",
                    "minValue": None,
                    "maxValue": None,
                    "values": [str(c.id) for c in construct.custom_specs],
                    "defaultValue": str(construct.original_spec_id),
                    "generateDistribution": "string",
                }
            )

        params: OptimisationConfigDict = {
            "inputParameters": input_params,
            "objectivesList": ["min", "min", "min"],
            "metadata": {"model": "artemis"},
        }
        return params

    def graph_objectives(self, study: Study, metrics: list[str], clear: bool = False):
        """Graph performed trials on terminal"""
        plt.title("Trial Progress")
        plt.subplots(len(metrics), 1)

        if clear:
            plt.clt()
            plt.cld()

        data = [list() for _ in metrics]
        for trial in study.trials:
            if trial.values is not None:
                for i, value in enumerate(trial.values):
                    data[i].append(value)

        for i, metric in enumerate(metrics):
            plt.subplot(i + 1, 1)
            plt.ylabel(metric)
            plt.xlabel("Trial Number")
            plt.bar([f"Trial {num}" for num in range(1, len(data[i]) + 2)], data[i])
        if len(data[-1]) > 0:
            plt.show()

    def handle_final_output(self, results: list[Solution], study: Study):
        """Handles the final output of the optimisation process."""
        for i, result in enumerate(results):
            logger.info(f"Optimal Solution {i}: \n{result}")

        # self.graph_objectives(study, METRICS)

        best_solutions_file = (
            conf_mgr.artemis_settings.output_path / "optimal-solutions.json"
        )
        best_solutions_file.write_text(orjson_dumps(results))

    def run_original_version(self):
        logger.info("Running original version")
        failed = False
        original_trial = MockTrial(number=0, params={}, user_attrs={})
        try:
            self.run_perf_test(test_id="0", trial=original_trial, trial_number=0)
        except Exception as e:
            failed = True
            print_exc()
        if not failed and conf_mgr.artemis_settings.incremental_build:
            shutil.rmtree(
                conf_mgr.artemis_settings.build_backup_dir, not_exists_ok=True
            )
            shutil.copytree(
                conf_mgr.artemis_settings.output_path / "mutated" / "0",
                conf_mgr.artemis_settings.build_backup_dir,
                symlinks=True,
            )
        original_trial.set_user_attr(
            "status", SolutionStatus.success if not failed else SolutionStatus.fail
        )
        OutputManager.add_solution_results(original_trial)
        sol = trial_to_solution_details(original_trial, trial_number=0)
        OutputManager.save_solution(sol)

    def optimise(self) -> list[OptimisationSolution]:
        """Performs the optimisation."""
        params = self.constructs_to_params()
        params = OptimisationConfig.model_validate(params)
        self.run_original_version()
        results, study = run_optimisation(
            config=params,
            evaluation_func=self.run_perf_test,
            optimiser_type=OptimiserType.NSGAII,
            pop_sz=conf_mgr.artemis_settings.population_size,
            gen_sz=conf_mgr.artemis_settings.generation_size,
            default=False,
        )
        self.handle_final_output(results, study)
        return results
