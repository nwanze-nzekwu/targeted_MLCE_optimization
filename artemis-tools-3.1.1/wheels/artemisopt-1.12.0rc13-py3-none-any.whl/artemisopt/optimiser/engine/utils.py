"""Contains utilities useful for the optimisation engine"""

from typing import List, Optional

from optuna import Study, Trial

from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.optimiser.engine.models import (
    OptimisationConfig,
    OptimisationSolution,
    ParameterInfo,
    SolutionDetails,
)


def prepare_results(
    study: Study, config: OptimisationConfig
) -> List[OptimisationSolution]:
    """Prepares output based on the best results of a study"""
    trials = sorted(
        filter(lambda t: t.values is not None, study.best_trials),
        key=lambda t: t.values,
    )
    solutions = []
    for i, trial in enumerate(trials):
        details = trial_to_solution_details(trial, study, trial_number=trial.number + 1)
        details.metadata = config.metadata
        solutions.append(OptimisationSolution(solution=details, rank=i))
    return solutions


def trial_to_solution_details(trial: Trial, study: Study = None, trial_number: int = 0):
    study = trial.study if hasattr(trial, "study") else study
    og_solution = study.user_attrs.get("default_values") if study else None
    metadata = {}
    if trial.user_attrs.get("log"):
        metadata["log"] = trial.user_attrs.get("log")
    details = SolutionDetails(
        original=(
            (trial.params == study.user_attrs.get("default_values", {}))
            if study
            else False
        ),
        parameters=[
            ParameterInfo(
                parameterName=str(k),
                parameterValue=str(v),
                originalValue=og_solution.get(str(k)) if og_solution else None,
            )
            for k, v in trial.params.items()
        ],
        objectives=(
            trial.user_attrs["full_results"]
            if trial.user_attrs.get("full_results")
            else None
        ),
        trial_id=str(trial_number or trial.number),
        status=trial.user_attrs.get("status", "pending"),
        metadata=metadata,
        hardware_id=conf_mgr.artemis_settings.hardware_id,
    )
    return details


def find_original_solution(
    solutions: List[OptimisationSolution],
) -> Optional[OptimisationSolution]:
    """Finds the original solution in a list of solutions"""
    for solution in solutions:
        if solution.solution.original:
            return solution
    return None
