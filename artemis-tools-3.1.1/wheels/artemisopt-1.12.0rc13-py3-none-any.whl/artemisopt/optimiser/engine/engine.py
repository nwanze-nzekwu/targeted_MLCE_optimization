"""Contains functionality that allows performing trials"""

import math
import warnings
from typing import Any, List, Protocol, Tuple, Type, Union
from uuid import UUID, uuid4

from loguru import logger
from optuna.exceptions import ExperimentalWarning

from artemisopt.conf.conf_manager import InterceptHandler
from artemisopt.optimiser.engine.utils import prepare_results, trial_to_solution_details
from artemisopt.util.cli import TrialPlotCallback
from artemisopt.util.output import OutputManager

warnings.simplefilter("ignore", category=ExperimentalWarning)
import optuna

optuna.logging.set_verbosity(optuna.logging.DEBUG)

optuna.logging.disable_default_handler()
optuna.logging._default_handler = InterceptHandler()
optuna.logging.enable_default_handler()
from optuna import Study, Trial
from optuna.samplers import NSGAIISampler
from optuna.trial import FrozenTrial, TrialState

from artemisopt.models.solution import SolutionStatus
from artemisopt.optimiser.engine.models import (
    InputParameter,
    OptimisationConfig,
    OptimisationSolution,
    OptimiserType,
    ParameterInfo,
    SolutionDetails,
)

OptimizerT = Type[NSGAIISampler]


def log_trial(study: optuna.study.Study, trial: optuna.trial.FrozenTrial) -> None:
    """Logs trial info"""
    og_solution = study.user_attrs.get("default_values", {})
    parameters = [
        ParameterInfo(
            parameterName=str(k),
            parameterValue=str(v),
            originalValue=og_solution.get(str(k)),
        )
        for k, v in trial.params.items()
    ]
    if trial.state == TrialState.COMPLETE:
        sol = SolutionDetails(
            original=trial.params == study.user_attrs.get("default_values", {}),
            parameters=parameters,
            objectives=trial.user_attrs["full_results"],
            trial_id=str(trial.number + 1),
            metadata={"log_id": trial.user_attrs.get("log_id")},
            status=SolutionStatus.success,
        )
        trial.set_user_attr("status", SolutionStatus.success)
        logger.info(
            "Trial {} finished : {}".format(trial.number + 1, str(sol)),
            extra={"markup": False},
        )
    elif trial.state == TrialState.FAIL:
        trial.set_user_attr("status", SolutionStatus.fail)

    if trial.state in [TrialState.FAIL, TrialState.COMPLETE]:
        sol = trial_to_solution_details(trial, study)
        logger.info(
            "Trial {} {} : {}".format(
                trial.number + 1,
                "failed" if trial.state == TrialState.FAIL else "finished",
                str(sol),
            ),
            extra={"markup": False},
        )
        OutputManager.add_solution_results(trial)
        OutputManager.save_solution(sol)


def get_optimiser_class(optimiser_type: OptimiserType) -> OptimizerT:
    """Get optimiser based on enum"""
    if optimiser_type == OptimiserType.NSGAII:
        return NSGAIISampler
    else:
        raise ValueError("Invalid optimiser type")


def get_suggestion(trial: Trial | FrozenTrial, input: InputParameter) -> Any:
    """Get suggestion based on input type"""
    if input.parameterType == "float":
        return trial.suggest_uniform(
            input.parameterName, input.minValue, input.maxValue
        )
    elif input.parameterType == "int":
        return trial.suggest_int(input.parameterName, input.minValue, input.maxValue)
    elif input.parameterType == "list":
        return trial.suggest_categorical(input.parameterName, input.values)
    elif input.parameterType == "bool":
        return trial.suggest_categorical(input.parameterName, [True, False])
    else:
        raise ValueError("Unknown parameter type: " + input.parameterType)


def get_default_params(config: OptimisationConfig):
    """Generates default parameters for trial"""
    params = {}
    tmp_trial = optuna.trial.create_trial(state=TrialState.WAITING)
    for input in config.inputParameters:
        if input.defaultValue is not None:
            params[input.parameterName] = input.defaultValue
        else:
            params[input.parameterName] = None
    return params


def generate_solution_params_and_diff_count(
    trial: Trial, config: OptimisationConfig
) -> tuple[dict[str, UUID], int]:
    """
    Generates a dictionary of solution parameters and returns the count of parameters
    that are different from the default values.

    Args:
        trial (Trial): The current Optuna trial to generate suggestions from.
        config (OptimisationConfig): The optimization configuration containing input parameters with default values.

    Returns:
        tuple: A tuple containing the dictionary of parameters and the count of parameters
               that differ from the default values.
    """
    # Initialize the solution dictionary and the difference counter
    solution_params = {}
    diff_count = 0

    # Iterate over each input parameter to get suggestions and compare with defaults
    for input_param in config.inputParameters:
        # Get the suggested value
        suggested_value = get_suggestion(trial, input_param)
        # Store the suggested value in the solution dictionary
        solution_params[input_param.parameterName] = UUID(suggested_value)
        # Check if it differs from the default value (if a default is specified)
        if input_param.defaultValue is not None and suggested_value != str(
            input_param.defaultValue
        ):
            diff_count += 1

    return solution_params, diff_count


class RunPerfTestProtocol(Protocol):
    def __call__(
        self,
        *,
        test_id: str | None = None,
        raise_exc: bool = True,
        trial: Trial | None = None,
        extra: dict[str, Any] | None = None,
        unit_test: bool = True,
        create_in_db: bool = True,
        study: Study | None = None,
        constructs: dict[str, UUID] = {},
    ) -> tuple[float, float, float]: ...


def create_callback_stop_after_n_completed_trials(n):
    def callback(study: optuna.study.Study, trial: optuna.trial.FrozenTrial):
        """This callback stops the study when a given number of trials are successfully completed."""

        # Count the number of completed trials in the study
        completed_trials = [
            t
            for t in study.get_trials(deepcopy=False)
            if t.state == optuna.trial.TrialState.COMPLETE
        ]
        num_completed_trials = len(completed_trials)

        # If the number of completed trials reaches the target `n`, raise a StopStudy exception
        if num_completed_trials >= n:
            study.stop()

    return callback


def create_callback_stop_if_last_m_trials_pruned(m):
    def callback(study: optuna.study.Study, trial: optuna.trial.FrozenTrial):
        """This callback stops a study if too many trials are pruned consecutively."""

        # Get all trials from the study (not a deep copy for efficiency)
        trials = study.get_trials(deepcopy=False)

        # Check if there are at least `m` trials to evaluate
        if len(trials) >= m:
            # Get the last `m` trials
            last_m_trials = trials[-m:]

            # Check if all last `m` trials were pruned
            if all(t.state == optuna.trial.TrialState.PRUNED for t in last_m_trials):
                study.stop()  # Stop the study if all last `m` trials were pruned

    return callback


def run_optimisation(
    config: OptimisationConfig,
    evaluation_func: RunPerfTestProtocol,
    optimiser_type: OptimiserType,
    pop_sz: int = 10,
    gen_sz: int = 10,
    default: bool = True,
) -> tuple[list[OptimisationSolution], Study]:
    """Runs an optimisation"""

    def objective(trial: Trial) -> tuple[float, float, float]:
        solution, diff_count = generate_solution_params_and_diff_count(trial, config)

        # Check for duplicates
        # Cannot use normal pruner, because trial is multi-objective
        for t in trial.study.trials:
            if diff_count == 0:
                raise optuna.TrialPruned()  # We assume the original solution has already been run.

            if t.state != TrialState.COMPLETE and t.state != TrialState.FAIL:
                continue

            if t.params == trial.params:
                raise optuna.TrialPruned()

        return evaluation_func(
            trial=trial,
            test_id=str(trial.number + 1),
            trial_number=trial.number + 1,
            **solution,
        )

    study_name = f"artemis_trial_{str(uuid4())}"
    study = optuna.create_study(
        study_name=study_name,
        directions=[
            "minimize" if d == "min" else "maximize" for d in config.objectivesList
        ],
        sampler=get_optimiser_class(optimiser_type)(population_size=pop_sz),
    )

    if default:
        default = get_default_params(config)
        study.enqueue_trial(default)
        study.set_user_attr("default_values", default)

    # The original code was run outside of the optuna study so we substract 1 from the parameter space size if the
    # original is also included in the parameters the study will attempt to explore.
    original_is_in_space = all(
        [param.defaultValue in param.values for param in config.inputParameters]
    )
    remaining_parameter_space_size = (
        math.prod([len(param.values) for param in config.inputParameters])
        - original_is_in_space
    )

    callbacks = [
        log_trial,
        TrialPlotCallback(),
        # This callback stops the study when the parameter space is fully explored.
        create_callback_stop_after_n_completed_trials(remaining_parameter_space_size),
        # This callback stops the study when there is excessive pruning indicating that the vast majority of the space
        # has already been explored and Optuna cannot find any new areas.
        create_callback_stop_if_last_m_trials_pruned(100),
    ]

    study.optimize(
        objective,
        n_trials=pop_sz * gen_sz,
        catch=(Exception,),
        callbacks=callbacks,
    )

    logger.info(f"Number of solutions generated: {len(study.trials)}")
    logger.info(f"Number of solutions in pareto front: {len(study.best_trials)}")

    return prepare_results(study, config), study
