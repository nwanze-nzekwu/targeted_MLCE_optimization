from enum import StrEnum
from typing import Any, Literal, TypedDict
from uuid import UUID

from pydantic import RootModel, StrictInt
from typing_extensions import override

from artemisopt.models.solution import SolutionStatus
from artemisopt.util.basemodel import ArtemisBaseModel
from artemisopt.util.md import create_md_table


class OptimiserType(StrEnum):
    NSGAII = "nsgaii"
    NSGAIII = "nsgaiii"


class InputParameter(ArtemisBaseModel):
    """Describes input parameter for optimisation"""

    parameterName: str
    parameterType: Literal["float", "int", "list", "bool"]
    minValue: StrictInt | float | None = None
    maxValue: StrictInt | float | None = None
    values: list[Any]
    defaultValue: Any
    generateDistribution: str


class OptimisationConfig(ArtemisBaseModel):
    """Describes config for optimisation"""

    inputParameters: list[InputParameter]
    objectivesList: list[str] | None = None
    metadata: dict[str, Any] | None = None


class InputParameterDict(TypedDict):
    parameterName: str
    parameterType: str
    minValue: int | float | None
    maxValue: int | float | None
    values: list[Any]
    defaultValue: str
    generateDistribution: str


class OptimisationConfigDict(TypedDict):
    inputParameters: list[InputParameterDict]
    objectivesList: list[str]
    metadata: dict[str, str]


class ParameterInfo(ArtemisBaseModel):
    """Info of a specific parameter"""

    parameterName: str
    parameterValue: str
    originalValue: str | None = None

    @override
    def __repr__(self):
        if self.originalValue is not None:
            repr = (
                f"{str(self.parameterName)[-5:]}: {self.originalValue} →"
                f" {self.parameterValue}"
            )
        else:
            repr = f"{str(self.parameterName)[-5:]}: {self.parameterValue}"
        return repr


class SolutionDetails(ArtemisBaseModel):
    """Details of a solution"""

    original: bool
    optimal: bool | None = None
    status: SolutionStatus
    parameters: list[ParameterInfo]
    objectives: dict[str, list[StrictInt | float]] | None = None
    metadata: dict[str, Any]
    trial_id: str
    log_id: UUID | None = None
    hardware_id: UUID | None = None

    @property
    def changed(self):
        return [
            param
            for param in self.parameters
            if param.originalValue is None
            or param.originalValue != param.parameterValue
        ]

    @override
    def __str__(self) -> str:
        repr = f"Optimal solution: {self.optimal}" if self.optimal is not None else ""
        repr += (
            "\nObjective values:"
            f" {str(self.objectives).replace('{', '').replace('}', '')}\nOriginal:"
            f" {self.original}\nChanged Parameters: {self.changed}"
        )
        return repr


class OptimisationSolution(ArtemisBaseModel):
    """Solution with ranking info"""

    solution: SolutionDetails
    rank: int

    @override
    def __str__(self) -> str:
        return f"Rank: {self.rank}\n{self.solution}"

    def compare_to_other(self, other: "OptimisationSolution") -> str:
        """Returns text summary of the difference between two EvaluationResults"""

        def diff_string(metric_name: str, value1: float, value2: float) -> str:
            return "{}: {} > {} ({:.2%})".format(
                metric_name, value1, value2, -1.0 * (value1 - value2) / abs(value1)
            )

        summary = ["Metric percentage change over original source code:"]
        summary += [
            diff_string(
                "Runtime", other.solution.objectives[0], self.solution.objectives[0]
            )
        ]
        summary += [
            diff_string(
                "CPU", other.solution.objectives[1], self.solution.objectives[1]
            )
        ]
        summary += [
            diff_string(
                "Memory", other.solution.objectives[2], self.solution.objectives[2]
            )
        ]
        return "\n".join(summary)

    def compare_to_raw_metrics(
        self, metrics: tuple[float, float, float], md: bool = False
    ) -> str:
        """Returns text summary of the difference between results"""

        def diff_string(metric_name: str, value1: float, value2: float) -> str:
            change = -1.0 * (value1 - value2) / (abs(value1) if value1 != 0 else 1)
            return "{}: {:0.2%} > {:0.2%} ({:0.2%})".format(
                metric_name, value1, value2, change
            )

        def diff_row(metric_name: str, value1: float, value2: float) -> list[Any]:
            change = -1.0 * (value1 - value2) / (abs(value1) if value1 != 0 else 1)
            return [metric_name, value1, value2, "{:0.2%}%".format(change)]

        if md:
            headers = ["", "Before", "After", "Δ"]
            rows: list[Any] = []
            rows += [diff_row("Runtime", metrics[0], self.solution.objectives[0])]
            rows += [diff_row("CPU", metrics[1], self.solution.objectives[1])]
            rows += [diff_row("Memory", metrics[2], self.solution.objectives[2])]
            summary = create_md_table(headers, rows)
        else:
            summary = ["Metric percentage change over original source code:"]
            summary += [diff_string("Runtime", metrics[0], self.solution.objectives[0])]
            summary += [diff_string("CPU", metrics[1], self.solution.objectives[1])]
            summary += [diff_string("Memory", metrics[2], self.solution.objectives[2])]
            summary = "\n".join(summary)
        return summary


class OptimisationResults(RootModel, ArtemisBaseModel):
    """Result of entire optimisation process"""

    root: list[OptimisationSolution]

    def dict(self, *args, **kwargs):
        return super().dict(*args, **kwargs)["root"]
