import traceback
import zipfile
from pathlib import Path
from typing import Any
from uuid import UUID

from falcon_models import ChangesetValidationCommandResponse, ChangesetValidationResponse
from falcon_models.enums.general import ExecutionStatusEnum
from loguru import logger

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.execution.executor import Executor
from artemisopt.util.output import OutputManager


def process_command(project_path: Path, command: str) -> str:
    command = command.replace("{{BEAR}}", "")
    command = command.replace("{{THREADS}}", str(conf_mgr.artemis_settings.run_threads))

    command = command.replace("{{PROJECT_DIR}}", str(project_path))
    command = command.replace("{{BUILD_DIR}}", ".")
    return command

def download_and_extract_version(project_id: str, changeset_id: UUID, version_sha: str, temp_dir: Path) -> Path:
    """
    Download and extract a specific version of a project.

    Args:
        project_id: The ID of the project
        changeset_id: The ID of the changeset
        version_sha: The SHA of the version to download
        temp_dir: The temporary directory to extract to

    Returns:
        Path to the extracted project root
    """
    logger.info(f"Downloading version {version_sha}")

    # Download the version as a ZIP file
    falcon_client = OutputManager.falcon_client()
    zip_path = temp_dir / "version.zip"
    falcon_client.download_version(
        project_id=project_id, changeset_id=changeset_id, version_sha=version_sha, output_path=zip_path
    )
    extract_path = temp_dir / "extract_dir"
    extract_path.mkdir(exist_ok=True)

    # Extract the ZIP file
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_path)

    # Find the project root (extraction might create a subdirectory)
    extracted_dirs = [d for d in extract_path.iterdir() if d.is_dir()]
    project_root = extracted_dirs[0] if extracted_dirs else extract_path

    logger.info(f"Version extracted to {project_root}")
    return project_root


def execute_validation_command(
    command: ChangesetValidationCommandResponse, project_id: str, project_root: Path, results_dir: Path
) -> None:
    """
    Execute a validation command and update its status.

    Args:
        command: The command to execute
        project_id: The ID of the project
        project_root: Path to the project root
        results_dir: Directory to store result files
    """
    falcon_client = OutputManager.falcon_client()
    cmd_log_file = results_dir / f"cmd_{command.order}_log.txt"

    # Update command status to running
    falcon_client.update_validation_command(
        project_id=project_id,
        command_id=str(command.id),
        log_id=None,
        exit_code=None,
        status=ExecutionStatusEnum.running,
    )

    try:
        logger.info(f"Running command {command.order}: {command.command}")

        # Execute the command using the Executor class
        execution_results = Executor.execute(
            command=process_command(project_root, command.command),
            cwd=project_root,
            benchmark=True,
            log_file=cmd_log_file,  # Enable detailed metrics
        )

        if execution_results is None:
            raise Exception("Failed to execute command: No results returned")

        # Process command results and update status
        update_command_with_results(
            command=command, project_id=project_id, log_file=cmd_log_file, execution_results=execution_results
        )

    except Exception as e:
        handle_command_execution_error(command=command, project_id=project_id, results_dir=results_dir, error=e)


def update_command_with_results(
    command: ChangesetValidationCommandResponse, project_id: str, log_file: Path, execution_results: Any
) -> None:
    """
    Update a command with execution results.

    Args:
        command: The command that was executed
        project_id: The ID of the project
        log_file: Path to the log file
        execution_results: Results from the executor
    """
    # Determine if the command passed based on exit code
    passed = execution_results.status_code == 0

    # Extract metrics from execution results
    if execution_results.evaluation:
        runtime = execution_results.evaluation.runtime
        cpu_usage = execution_results.evaluation.cpu_avg
        memory_usage = execution_results.evaluation.mem_avg
    else:
        runtime = None
        cpu_usage = None
        memory_usage = None

    # Upload the log file to Thor
    log_id = OutputManager.get_new_log_id()
    OutputManager.save_logs_in_falcon(log_file.read_text(), log_id)

    # Update the command with results
    falcon_client = OutputManager.falcon_client()
    falcon_client.update_validation_command(
        project_id=project_id,
        command_id=str(command.id),
        log_id=log_id,
        exit_code=execution_results.status_code,
        runtime=runtime,
        cpu=cpu_usage,
        memory=memory_usage,
        status=ExecutionStatusEnum.success if passed else ExecutionStatusEnum.failed,
    )

    logger.info(f"Command {command.order} completed with status: {'PASSED' if passed else 'FAILED'}")


def handle_command_execution_error(
    command: ChangesetValidationCommandResponse, project_id: str, results_dir: Path, error: Exception
) -> None:
    """
    Handle errors during command execution.

    Args:
        command: The command that failed
        project_id: The ID of the project
        results_dir: Directory to store result files
        error: The exception that occurred
    """
    logger.error(f"Error executing command {command.order}: {str(error)}")

    # Create a log file with the error
    error_log_path = results_dir / f"cmd_{command.order}_error_log.txt"
    with open(error_log_path, "w") as log_f:
        log_f.write(f"Command: {command.command}\n")
        log_f.write(f"Error: {str(error)}\n\n")
        log_f.write("=== TRACEBACK ===\n")
        import traceback

        log_f.write(traceback.format_exc())

    # Upload the error log file to Thor
    log_id = OutputManager.get_new_log_id()
    OutputManager.save_logs_in_falcon(error_log_path.read_text(), log_id)

    # Update command with failure status
    falcon_client = OutputManager.falcon_client()
    falcon_client.update_validation_command(
        project_id=project_id,
        command_id=str(command.id),
        log_id=log_id,
        exit_code=1,
        runtime=None,
        cpu=None,
        memory=None,
        status=ExecutionStatusEnum.failed,
    )


def mark_remaining_commands_as_failed(validation: ChangesetValidationResponse, project_id: str) -> None:
    """
    Mark all remaining commands as failed if overall process fails.

    Args:
        validation: The validation containing commands
        project_id: The ID of the project
    """
    falcon_client = OutputManager.falcon_client()

    for cmd in validation.commands:
        if cmd.status == ExecutionStatusEnum.running or cmd.status == ExecutionStatusEnum.created:
            falcon_client.update_validation_command(
                project_id=project_id,
                command_id=str(cmd.id),
                log_id=None,
                exit_code=1,
                runtime=None,
                cpu=None,
                memory=None,
                status=ExecutionStatusEnum.cancelled,
            )


def run_changeset_evaluation(
    artemis_config: ArtemisTaskConfig,
    output_dir: Path,
) -> None:
    """
    Run the changeset evaluation process.

    Args:
        artemis_config: The Artemis task configuration.
        output_dir: The output directory for the evaluation results.

    Returns:
        None
    """
    results_dir = output_dir / "validation_results"
    results_dir.mkdir(exist_ok=True)

    # Get necessary parameters from config
    project_id = artemis_config.project_id
    validation_id = artemis_config.validation_id

    if not project_id or not validation_id:
        raise ValueError("Project ID and validation ID are required for changeset evaluation")

    # Get the validation details from Falcon
    falcon_client = OutputManager.falcon_client()
    validation = falcon_client.get_changeset_validation(project_id=project_id, validation_id=validation_id)

    logger.info(f"Running validation for changeset version {validation.version_sha}")

    try:
        # Download and extract the version
        project_root = download_and_extract_version(
            project_id=project_id,
            changeset_id=validation.changeset_id,
            version_sha=validation.version_sha,
            temp_dir=output_dir,
        )

        # Process each command
        for cmd in validation.commands:
            execute_validation_command(
                command=cmd, project_id=project_id, project_root=project_root, results_dir=results_dir
            )

    except Exception as e:
        logger.error(f"Error in changeset validation: {str(e)}")
        traceback.print_exc()
        # Mark all commands as failed if something went wrong with the overall process
        mark_remaining_commands_as_failed(validation, project_id)

    logger.info("Changeset validation completed")
