"""
File containing basic structure for build systems
"""

from os.path import relpath
from pathlib import Path
from typing import Any

from artemis_tools.models.generic import Language
from loguru import logger

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.execution import Executor
from artemisopt.models.executor import ExecutionResults

Glob = str

DEFAULT_BUILD_COMMAND = "exit 0;"
DEFAULT_UNIT_TEST_COMMAND = "exit 0;"


class BuildSystem:

    project_path: Path
    language: Language | None = None
    build_command: str
    unit_test_command: str
    perf_test_command: str
    custom_command: str | None = None
    clean_command: str | None = None
    setup_command: str | None = None
    fail_messages: list[str] | None = None
    trial_number: int | None = None
    project_id: str | None = None
    optimisation_id: str | None = None

    def __init__(
        self,
        input_config: ArtemisTaskConfig,
        project_path: Path | None = None,
        build_command: str | None = None,
        unit_test_command: str | None = None,
        clean_command: str | None = None,
        fail_messages: list[str] | None = None,
        perf_test_command: str | None = None,
        custom_command: str | None = None,
        build_path: Path | None = None,
        setup_command: str | None = None,
        trial_number: int | None = None,
    ):
        config_project_path = project_path or input_config.project_path
        if config_project_path:
            self.project_path = config_project_path
        else:
            raise ValueError("Project path must be provided")

        self.build_path = build_path or self.project_path

        config_build_command = (
            input_config.build_commands.build or build_command or DEFAULT_BUILD_COMMAND
        )
        if config_build_command:
            self.build_command = config_build_command
        else:
            raise ValueError("Build commands must be provided")

        config_unit_test_command = (
            input_config.build_commands.unit_test
            or unit_test_command
            or DEFAULT_UNIT_TEST_COMMAND
        )
        if config_unit_test_command:
            self.unit_test_command = config_unit_test_command
        else:
            raise ValueError("Unit test commands must be provided")

        config_perf_test_command = input_config.build_commands.perf or perf_test_command
        if config_perf_test_command:
            self.perf_test_command = config_perf_test_command
        else:
            self.perf_test_command = self.unit_test_command

        self.custom_command = input_config.build_commands.custom

        self.clean_command = input_config.build_commands.clean or clean_command
        self.setup_command = input_config.build_commands.setup or setup_command

        self.fail_messages = fail_messages or []
        self.trial_number = trial_number
        self.project_id = input_config.project_id
        self.optimisation_id = input_config.optimisation_id

    def process_command(self, command: str, extract: bool = False) -> str:
        command = command.replace("{{BEAR}}", "" if extract else "")
        command = command.replace(
            "{{THREADS}}", str(conf_mgr.artemis_settings.run_threads)
        )
        # str(self.project_path.relative_to(self.build_path))
        project_dir = relpath(self.project_path, self.build_path)
        command = command.replace("{{PROJECT_DIR}}", project_dir)
        command = command.replace("{{BUILD_DIR}}", str(self.build_path))
        command = command.replace(
            "{{VERSION_NUMBER}}", "-1" if self.trial_number is None else str(self.trial_number)
        )
        command = command.replace(
            "{{PROJECT_ID}}", "undefined" if self.project_id is None else self.project_id
        )
        command = command.replace(
            "{{OPTIMISATION_ID}}", "undefined" if self.optimisation_id is None else self.optimisation_id
        )
        return command

    def build(
        self, prepend: str | None = None, extract: bool = False, **kwargs: Any
    ) -> ExecutionResults | None:
        """Build a project"""
        prepend = prepend or ""
        return Executor.execute(
            f"{prepend}{self.process_command(self.build_command, extract=extract)}",
            cwd=self.build_path,
            **kwargs,
        )

    def unit_test(
        self, prepend: str | None = None, **kwargs: Any
    ) -> ExecutionResults | None:
        """Unit test a project"""
        prepend = prepend or ""
        return Executor.execute(
            f"{prepend}{self.process_command(self.unit_test_command)}",
            cwd=self.build_path,
            **kwargs,
        )

    def perf_test(
        self, prepend: str | None = None, **kwargs: Any
    ) -> ExecutionResults | None:
        """Performance test a project"""
        prepend = prepend or ""
        results = Executor.execute(
            f"{prepend}{self.process_command(self.perf_test_command)}",
            cwd=self.build_path,
            benchmark=True,
            **kwargs,
        )
        return results

    def custom(
        self, prepend: str | None = None, **kwargs: Any
    ) -> ExecutionResults | None:
        """Custom run on a project"""
        if self.custom_command is None:
            raise RuntimeError("Cannot run custom command, no command stored.")
        prepend = prepend or ""
        results = Executor.execute(
            f"{prepend}{self.process_command(self.custom_command)}",
            cwd=self.build_path,
            **kwargs,
        )
        return results

    def clean(self, prepend: str | None = None) -> ExecutionResults | None:
        """Clean build output from project"""
        if not self.clean_command:
            logger.warning("No clean command provided")
            return
        prepend = prepend or ""
        return Executor.execute(
            f"{prepend}{self.process_command(self.clean_command)}",
            cwd=self.build_path,
        )
