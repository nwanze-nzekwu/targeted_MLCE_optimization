import json
import math
from collections.abc import AsyncIterator
from textwrap import dedent

from artemis_client.vision.client import VisionClient, VisionSettings
from artemis_tools.conf.base_data_types import BaseModelWithSchema
from falcon_models.api import CodeContextRequest, ConcreteConstructRequest
from loguru import logger
from pydantic import RootModel, ValidationError
from vision_models import (
    LLMConversationMessage,
    LLMRole,
    LLMStructuredInferenceRequest,
    TokeniseBatchRequest,
    TokeniseRequest,
)
from vision_models.rest_api.inference import ExtraParams
from vision_models.service.llm import LLMType

from artemisopt.models.code import original_spec_from_construct_request


class RerankLLMItemResponse(BaseModelWithSchema):
    """Index and explanation of a reranked item."""

    doc_id: int
    explanation: str


class RerankLLMResponse(BaseModelWithSchema):
    """List of reranked items."""

    items: list[RerankLLMItemResponse]


class LLMFilter:
    def __init__(
        self, user_id: str, tool_id: str, llm_type: str, llm_filter_number: int
    ):
        vision_settings = VisionSettings.with_env_prefix("vision")
        vision_settings.user_override = user_id
        vision_settings.read_timeout = None
        self.vision = VisionClient(vision_settings)
        self.models = {model.code: model for model in self.vision.get_models().models}
        self.user_id = user_id
        self.tool_id = tool_id
        self.llm_type = llm_type
        self.top_n = llm_filter_number

    async def rerank(
        self, query: str, documents: list[str]
    ) -> AsyncIterator[RerankLLMResponse]:
        """Rerank documents
        Args:
            user_id: used for tracking transactions (linked to Thanos user)
            task_id: used for tracking transactions (allows for grouping of transactions)
            query: query to rerank documents
            documents: list of documents to rerank
            top_n: number of documents to return
        Returns:
            RerankLLMResponse: reranked documents
        """
        placeholder = "{top_n}"
        top_n = min(self.top_n, len(documents))
        if top_n:
            system_prompt = dedent(
                f"""\
                You are rating the following documents based on how well they satisfy the
                provided query. Return the doc_id of the best {placeholder} documents.
                Provide reasoning for each selection. The query is "{query}"
            """
            )
        else:
            system_prompt = dedent(
                f"""\
                You are a filter and decide which documents satisfy the provided query.
                Return the doc_id of each document you decide to allow.
                Provide reasoning for each selection. The query is "{query}"
            """
            )

        query_tokens = (
            self.vision.count_tokens(
                TokeniseRequest(
                    llm_name=self.llm_type,
                    query=system_prompt
                    + json.dumps(RerankLLMResponse.generate_example()),
                )
            )
        ).count + 40
        doc_tokens = self.vision.count_tokens_batch(
            TokeniseBatchRequest(llm_name=self.llm_type, queries=documents)
        ).counts
        # 80% as a safety margin
        max_tokens = int(
            (self.models[self.llm_type].context_length - query_tokens) * 0.8
        )

        # Greedy bin packing elements of `doc_tokens` into bins of size `max_tokens`
        # This is a heuristic for optimising the number of documents we can process
        # in a single request
        bin: list[int] = []
        bins: list[list[int]] = []
        current_bin = 0
        for i, token in enumerate(doc_tokens):
            if token > max_tokens:
                logger.warning(f"skipping document {i} due to size limitations")
                continue
            elif current_bin + token <= max_tokens:
                bin.append(i)
                current_bin += token
            else:
                bins.append(bin)
                bin = [i]
                current_bin = token
        if bin:
            bins.append(bin)

        for i, bin in enumerate(bins):
            top_k = max(math.ceil(top_n / (len(bins) - i)), 1)
            top_n -= top_k
            system = LLMConversationMessage(
                role=LLMRole.SYSTEM, content=system_prompt.format(top_n=top_k)
            )
            documents_chunk = "\n\n".join(
                [f"## DOC ID #{i}\n\n```\n{documents[i]}\n```\n" for i in bin]
            )
            try:
                response = self.vision.ask_structured(
                    LLMStructuredInferenceRequest(
                        model_type=LLMType(self.llm_type),
                        messages=[
                            system,
                            LLMConversationMessage(
                                role=LLMRole.USER, content=documents_chunk
                            ),
                        ],
                        response_schema=RerankLLMResponse.schema(),
                        example=RerankLLMResponse.generate_example(),
                        extra_params=ExtraParams(timeout_s=300),
                    )
                )
            except BaseException as e:
                logger.warning(f"LLM failed to rerank documents: {e}")
                continue
            try:
                validated = RerankLLMResponse.model_validate(response.output)
                top_n += top_k - len(validated.items)
                logger.info(f"LLM Filtered {len(validated.items)} documents")
                yield validated
            except ValidationError:
                if response.output is None or "items" not in response.output:
                    # failed, continue and just don't filter these
                    logger.warning(
                        "LLM failed to create correct json output, skipping filter step"
                    )
                    yield RerankLLMResponse(
                        items=[
                            RerankLLMItemResponse(doc_id=i, explanation="") for i in bin
                        ]
                    )
                    continue
                # otherwise, try to use the fallback model
                try:
                    reranked_items = (
                        RootModel[list[RerankLLMItemResponse]]
                        .model_validate_json(response.output["items"])
                        .root
                    )
                    validated = RerankLLMResponse(items=reranked_items)
                    top_n += top_k - len(validated.items)
                    logger.info(f"LLM Filtered {len(validated.items)} documents")
                    yield validated
                except ValidationError:
                    logger.warning(
                        "LLM failed to create correct json output, skipping filter step"
                    )
                    yield RerankLLMResponse(
                        items=[
                            RerankLLMItemResponse(doc_id=i, explanation="") for i in bin
                        ]
                    )
                    continue

    async def filter_constructs(
        self, constructs: list[ConcreteConstructRequest], llm_query: str
    ) -> AsyncIterator[ConcreteConstructRequest]:
        """Filter data from a list of ConcreteConstruct objects."""
        og_specs = [
            original_spec_from_construct_request(construct) for construct in constructs
        ]
        async for response in self.rerank(
            llm_query, [spec.content for spec in og_specs]
        ):
            for item in response.items:
                if item.doc_id >= len(constructs):
                    logger.warning(
                        f"LLM returned invalid doc_id {item.doc_id}, skipping"
                    )
                    continue
                og_spec = og_specs[item.doc_id]
                new_contexts = [
                    CodeContextRequest(
                        tool_id=self.tool_id,
                        context=item.explanation,
                        customspec_id=og_spec.id,
                    )
                ]
                if og_spec.contexts is None:
                    og_spec.contexts = new_contexts
                else:
                    og_spec.contexts.extend(new_contexts)

                construct = constructs[item.doc_id]
                construct.tags = [*construct.tags, "LLM"] if construct.tags else ["LLM"]
                yield constructs[item.doc_id]

    async def filter_content(
        self, content: list[str], llm_query: str
    ) -> AsyncIterator[str]:
        """Filter data from a list of str objects."""
        async for response in self.rerank(llm_query, content):
            for item in response.items:
                if item.doc_id >= len(content):
                    logger.warning(
                        f"LLM returned invalid doc_id {item.doc_id}, skipping"
                    )
                    continue
                yield content[item.doc_id]
