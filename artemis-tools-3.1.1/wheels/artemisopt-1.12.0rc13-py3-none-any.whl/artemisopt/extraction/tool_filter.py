import json
from pathlib import Path
from typing import Any
from uuid import UUID

from artemis_tools.models.generic import Language, language_by_extension
from artemis_tools.services.context_tools.adapter import (
    CodeWithContext,
    ContextToolConstructs,
)
from falcon_models.api.code_models import (
    CodeContextModel,
    ConcreteConstructRequest,
    CustomSpecRequest,
)
from loguru import logger

from artemisopt.extraction import ARTEMIS_COMPATIBLE_FILE_NAME
from artemisopt.extraction.tool_filter_impl.tool_filter_abstract import FilterTool
from artemisopt.extraction.tool_filter_impl.tool_filter_category import (
    ToolFilterCategory,
)
from artemisopt.models.extraction import ToolConfig


class ToolFilter:
    def __init__(
        self,
        project_path: str,
        file_ids: list[str],
        project_id: UUID,
        tool_config: ToolConfig,
    ):
        self.file_ids = file_ids
        self.project_id = project_id
        self.tool = tool_config.tool
        self.tool_id = tool_config.tool_id
        self.category = tool_config.category
        self.project_path = project_path
        self.input_file_path = tool_config.input_file_path
        self.additional_file_path = tool_config.additional_file_path
        self.current_branch = tool_config.current_branch
        self.main_branch = tool_config.main_branch
        self.git_url = tool_config.git_url
        self.git_mode = tool_config.git_mode
        self.extractor_scope = tool_config.extractor_scope
        self.filter = tool_config.filter
        self.start_date = tool_config.start_date
        self.end_date = tool_config.end_date
        self.contributor = tool_config.contributor

    def create_constructs(self):
        output_path = self._prepare_output_path()
        json_data = self._run_tool_filter(output_path)

        if json_data is None or not self.is_expected_tool(json_data):
            return self._build_constructs([])

        parsed_body = self._parse_sourcekon_adapter(json_data)
        if parsed_body is None:
            raise ValueError(f"Parsed_body cannot be none")
        filtered_body = self._filter_constructs(parsed_body)
        return self._build_constructs(filtered_body)

    def _prepare_output_path(self) -> Path:
        output_path = Path(self.project_path).joinpath("sourcekon-output")
        logger.info(f"output path : {output_path}")
        logger.info(f"main_tool_file_path : {self.input_file_path}")
        return output_path

    def _run_tool_filter(self, output_path: Path) -> dict | None:
        tool_filter_category = ToolFilterCategory
        category = tool_filter_category.from_name(self.category)
        filter_tool: FilterTool = category.get_filter_class()
        tool_config = ToolConfig(
            tool=self.tool,
            tool_id=self.tool_id,
            category=self.category,
            input_file_path=self.input_file_path,
            additional_file_path=self.additional_file_path,
            current_branch=self.current_branch,
            main_branch=self.main_branch,
            git_url=self.git_url,
            git_mode=self.git_mode,
            extractor_scope=self.extractor_scope,
            start_date=self.start_date,
            end_date=self.end_date,
            contributor=self.contributor,
            filter=self.filter,
        )
        logger.info(f"tool_config : {tool_config.model_dump_json()}")
        filter_tool.main(
            project_path=self.project_path,
            output_path=str(output_path),
            project_id=self.project_id,
            tool=self.tool,
            tool_config=tool_config,
        )

        json_file_path = output_path.joinpath(ARTEMIS_COMPATIBLE_FILE_NAME)
        logger.info(f"json_file_path : {json_file_path}")

        if not json_file_path.exists():
            logger.error(
                f"No JSON file starting with '{json_file_path.name}' found in the"
                " output path."
            )
            return None

        try:
            with open(json_file_path, "r") as json_file:
                return json.load(json_file)
        except Exception as e:
            raise Exception(f"Failed to read JSON file {json_file_path}: {e}")

    def _parse_sourcekon_adapter(
        self, json_data: dict[str, Any]
    ) -> ContextToolConstructs:
        try:
            return ContextToolConstructs(
                tool=self.tool, constructs=json_data.get("constructs", [])
            )
        except ValueError as e:
            raise ValueError(f"Validation error during SourcekonAdapter creation: {e}")

    def _build_constructs(
        self, parsed_body: list[dict[str, Any]]
    ) -> list[ConcreteConstructRequest]:
        constructs = []
        for construct_data in parsed_body:
            try:
                construct = self._create_concrete_construct(construct_data)
                if construct:
                    constructs.append(construct)
                else:
                    logger.warning(f"Skipping construct due to error: {construct_data}")
            except Exception as e:
                raise Exception(
                    f"Error creating ConcreteConstruct: {e}, data: {construct_data}"
                )

        return constructs

    def _filter_constructs(
        self, constructs: ContextToolConstructs
    ) -> list[dict[str, Any]]:
        """Filters constructs based on include and exclude paths."""

        if not self.filter.include and not self.filter.exclude:
            return constructs.constructs

        filtered_constructs = []
        for construct in constructs.constructs:
            code_with_context = CodeWithContext.model_validate(construct)
            file_path = code_with_context.file_path

            if self._should_include(file_path) and not self._should_exclude(file_path):
                filtered_constructs.append(construct)

        return filtered_constructs

    def _should_include(self, file_path: str) -> bool:
        """Checks if the file_path should be included based on the include filter."""
        if not self.filter.include:
            return True

        for include_path in self.filter.include:
            if file_path.startswith(include_path):
                return True
        return False

    def _should_exclude(self, file_path: str) -> bool:
        """Checks if the file_path should be excluded based on the exclude filter."""
        if not self.filter.exclude:
            return False

        for exclude_path in self.filter.exclude:
            if file_path.startswith(exclude_path):
                return True
        return False

    def _read_file_content(self, file_path: Path) -> list[str] | None:
        """Reads file content with exception handling.

        Args:
            file_path (Path): The path to the file.

        Returns:
            list[str] | None: The content of the file as a list of strings, or None if an error occurred.
        """
        try:
            content = file_path.read_text().split("\n")
            return content
        except FileNotFoundError:
            logger.warning(f"File not found: {file_path}")
        except PermissionError:
            logger.warning(f"Permission denied to read: {file_path}")
        except IsADirectoryError:
            logger.warning(f"{file_path} is a directory, not a file.")
        except Exception as e:
            logger.warning(f"An unexpected error occurred: {e}")
        return None

    def _create_concrete_construct(
        self, construct_data: dict[str, Any]
    ) -> ConcreteConstructRequest | None:
        code_with_context = CodeWithContext.model_validate(construct_data)
        file_path = Path(self.project_path).joinpath(code_with_context.file_path)

        content = self._read_file_content(file_path)
        if content is None:
            return None

        start_line = (
            code_with_context.start_line - 1
            if code_with_context.start_line else 0
        )
        end_line = (
            code_with_context.end_line
            if code_with_context.end_line is not None
            else len(content)
        )
        content = content[start_line:end_line]
        custom_spec = CustomSpecRequest(
            name="original",
            content=" ".join(content),
            imports=[],
            tags=[],
        )

        context = CodeContextModel(
            customspec_id=custom_spec.id,
            tool_id=self.tool_id,
            context=code_with_context.context,
        )
        custom_spec.contexts = [context]

        file_extension = Path(code_with_context.file_path).suffix
        language = language_by_extension.get(file_extension, Language.UNSUPPORTED)

        return ConcreteConstructRequest(
            original_spec_id=custom_spec.id,
            file=code_with_context.file_path,
            lineno=code_with_context.start_line or 1,
            end_lineno=code_with_context.end_line or code_with_context.start_line or 1,
            tags=code_with_context.tags,
            global_tags=code_with_context.tags,
            language=language,
            custom_specs=[custom_spec],
        )

    def is_expected_tool(self, json_data: dict[str, Any]) -> bool:
        if self.tool != json_data.get("tool"):
            logger.warning(
                f"Tool mismatch: '{self.tool}' is different than"
                f" '{json_data.get('tool')}'"
            )
            return False
        return True
