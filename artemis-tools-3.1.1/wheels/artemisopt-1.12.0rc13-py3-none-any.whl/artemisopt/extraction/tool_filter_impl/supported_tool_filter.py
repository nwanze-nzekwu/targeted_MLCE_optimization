from uuid import UUID

from loguru import logger

from artemisopt.extraction.tool_filter_impl.sourcekon_convert.sourcekon_convert_tool import (
    SourcekonConvertTool,
)
from artemisopt.extraction.tool_filter_impl.tool_filter_abstract import FilterTool
from artemisopt.models.extraction import ToolConfig


class SupportedToolFilter(FilterTool):
    """Filter tool implementation for supported tool conversions"""

    def main(
        self,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool: str,
        tool_config: ToolConfig,
    ):
        """Convert tool output to sourcekon format without returning a value

        Args:
            project_path: Path to project directory
            output_path: Path where converted output should be stored
            project_id: Unique identifier for the project
            tool: Name of the tool to convert from
            tool_config: Configuration for the tool
        """
        try:
            logger.info(f"project id: {project_id}")
            logger.info(f"selected tool: {tool}")

            if not tool or not isinstance(tool, str):
                logger.error("Invalid tool parameter provided")
                return  # Simply exit if the tool parameter is invalid

            convert = SourcekonConvertTool.from_tool_name(name=tool.lower())
            if not convert:
                logger.error(f"No converter found for tool: {tool}")
                return  # Exit if no converter is found

            convert.get_tool_converter.execute_convert(
                output_path=output_path,
                project_path=project_path,
                output_file_path=tool_config.input_file_path,
                additional_file_path=tool_config.additional_file_path,
                extractor_scope=tool_config.extractor_scope,
            )

        except Exception as e:
            logger.error(f"Error during tool conversion: {str(e)}")
