from uuid import UUID

from artemis_client.falcon.client import FalconClient
from falcon_models.api import ProjectGitDiffRequest, ProjectGitDiffResponse
from loguru import logger
from sourcekon.tools.tool_data_types import AnalysisTool
from sourcekon.tools.vcs.git.git_functions import create_git_messages
from sourcekon.tools.vcs.git.git_tool_dtos import GitExecuteInput, GitExecuteOutput
from sourcekon.utils.file_utils import write_json
from sourcekon_scripts.artemis_integration.falcon_converter_git import (
    convert_project_file_info,
)
from sourcekon_scripts.terminal.git_operation.git_operations import get_repo_name

from artemisopt.extraction import ARTEMIS_COMPATIBLE_FILE_NAME
from artemisopt.extraction.tool_filter_impl.git_operations.git_func import GitFunc
from artemisopt.models.extraction import ToolConfig
from artemisopt.util.output import OutputManager


class GitDiffs(GitFunc):
    @classmethod
    def execute(
        cls,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool_config: ToolConfig,
    ):
        falcon_client: FalconClient = OutputManager.falcon_client()
        data = GitExecuteInput(
            source_path=project_path,
            output_path=output_path,
            new_branch=tool_config.current_branch,
            main_branch=tool_config.main_branch,
            git_url=tool_config.git_url,
        )

        project_get_diff_request: ProjectGitDiffRequest = ProjectGitDiffRequest(
            base_branch=tool_config.main_branch
        )
        diffs_per_file: ProjectGitDiffResponse = falcon_client.get_project_diff(
            project_id=project_id, request=project_get_diff_request
        )
        git_execute_output: GitExecuteOutput = create_git_messages(
            diffs_per_file.file_changes, data.source_path
        )

        repo_name = get_repo_name(data.git_url)
        output_file_path = data.output_path / f"{repo_name}-diffs.json"
        write_json(file_path=output_file_path, data=git_execute_output.json())  # type: ignore

        logger.info(f"Diffs written to {output_file_path}")

        git_show_diffs_artemis_output = convert_project_file_info(
            data=git_execute_output, tool=AnalysisTool.GITHUB
        )
        write_json(
            file_path=data.output_path / ARTEMIS_COMPATIBLE_FILE_NAME,
            data=git_show_diffs_artemis_output,
        )
