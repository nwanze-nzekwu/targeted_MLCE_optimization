from enum import Enum
from typing import Type, Self
from artemisopt.extraction.tool_filter_impl.git_operations.git_diffs import GitDiffs
from artemisopt.extraction.tool_filter_impl.git_operations.git_func import GitFunc
from artemisopt.extraction.tool_filter_impl.git_operations.git_user_code import (
    GitUserCode,
)

__all__ = ["GitOperationType"]


# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                      Data types                                                      #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class GitOperationType(Enum):
    DIFFS = "diffs", GitDiffs
    USER_CODE = "user_code", GitUserCode

    @property
    def git_operation(self) -> str:
        return self.value[0]

    @property
    def get_executor(self) -> Type[GitFunc]:
        return self.value[1]

    @classmethod
    def from_type(cls, type: str) -> Self:
        for executor in cls:
            if executor.git_operation == type:
                return executor
        raise ValueError(f"not supported: '{type}'")
