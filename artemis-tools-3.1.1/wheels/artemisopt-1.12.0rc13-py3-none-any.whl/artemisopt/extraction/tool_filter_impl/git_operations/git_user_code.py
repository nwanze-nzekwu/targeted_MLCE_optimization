from pathlib import Path
from uuid import UUID

from artemis_client import FalconClient
from falcon_models.api.git_key_models import GitUserLinesResponse, GitFilter
from loguru import logger
from sourcekon_scripts.artemis_integration.falcon_converter_git import (
    convert_project_functions_info,
)
from sourcekon.extractors.projects.project_extractor import ProjectExtractor
from sourcekon.extractors.projects.project_extractor_dtos import ProjectFunctionsInfo
from sourcekon.tools.tool_data_types import AnalysisTool
from sourcekon.tools.vcs.git.git_tool_dtos import GitExecuteInput, GitMessage
from sourcekon.utils.file_utils import write_json

from artemisopt.extraction import ARTEMIS_COMPATIBLE_FILE_NAME
from artemisopt.extraction.tool_filter_impl.git_operations.git_func import GitFunc
from artemisopt.models.extraction import ToolConfig
from artemisopt.util.output import OutputManager


class GitUserCode(GitFunc):
    @classmethod
    def execute(
        cls,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool_config: ToolConfig,
    ):
        falcon_client: FalconClient = OutputManager.falcon_client()
        filters = GitFilter(
            start_date=tool_config.start_date,
            end_date=tool_config.end_date,
            include=tool_config.filter.include,
            exclude=tool_config.filter.exclude,
            user_email=tool_config.contributor,
        )

        data = GitExecuteInput(
            source_path=project_path,
            output_path=output_path,
            main_branch=tool_config.current_branch,
            git_url=tool_config.git_url,
        )

        repo_name = Path(project_path).name
        user_lines: GitUserLinesResponse = falcon_client.get_project_user_lines(
            project_id=project_id, git_filter=filters
        )
        output_file_path = data.output_path / f"{repo_name}-user_code.json"
        write_json(file_path=output_file_path, data=user_lines.model_dump(mode="json"))
        logger.info(f"User lines written to {output_file_path}")

        git_messages = []
        for message in user_lines.messages:
            git_message = GitMessage(
                file_path=data.source_path / Path(message["file_path"]).relative_to(Path(message["file_path"]).anchor),
                start_line=message["start_line"],
                end_line=message["end_line"],
                content=message["content"],
                message=message["message"],
                start_column=message["start_column"],
                end_column=message["end_column"],
            )
            git_messages.append(git_message)
        extractor = ProjectExtractor(project_path=data.source_path)

        extractor_result: ProjectFunctionsInfo = extractor.extract_git_functions(
            git_data=git_messages,
        )

        git_user_code_falcon_output = convert_project_functions_info(
            data=extractor_result, tool=AnalysisTool.GITHUB, project_name=str(repo_name)
        )
        write_json(
            file_path=data.output_path / ARTEMIS_COMPATIBLE_FILE_NAME,
            data=git_user_code_falcon_output,
        )
