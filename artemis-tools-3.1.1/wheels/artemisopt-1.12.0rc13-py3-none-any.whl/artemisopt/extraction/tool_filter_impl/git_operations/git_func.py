from uuid import UUID

from artemisopt.models.extraction import ToolConfig


class GitFunc:

    @classmethod
    def execute(
        cls,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool_config: ToolConfig,
    ):
        raise NotImplementedError("Subclasses should implement this method")
