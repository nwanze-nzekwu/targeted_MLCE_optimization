import os
from pathlib import Path
from typing import Optional

from loguru import logger
from sourcekon.extractors.code_extractor_data_types import ExtractorScope
from sourcekon_scripts.terminal.converter.converter_tools.vtune_converter import (
    VtuneConverter,
)
from sourcekon_scripts.terminal.dtos.vtune_command_dtos import VtuneParseCommandInput

from artemisopt.extraction.tool_filter_impl.sourcekon_convert.tool_convert import (
    ToolConvert,
)


class VtuneConvert(ToolConvert):
    @classmethod
    def execute_convert(
        cls,
        output_file_path: str,
        project_path: str,
        output_path: str,
        additional_file_path: Optional[str],
        extractor_scope: Optional[str],
    ):
        """Convert Vtune output files to the required format.

        Args:
            output_file_path: Path to the Vtune output file
            project_path: Path to the source project
            output_path: Path where converted output should be saved
            additional_file_path: Path to additional SQLite file (optional)
            extractor_scope (Optional[str]: The scope of extraction between file and function.

        Raises:
            FileNotFoundError: If any of the required input files do not exist
            ValueError: If input paths are invalid
        """
        # Validate required paths exist
        if not os.path.exists(output_file_path):
            raise FileNotFoundError(f"Output file not found: {output_file_path}")
        if not os.path.exists(project_path):
            raise FileNotFoundError(f"Project path not found: {project_path}")

        # Handle optional SQLite file path
        sqlite_path = Path(additional_file_path) if additional_file_path else None
        if not sqlite_path:
            raise FileNotFoundError(f"SQLite file not found: {sqlite_path}")
        try:
            data = VtuneParseCommandInput(
                file_path=Path(output_file_path),
                source_path=Path(project_path),
                output_path=Path(output_path),
                sqlite_file_path=sqlite_path,
                extractor_scope=extractor_scope,
            )
            converter_tool = VtuneConverter()
            converter_tool.convert(data=data)
        except Exception as e:
            logger.error(f"An error occurred during conversion: {e}")
