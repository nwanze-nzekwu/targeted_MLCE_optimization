from typing import Optional

from sourcekon.extractors.code_extractor_data_types import ExtractorScope


class ToolConvert:
    """
    A parent abstract class to convert a tool data to artemis compatible.
    """

    @classmethod
    def execute_convert(
        cls,
        output_file_path: str,
        project_path: str,
        output_path: str,
        additional_file_path: Optional[str],
        extractor_scope: Optional[str],
    ):
        """
        This method should be implemented by subclasses to perform the conversion.

        Args:
            output_file_path (str): The path to the output file.
            project_path (str): The path to the project.
            output_path (str): The path to the output directory.
            additional_file_path (Optional[str]): The path to an additional file (if applicable).
            extractor_scope (Optional[str]: The scope of extraction between file and function.

        """
        raise NotImplementedError("Subclasses should implement this method")
