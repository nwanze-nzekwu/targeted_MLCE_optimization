from pathlib import Path
from typing import Optional

from loguru import logger
from sourcekon.extractors.code_extractor_data_types import ExtractorScope
from sourcekon_scripts.terminal.converter.converter_tools.flake8_converter import (
    Flake8Converter,
)
from sourcekon_scripts.terminal.dtos.flake8_command_dtos import Flake8ParseCommandInput

from artemisopt.extraction.tool_filter_impl.sourcekon_convert.tool_convert import (
    ToolConvert,
)


class Flake8Convert(ToolConvert):
    """
    A class used to convert Flake8 data to artemis compatible.
    """

    @classmethod
    def execute_convert(
        cls,
        output_file_path: str,
        project_path: str,
        output_path: str,
        additional_file_path: Optional[str],
        extractor_scope: Optional[str],
    ):
        """
        This method executes the conversion of flake8 data to artemis compatible.

        Args:
            output_file_path (str): The path to the output file.
            project_path (str): The path to the project.
            output_path (str): The path to the output directory.
            additional_file_path (Optional[str]): The path to an additional file (not used in this implementation).
            extractor_scope (Optional[str]: The scope of extraction between file and function.
        """
        try:
            data = Flake8ParseCommandInput(
                file_path=Path(output_file_path),
                source_path=Path(project_path),
                output_path=Path(output_path),
                extractor_scope=extractor_scope,
            )
            converter_tool = Flake8Converter()
            converter_tool.convert(data=data)
        except Exception as e:
            logger.error(f"An error occurred during conversion: {e}")
