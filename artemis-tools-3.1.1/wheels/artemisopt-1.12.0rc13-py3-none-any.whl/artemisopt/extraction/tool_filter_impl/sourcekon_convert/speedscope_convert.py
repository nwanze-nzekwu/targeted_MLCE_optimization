from pathlib import Path
from typing import Optional

from loguru import logger
from sourcekon.extractors.code_extractor_data_types import ExtractorScope
from sourcekon_scripts.terminal.converter.converter_tools.speedscope_converter import (
    SpeedscopeConverter,
)
from sourcekon_scripts.terminal.dtos.speedscope_command_dtos import (
    SpeedscopeParseCommandInput,
)

from artemisopt.extraction.tool_filter_impl.sourcekon_convert.tool_convert import (
    ToolConvert,
)


class SpeedscopeConvert(ToolConvert):
    """
    This class is responsible for converting Speedscope data.
    """

    @classmethod
    def execute_convert(
        cls,
        output_file_path: str,
        project_path: str,
        output_path: str,
        additional_file_path: Optional[str],
        extractor_scope: Optional[str],
    ):
        """
        This method executes the conversion of Speedscope data.

        Args:
            output_file_path (str): The path to the output file.
            project_path (str): The path to the project.
            output_path (str): The path to the output directory.
            additional_file_path (Optional[str]): The path to an additional file (not used in this implementation).
            extractor_scope (Optional[str]: The scope of extraction between file and function.

        """

        # Check if the input paths exist
        if not Path(output_file_path).exists():
            raise FileNotFoundError(f"Output file not found: {output_file_path}")
        if not Path(project_path).exists():
            raise FileNotFoundError(f"project file not found: {project_path}")

        try:
            data = SpeedscopeParseCommandInput(
                file_path=Path(output_file_path),
                source_path=Path(project_path),
                output_path=Path(output_path),
                extractor_scope=extractor_scope,
            )
            converter_tool = SpeedscopeConverter()
            converter_tool.convert(data=data)
        except Exception as e:
            logger.error(f"An error occurred during conversion: {e}")
