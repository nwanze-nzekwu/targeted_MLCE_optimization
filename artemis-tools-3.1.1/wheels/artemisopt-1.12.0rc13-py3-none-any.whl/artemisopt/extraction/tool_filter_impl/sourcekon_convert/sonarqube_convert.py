from pathlib import Path
from typing import Optional

from loguru import logger
from sourcekon.extractors.code_extractor_data_types import ExtractorScope
from sourcekon_scripts.terminal.converter.converter_tools.sonarqube_converter import (
    SonarqubeConverter,
)
from sourcekon_scripts.terminal.dtos.sonarqube_command_dtos import (
    SonarqubeParseCommandInput,
)

from artemisopt.extraction.tool_filter_impl.sourcekon_convert.tool_convert import (
    ToolConvert,
)


class SonarqubeConvert(ToolConvert):
    """
    A class to convert Sonarqube data to artemis compatible.
    """

    @classmethod
    def execute_convert(
        cls,
        output_file_path: str,
        project_path: str,
        output_path: str,
        additional_file_path: Optional[str],
        extractor_scope: Optional[str],
    ):
        """
        Converts Sonarqube data using the SonarqubeConverter to artemis compatible.

        Args:
            output_file_path (str): The path to the output file.
            project_path (str): The path to the project.
            output_path (str): The path to the output directory.
            additional_file_path (Optional[str]): The path to an additional file (not used).
            extractor_scope (Optional[str]: The scope of extraction between file and function.

        """
        try:
            data = SonarqubeParseCommandInput(
                file_path=Path(output_file_path),
                source_path=Path(project_path),
                output_path=Path(output_path),
                extractor_scope=extractor_scope,
            )
            converter_tool = SonarqubeConverter()
            converter_tool.convert(data=data)
        except Exception as e:
            logger.error(f"An error occurred during conversion: {e}")
