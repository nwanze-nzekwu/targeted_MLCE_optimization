from enum import Enum
from typing import Type, Self

from artemisopt.extraction.tool_filter_impl.sourcekon_convert.coverity_convert import (
    CoverityConvert,
)
from artemisopt.extraction.tool_filter_impl.sourcekon_convert.flake8_convert import (
    Flake8Convert,
)
from artemisopt.extraction.tool_filter_impl.sourcekon_convert.pylint_convert import (
    PylintConvert,
)
from artemisopt.extraction.tool_filter_impl.sourcekon_convert.sonarqube_convert import (
    SonarqubeConvert,
)
from artemisopt.extraction.tool_filter_impl.sourcekon_convert.speedscope_convert import (
    SpeedscopeConvert,
)
from artemisopt.extraction.tool_filter_impl.sourcekon_convert.tool_convert import (
    ToolConvert,
)
from artemisopt.extraction.tool_filter_impl.sourcekon_convert.vtune_convert import (
    VtuneConvert,
)

__all__ = ["SourcekonConvertTool"]

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                      Data types                                                      #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class SourcekonConvertTool(Enum):
    """
    Enum for sourcekon convert tools.

    Each enum member represents a tool and its corresponding converter class.
    """

    SPEEDSCOPE = (
        "speedscope",
        SpeedscopeConvert,
    )
    VTUNE = (
        "vtune",
        VtuneConvert,
    )
    FLAKE8 = (
        "flake8",
        Flake8Convert,
    )
    PYLINT = (
        "pylint",
        PylintConvert,
    )
    SONARQUBE = (
        "sonarqube",
        SonarqubeConvert,
    )
    COVERITY = "coverity", CoverityConvert

    @property
    def tool_name(self) -> str:
        """Returns the name of the tool.

        Returns:
             str: The name of the tool.
        """
        return self.value[0]

    @property
    def get_tool_converter(self) -> Type[ToolConvert]:
        """Returns the converter class for the tool.

        Returns:
              Type[ToolConvert]: The converter class for the tool.
        """
        return self.value[1]

    @classmethod
    def from_tool_name(cls, name: str) -> Self:
        """Returns the enum member for the given tool name.

        Args:
            name (str): The name of the tool.

        Returns:
            Self: The enum member for the tool.

        Raises:
            ValueError: If the tool is not supported.
        """
        for tool in cls:
            if tool.tool_name == name:
                return tool
        raise ValueError(f"not supported: '{name}'")
