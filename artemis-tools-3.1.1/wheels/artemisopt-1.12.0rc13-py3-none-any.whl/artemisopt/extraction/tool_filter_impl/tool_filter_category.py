from enum import Enum
from typing import Type, Self
from artemisopt.extraction.tool_filter_impl.embedding_tool_filter import (
    EmbeddingToolFilter,
)
from artemisopt.extraction.tool_filter_impl.git_tool_filter import GitToolFilter
from artemisopt.extraction.tool_filter_impl.artemis_compatible_tool_filter import (
    ArtemisCompatibleToolFilter,
)
from artemisopt.extraction.tool_filter_impl.supported_tool_filter import (
    SupportedToolFilter,
)
from artemisopt.extraction.tool_filter_impl.tool_filter_abstract import FilterTool

__all__ = ["ToolFilterCategory"]

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                      Data types                                                      #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class ToolFilterCategory(Enum):
    # pylint: disable=R0801
    GENERIC = "generic", EmbeddingToolFilter
    ARTEMIS = "artemis", ArtemisCompatibleToolFilter
    SUPPORTED = "supported", SupportedToolFilter
    GIT = "git", GitToolFilter

    @property
    def mode(self) -> str:
        return self.value[0]

    @property
    def get_filter_class(self) -> Type[FilterTool]:
        return self.value[1]

    @classmethod
    def from_name(cls, name: str) -> Self:
        for category in cls:
            if category.mode == name:
                return category
        raise ValueError(f"not supported: '{name}'")
