import os
import shutil
from pathlib import Path
from uuid import UUID

from loguru import logger

from artemisopt.extraction import ARTEMIS_COMPATIBLE_FILE_NAME
from artemisopt.extraction.tool_filter_impl.tool_filter_abstract import FilterTool
from artemisopt.models.extraction import ToolConfig


class ArtemisCompatibleToolFilter(FilterTool):
    """Filter tool implementation for artemis compatible tool conversions"""

    def main(
        self,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool: str,
        tool_config: ToolConfig,
    ):
        """
        Uses sourcekon output file to extract code snippets

        Args:
            project_path: Path to project directory
            output_path: Path where converted output should be stored
            project_id: Unique identifier for the project
            tool: Name of the tool to convert from
            tool_config: Configuration for the tool
        """
        logger.info(f"project id: {project_id}")
        logger.info(f"selected tool: {tool}")
        output_dir = Path(output_path)
        output_dir.mkdir(parents=True, exist_ok=True)

        destination_file_path = output_dir / ARTEMIS_COMPATIBLE_FILE_NAME
        if not os.path.exists(tool_config.input_file_path):
            logger.error(f"Input file {tool_config.input_file_path} does not exist.")
            return

        try:
            shutil.copy(tool_config.input_file_path, destination_file_path)
            logger.info(
                f"Copied {tool_config.input_file_path} to {destination_file_path}"
            )
        except Exception as e:
            logger.error(f"Failed to copy file: {e}")
