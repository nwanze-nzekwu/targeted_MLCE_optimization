from abc import ABC, abstractmethod
from uuid import UUID

from artemisopt.models.extraction import ToolConfig


class FilterTool(ABC):
    """
    Abstract base class for tool filters.

    This class provides a basic interface structure for tool filters, including
    the main method and the get_category_name method.
    """

    @abstractmethod
    def main(
        self,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool: str,
        tool_config: ToolConfig,
    ):
        """
        Main method for the tool filter.

        This method should be implemented by subclasses to perform the actual
        filtering.

        Args:
            project_path (str): The path to the project.
            output_path (str): The path to the output directory.
            project_id (UUID): The ID of the project.
            tool (str): The name of the tool.
            tool_config (ToolConfig): The configuration for the tool.

        Raises:
            NotImplementedError: If the method is not implemented by a subclass.
        """
        raise NotImplementedError("Subclasses should implement this method")
