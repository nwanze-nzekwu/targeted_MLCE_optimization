import json
from pathlib import Path
from uuid import UUID

from artemis_client import VisionClient
from artemis_client.vision.client import VisionSettings
from evoml_services.clients.thanos import ThanosSettings
from loguru import logger
from sourcekon_scripts.artemis_integration.artemis_tos import (
    FalconMessagesOutput,
    FalconParseOutput,
)
from sourcekon.parsers.code_parser_data_types import ProgrammingLanguage
from vision_models import SearchResultsResponse
from vision_models.service.embedding import CodeEmbeddingMetadata

from artemisopt.extraction import ARTEMIS_COMPATIBLE_FILE_NAME
from artemisopt.extraction.tool_filter_impl.readers.reader_type import (
    ProcessorType,
)
from artemisopt.extraction.tool_filter_impl.tool_filter_abstract import FilterTool
from artemisopt.models.extraction import ToolConfig


class LLMClient:
    def vision_client(self) -> VisionClient:
        vision_settings = VisionSettings.with_env_prefix(
            "vision",
            _env_file=".env",
        )
        thanos_settings = ThanosSettings.with_env_prefix(
            "thanos",
            _env_file=".env",
        )
        return VisionClient(vision_settings, thanos_settings)


class EmbeddingToolFilter(FilterTool):
    # Main function
    def main(
        self,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool: str,
        tool_config: ToolConfig,
    ):

        assert tool_config.input_file_path is not None
        try:
            llm_client = LLMClient()
            vc = llm_client.vision_client()
            output_dir: Path = Path(output_path)
            output_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"input_file_path = {tool_config.input_file_path}")

            input_path = Path(tool_config.input_file_path)
            if not input_path.exists():
                raise FileNotFoundError(f"Input file not found: {input_path}")

            falcon_messages = self.process_input_file(
                input_file_path=input_path, vc=vc, project_id=project_id
            )
            self.write_output(falcon_messages=falcon_messages, output_path=output_dir)
        except Exception as e:
            logger.error(f"Error in main processing: {str(e)}")
            raise

    def process_input_file(
        self, input_file_path: Path, vc: VisionClient, project_id: UUID
    ) -> list[FalconMessagesOutput]:
        processor_type = ProcessorType
        processor = processor_type.from_extension(str(input_file_path))
        falcon_messages = []
        rank = 1
        search_limit = 1

        try:
            for row in processor.get_processor.read_file(input_file_path):
                if not row:
                    continue

                query_str = row
                logger.info(f"query: {query_str}")
                results: SearchResultsResponse = vc.search_projects(
                    query=query_str, project_ids=[str(project_id)], limit=search_limit
                )

                new_falcon_messages = self.create_falcon_messages(
                    results, rank, search_limit
                )
                if new_falcon_messages:
                    falcon_messages.extend(new_falcon_messages)
                    rank += search_limit
        except Exception as e:
            logger.error(f"Error processing input file: {str(e)}")
            raise

        return falcon_messages

    @staticmethod
    def create_falcon_messages(
        results: SearchResultsResponse, rank: int, search_limit: int
    ) -> list[FalconMessagesOutput]:
        falcon_messages = []
        for r in results.results[:search_limit]:
            metadata = r.metadata
            if isinstance(metadata, CodeEmbeddingMetadata):
                categories = ["EMBEDDING"]
                if rank <= 10:
                    categories += ["TOP_10"]
                falcon_message = FalconMessagesOutput(
                    message=f"{metadata.name} found",
                    category=categories,
                    start_line=metadata.start_line,
                    end_line=metadata.end_line,
                    start_column=metadata.start_col,
                    end_column=metadata.end_col,
                    message_id=None,
                    file_path=metadata.file,
                    language=ProgrammingLanguage.get_from_extension(
                        extension=Path(metadata.file).suffix
                    ).id,
                )
                logger.info(f"falcon_message : {falcon_message}")

                falcon_messages.append(falcon_message)

        return falcon_messages

    @staticmethod
    def write_output(falcon_messages: list[FalconMessagesOutput], output_path: Path):
        output_file_path = output_path.joinpath(ARTEMIS_COMPATIBLE_FILE_NAME)
        try:
            falcon_parse_output = FalconParseOutput(
                constructs=falcon_messages, tool="other"
            )
            with open(output_file_path, "w") as output_file:
                json.dump(
                    falcon_parse_output,
                    output_file,
                    default=lambda o: o.__dict__,
                    indent=4,
                )

            logger.debug(f"Results written to {output_file_path}")
        except Exception as e:
            logger.error(f"Error writing output file: {str(e)}")
            raise
