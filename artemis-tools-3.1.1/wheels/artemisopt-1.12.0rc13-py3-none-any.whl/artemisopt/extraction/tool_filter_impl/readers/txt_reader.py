from pathlib import Path

from loguru import logger

from artemisopt.extraction.tool_filter_impl.readers.file_reader import (
    FileReader,
)
from artemisopt.extraction.tool_filter_impl.readers.reader_utils import detect_file_encoding_from_path


class TxtReader(FileReader):
    """
    A processor for text files.

    This class extends the FileProcessor and provides a method to process text files.
    """

    @classmethod
    def read_file(cls, file_path: Path, **kwargs):
        """
        Process a text file and yield each line.

        Args:
            file_path (str): The path to the text file.

        Yields:
            str: Each line in the text file.

        Raises:
            FileNotFoundError: If the file does not exist.
        """
        try:
            detected_encoding=detect_file_encoding_from_path(path=file_path)
            with open(file_path, "r", encoding=detected_encoding) as file:
                for line in file:
                    line = line.strip()
                    yield line

        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            raise FileNotFoundError(f"The file {file_path} does not exist.")
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            raise Exception(f"An error occurred: {e}")
