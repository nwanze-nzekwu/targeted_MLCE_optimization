import json
from pathlib import Path

from loguru import logger
from artemisopt.extraction.tool_filter_impl.readers.file_reader import (
    FileReader,
)
from artemisopt.extraction.tool_filter_impl.readers.reader_utils import detect_file_encoding_from_path


class JsonReader(FileReader):
    """
    A processor for JSON files.
    """

    @classmethod
    def read_file(cls, file_path: Path, **kwargs):
        """
        Process a JSON file and yield its contents.

        Args:
            file_path (str): The path to the JSON file.

        Yields:
            str: The contents of the JSON file.

        Raises:
            FileNotFoundError: If the file does not exist
        """
        try:
            detected_encoding=detect_file_encoding_from_path(path=file_path)
            with open(file_path, "r", encoding=detected_encoding) as file:
                data = json.load(file)
                for item in data:
                    content = json.dumps(item)
                    yield content
        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            raise FileNotFoundError(f"The file {file_path} does not exist.")
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing JSON: {e}")
            raise ValueError(f"The file {file_path} does not exist.")
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            raise Exception(f"An error occurred: {e}")
