import csv
from pathlib import Path

from loguru import logger

from artemisopt.extraction.tool_filter_impl.readers.file_reader import (
    FileReader,
)
from artemisopt.extraction.tool_filter_impl.readers.reader_utils import detect_file_encoding_from_path


class CsvReader(FileReader):
    """Process CSV files and yield each row as a comma-separated string."""

    @classmethod
    def read_file(cls, file_path: Path, delimiter: str = ",", **kwargs):
        """Process a CSV file and yield each row as a string.

        Args:
            file_path: Path to the CSV file to process
            delimiter: str
        Yields:
            str: Each row from the CSV converted to a comma-separated string

        Raises:
            FileNotFoundError: If the file does not exist
        """
        try:
            detected_encoding=detect_file_encoding_from_path(path=file_path)
            with open(file_path, "r", encoding=detected_encoding) as file:
                reader = csv.reader(file, delimiter=delimiter)

                for row in reader:
                    row_as_string = ",".join(row)
                    yield row_as_string
        except FileNotFoundError:
            logger.error(f"File not found: {file_path}")
            raise FileNotFoundError(f"The file {file_path} does not exist.")
        except csv.Error as e:
            logger.error(f"CSV parsing error: {e}")
            raise ValueError(f"CSV parsing error: {e}")
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            raise Exception(f"An error occurred: {e}")
