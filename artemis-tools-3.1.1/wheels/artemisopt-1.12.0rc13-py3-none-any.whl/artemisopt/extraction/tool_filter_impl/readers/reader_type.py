from enum import Enum
from pathlib import Path
from typing import Type, Self

from artemisopt.extraction.tool_filter_impl.readers.csv_reader import CsvReader
from artemisopt.extraction.tool_filter_impl.readers.file_reader import (
    FileReader,
)
from artemisopt.extraction.tool_filter_impl.readers.json_reader import (
    JsonReader,
)
from artemisopt.extraction.tool_filter_impl.readers.txt_reader import TxtReader

__all__ = ["ProcessorType"]

# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #
#                                                      Data types                                                      #
# ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────── #


class ProcessorType(Enum):
    # pylint: disable=R0801
    JSON = ".json", JsonReader
    CSV = ".csv", CsvReader
    TXT = ".txt", TxtReader

    @property
    def file_extension(self) -> str:
        return self.value[0]

    @property
    def get_processor(self) -> Type[FileReader]:
        return self.value[1]

    @classmethod
    def from_extension(cls, file_path: str) -> Self:
        user_file_extension = Path(file_path).suffix
        for processor in cls:
            if processor.file_extension == user_file_extension:
                return processor
        raise ValueError(f"not supported: '{user_file_extension}'")
