from pathlib import Path

from charset_normalizer import from_path


def detect_file_encoding_from_path(path: Path):
    detected_encoding="utf-8"
    try:
        detected_encoding=from_path(path).best().encoding
    except Exception as e:
        pass

    return detected_encoding