from abc import ABC
from pathlib import Path


class FileReader(ABC):
    @classmethod
    def read_file(cls, file_path: Path, **kwargs):
        raise NotImplementedError("Subclasses should implement this method")
