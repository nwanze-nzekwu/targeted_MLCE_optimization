from uuid import UUID

from artemisopt.extraction.tool_filter_impl.git_operations.git_operation_type import (
    GitOperationType,
)
from artemisopt.extraction.tool_filter_impl.tool_filter_abstract import FilterTool
from artemisopt.models.extraction import ToolConfig


class GitToolFilter(FilterTool):
    """Filter tool for handling Git operations and executing git-related commands."""

    def main(
        self,
        project_path: str,
        output_path: str,
        project_id: UUID,
        tool: str,
        tool_config: ToolConfig,
    ) -> None:
        """Execute git operations based on the provided configuration.

        Args:
            project_path: Path to the target project directory
            output_path: Path where operation output should be stored
            project_id: Unique identifier for the project
            tool: Name of the tool being used
            tool_config: Configuration settings for git operations

        Raises:
            ValueError: If required git configuration parameters are missing
            RuntimeError: If git operation execution fails
        """

        if not tool_config.git_mode:
            raise ValueError("Git mode is a required configuration parameter")

        if not tool_config.git_url:
            raise ValueError("Git URL is a required configuration parameter")

        try:
            executor = GitOperationType.from_type(type=tool_config.git_mode)
            executor.get_executor.execute(
                project_path=project_path,
                output_path=output_path,
                tool_config=tool_config,
                project_id=project_id,
            )
        except Exception as e:
            raise RuntimeError(f"Git operation failed: {str(e)}") from e
