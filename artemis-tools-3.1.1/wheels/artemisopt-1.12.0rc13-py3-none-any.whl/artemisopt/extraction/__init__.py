ARTEMIS_COMPATIBLE_FILE_NAME = "artemis-compatible.json"
