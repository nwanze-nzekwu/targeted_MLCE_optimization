"""
Contains basic structure for extractors
"""

from collections.abc import Iterable, Iterator
from pathlib import Path
from typing import Self

from artemis_tools.conf.base_data_types import BaseModelWithAlias
from artemis_tools.models.generic import Language, language_by_extension
from artemis_tools.services.extract.analyser import Analyser, AnalyserConfig
from falcon_models.api import ConcreteConstructRequest, CustomSpecRequest
from loguru import logger


class ExtractorConfig(BaseModelWithAlias):
    """Configuration for the extractor"""

    project_path: Path
    include_globs: list[str] = []
    exclude_globs: list[str] = []
    queries: list[str] = []


class ExtractorWrapper:
    """Acts as a wrapper around `artemis-tools` analyser.

    `Analyser` is still an extractor as in it extracts snippets from a project path
    but its name is changed to distinguish it from the actual extraction task.
    `Analyser` also performs file and content filtering.

    Where the extractor in `artemis-tools` is responsible to getting relevant chunks,
    the wrapper converts these to falcon specific objects ready for storage.

    This does not follow the `Extractor` ABC since it's not tied to a particular
    language. Instead, we use the `Extracts` protocol to unify all of these
    implementations.

    1. Prepare config for extraction
    2. Call extraction
    3. Adapt results to falcon objects

    TODO: consider an extractor per type of extraction, which all share an `extract` method
    """

    def __init__(
        self,
        project_path: Path,
        include_globs: list[str] | None,
        exclude_globs: list[str] | None,
        queries: list[str] | None = None,
    ):
        queries = queries or []
        include_globs = include_globs or []
        exclude_globs = exclude_globs or []
        self.project_path = project_path
        self.include_globs = include_globs
        self.exclude_globs = exclude_globs
        self.queries = queries

    @classmethod
    def from_config(cls, input_config: ExtractorConfig) -> Self:
        return cls(
            input_config.project_path,
            input_config.include_globs,
            input_config.exclude_globs,
            input_config.queries,
        )

    def iter_extract_query(self, query: str) -> Iterator[ConcreteConstructRequest]:
        for extract in Analyser.analyse(
            AnalyserConfig(
                project_path=self.project_path,
                include_globs=self.include_globs,
                exclude_globs=self.exclude_globs,
                query=query,
            )
        ):
            og_spec = CustomSpecRequest(name=extract.name, content=extract.content)
            # a fallback name if extraction failed to label the snippet
            if not og_spec.name:
                og_spec.name = f"snippet-{str(og_spec.id)[-5:]}"

            # file_path should be not None unless the extraction was performed on
            # a list of strings
            assert extract.file_path is not None
            yield ConcreteConstructRequest(
                file=str(Path(extract.file_path).relative_to(self.project_path)),
                original_spec_id=og_spec.id,
                lineno=extract.start_line,
                end_lineno=extract.end_line,
                custom_specs=[og_spec],
                language=language_by_extension.get(
                    Path(extract.file_path).suffix, Language.TEXT
                ),
                global_tags=[extract.node_type.upper()],
            )

    def iter_extract(self) -> Iterable[ConcreteConstructRequest]:
        n_constructs = 0
        for query in self.queries:
            for new_spec in self.iter_extract_query(query):
                n_constructs += 1
                yield new_spec
        logger.info(f"Created {n_constructs} code snippets after static filtering.")

    def extract(self) -> list[ConcreteConstructRequest]:
        """Initiates extraction of a project"""
        specs: list[ConcreteConstructRequest] = []
        for spec in self.iter_extract():
            specs.append(spec)
        return specs


class StaticExtractor:
    @classmethod
    def iter_extract_query(
        cls, text: str, path: Path, query: str
    ) -> Iterator[ConcreteConstructRequest]:
        for extract in Analyser.analyse_from_string(
            text, AnalyserConfig(project_path=None, query=query)
        ):
            og_spec = CustomSpecRequest(name=extract.name, content=extract.content)
            # a fallback name if extraction failed to label the snippet
            if not og_spec.name:
                og_spec.name = f"snippet-{str(og_spec.id)[-5:]}"

            # file_path should be not None unless the extraction was performed on
            # a list of strings
            assert extract.file_path is not None
            yield ConcreteConstructRequest(
                file=str(path),
                original_spec_id=og_spec.id,
                lineno=extract.start_line,
                end_lineno=extract.end_line,
                custom_specs=[og_spec],
                language=language_by_extension[path.suffix],
                global_tags=[extract.node_type.upper()],
            )

    @classmethod
    def extract(
        cls, text: str, path: Path, query: str
    ) -> list[ConcreteConstructRequest]:
        """Initiates extraction of a project"""
        specs: list[ConcreteConstructRequest] = []
        for spec in cls.iter_extract_query(text, path, query):
            specs.append(spec)
        return specs
