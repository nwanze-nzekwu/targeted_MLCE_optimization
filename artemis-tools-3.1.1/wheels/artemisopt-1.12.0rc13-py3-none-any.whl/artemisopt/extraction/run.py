import time
import uuid
from typing import Any, AsyncGenerator, AsyncIterator, Iterable

from falcon_models.api import ConcreteConstructRequest, ConcreteConstructResponse
from loguru import logger

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.extraction.llm_filter import LLMFilter
from artemisopt.extraction.tool_filter import ToolFilter
from artemisopt.extraction.tools_extractor import ExtractorConfig, ExtractorWrapper
from artemisopt.models.code import ConstructMapping
from artemisopt.models.extraction import Filter, ToolConfig
from artemisopt.util.output import OutputManager

EXTRACT_BATCH_SIZE = 500
EXTRACT_DEBOUNCE_TIME = 1
EXTRACT_DEBOUNCE_MIN_SIZE = 50
SNIPPET_KB_LIMIT = 300


async def async_constructs_generator(
    extracts: Iterable[ConcreteConstructRequest],
) -> AsyncGenerator[ConcreteConstructRequest, Any]:
    for construct in extracts:
        yield construct


async def process_construct_iterator(construct_iterator: AsyncIterator[ConcreteConstructRequest]):
    saved: list[ConcreteConstructResponse] = []
    created: list[ConcreteConstructRequest] = []
    created_info = set()

    last_update_time = 0

    try:
        async for extracted_construct in construct_iterator:
            snippet_size = (
                len(extracted_construct.custom_specs[0].content.encode("utf-8")) / 1024
            )
            current_snippet_info = (
                    extracted_construct.file,
                    extracted_construct.lineno,
                    extracted_construct.end_lineno,
                )
            if snippet_size < SNIPPET_KB_LIMIT:
                if current_snippet_info not in created_info:
                    created.append(extracted_construct)
                    created_info.add(
                        current_snippet_info
                    )
                else:
                    dup_construct = next(
                        filter(
                            lambda c: (c.file, c.lineno, c.end_lineno)
                            == current_snippet_info,
                            created,
                        ),
                        None,
                    )
                    if dup_construct is not None:
                        dup_construct.tags.extend(extracted_construct.tags)

            else:
                logger.info(f"Skipping construct with content size {snippet_size}KB as it exceeds the limit of {SNIPPET_KB_LIMIT}KB")

            if len(created) >= EXTRACT_BATCH_SIZE or (
                len(created) >= EXTRACT_DEBOUNCE_MIN_SIZE
                and (last_update_time + EXTRACT_DEBOUNCE_TIME < time.perf_counter())
            ):
                saved.extend(OutputManager.add_construct(created))
                logger.info(f"Saved {len(created)} code snippets")
                created.clear()
                created_info.clear()
                last_update_time = time.perf_counter()

    finally:
        if created:
            saved.extend(OutputManager.add_construct(created))
            logger.info(f"Saved {len(created)} code snippets")

    construct_mapping = ConstructMapping({c.id: c for c in saved})
    with (conf_mgr.artemis_settings.output_path / "constructs.json").open("w") as f:
        f.write(construct_mapping.model_dump_json())
    return construct_mapping

async def run_extraction(
    artemis_config: ArtemisTaskConfig,
) -> ConstructMapping:
    """Run extraction

    Returns:
        - list of constructs after saving in DB
    """

    assert artemis_config.project_path is not None
    assert artemis_config.user_id is not None

    extractor = ExtractorWrapper.from_config(
        input_config=ExtractorConfig(
            project_path=artemis_config.project_path,
            include_globs=artemis_config.include_globs,
            exclude_globs=artemis_config.exclude_globs,
            queries=artemis_config.extraction_queries,
        ),
    )

    return await process_construct_iterator(async_constructs_generator(extractor.iter_extract()))


async def run_extraction_with_llm_filter(
    artemis_config: ArtemisTaskConfig,
) -> ConstructMapping:

    assert artemis_config.llm_type is not None
    assert artemis_config.llm_filter is not None
    assert artemis_config.project_path is not None
    assert artemis_config.user_id is not None

    extractor = ExtractorWrapper.from_config(
        input_config=ExtractorConfig(
            project_path=artemis_config.project_path,
            include_globs=artemis_config.include_globs,
            exclude_globs=artemis_config.exclude_globs,
            queries=artemis_config.extraction_queries,
        ),
    )
    tool = OutputManager.falcon_client().put_tool("llm-filter")
    llm_filter = LLMFilter(
        user_id=artemis_config.user_id,
        tool_id=tool.tool_id,
        llm_type=artemis_config.llm_type,
        llm_filter_number=artemis_config.llm_filter_number or 0,
    )

    constructs_iterator = llm_filter.filter_constructs(extractor.extract(), artemis_config.llm_filter)
    return await process_construct_iterator(constructs_iterator)

async def run_extraction_with_tool(
    artemis_config: ArtemisTaskConfig,
) -> ConstructMapping:

    if artemis_config.filter_tool_mode is None:
        raise AssertionError("filter_tool_mode should not be None")
    if artemis_config.tool_filter is None:
        raise AssertionError("tool_filter should not be None")
    logger.info(f"artemis_config: {artemis_config.model_dump_json()}")
    tool = OutputManager.falcon_client().put_tool(artemis_config.tool_filter.value)

    extra_filter = Filter(
        include=artemis_config.include_globs, exclude=artemis_config.exclude_globs
    )
    tool_config = ToolConfig(
        tool=artemis_config.tool_filter,
        tool_id=uuid.UUID(tool.tool_id),
        category=artemis_config.filter_tool_mode,
        input_file_path=artemis_config.input_file_path,
        additional_file_path=artemis_config.additional_file_path,
        current_branch=artemis_config.current_branch,
        main_branch=artemis_config.main_branch,
        git_url=artemis_config.git_url,
        git_mode=artemis_config.git_mode,
        extractor_scope=artemis_config.extractor_scope,
        start_date=artemis_config.start_date,
        end_date=artemis_config.end_date,
        contributor=artemis_config.contributor,
        filter=extra_filter,
    )

    tool_filter = ToolFilter(
        project_path=str(artemis_config.project_path),
        file_ids=artemis_config.tool_files,
        project_id=uuid.UUID(artemis_config.project_id),
        tool_config=tool_config,
    )
    llm_filter = None
    if artemis_config.llm_filter is not None:
        if artemis_config.llm_type is None:
            raise AssertionError("llm_type should not be None")
        if artemis_config.user_id is None:
            raise AssertionError("user_id should not be None")

        llm_tool = OutputManager.falcon_client().put_tool("llm-filter")
        llm_filter = LLMFilter(
            user_id=artemis_config.user_id,
            tool_id=llm_tool.tool_id,
            llm_type=artemis_config.llm_type,
            llm_filter_number=artemis_config.llm_filter_number or 0,
        )

    extracts: list[ConcreteConstructRequest] = tool_filter.create_constructs()

    if llm_filter:
        construct_iterator = llm_filter.filter_constructs(
            extracts, artemis_config.llm_filter
        )
    else:
        construct_iterator = async_constructs_generator(extracts)

    return await process_construct_iterator(construct_iterator)
