"""Implements functionality to gather metrics for a running process and its children"""

import logging
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Union

import psutil
from loguru import logger
from psutil import NoSuchProcess

from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.models.executor import EvaluationResults, ExecutionResults
from artemisopt.util.general import (
    pipe_process_logs_in_chunks,
    send_command_output_logs,
)

executor_logger = logging.getLogger("executor")
executor_logger.setLevel(logging.INFO)
METRICS = ["Runtime", "Average CPU usage", "Average Memory usage"]


def kill_process(proc: psutil.Process):
    """Kills a process and its children"""
    try:
        if proc.is_running():
            proc.kill()
    except NoSuchProcess:
        ...


def kill_process_with_children(proc: psutil.Process):
    """Kills a process and its children"""
    try:
        children = list(proc.children(recursive=True))
        for child in children:
            kill_process(child)
        kill_process(proc)
        psutil.wait_procs(children)
        proc.wait()
    except NoSuchProcess:
        ...


class Executor:
    """Contains all evaluator related infrastructure"""

    @staticmethod
    def evaluate_process(p: psutil.Popen, lightweight: bool = False):
        """Records the metrics of a running process"""
        cpu_times = {}
        mem = 0
        cnt = 0
        start_time = time.perf_counter()
        wait_time = 1 if lightweight else 0.1
        # Parent process is shell
        failed_child_pids: set = set()
        while True:
            status_code = p.poll()
            if status_code is not None:
                break

            cnt += 1
            cur_mem = 0
            try:
                with p.oneshot():
                    for child in p.children(True):
                        with child.oneshot():
                            if child.is_running():
                                # Permissions for child processes on macOS seem to run into
                                try:
                                    cur_mem += child.memory_full_info().uss
                                    cpu_times[child.pid] = sum(child.cpu_times()[:2])
                                except psutil.AccessDenied:
                                    failed_child_pids.add(child.pid)
                                    pass
                mem = Executor._calc_rolling_avg(cur_mem, mem, cnt)
            except NoSuchProcess:
                pass
            if cur_mem / 1024**2 > conf_mgr.artemis_settings.ram_limit_mb:
                kill_process_with_children(p)
                logger.error(
                    f"Memory limit exceeded {conf_mgr.artemis_settings.ram_limit_mb} MB"
                )
                return ExecutionResults(status_code=1)

            time.sleep(wait_time)

        if len(failed_child_pids) > 0:
            logger.info(
                f"Metrics couldn't be gathered for the child processes "
                f"wih pid {failed_child_pids}, because of an AccessDenied exception."
                f"This may impact the accuracy of the metrics obtained."
            )

        if status_code != 0:
            return ExecutionResults(status_code=status_code)

        last_rec_time = time.perf_counter()
        runtime = last_rec_time - start_time
        cpu = sum(cpu_times.values()) / (1.0 if runtime == 0.0 else runtime) * 100.0

        return ExecutionResults(
            status_code=status_code,
            evaluation=EvaluationResults(
                **{"runtime": runtime, "cpu_avg": cpu, "mem_avg": mem}
            ),
        )

    @staticmethod
    def _calc_rolling_avg(new_val: Union[float, int], cur_avg: float, n: int):
        """Helper function to calculate rolling average"""
        return cur_avg + (new_val - cur_avg) / n

    @staticmethod
    def execute(
        command: str,
        *,
        cwd: Path | None = None,
        env: dict[str, Any] | None = None,
        benchmark: bool = False,
        log_file: Path | None = None,
    ) -> ExecutionResults | None:
        results = None
        if not log_file:
            log_file = Path(conf_mgr.artemis_settings.output_path) / "execution.log"
        logger.trace(command)

        # Open the log file for writing
        with log_file.open("w", encoding="utf-8") as pipe:
            proc = None
            try:
                # Start the process with stdout and stderr redirected to a PIPE.
                proc = psutil.Popen(
                    command,
                    cwd=cwd,
                    env=env,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                )
                log_thread = threading.Thread(
                    target=pipe_process_logs_in_chunks,
                    args=(pipe, proc, executor_logger),
                )
                log_thread.start()
                results = Executor.evaluate_process(proc, not benchmark)
                log_thread.join()
            finally:
                # make sure process is dead
                if proc is not None:
                    kill_process_with_children(proc)

                command_output_header = "Command Output"
                command_output_footer = ""

                # add exit code to the header
                if results:
                    command_output_header += f" (status code: {results.status_code})"

                # add runtime, cpu and mem to the footer
                if results and results.evaluation is not None:
                    runtime = results.evaluation.runtime
                    cpu = results.evaluation.cpu_avg
                    mem = results.evaluation.mem_avg
                    runtime_msg = f" \nRuntime: {runtime:.4}s CPU: {cpu:.4}% Mem: {mem}"
                    command_output_footer += runtime_msg

                if log_file.exists():
                    send_command_output_logs(
                        log_file,
                        logger,
                        prefix=command_output_header,
                        suffix=command_output_footer,
                    )
                # only send header and footer as command output is sent in real time
                executor_logger.info(
                    "\n".join([command_output_header, command_output_footer])
                )

        return results
