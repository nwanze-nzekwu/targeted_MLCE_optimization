"""
Contains extract related models
"""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel
from uuid import UUID


class Filter(BaseModel):
    include: Optional[list[str]]
    exclude: Optional[list[str]]


class ToolConfig(BaseModel):
    tool: str
    tool_id: UUID
    category: str
    input_file_path: Optional[str]
    additional_file_path: Optional[str]
    current_branch: Optional[str]
    main_branch: Optional[str]
    git_url: Optional[str]
    git_mode: Optional[str]
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    contributor: Optional[str] = None
    extractor_scope: Optional[str]
    filter: Optional[Filter]
