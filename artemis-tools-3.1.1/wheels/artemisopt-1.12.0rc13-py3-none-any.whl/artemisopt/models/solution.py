from enum import StrEnum
from uuid import UUID

from artemisopt.models.executor import EvaluationResults
from artemisopt.util.basemodel import ArtemisBaseModel


class SolutionEntry(ArtemisBaseModel):
    """Single entry in solution that contains the state of a single construct"""

    construct_id: UUID
    spec_id: UUID


class SolutionStatus(StrEnum):
    created = "created"
    success = "success"
    fail = "failed"
    running = "running"
    pending = "pending"


class Solution(ArtemisBaseModel):
    """Contains info about the state of each construct in a proposed mutation
    and metrics related to its performance"""

    constructs: list[SolutionEntry]
    metrics: EvaluationResults | None = None


class BriefSolutionInfo(ArtemisBaseModel):
    """Contains info about the state of each construct in a proposed mutation"""

    constructs: list[SolutionEntry]
