import uuid

from artemis_tools.conf.base_data_types import RootModelWithAlias
from falcon_models.api import (
    ConcreteConstructRequest,
    ConcreteConstructResponse,
    CustomSpecRequest,
)


class ConstructMapping(
    RootModelWithAlias[dict[uuid.UUID, ConcreteConstructResponse]]
): ...


def original_spec_from_construct_request(
    construct: ConcreteConstructRequest,
) -> CustomSpecRequest:
    return next(
        (s for s in construct.custom_specs if s.id == construct.original_spec_id)
    )
