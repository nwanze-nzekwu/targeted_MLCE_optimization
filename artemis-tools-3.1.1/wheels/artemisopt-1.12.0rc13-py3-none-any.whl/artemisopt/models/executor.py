"""Implements evaluator related models"""

from __future__ import annotations

from typing_extensions import override

from artemisopt.util.basemodel import ArtemisBaseModel


def sizeof_fmt(num: float, suffix: str = "B") -> str:
    """Formats file sizes"""
    for unit in ["", "Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi"]:
        if abs(num) < 1024.0:
            return f"{num:3.1f}{unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f}Yi{suffix}"


class EvaluationResults(ArtemisBaseModel):
    """Metrics collected for an evaluation run"""

    runtime: float
    cpu_avg: float
    mem_avg: float

    @override
    def __repr__(self):
        return (
            f"Runtime: {self.runtime:.4}s CPU: {self.cpu_avg:.4}% Mem:"
            f" {sizeof_fmt(self.mem_avg)}"
        )


class ExecutionResults(ArtemisBaseModel):
    """Metrics collected for an execution run"""

    status_code: int
    evaluation: EvaluationResults | None = None


class OptimisationChangeDetails(ArtemisBaseModel):
    """Details of a change in the optimisation"""

    title: str
    path: str
    start_line: int
    end_line: int
    message: str = ""
    annotation_level: str


class OptimisationOutputSummary(ArtemisBaseModel):
    """Model for summarized output ready for GitHub"""

    title: str = "Optimisation Summary"
    summary: str
    text: str
    annotations: list[OptimisationChangeDetails]
