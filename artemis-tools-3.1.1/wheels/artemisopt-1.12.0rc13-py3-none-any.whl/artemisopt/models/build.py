from artemisopt.util.basemodel import ArtemisBaseModel


class BuildCommands(ArtemisBaseModel):
    """Specific commands to be used for different functionalities of the build system"""

    build: str | None = None
    unit_test: str | None = None
    perf: str | None = None
    clean: str | None = None
    setup: str | None = None
    custom: str | None = None
