from enum import StrEnum


class OutputMode(StrEnum):
    API = "api"
    LOCAL = "local"
    HYBRID = "hybrid"
