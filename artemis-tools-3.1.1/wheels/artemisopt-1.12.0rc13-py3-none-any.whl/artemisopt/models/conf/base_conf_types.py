"""
This module contains a base configuration class that takes the values of the environment variables and
allows setting different default values to those implemented in the configuration class.
"""

# ────────────────────────────────────────── imports ────────────────────────────────────────── #

from typing import Any, Dict, Type

from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

# ───────────────────────────────────────────────────────────────────────────────────────────── #
#      specifies all modules that shall be loaded and imported into the current namespace       #
#      when us use from package import *                                                        #
# ───────────────────────────────────────────────────────────────────────────────────────────── #

__all__ = ["BaseDefaultConf", "conf_factory"]


# ───────────────────────────────────────────────────────────────────────────────────────────── #
#                               Base Configuration with Defaults                                #
# ───────────────────────────────────────────────────────────────────────────────────────────── #


class CustomDefaultsSource(PydanticBaseSettingsSource):

    def __init__(self, settings_cls: Type[BaseSettings], defaults: Dict[str, Any]):
        super().__init__(settings_cls)
        self.defaults = defaults

    def get_field_value(self, field: Any, field_name: str):
        # Use the default from the 'defaults' dictionary if it exists; otherwise, fall back to the field's default
        return self.defaults.get(field_name), field_name, False

    def __call__(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {}

        for field_name, field in self.settings_cls.model_fields.items():
            field_value, field_key, value_is_complex = self.get_field_value(
                field, field_name
            )
            field_value = self.prepare_field_value(
                field_name, field, field_value, value_is_complex
            )
            if field_value is not None:
                d[field_key] = field_value

        return d


class BaseDefaultConf(BaseSettings):
    """
    Base class for settings, allowing values to be overridden by environment variables.

    Field value priority
        In the case where a value is specified for the same Settings field in multiple ways,
        the selected value is determined as follows (in descending order of priority):
            1. Arguments passed to the Settings class initializer.
            2. Environment variables, e.g. my_prefix_special_function.
            3. Variables loaded from a dotenv (.env) file.
            4. Variables loaded from the secrets directory.
            5. Variables loaded from the 'defaults' argument
            6. The default field values for the Settings model.
    """

    def __init__(self, _env_file: str = ".env", defaults: dict = None, **values):

        # Arguments passed to the Settings class initializer and Environment variables
        super().__init__(_env_file=_env_file, **values)

        # Initialize None attributes with class defaults
        self._update_empty_values()

    def _update_empty_values(self):
        """
        Updating the attributes for which its value has not been indicated through the environment variables.
        """


# ───────────────────────────────────────────────────────────────────────────────────────────── #
#                                     Configuration Factory                                     #
# ───────────────────────────────────────────────────────────────────────────────────────────── #


def conf_factory(
    config_class,
    _env_file: str = ".env",
    prefix: str = None,
    defaults: dict = None,
    **kwargs,
):
    """
    This is a factory generating an 'config_class' class specific to a service, loading every value from a generic
    .env file storing variables in uppercase with a service prefix.

    :param config_class: (Callable[..., BaseModel]) Class type inheriting from BaseModel to instantiate.
    :param _env_file: Configuration file of the environment variables from where to load the values.
    :param prefix: Prefix that the class attributes must have in the environment variables.
    :param defaults: New values to override the default field values for the configuration model.
    :param kwargs: Arguments passed to the Settings class initializer.

    :return: Object of the required configuration class
    """

    class ConfFactory(config_class):
        """Configuration Class Factory"""

        model_config = SettingsConfigDict(
            env_prefix=f"{prefix}_" if prefix else "", extra="ignore"
        )

        @classmethod
        def settings_customise_sources(
            cls,
            settings_cls: Type[BaseSettings],
            init_settings: PydanticBaseSettingsSource,
            env_settings: PydanticBaseSettingsSource,
            dotenv_settings: PydanticBaseSettingsSource,
            file_secret_settings: PydanticBaseSettingsSource,
        ):
            # Add CustomDefaultsSource as the lowest priority source
            return (
                init_settings,
                env_settings,
                dotenv_settings,
                file_secret_settings,
                CustomDefaultsSource(cls, defaults or {}),
            )

    return ConfFactory(_env_file=_env_file, defaults=defaults, **kwargs)
