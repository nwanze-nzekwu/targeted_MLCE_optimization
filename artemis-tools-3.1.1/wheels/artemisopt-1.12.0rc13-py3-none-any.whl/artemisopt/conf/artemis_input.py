"""
Contains input related models
"""

# ────────────────────────────────────────── imports ────────────────────────────────────────── #
# Standard Library
import os
from enum import StrEnum
from pathlib import Path

# 3rd Party
from artemis_tools.models.generic import Language
from falcon_models.api.code_models import ToolExtractionRun
from falcon_models.enums import ValidationFilterTypeEnum
from pydantic import model_validator

from artemisopt.models.build import BuildCommands

# ───────────────────────────────────────────────────────────────────────────────────────────── #
#      specifies all modules that shall be loaded and imported into the current namespace       #
#      when us use from package import *                                                        #
# ───────────────────────────────────────────────────────────────────────────────────────────── #

__all__ = ["ArtemisTaskConfig"]


# ───────────────────────────────────────────────────────────────────────────────────────────── #
#                                       Main implementation                                     #
# ───────────────────────────────────────────────────────────────────────────────────────────── #


class ExtractionType(StrEnum):
    """Type of extraction"""

    TEMPLATE = "template"
    FUNCTION = "function"
    CLASS = "class"
    LLM = "llm"
    FILE = "file"


class ToolTaskConfig(ToolExtractionRun):
    start_date: str | None = None
    end_date: str | None = None


class ArtemisTaskConfig(ToolTaskConfig):
    """Config for extraction mode of Artemis"""

    language: Language | None = None
    git_url: str | None = None
    git_hash: str | None = None
    project_path: Path | None = None
    optimisation_id: str | None = None
    filtering_id: str | None = None
    filter_types: list[ValidationFilterTypeEnum] = [
        ValidationFilterTypeEnum.COMPILATION,
        ValidationFilterTypeEnum.UNIT,
    ]
    filter_run_original: bool = False
    evaluation_repetitions: int = os.getenv("ARTEMIS_EVALUATION_REPETITIONS", 1)
    evaluation_unit_test: bool = False
    validation_id: str | None = None
    extraction_id: str | None = None
    project_id: str | None
    user_id: str | None = None
    build_commands: BuildCommands = BuildCommands()
    llm_type: str | None = None
    llm_filter: str | None = None
    llm_filter_number: int | None = None
    input_file_path: str | None = None
    additional_file_path: str | None = None
    current_branch: str | None = None
    # Extraction config
    extraction_queries: list[str] = []
    include_globs: list[str] = []
    exclude_globs: list[str] = []

    @model_validator(mode="before")
    def check_git_or_path(cls, values):
        """Checks whether a Git URL or a path was provided"""
        if not values.get("validation_id") and not values.get("project_path") and not values.get("git_url"):
            raise ValueError("Either project path or Git URL is required")
        return values
