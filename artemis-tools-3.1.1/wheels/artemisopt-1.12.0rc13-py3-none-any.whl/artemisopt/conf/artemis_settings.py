"""
This module defines the file directory structure
"""

import os

# ────────────────────────────────────────── imports ────────────────────────────────────────── #
import re
from pathlib import Path
from re import Pattern
from typing import TYPE_CHECKING, Optional
from uuid import UUID

from loguru import logger
from pydantic import PrivateAttr
from rich.console import Console

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.models.conf.base_conf_types import BaseDefaultConf, conf_factory
from artemisopt.models.conf.output import OutputMode

# ───────────────────────────────────────────────────────────────────────────────────────────── #
#      specifies all modules that shall be loaded and imported into the current namespace       #
#      when us use from package import *                                                        #
# ───────────────────────────────────────────────────────────────────────────────────────────── #

SEMVER_REGEX = re.compile(
    r"^([0-9]+)\.([0-9]+)\.([0-9]+)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+)?$"
)
__all__ = ["ArtemisSettings", "artemis_input_conf_factory"]


# ───────────────────────────────────────────────────────────────────────────────────────────── #
#                                      Data Configuration                                       #
# ───────────────────────────────────────────────────────────────────────────────────────────── #


def init_rich_console():
    return Console()


class ArtemisSettings(BaseDefaultConf):
    """
    Configuration class of a Data.
    """

    input_path: Path = Path("input")
    output_path: Path = Path("output")
    hardware_id: Optional[UUID] = None
    clang_include_path: Path | None = None
    clang_tool_path: Path | None = None
    copy_project_to_output: bool = True
    openai_api_key: str | None = None
    delete_mutated: bool = False
    incremental_build: bool = True
    filter_keywords: list[str] = [
        "test",
        "example",
        "sample",
        "demo",
        "cmake",
        "3rdparty",
        "deps",
        "bench",
        "perf",
        "external_libs",
        "CMakeFiles",
        "third_party",
    ]
    resources_folder: Path = Path(__file__).parents[1] / "resources"
    _filter_regex: Pattern = PrivateAttr(None)
    population_size: int = 10  # Number of solutions in each generation
    generation_size: int = 100  # Number of generations
    ram_limit_mb: int = 3072
    command_output_chunk_size_bytes: int = 512 * 1024  # 512KB
    debug_mode: bool = False
    _console: Console = PrivateAttr(default_factory=init_rich_console)
    extended_output: bool = False
    output_mode: OutputMode = OutputMode.LOCAL
    filtering_enabled: bool = False
    artemis_task: ArtemisTaskConfig | None = None
    run_threads: int = max(int(os.cpu_count() * 3 / 4), 1)
    run_vtune: bool = False

    @property
    def clang_executable(self):
        return (
            self.clang_tool_path or self.resources_folder / "cpp" / "clang-statements"
        )

    @property
    def build_dir(self):
        return self.output_path / "build"

    @property
    def build_backup_dir(self):
        return self.output_path / "build_dir_backup"

    @property
    def filter_regex(self):
        self._filter_regex = self._filter_regex or re.compile(
            "|".join(self.filter_keywords)
        )
        return self._filter_regex

    @classmethod
    def find_clang_path(cls) -> Path:
        """Auto Clang if it exists in PATH"""
        paths = ["/usr/local/lib", "/usr/lib", "/lib", "/opt/conda/lib"]
        for path_entry in paths:
            possible_path = Path(path_entry) / "clang"
            if possible_path.exists() and possible_path.is_dir():
                for subfolder in possible_path.iterdir():
                    if subfolder.is_dir():
                        clang_include_path = subfolder / "include"
                        if clang_include_path.exists():
                            logger.info(
                                f"Detected clang automatically! {clang_include_path}"
                            )
                            return clang_include_path

        raise Exception(
            "Could not detect clang automatically! Please specify path in config!"
        )

    def _update_empty_values(self):
        """
        Updating the attributes for which its value has not been indicated through the environment variables.
        """
        # if not self.clang_include_path:
        #     self.clang_include_path = self.find_clang_path()

        self._resolve_paths()

    def _resolve_paths(self):
        """
        Resolve full path of all Path attributes
        """
        for field in self.__fields__:
            value = self.__getattribute__(field)
            if isinstance(value, Path):
                self.__setattr__(field, Path(value).resolve() if value else None)


# ───────────────────────────────────────────────────────────────────────────────────────────── #
#                                  Data Configuration Factory                                   #
# ───────────────────────────────────────────────────────────────────────────────────────────── #


def artemis_input_conf_factory(
    _env_file: str = ".env", prefix: str = None, defaults: dict = None, **kwargs
) -> ArtemisSettings:
    """
    This is a factory generating an DataConf class specific to a service, loading every value from a generic
    .env file storing variables in uppercase with a service prefix.

    example .env:
       PREFIX_DATA_PATH=/tmp/data
       ...
    """
    return conf_factory(
        config_class=ArtemisSettings,
        _env_file=_env_file,
        prefix=prefix,
        defaults=defaults,
        **kwargs,
    )
