"""
This module implements and instantiates the common configuration class used in the project.
"""

# ────────────────────────────────────────── imports ────────────────────────────────────────── #
import sys
import tempfile
from logging import Handler
from pathlib import Path
from typing import Dict

from loguru import logger

from artemisopt.conf.artemis_settings import ArtemisSettings, artemis_input_conf_factory
from artemisopt.conf.logger_conf import FileLoggerConf, file_logger_conf_factory

# ───────────────────────────────────────────────────────────────────────────────────────────── #
#      specifies all modules that shall be loaded and imported into the current namespace       #
#      when us use from package import *                                                        #
# ───────────────────────────────────────────────────────────────────────────────────────────── #

__all__ = ["conf_mgr"]


# ───────────────────────────────────────────────────────────────────────────────────────────── #
#                                     Configuration Manager                                     #
# ───────────────────────────────────────────────────────────────────────────────────────────── #


class InterceptHandler(Handler):
    def emit(self, record):
        logger_opt = logger.opt(depth=6, exception=record.exc_info)
        logger_opt.log(record.levelname, record.getMessage())


class ConfManager:
    """Configuration Manager class"""

    # APP paths
    conf_path: Path = Path(__file__).parent.resolve()  # conf package
    artemis_path: Path = conf_path.parent.resolve()  # artemis package
    resources_path: Path = conf_path.parent.resolve() / "resources"  # artemis package
    root_path: Path = artemis_path.parent  # project
    tmp_directory: Path = Path(tempfile.gettempdir()).joinpath("artemis")

    # APP environment file
    _path_env_file: Path = None
    _env_file: str = None

    # The Data Configurations object
    _artemis_settings: ArtemisSettings = None
    default_artemis_settings: Dict = dict(
        input_path=root_path / "input", output_path=root_path / "output"
    )

    # -------------------------------------------------------------------------------------------------

    def __init__(self, env_file: str or Path = None):
        if env_file:
            self.update_conf_mgr(env_file=env_file)

        logger.info("Configuration Manager initialized")

    # -------------------------------------------------------------------------------------------------

    @property
    def rich_console(self):
        return self.artemis_settings._console

    @property
    def env_file(self) -> str:
        """
        Environment configuration file used in the current configuration
        """
        return self._env_file

    def update_conf_mgr(self, env_file: str):
        """
        Update all the configuration by loading the environment variables from the indicated file.
        """
        self._path_env_file = Path(env_file)
        self._env_file = (
            str(self._path_env_file) if self._path_env_file.exists() else None
        )

        if not self._path_env_file.exists():
            print(f"[WARNING] environment file does not exist: {env_file}")
            return

    # -------------------------------------------------------------------------------------------------

    def update_artemis_settings(self, _env_file: str = None, defaults: dict = None):
        """
        Update all the configuration by loading the environment variables from the indicated file.
        """
        factory_args = dict(
            _env_file=_env_file or self._env_file,
            prefix="ARTEMIS",
            defaults=defaults or self.default_artemis_settings,
        )

        self._artemis_settings = artemis_input_conf_factory(**factory_args)

    @property
    def artemis_settings(self) -> ArtemisSettings:
        """Basic settings for Artemis"""
        if not self._artemis_settings:
            self.update_artemis_settings()
        return self._artemis_settings


# ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
# ─── ConfManager instance
# ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

conf_mgr = ConfManager(".env")
