import re
import traceback
from urllib.parse import quote
from uuid import uuid4

from git import Repo
from loguru import logger

from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.optimiser.engine.models import OptimisationSolution
from artemisopt.optimiser.engine.utils import find_original_solution


def get_repo_name(url: str) -> str | None:
    """Gets repo name from url"""
    m = re.match(
        r"((git|ssh|http(s)?)|(git@[\w\.]+))(:(//)?)(?P<repo>[\w\.@\:/\-~]+)(\.git)(/)?",
        url,
    )
    return m.group("repo") if m else None


def create_results_pr(results: list[OptimisationSolution]) -> None:
    """Create a branch on git and prints a link to create a PR"""
    results = [r for r in results if r.solution.objectives]
    if len(results) > 0:
        try:
            repo = Repo(
                conf_mgr.artemis_settings.output_path
                / "mutated"
                / results[0].solution.trial_id
            )
            repo.config_writer().set_value("user", "name", "Turintech Bot").release()
            repo.config_writer().set_value(
                "user", "email", "bot@turintech.ai"
            ).release()
            git = repo.git
            branch = f"artemis-{uuid4()}"
            original_branch = repo.active_branch.name
            git.checkout(b=branch)
            git.add("-u")
            if len(repo.index.diff(repo.head.commit)) > 0:
                git.commit(m="artemis: Proposed changes for increased performance")
                git.push(f"-u", "origin", branch)
                logger.info(f"Branch {branch} was pushed to {repo.remotes.origin.url}.")
                if "github.com" in repo.remotes.origin.url:
                    og_solution = find_original_solution(results)
                    repo_name = get_repo_name(repo.remotes.origin.url)
                    url = (
                        "You can create A PR on"
                        f" https://github.com/{repo_name}/compare/{original_branch}...{branch}"
                    )
                    if og_solution is not None:
                        url += (
                            f"?body={quote(results[0].compare_to_other(og_solution))}"
                        )
                    logger.info(url)
            else:
                logger.info("Original branch had the optimal performance.")
        except Exception as e:
            logger.error("Failed to create PR")
            logger.error(traceback.format_exc())
