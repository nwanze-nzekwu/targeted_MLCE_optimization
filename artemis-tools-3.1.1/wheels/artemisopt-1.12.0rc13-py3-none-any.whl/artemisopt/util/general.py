"""Basic Pydantic configuration for Artemis models"""

import json
from contextlib import contextmanager
from logging import Logger
from pathlib import Path
from typing import TYPE_CHECKING, Any, Generator, Iterable, TextIO
from uuid import UUID

import orjson
import psutil
from falcon_models.api import LogAdditionRequest
from loguru import logger
from artemisopt.conf.conf_manager import conf_mgr
import loguru
from pydantic.json import pydantic_encoder

if TYPE_CHECKING:
    from loguru import Message, Record


def orjson_dumps(v, *, default=pydantic_encoder):
    """Dumps using orjson. Used to customise encoding arguments."""
    return orjson.dumps(
        v,
        default=default,
        option=orjson.OPT_SERIALIZE_UUID
        | orjson.OPT_NON_STR_KEYS
        | orjson.OPT_INDENT_2
        | orjson.OPT_SERIALIZE_UUID,
    ).decode()


def log_formatter(record: "Record"):
    record["extra"]["serialised"] = json.dumps(
        {
            "level": record["level"].name.lower(),
            "message": record["message"],
            "timestamp": record["time"].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        }
    )
    return "{extra[serialised]}\n"


class FalconHandler:
    def __init__(self, log_id: UUID):
        from artemisopt.util.output import OutputManager

        self.falcon_client = OutputManager.falcon_client()
        self.log_id = str(log_id)

    def write(self, message: "Message") -> None:
        try:
            self.falcon_client.post_log(
                self.log_id,
                LogAdditionRequest(
                    message=message.record["message"],
                    level=message.record["level"].name.lower(),
                    timestamp=message.record["time"],
                ),
            )
        except BaseException:
            # Retrying to send log
            try:
                self.falcon_client.post_log(
                    self.log_id,
                    LogAdditionRequest(
                        message=message.record["message"],
                        level=message.record["level"].name.lower(),
                        timestamp=message.record["time"],
                    ),
                )
            except BaseException:
                ...


@contextmanager
def loguru_falcon_wrapper(log_id: UUID, level: str = "TRACE"):
    handler_id = None
    try:
        handler_id = logger.add(
            sink=FalconHandler(log_id),
            level=level,
            format=log_formatter,
            enqueue=True,
        )
        yield
    finally:
        if handler_id is not None:
            logger.remove(handler_id)


@contextmanager
def loguru_file_wrapper(sink: Any, level: str = "TRACE"):
    handler_id = None
    try:
        add_kwargs = {"level": level}
        # if sink is a filename or pathlib.Path, Loguru will open it with encoding
        if isinstance(sink, (str, Path)):
            add_kwargs["encoding"] = "utf-8"

        handler_id = logger.add(sink, **add_kwargs)
        yield
    finally:
        if handler_id is not None:
            logger.remove(handler_id)


def pipe_process_logs_in_chunks(
    pipe: TextIO, proc: psutil.Popen, console_logger: Logger, chunk_size: int = 1024
):
    """
    Reads the stdout of a process in binary chunks, decodes the data,
    and logs complete log entries to both a file and a console logger.
    Incomplete log text is buffered until additional data completes the token.

    Works on both Windows and Unix-based platforms with platform-specific optimizations.
    """
    import os
    import platform
    import re
    import sys

    # Check if we're on Windows for platform-specific optimizations
    is_windows = platform.system() == "Windows"

    def find_last_complete_token(decoded_text: str) -> int:
        """
        Return the index up to which the text contains complete tokens.
        A token is considered incomplete if it ends exactly at the end of the string
        and is not terminated by a whitespace.
        """
        tokens = list(re.finditer(r"\S+\s*", decoded_text))
        last_index = 0
        for match in tokens:
            # If the token ends at the end of the text and the text doesn't end with a space,
            # assume it's incomplete.
            if match.end() == len(decoded_text) and not decoded_text[-1].isspace():
                break
            last_index = match.end()
        return last_index

    def log_text(text: str):
        """Logs the provided text to the console, file pipe, and optionally stdout."""
        if text:
            # Strip trailing whitespace for console logger
            text_to_log = text.rstrip()
            console_logger.info(text_to_log)
            # Write to file pipe (preserving newlines)
            pipe.write(text)
            pipe.flush()
            # On Windows, also write directly to stdout for immediate visibility
            if is_windows:
                sys.stdout.write(text)
                sys.stdout.flush()

    def log_error(error_phase: str, e: Exception):
        """Centralized error logging for different phases of pipe reading"""
        error_msg = f"{error_phase} error: {str(e)}\n"
        console_logger.error(error_msg)
        pipe.write(error_msg)
        pipe.flush()
        # On Windows, also write directly to stdout
        if is_windows:
            sys.stdout.write(error_msg)
            sys.stdout.flush()

    # Main pipe reading loop
    try:
        stdout_fd = proc.stdout.fileno()
        buffer = b""

        while True:
            try:
                # Read a chunk from the process stdout
                chunk = os.read(stdout_fd, chunk_size)
                # If no chunk is read and the process has terminated, break the loop
                if not chunk and proc.poll() is not None:
                    break

                if chunk:
                    buffer += chunk

                # Try to decode the buffer
                try:
                    decoded = buffer.decode("utf-8")
                except UnicodeDecodeError:
                    # If the buffer cannot be decoded yet, wait for more data
                    continue

                # Find the last complete token in the decoded text
                last_complete_index = find_last_complete_token(decoded)
                complete_text = decoded[:last_complete_index]
                if complete_text:
                    log_text(complete_text)

                # Keep the incomplete remainder in the buffer for the next iteration
                buffer = decoded[last_complete_index:].encode("utf-8")
            except Exception as e:
                # Log any errors in the pipe reading process
                log_error("Pipe read", e)
                break
    except Exception as e:
        # Handle setup errors
        log_error("Pipe setup", e)

    # After the loop ends (i.e. process terminated), flush any remaining text
    if buffer:
        try:
            remaining = buffer.decode("utf-8", errors="replace")
            log_text(remaining)
        except Exception as e:
            # Handle cleanup errors
            log_error("Pipe cleanup", e)


def send_command_output_logs(
    command_output_log_file: Path,
    file_logger: loguru._Logger,
    prefix: str = "",
    suffix: str = "",
):
    """
    Sends command output logs to the file logger.
    We need to chunk the logs as TTM reads the file and sends the logs to Loki.

    Logs are split into chunks of approximately 0.5MB to optimize processing.
    Handles cases where individual lines may exceed the maximum chunk size.

    Uses break_long_lines to handle lines exceeding the maximum size and
    chunk_log_file to group lines into appropriately sized chunks.

    Future Optimisations: don't read entire command output into memory.
    """

    MAX_CHUNK_SIZE = conf_mgr.artemis_settings.command_output_chunk_size_bytes

    file_logger.debug(prefix)

    with command_output_log_file.open("r", encoding="utf-8") as log_file:

        # Lazily read the log file line by line
        lines = (line for line in log_file)

        # First break any long lines that exceed the maximum chunk size
        broken_lines = break_long_lines(lines, MAX_CHUNK_SIZE)

        # Then chunk the lines to not exceed the maximum chunk size
        for chunk in chunk_log_file(broken_lines, MAX_CHUNK_SIZE):
            chunk_message = "\n".join(chunk)
            file_logger.debug(chunk_message)

    file_logger.debug(suffix)


def chunk_log_file(
    log_lines: Iterable[str], bytes_per_chunk: int = 512 * 1024
) -> Generator[list[str], None, None]:
    """
    Processes an iterable of log lines, chunking them so each chunk doesn't exceed bytes_per_chunk.
    Yields chunks of lines where the total byte size is approximately bytes_per_chunk.

    Args:
        log_lines: An iterable of strings (e.g., lines from a log file)
        bytes_per_chunk: Maximum size in bytes for each chunk

    Yields:
        Lists of strings, where each list's total byte size is approximately bytes_per_chunk
    """

    current_chunk = []
    current_size = 0

    for line in log_lines:
        # Calculate the size of this line in bytes
        line_size = len(line.encode("utf-8"))

        # If adding this line would exceed the chunk size and we already have lines,
        # yield the current chunk and start a new one
        if current_size + line_size > bytes_per_chunk and current_chunk:
            yield current_chunk
            current_chunk = []
            current_size = 0

        # Add the line to the current chunk
        current_chunk.append(line)
        current_size += line_size

    # Yield any remaining lines in the last chunk
    if current_chunk:
        yield current_chunk


def break_long_lines(
    log_lines: Iterable[str], bytes_per_line: int = 512 * 1024
) -> Generator[str, None, None]:
    """
    Processes an iterator of log lines, breaking up lines that exceed bytes_per_line.

    Args:
        log_lines: An iterator of strings (e.g., lines from a log file)
        bytes_per_line: Maximum size in bytes for each line segment

    Yields:
        String chunks, either complete lines or parts of lines that don't exceed bytes_per_line
    """
    for line in log_lines:
        # Calculate the size of this line in bytes
        line_bytes = line.encode("utf-8")
        line_size = len(line_bytes)

        # If the line is smaller than the chunk size, yield it as is
        if line_size <= bytes_per_line:
            yield line
        else:
            # Break up the line into chunks of bytes_per_chunk
            for i in range(0, line_size, bytes_per_line):
                # Extract a chunk of the line (up to bytes_per_chunk bytes)
                chunk_bytes = line_bytes[i : i + bytes_per_line]
                # Decode the chunk back to string and yield it
                chunk_str = chunk_bytes.decode("utf-8", errors="replace")
                yield chunk_str
