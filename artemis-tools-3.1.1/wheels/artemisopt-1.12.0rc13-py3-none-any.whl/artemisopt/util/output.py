import typing
from datetime import datetime
from io import BytesIO
from pathlib import Path
from uuid import UUID

from artemis_client.auth.thor_client import AuthThorClient
from artemis_client.falcon.client import FalconClient, FalconSettings
from evoml_services.clients.thanos.client import ThanosSettings
from evoml_services.clients.thor import ThorClient, ThorSettings
from falcon_models import LogAdditionRequest
from falcon_models.api.code_models import (
    ConcreteConstructBatchRequest,
    ConcreteConstructRequest,
    ConcreteConstructResponse,
    ExtractionRunFilterParamsRequestResponse,
    FullSolutionInfoRequest,
    GenericConstructFilterRequestResponse,
    PaginatedConstructFilterRequest,
    SolutionResultsRequest,
    SolutionResultsResponseBase,
    SolutionSpecResponseBase,
)
from falcon_models.enums import FilterTypeEnum, SolutionStatusEnum, ValidationFilterTypeEnum
from loguru import logger
from optuna import Trial

from artemisopt.compilation.build import BuildSystem
from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.models.conf.output import OutputMode
from artemisopt.optimiser.engine.models import SolutionDetails


class OutputManager:

    _falcon_client: FalconClient | None = None
    _thor_client: ThorClient | None = None

    @classmethod
    def falcon_client(cls) -> FalconClient:
        if cls._falcon_client is None:
            falcon_settings = FalconSettings.with_env_prefix(
                "falcon",
                _env_file=conf_mgr.root_path / ".env",
            )
            thanos_settings = ThanosSettings.with_env_prefix(
                "thanos", _env_file=conf_mgr.root_path / ".env"
            )
            cls._falcon_client = FalconClient(falcon_settings, thanos_settings)
        return cls._falcon_client

    @classmethod
    def thor_client(cls) -> ThorClient:
        if cls._thor_client is None:
            thor_settings = ThorSettings.with_env_prefix(
                "thor",
                _env_file=conf_mgr.root_path / ".env",
            )
            cls._thor_client = AuthThorClient(thor_settings)
        return cls._thor_client

    @classmethod
    def populate_commands(cls, input_config: ArtemisTaskConfig):
        assert conf_mgr.artemis_settings.artemis_task is not None
        if (
            conf_mgr.artemis_settings.output_mode in [OutputMode.HYBRID, OutputMode.API]
            and conf_mgr.artemis_settings.artemis_task.project_id
        ):
            build_system = BuildSystem(input_config)
            new_commands: dict[str, typing.Any] = {}
            if build_system and build_system.language is not None:
                if not input_config.build_commands.build and build_system.build_command:
                    new_commands["compileCommand"] = build_system.build_command
                if (
                    not input_config.build_commands.unit_test
                    and build_system.unit_test_command
                ):
                    new_commands["unitTestCommand"] = build_system.unit_test_command
                if (
                    not input_config.build_commands.perf
                    and build_system.perf_test_command
                ):
                    new_commands["perfCommand"] = build_system.perf_test_command
                if not input_config.build_commands.clean and build_system.clean_command:
                    new_commands["cleanCommand"] = build_system.clean_command
                if new_commands:
                    cls.falcon_client().patch_project(
                        project_id=conf_mgr.artemis_settings.artemis_task.project_id,
                        updated_info=new_commands,
                    )

    @classmethod
    def save_project_repo(cls, original_repo: Path):
        assert conf_mgr.artemis_settings.artemis_task is not None
        if conf_mgr.artemis_settings.output_mode in [OutputMode.HYBRID, OutputMode.API]:
            if conf_mgr.artemis_settings.artemis_task.project_id:
                logger.info("Saving repo archive")
                repo_archive = cls.thor_client().upload_folder(original_repo)
                cls.falcon_client().patch_project(
                    project_id=conf_mgr.artemis_settings.artemis_task.project_id,
                    updated_info={"fileId": repo_archive.id},
                )
                logger.info(f"Project archive {repo_archive.id} added to database")

    @classmethod
    def verify_spec(
        cls,
        construct_id: str | None,
        spec_id: str | None,
        type: ValidationFilterTypeEnum,
        passed: bool,
        logs: str | None = None,
        log_file_id: str | None = None,
        cpu: float | None = None,
        memory: float | None = None,
        runtime: float | None = None,
    ):
        assert conf_mgr.artemis_settings.artemis_task is not None
        assert conf_mgr.artemis_settings.artemis_task.project_id is not None

        if (
            conf_mgr.artemis_settings.output_mode in [OutputMode.HYBRID, OutputMode.API]
            and conf_mgr.artemis_settings.artemis_task.filtering_id
        ):
            if log_file_id is None:
                if logs is not None:
                    log_file_id = (
                        cls.thor_client()
                        .upload_simple_file(("artemis_log.txt", BytesIO(logs.encode())))
                        .id
                    )
                else:
                    raise ValueError("Could not infer `log_file_id`!")
            cls.falcon_client().verify_construct(
                project_id=conf_mgr.artemis_settings.artemis_task.project_id,
                filtering_id=conf_mgr.artemis_settings.artemis_task.filtering_id,
                construct_id=construct_id,
                spec_id=spec_id,
                filter_type=type,
                passed=passed,
                logs=log_file_id,
                cpu=cpu,
                memory=memory,
                runtime=runtime,
            )
            return log_file_id

    @classmethod
    def get_new_log_id(cls):
        return cls.falcon_client().create_log_group().id

    @classmethod
    def save_logs_in_falcon(cls, log: str, log_id: str):
        assert conf_mgr.artemis_settings.artemis_task is not None
        if conf_mgr.artemis_settings.output_mode in [OutputMode.HYBRID, OutputMode.API]:
            cls.falcon_client().post_log(
                log_id=log_id, log_addition=LogAdditionRequest(message=log, level="info", timestamp=datetime.now())
            )

    @classmethod
    def save_solution(cls, sol: SolutionDetails):
        if conf_mgr.artemis_settings.output_mode in [
            OutputMode.HYBRID,
            OutputMode.LOCAL,
        ]:
            solutions_path = conf_mgr.artemis_settings.output_path / "solutions"
            if not solutions_path.exists():
                solutions_path.mkdir(exist_ok=True)
            with open(solutions_path / f"{sol.trial_id}.json", "w") as f:
                f.write(sol.model_dump_json())

    @classmethod
    def create_solution(cls, sol: SolutionDetails) -> str | None:
        assert conf_mgr.artemis_settings.artemis_task is not None
        if (
            conf_mgr.artemis_settings.output_mode in [OutputMode.HYBRID, OutputMode.API]
            and conf_mgr.artemis_settings.artemis_task.optimisation_id
        ):
            sol_info = FullSolutionInfoRequest(
                number=int(sol.trial_id),
                specs=[
                    SolutionSpecResponseBase(
                        spec_id=UUID(param.parameterValue),
                    )
                    for param in sol.parameters
                ],
                status=SolutionStatusEnum.running,
                log_file_id=str(sol.log_id) if sol.log_id is not None else None,
                hardware_id=sol.hardware_id,
            )

            logger.info(f"Saving solution {sol_info.number} to database")
            assert conf_mgr.artemis_settings.artemis_task.project_id is not None
            response = cls.falcon_client().add_solution(
                conf_mgr.artemis_settings.artemis_task.project_id,
                conf_mgr.artemis_settings.artemis_task.optimisation_id,
                sol_info,
            )
            logger.info(
                f"Solution {sol_info.number} added to database", sol_info.number
            )
            return response["id"]

    @classmethod
    def add_solution_results(cls, trial: Trial) -> None:
        if trial.user_attrs.get("sol_id"):
            results = {}
            if trial.user_attrs.get("log"):
                log_file = ("log.txt", BytesIO(trial.user_attrs["log"].encode()))
                results["log_file_id"] = (
                    OutputManager.thor_client().upload_simple_file(log_file).id
                )
            if trial.user_attrs.get("full_results"):
                # TODO: use internal solution results model and adapt to this one
                results["results"] = SolutionResultsResponseBase.model_validate(
                    trial.user_attrs.get("full_results")
                )
            results["status"] = trial.user_attrs.get("status", "pending")
            results = SolutionResultsRequest.model_validate(results)
            cls.falcon_client().add_solution_results(
                trial.user_attrs["sol_id"], results
            )

    @classmethod
    def add_construct(
        cls, constructs: list[ConcreteConstructRequest]
    ) -> list[ConcreteConstructResponse]:
        assert conf_mgr.artemis_settings.artemis_task is not None
        assert conf_mgr.artemis_settings.artemis_task.project_id is not None

        if (
            conf_mgr.artemis_settings.output_mode in [OutputMode.HYBRID, OutputMode.API]
            and conf_mgr.artemis_settings.artemis_task.extraction_id
        ):
            return (
                cls.falcon_client()
                .add_constructs(
                    conf_mgr.artemis_settings.artemis_task.project_id,
                    conf_mgr.artemis_settings.artemis_task.extraction_id,
                    ConcreteConstructBatchRequest(constructs=constructs),
                )
                .constructs
            )
        return []

    @classmethod
    def calculate_extracted_constructs_and_patch_extraction(cls, nr_detected: int):
        if (
            conf_mgr.artemis_settings.output_mode in [OutputMode.HYBRID, OutputMode.API]
            and conf_mgr.artemis_settings.artemis_task is not None
            and conf_mgr.artemis_settings.artemis_task.extraction_id
            and conf_mgr.artemis_settings.artemis_task.project_id
        ):
            # get nr of constructs extracted from this extraction id (that made it to the db
            falcon_client = OutputManager.falcon_client()
            extraction_id = conf_mgr.artemis_settings.artemis_task.extraction_id
            nr_extracted = falcon_client.get_constructs(
                project_id=str(conf_mgr.artemis_settings.artemis_task.project_id),
                filters=PaginatedConstructFilterRequest(
                    page=1,
                    per_page=1,
                    filters=[
                        GenericConstructFilterRequestResponse(
                            type=FilterTypeEnum.extraction,
                            params=ExtractionRunFilterParamsRequestResponse(
                                extraction_ids=[UUID(extraction_id)]
                            ),
                        )
                    ],
                ),
            ).total_docs
            logger.info(f"Extracted {nr_extracted} code snippets out of {nr_detected}")
            # we can patch the extraction run now
            falcon_client.patch_extraction(
                extraction_id=str(extraction_id),
                updated_info={
                    "numOfConstructsDetected": nr_detected,
                    "numOfConstructsExtracted": nr_extracted,
                },
            )
