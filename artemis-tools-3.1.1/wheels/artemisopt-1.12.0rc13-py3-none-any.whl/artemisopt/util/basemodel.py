from typing import Any, Callable
from uuid import UUID

import orjson
from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_pascal
from pydantic.json import pydantic_encoder
from typing_extensions import override


def orjson_dumps(v: Any, *, default: Callable[[Any], Any] = pydantic_encoder):
    """Dumps using orjson. Used to customise encoding arguments."""
    return orjson.dumps(
        v,
        default=default,
        option=orjson.OPT_SERIALIZE_UUID
        | orjson.OPT_NON_STR_KEYS
        | orjson.OPT_INDENT_2
        | orjson.OPT_SERIALIZE_UUID,
    ).decode()


def to_lower_camel(value: str) -> str:
    # Helper function to convert to lower camel case
    camel_value = to_pascal(value)
    return camel_value[0].lower() + camel_value[1:] if camel_value else camel_value


class ArtemisBaseModel(BaseModel):
    """
    Base Model with enabled alias.
    Whether an aliased field may be populated by its name as given by the model attribute, as well as the alias
    """

    @override
    def dict(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        """Generates dict for model."""
        if kwargs and kwargs.get("exclude_none") is not None:
            kwargs["exclude_none"] = True
        return BaseModel.dict(self, *args, **kwargs)

    def dict_alias(self, *args: Any, **kwargs: Any):
        """Generate a dictionary representation of the model with field alias as keys"""
        return self.dict(by_alias=True, *args, **kwargs)

    model_config = ConfigDict(
        alias_generator=to_lower_camel,
        # Convert snake_case to camelCase for JSON serialization
        populate_by_name=True,
        # Allows setting values by both the original name and the alias
        arbitrary_types_allowed=True,  # Allows arbitrary (non-Pydantic) types
        protected_namespaces=(),
    )
