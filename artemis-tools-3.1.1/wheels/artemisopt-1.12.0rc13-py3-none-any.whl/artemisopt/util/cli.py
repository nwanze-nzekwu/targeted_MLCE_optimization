import json
import sys
from contextlib import contextmanager
from pathlib import Path

import optuna
from loguru import logger
from optuna import Study
from optuna.trial import TrialState
from rich.ansi import AnsiDecoder
from rich.console import Group, Console
from rich.jupyter import JupyterMixin
from rich.live import Live
from rich.logging import RichHandler
from typing import List

from rich.markup import escape
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TaskID
import plotext as plt
from rich.table import Table

from artemisopt.conf.conf_manager import conf_mgr

plt.interactive(False)

from artemisopt.execution import METRICS


class TrialPlotMixin(JupyterMixin):
    def make_plot(self):
        """Graph performed trials on terminal"""
        plt.main()
        plt.clf()
        plt.cld()
        plt.subplots(len(self.metrics), 1)
        if self.width and self.height:
            plt.plot_size(self.width * 0.95, self.height * 0.8)
        plt.theme("pro")

        data = [list() for _ in self.metrics]
        for trial in self.study.trials:
            if trial.values is not None:
                for i, value in enumerate(trial.values):
                    data[i].append(value)

        for i, metric in enumerate(self.metrics):
            plt.subplot(i + 1, 1)
            plt.bar(data[i], marker="hd")
            plt.xticks(
                range(len(data[i])),
                [f"Version {num}" for num in range(0, len(data[i]) + 1)],
            )
            plt.xlabel("Version Number")
            plt.ylabel(metric)

        try:
            res = plt.build()
            return res
        except:
            ...

    def __init__(self, study: Study, metrics: List[str], title=""):
        self.decoder = AnsiDecoder()
        self.study = study
        self.metrics = metrics
        self.title = title
        self.canvas = ""
        self.height = None
        self.width = None

    def update_plot(self, study: Study, metrics: List[str]):
        self.study = study
        self.metrics = metrics
        self.make_canvas()

    def make_canvas(self):
        if self.study and self.metrics:
            canvas = self.make_plot() or ""
            self.canvas = Group(*self.decoder.decode(canvas))

    def __rich_console__(self, console, options):
        self.width = options.max_width or console.width
        self.height = options.height or console.height
        self.make_canvas()
        yield self.canvas


class TaskDisplay:
    total_jobs: int = 0
    job_progress: Progress
    overall_task: Progress
    live: Live
    study: Study = None
    metrics: List[str] = None

    def __init__(self, total_jobs: int = 1, console: Console = None):
        self.total_jobs = total_jobs
        self.overall_progress = Progress(
            SpinnerColumn(finished_text="✓"),
            TextColumn("[progress.description]{task.description}"),
        )
        self.plot = TrialPlotMixin(self.study, self.metrics)

        self.job_progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
        )
        # overall_task = self.overall_progress.add_task("All Jobs", total=total_jobs)

        self.overall_panel = Panel.fit(
            self.overall_progress,
            title="Overall Progress",
            border_style="green",
            padding=(2, 2),
        )
        self.progress_panel = None

        self.live = Live(self.make_layout(), auto_refresh=False, console=console)

    def make_layout(self):
        new_table = Table.grid()
        row_contents = [self.overall_panel, self.progress_panel]
        new_table.add_row(*[content for content in row_contents if content is not None])
        return new_table

    def update(self):
        self.live.update(self.make_layout(), refresh=True)

    def new_task(self, task_name: str) -> TaskID:
        return self.overall_progress.add_task(description=task_name)

    def finish_task(self, task_id: TaskID):
        self.overall_progress.update(task_id, completed=1, total=1)

    def update_trial_data(self, study: Study, metrics: List[str]):
        if self.progress_panel == None:
            self.progress_panel = Panel(
                self.plot, title="[b]Details", border_style="red", padding=(1, 2)
            )
        self.plot.update_plot(study, metrics)
        self.update()


if conf_mgr.artemis_settings.extended_output:
    task_display = TaskDisplay(console=conf_mgr.rich_console)


class TrialPlotCallback:
    def __init__(self): ...

    def __call__(
        self, study: optuna.study.Study, trial: optuna.trial.FrozenTrial
    ) -> None:
        if (
            trial.state == TrialState.COMPLETE
            and conf_mgr.artemis_settings.extended_output
        ):
            task_display.update_trial_data(study, METRICS)


@contextmanager
def display_task(task_name: str):
    if conf_mgr.artemis_settings.extended_output:
        task_id = task_display.new_task(task_name)
    yield
    if conf_mgr.artemis_settings.extended_output:
        task_display.finish_task(task_id)


def rich_formatter(record):
    record["extra"]["rich_safe"] = escape(record["message"])
    return "[red]{function}[/red] {extra[rich_safe]}"


def file_log_formatter(record):
    level = record["level"].name.lower()
    if level == "trace":
        level = "debug"
    record["extra"]["serialised"] = json.dumps(
        {
            "level": level,
            "message": record["message"],
            "timestamp": record["time"].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        }
    )
    return "{extra[serialised]}\n"


def configure_logger(level="DEBUG", log_path=None, override_existing: bool = False):
    from artemisopt.conf.conf_manager import conf_mgr

    if override_existing:
        logger.remove()
        if conf_mgr.artemis_settings.extended_output:
            logger.configure(
                handlers=[
                    {
                        "sink": RichHandler(
                            markup=True,
                            console=conf_mgr.rich_console,
                            locals_max_string=None,
                            locals_max_length=None,
                        ),
                        "format": rich_formatter,
                        "level": level,
                    }
                ]
            )
        else:
            logger.add(sys.stderr, level=level)
    if log_path is not None:
        log_path = Path(log_path)
        if not log_path.exists():
            log_path.touch()
        logger.add(log_path, format=file_log_formatter, mode="w", level="TRACE", encoding="utf-8")
