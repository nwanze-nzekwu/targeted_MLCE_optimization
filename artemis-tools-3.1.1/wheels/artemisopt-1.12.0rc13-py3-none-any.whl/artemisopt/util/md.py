from pytablewriter import MarkdownTableWriter


def create_md_table(headers: list[str], rows: list[list[str]]) -> str:
    writer = MarkdownTableWriter(
        headers=headers, value_matrix=rows, flavour="gfm", max_precision=3
    )
    return writer.dumps()
