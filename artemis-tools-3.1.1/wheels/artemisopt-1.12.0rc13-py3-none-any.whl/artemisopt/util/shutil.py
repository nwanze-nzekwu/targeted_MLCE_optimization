"""
Wrapper around shutil functions used in ArtemisOpt with windows-freindly default behavior.
"""

import os
import shutil
import stat
from shutil import copytree, copy


def rmtree(path, ignore_errors=False, onerror=None, dir_fd=None, not_exists_ok=False):
    """
    Remove a directory tree. This is a wrapper around shutil.rmtree with
    windows-friendly default behavior.

    By default, if a file fails to be removed because it's readonly, it will be
    made writable and then removed.

    We also add a not_exists_ok parameter to suppress the error if the
    directory does not exist, since most of the times when we set
    ignore_errors=True, we're trying to supress this specific error.
    """

    if not_exists_ok and not os.path.exists(path):
        return

    def remove_readonly(func, path, excinfo):
        """
        Clear the readonly bit and reattempt the removal.
        Windows doesn't allow deletion of readonly files.
        """
        os.chmod(path, stat.S_IWRITE)
        if onerror is not None:
            onerror(func, path, excinfo)
        else:
            func(path)

    try:
        # try our default exception handler
        # need to set ignore_errors to False for it to be called
        shutil.rmtree(path, ignore_errors=False, onerror=remove_readonly, dir_fd=dir_fd)
    except:
        # fallback to the original implementation
        shutil.rmtree(path, ignore_errors=ignore_errors, onerror=onerror, dir_fd=dir_fd)


def move(src, dst, copy_function=shutil.copy2):
    """
    Move a file or directory to a new location.

    We opt to use copytree -> rmtree instead of shutil.move because shutil.move
    uses copytree -> rmtree under the hood as a fallback if os.rename fails. We
    don't want to use the shutil version of rmtree because it has cases that will
    fail on windows (e.g. readonly files).
    """
    shutil.copytree(src, dst, copy_function=copy_function, symlinks=True)
    rmtree(src, ignore_errors=True)


__all__ = ["copytree", "copy", "move", "rmtree"]
