#!/usr/bin/env python3
# encoding: utf
"""
Main file of Artemis
"""
import asyncio
import enum
import json
import os
import traceback
from collections.abc import Sequence
from typing import Any, TypeVar
from uuid import UUID

from falcon_models import SolutionResultsRequest
from typing_extensions import override

from artemisopt.changeset.evaluation import run_changeset_evaluation
from artemisopt.extraction.run import (
    run_extraction,
    run_extraction_with_llm_filter,
    run_extraction_with_tool,
)
from artemisopt.filtration.utils import run_filtering
from artemisopt.models.executor import OptimisationOutputSummary
from artemisopt.util.cli import configure_logger, display_task
from artemisopt.util.general import orjson_dumps
from artemisopt.util.output import OutputManager

os.environ["GIT_SSH_COMMAND"] = (
    "ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"
)
import argparse
from pathlib import Path

from git import Repo
from loguru import logger

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.models.code import ConstructMapping
from artemisopt.models.solution import BriefSolutionInfo, Solution, SolutionStatus
from artemisopt.optimiser.optimise import Optimiser
from artemisopt.util import shutil
from artemisopt.util.git import create_results_pr

if conf_mgr.artemis_settings.extended_output:
    from rich import pretty

    from artemisopt.util.cli import configure_logger, display_task

    pretty.install()


def _clean_workspace(output_dir: Path):
    """Re-creates output folder if it's not empty"""
    if output_dir.exists() and output_dir.is_dir() and any(output_dir.iterdir()):
        shutil.rmtree(output_dir)
        output_dir.mkdir()


def filter(
    artemis_config: ArtemisTaskConfig,
    constructs: ConstructMapping,
    output_dir: Path,
):
    filtered = run_filtering(constructs, artemis_config)
    with open(output_dir / "constructs_filtered.json", "w", encoding="utf-8") as f:
        f.write(filtered.model_dump_json())


def changeset_validation(
    artemis_config: ArtemisTaskConfig,
    output_dir: Path,
):
    run_changeset_evaluation(artemis_config, output_dir)


def optimise(
    artemis_config: ArtemisTaskConfig,
    constructs: ConstructMapping,
    output_dir: Path,
    generate_pr: bool = False,
    generate_summary: bool = False,
):
    with display_task("Optimisation"):
        logger.info(
            "------------------ Starting Optimisation procedure ------------------"
        )
        if len(constructs.root) != 0:
            opt = Optimiser(constructs, artemis_config)
            og_params: dict[str, UUID] = {
                str(cid): construct.original_spec_id
                for cid, construct in constructs.root.items()
            }
            og_solution = None
            results = opt.optimise()
            if generate_pr:
                create_results_pr(results)
            if generate_summary:
                try:
                    og_solution = opt.run_perf_test(
                        unit_test=False, create_in_db=False, constructs=og_params
                    )
                except Exception:
                    logger.error("Failed to run original code")
                    traceback.print_exc()
                if not results or results[0].solution.original or not og_solution:
                    summary = "A more optimised version of the code was not found"
                    text = ""
                else:
                    summary = (
                        "A more optimised version of the code was found. \n A total "
                        f"of {len(results[0].solution.parameters)} construct(s) "
                        "were detected."
                    )
                    text = results[0].compare_to_raw_metrics(og_solution, md=True)

                opt_summary = OptimisationOutputSummary.from_templates(
                    summary, text, template, results[0].solution if results else None
                )
                with open(output_dir / "summary.json", "w", encoding="utf-8") as f:
                    json.dump(opt_summary.dict(), f, indent=3)


def generate(
    artemis_config: ArtemisTaskConfig,
    constructs: ConstructMapping,
    input_dir: Path,
):
    with display_task("Generating code"):
        opt = Optimiser(constructs, artemis_config)
        with open(input_dir / "solution.json", "r", encoding="utf-8") as f:
            solution_info = BriefSolutionInfo.model_validate_json(f.read())
        sol = Solution(constructs=solution_info.constructs)
        if artemis_config.project_path is None:
            raise ValueError("Project path is required for code generation")
        opt.generate_substitution(sol, artemis_config.project_path, "generated")


def evaluate(
    artemis_config: ArtemisTaskConfig,
    constructs: ConstructMapping,
    input_dir: Path,
    output_dir: Path,
):
    with display_task("Evaluating code"):
        opt = Optimiser(constructs, artemis_config)
        with open(input_dir / "solution.json", "r", encoding="utf-8") as f:
            solution_info = BriefSolutionInfo.model_validate_json(f.read())
        solution_constructs: dict[str, UUID] = {
            str(entry.construct_id): entry.spec_id for entry in solution_info.constructs
        }
        extra: dict[str, Any] = {}
        try:
            res = opt.run_perf_test(
                extra=extra,
                unit_test=artemis_config.evaluation_unit_test,
                create_in_db=False,
                **solution_constructs,
            )
        except Exception:
            traceback.print_exc()
            res = None
        results = {}
        if extra.get("full_results"):
            results["results"] = extra["full_results"]
        results["status"] = (
            SolutionStatus.success
            if res and res != (0.0, 0.0, 0.0)
            else SolutionStatus.fail
        )
        results = SolutionResultsRequest.model_validate(results)
        with open(output_dir / "results.json", "w", encoding="utf-8") as f:
            f.write(orjson_dumps(results.dict()))


class OptimiserModeEnum(enum.StrEnum):
    EXTRACT = "extract"
    OPTIMISE = "optimise"
    GENERATE = "generate"
    EVALUATE = "evaluate"
    CHANGESET_EVALUATE = "changeset-evaluate"
    FILTER = "filter"

    def needs_constructs(self) -> bool:
        return self not in [self.CHANGESET_EVALUATE]


class OptimiserNamespace(argparse.Namespace):
    mode: OptimiserModeEnum
    input_dir: Path
    output_dir: Path
    hardware_id: str
    log_path: Path
    pr: bool = False
    debug: bool = False
    trace: bool = False
    summary: bool = False


class EnumAction(argparse.Action):
    def __init__(self, **kwargs: Any):
        enum_type = kwargs.pop("type", None)
        if enum_type is None:
            raise ValueError("type must be assigned an Enum when using EnumAction")

        kwargs.setdefault("choices", list(enum_type))
        super().__init__(**kwargs)
        self._enum = enum_type

    @override
    def __call__(
        self,
        parser: argparse.ArgumentParser,
        namespace: argparse.Namespace,
        values: str | Sequence[Any] | None,
        option_string: str | None = None,
    ) -> None:
        try:
            enum_value = self._enum(values)
        except ValueError:
            valid_values = ", ".join([e.value for e in self._enum])
            raise argparse.ArgumentTypeError(
                f"Invalid value: '{values}'. Choose from: {valid_values}"
            )
        setattr(namespace, self.dest, enum_value)


async def main():
    parser = argparse.ArgumentParser(description="Artemis code optimisation system")
    parser.add_argument(
        "-m",
        "--mode",
        action=EnumAction,
        type=OptimiserModeEnum,
        choices=list(OptimiserModeEnum),
        help="Mode for tool",
    )
    parser.add_argument(
        "-i",
        "--input",
        type=Path,
        dest="input_dir",
        nargs="?",
        default=conf_mgr.artemis_settings.input_path,
        help="Input folder for Artemis",
    )
    parser.add_argument(
        "-o",
        "--output",
        dest="output_dir",
        type=Path,
        nargs="?",
        default=conf_mgr.artemis_settings.output_path,
        help="Output folder for Artemis",
    )
    parser.add_argument(
        "--hardware-id",
        type=str,
        nargs="?",
        help="Artemis hardware ID",
    )
    parser.add_argument(
        "-l",
        "--log",
        dest="log_path",
        type=Path,
        nargs="?",
        help="Output log file",
    )
    parser.add_argument(
        "--pr",
        action="store_true",
        default=False,
        help="""
            Enables pull request feature
            """,
    )
    parser.add_argument(
        "--debug",
        "-d",
        action="store_true",
        help="""
            Enables extended logging
            """,
    )
    parser.add_argument(
        "--trace",
        "-t",
        action="store_true",
        help="""
            Enables further extended logging
            """,
    )
    parser.add_argument(
        "--summary",
        "-s",
        action="store_true",
        help="""
            Enables summary output
            """,
    )

    args = parser.parse_args(namespace=OptimiserNamespace)
    logger.info(args)

    _clean_workspace(args.output_dir)
    conf_mgr.artemis_settings.input_path = args.input_dir
    conf_mgr.artemis_settings.output_path = args.output_dir
    if args.hardware_id:
        conf_mgr.artemis_settings.hardware_id = UUID(args.hardware_id)
    if args.trace:
        configure_logger(level="TRACE", log_path=args.log_path, override_existing=True)
        conf_mgr.artemis_settings.debug_mode = True
    elif args.debug:
        configure_logger(level="DEBUG", log_path=args.log_path, override_existing=True)
        conf_mgr.artemis_settings.debug_mode = True
    else:
        configure_logger(level="INFO", log_path=args.log_path)

    config_file = args.input_dir / "config.json"
    constructs_file = args.input_dir / "constructs.json"

    with open(config_file, "r", encoding="utf-8") as f:
        config_json = json.load(f)
    artemis_config = ArtemisTaskConfig.model_validate(config_json)

    if constructs_file.exists():
        with open(constructs_file, "r", encoding="utf-8") as f:
            constructs_json = json.load(f)
        constructs = ConstructMapping.model_validate(constructs_json)
    else:
        constructs = None

    conf_mgr.artemis_settings.artemis_task = artemis_config

    if artemis_config.project_path or artemis_config.git_url or artemis_config.git_hash:
        artemis_config.project_path = load_project(
            artemis_config.project_path, artemis_config.git_url, artemis_config.git_hash
        )
        OutputManager.populate_commands(artemis_config)

    with display_task("Code analysis"):
        if constructs is None and args.mode.needs_constructs():
            logger.info(
                "------------------ Running Source code Analysis ------------------"
            )
            if artemis_config.filter_tool_mode:
                constructs = await run_extraction_with_tool(artemis_config)
            elif artemis_config.llm_type and artemis_config.llm_filter:
                constructs = await run_extraction_with_llm_filter(artemis_config)
            else:
                constructs = await run_extraction(artemis_config)
            nr_detected = len(constructs.root)
            logger.info(f"Detected {nr_detected} code snippets.")
            OutputManager.calculate_extracted_constructs_and_patch_extraction(
                nr_detected
            )

    if args.mode == OptimiserModeEnum.FILTER:
        filter(artemis_config, constructs, args.output_dir)
    elif args.mode == OptimiserModeEnum.OPTIMISE:
        optimise(
            artemis_config,
            constructs,
            args.output_dir,
            args.pr,
            args.summary,
        )
    elif args.mode == OptimiserModeEnum.GENERATE:
        generate(artemis_config, constructs, args.input_dir)
    elif args.mode == OptimiserModeEnum.EVALUATE:
        evaluate(
            artemis_config,
            constructs,
            args.input_dir,
            args.output_dir,
        )
    elif args.mode == OptimiserModeEnum.CHANGESET_EVALUATE:
        changeset_validation(
            artemis_config,
            args.output_dir,
        )


def load_project(
    project_path: Path | None, git_url: str | None, git_hash: str | None
) -> Path:
    if not project_path and git_url:
        with display_task("Downloading source"):
            repo = Repo.clone_from(
                git_url,
                conf_mgr.artemis_settings.output_path / "original_repo",
                filter="tree:0",
                no_checkout=True,
            )
            if git_hash:
                repo.git.checkout(git_hash)
            else:
                repo.git.checkout()
            repo.git.submodule("update", "--init", "--recursive")
            project_path = conf_mgr.artemis_settings.output_path / "original_repo"
            OutputManager.save_project_repo(project_path)
    elif project_path:
        with display_task("Loading source"):
            project_path = conf_mgr.artemis_settings.input_path / project_path
            if conf_mgr.artemis_settings.copy_project_to_output:
                new_path = conf_mgr.artemis_settings.output_path / "original_repo"
                shutil.copytree(project_path, new_path, symlinks=True)
                project_path = conf_mgr.artemis_settings.output_path / "original_repo"
    else:
        raise Exception("No URL or path provided.")

    return project_path


if __name__ == "__main__":
    try:
        if conf_mgr.artemis_settings.extended_output:
            from artemisopt.util.cli import task_display

            with task_display.live:
                asyncio.run(main())
        else:
            asyncio.run(main())
    except BaseException:
        logger.error(traceback.format_exc())
