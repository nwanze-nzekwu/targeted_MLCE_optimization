"""Implementation of Optimise worker for Artemis"""

import logging
import os
import sys
from pathlib import Path
from typing import List, Tuple
from uuid import UUID

if sys.platform == "win32":
    import mslex as shlex
else:
    import shlex

from artemis_client.workers.base import ArtemisWorker
from falcon_models.api.code_models import (
    CustomSpecChildResponse,
    GenericConstructFilterRequestResponse,
    PaginatedConstructFilterRequest,
    ProjectInfoResponse,
    SnippetFilterParamsRequestResponse,
)
from falcon_models.enums import FilterTypeEnum
from turing_task_manager import WorkingEnv

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.models.build import BuildCommands
from artemisopt.models.code import ConstructMapping
from artemisopt.util.basemodel import ArtemisBaseModel

# ──────────────────────────────────────────────────────────────────────────── #

logger = logging.getLogger(__name__)
inputs_logger = logging.getLogger(__name__ + ".inputs_download")
output_logger = logging.getLogger(__name__ + ".output")


# ---------------------------------- worker ---------------------------------- #


class ArtemisOptimiseTaskModel(ArtemisBaseModel):
    project_id: UUID
    optimisation_id: UUID


class ArtemisOptimiseWorker(ArtemisWorker):
    """Task-specific behaviors for the optimise task"""

    taskType = ArtemisOptimiseTaskModel
    task: ArtemisOptimiseTaskModel
    project: ProjectInfoResponse
    hardware_id: UUID = None

    def download_inputs(self, env: WorkingEnv):
        """Creates template and Artemis input config from project ID and language"""
        self.optimisation = self.falcon_client.get_optimisation(
            str(self.task.optimisation_id)
        )

        optimisation = self.falcon_client.get_optimisation(
            str(self.task.optimisation_id)
        )

        self.project = self.falcon_client.get_project(str(self.optimisation.project_id))
        config = ArtemisTaskConfig(
            git_url=self.project.git_url,
            git_hash=self.project.git_hash,
            build_commands=BuildCommands(
                build=self.project.compile_command,
                unit_test=self.project.unit_test_command,
                perf=self.project.perf_command,
                clean=self.project.clean_command,
                setup=self.project.setup_command,
            ),
            project_id=str(self.project.id),
            optimisation_id=str(self.optimisation.id),
            project_path=self.init_project(env, str(self.project.id)),
            user_id="",
            evaluation_repetitions=optimisation.evaluation_repetitions,
        )

        constructs = optimisation.constructs or []
        spec_map = {c.construct_id: c.spec_ids for c in constructs}

        construct_ids = list(str(c.construct_id) for c in constructs)
        if len(construct_ids) > 0:
            construct_list = self.falcon_client.get_constructs(
                project_id=str(self.project.id),
                filters=PaginatedConstructFilterRequest(
                    page=1,
                    per_page=-1,
                    filters=[
                        GenericConstructFilterRequestResponse(
                            type=FilterTypeEnum.snippets,
                            params=SnippetFilterParamsRequestResponse(
                                ids=construct_ids
                            ),
                        )
                    ],
                ),
            ).docs
        else:
            construct_list = []

        # We have a `ConcreteConstruct` but want a `ConcreteConstructResponse`
        for construct in construct_list:
            requested_specs: list[CustomSpecChildResponse] = []
            for spec in construct.custom_specs:
                filtering_specs: list[UUID] = []
                if construct.id in spec_map:
                    filtering_specs = spec_map[construct.id]
                if spec.id in filtering_specs:
                    requested_specs.append(
                        CustomSpecChildResponse.model_validate(spec.model_dump())
                    )
            construct.custom_specs = requested_specs

        with open(env.input_dir / "config.json", "w", encoding="utf-8") as f:
            f.write(config.model_dump_json())
        with (env.input_dir / "constructs.json").open("w", encoding="utf-8") as f:
            f.write(
                ConstructMapping({c.id: c for c in construct_list}).model_dump_json()
            )

        if self.hardware_id is None:
            self.hardware_id = self.falcon_client.add_hardware(
                self.get_hardware_info()
            ).id
        self.falcon_client.patch_optimisation(
            str(self.task.optimisation_id), {"hardware_id": str(self.hardware_id)}
        )

    def executable_inputs(self, env: WorkingEnv) -> Tuple[Path, str]:
        """Executes Artemis in optimise mode"""
        cli = (
            "-d -i {input} -o {output} -m optimise --hardware-id {hardware_id}  -l"
            " {log_path}"
        )
        return "module:artemisopt", cli.format(
            input=shlex.quote(str(env.input_dir)),
            output=shlex.quote(str(env.output_dir)),
            hardware_id=str(self.hardware_id),
            log_path=shlex.quote(str(env.output_dir / ".log")),
        )

    def process_outputs_on_exit(self, paths_list: List[Path]):
        """Handles results at end of optimisation"""
        output_logger.info("Finished optimisation!")


if __name__ == "__main__":
    import turing_task_manager as task_manager

    os.environ["ARTEMIS_OUTPUT_MODE"] = "api"
    task_name = "artemis-optimise"
    if os.environ.get("WORKER_SUFFIX"):
        task_name += "-" + os.environ["WORKER_SUFFIX"]
    task_manager.start(ArtemisOptimiseWorker, task_type=task_name)
