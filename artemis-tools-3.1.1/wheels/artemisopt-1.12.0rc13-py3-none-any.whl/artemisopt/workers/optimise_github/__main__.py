#!/usr/bin/env python3
"""Implementation of Optimise worker for Artemis"""
import json
import logging
import os
from pathlib import Path
from typing import List, Tuple

from git import Repo
from github import Github, GithubIntegration, Repository
from github.CheckRun import CheckRun
from turing_task_manager import BaseWorker, WorkingEnv

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.util.basemodel import ArtemisBaseModel
from artemisopt.workers.optimise_github.utils import GitHubConfig

# ──────────────────────────────────────────────────────────────────────────── #


class ArtemisTaskModel(ArtemisBaseModel):
    """
    Task for Artemis operations
    """

    repository_id: int
    check_suite_id: int
    check_name: str = "Optimisation run"
    language: str = "cpp"


logging.getLogger("github").setLevel(logging.WARNING)
logging.getLogger("git").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)
inputs_logger = logging.getLogger(__name__ + ".inputs_download")
output_logger = logging.getLogger(__name__ + ".output")


# ---------------------------------- worker ---------------------------------- #
class ArtemisOptimiseWorker(BaseWorker):
    """Task-specific behaviors for the optimise task"""

    taskType = ArtemisTaskModel
    github_client: Github
    github_integration: GithubIntegration
    access_token: str
    repo: Repository
    check_run: CheckRun

    def download_inputs(self, env: WorkingEnv):
        """Creates template and Artemis input config from project ID and language"""
        github_conf = GitHubConfig(_env_file=Path(__file__).parents[2] / ".env")
        self.github_integration = GithubIntegration(
            github_conf.app_id, github_conf.github_token
        )
        self.access_token = self.github_integration.get_access_token(
            github_conf.installation_id
        ).token
        self.github_client = Github(login_or_token=self.access_token)
        # Clone
        self.repo = self.github_client.get_repo(self.task.repository_id)
        check_suite = self.repo.get_check_suite(self.task.check_suite_id)
        self.check_run = self.repo.create_check_run(
            head_sha=check_suite.head_sha,
            name=self.task.check_name,
            status="in_progress",
        )
        url = self.repo.git_url
        logger.info(f"Cloning repo {url}")
        for prefix in ["https://", "git://", "ssh://git@"]:
            if url.startswith(prefix):
                url = url.replace(
                    prefix, f"https://x-access-token:{self.access_token}@", 1
                )
        logger.info(f"Cloning repo {url}")
        original_repo_path = env.input_dir / "original_repo"
        py_repo = Repo.clone_from(
            url,
            original_repo_path,
            no_checkout=True,
        )
        py_repo.git.checkout(check_suite.head_sha)
        py_repo.git.submodule("update", "--init", "--recursive")
        # Generate config
        config = ArtemisTaskConfig(
            project_path=original_repo_path, language=self.task.language
        )

        with open(env.input_dir / "config.json", "w", encoding="utf-8") as f:
            f.write(config.json())

    def executable_inputs(self, env: WorkingEnv) -> Tuple[Path, str]:
        """Executes Artemis in optimise mode"""
        cli = "-i {input} -o {output} --summary -m optimise"
        return "module:artemisopt", cli.format(
            input=env.input_dir,
            output=env.output_dir,
        )

    def process_outputs_on_exit(self, paths_list: List[Path]):
        """Handles results at end of optimisation"""
        # TODO: Upload results to GitHub
        output_logger.info("Finished optimisation!")
        summary_file = self.env.output_dir / "summary.json"
        options = {}
        if summary_file.exists():
            summary = json.load(summary_file.open(encoding="utf-8"))
            logger.info(summary)
            options["output"] = summary
        self.check_run.edit(status="completed", conclusion="success", **options)

    def on_failure(self) -> None:
        if "check_run" in self.__dict__ and self.check_run:
            self.check_run.edit(status="completed", conclusion="failure")


if __name__ == "__main__":
    import turing_task_manager as task_manager

    task_name = "artemis-optimise-github"
    if os.environ.get("WORKER_SUFFIX"):
        task_name += "-" + os.environ["WORKER_SUFFIX"]
    task_manager.start(ArtemisOptimiseWorker, task_type=task_name)
