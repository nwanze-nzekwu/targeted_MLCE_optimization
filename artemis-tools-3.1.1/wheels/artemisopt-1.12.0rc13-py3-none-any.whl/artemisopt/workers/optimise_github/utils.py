from pydantic_settings import BaseSettings


class GitHubConfig(BaseSettings):
    webhook_secret: str
    github_token: str
    app_id: int
    installation_id: int
