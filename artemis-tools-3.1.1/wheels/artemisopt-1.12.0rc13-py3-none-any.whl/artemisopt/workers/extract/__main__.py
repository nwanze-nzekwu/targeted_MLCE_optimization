"""Implements extract worker for Artemis."""

import logging
import os
from pathlib import Path
from typing import List, Optional, Tuple
from uuid import UUID

from artemis_client.workers.base import ArtemisWorker
from evoml_services.clients.thor.models import File
from falcon_models.api.code_models import (
    ExtractionRunResponse,
    FilterToolMode,
    ProjectInfoResponse,
    ToolFilter,
)
from sourcekon.extractors.code_extractor_data_types import ExtractorScope
from sourcekon.utils.data_utils import serialize_data
from turing_task_manager import WorkingEnv
from typing_extensions import override

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.util.basemodel import ArtemisBaseModel

logger = logging.getLogger(__name__)
inputs_logger = logging.getLogger(__name__ + ".inputs_download")
output_logger = logging.getLogger(__name__ + ".output")


# ---------------------------------- worker ---------------------------------- #


class ArtemisExtractTaskModel(ArtemisBaseModel):
    extraction_id: UUID
    user_id: str


class ArtemisExtractWorker(ArtemisWorker):
    """Task-specific behaviors for the extract task"""

    taskType = ArtemisExtractTaskModel
    project: ProjectInfoResponse
    task: ArtemisExtractTaskModel  # typing only
    user_id: str

    @override
    def download_inputs(self, env: WorkingEnv):
        """Creates Artemis input config from project ID and language"""
        os.environ["VISION_USER_OVERRIDE"] = self.task.user_id
        extraction: ExtractionRunResponse = self.falcon_client.get_extraction(
            str(self.task.extraction_id)
        )
        self.project = self.falcon_client.get_project(str(extraction.project_id))
        project_path = self.init_project(env, str(self.project.id))
        tool_files = extraction.tool_files
        input_file_path, additional_file_path = self.download_tool_files_from_thor(
            env, tool_files
        )
        additional_file_path = additional_file_path or ""

        config = ArtemisTaskConfig(
            project_id=str(extraction.project_id),
            extraction_id=str(extraction.id),
            include_globs=extraction.include_globs or [],
            exclude_globs=extraction.exclude_globs or [],
            user_id=self.task.user_id,
            llm_type=extraction.llm_type,
            llm_filter=extraction.llm_filter,
            extraction_queries=extraction.queries,
            project_path=project_path,
            filter_tool_mode=self.get_filter_tool_mode(extraction),
            tool_filter=extraction.tool_filter,
            tool_files=tool_files,
            input_file_path=str(input_file_path),
            additional_file_path=str(additional_file_path),
            current_branch=self.project.git_branch,
            git_url=self.project.git_url,
            main_branch=extraction.main_branch,
            git_mode=extraction.git_mode,
            extractor_scope=(
                extraction.extractor_scope
                if extraction.extractor_scope is not None
                else ExtractorScope.FUNC
            ),
            contributor=extraction.contributor,
            start_date=serialize_data(data=extraction.start_date),
            end_date=serialize_data(data=extraction.end_date),
        )

        try:
            with open(env.input_dir / "config.json", "w", encoding="utf-8") as f:
                json_data = config.model_dump_json()
                f.write(json_data)
        except Exception as e:
            print(f"An error occurred: {e}")

    def executable_inputs(self, env: WorkingEnv) -> tuple[Path, str]:
        """Executes Artemis with extract mode"""
        cli = "-i {input} -o {output} -l {log_path} -m extract"
        return "module:artemisopt", cli.format(
            input=env.input_dir,
            output=env.output_dir,
            log_path=env.output_dir / ".log",
        )

    def download_tool_files_from_thor(
        self, env: WorkingEnv, file_ids: List[str]
    ) -> Tuple[Optional[Path], Optional[Path]]:
        main_file_path = None
        additional_file_path = None
        for file_id in file_ids:
            file_info: File = self.thor_client.get_file(file_id)
            file_path = env.input_dir.joinpath(file_info.originalFilename)
            self.thor_client.download_simple_file(file_id, file_path)

            if file_path.suffix == ".db":
                additional_file_path = file_path
            else:
                main_file_path = file_path

            if main_file_path and additional_file_path:
                break

        return main_file_path, additional_file_path

    @staticmethod
    def get_filter_tool_mode(
        extraction: ExtractionRunResponse,
    ) -> Optional[FilterToolMode]:
        filter_tool_mode = extraction.filter_tool_mode
        if extraction.tool_filter is ToolFilter.GIT:
            filter_tool_mode = FilterToolMode.GIT
        return filter_tool_mode

    @override
    def process_outputs_on_exit(self, paths_list: set[Path]):
        """Uploads results to Vision API"""
        ...


if __name__ == "__main__":
    import turing_task_manager as task_manager

    os.environ["ARTEMIS_OUTPUT_MODE"] = "api"
    task_name = "artemis-extract"
    if os.environ.get("WORKER_SUFFIX"):
        task_name += "-" + os.environ["WORKER_SUFFIX"]
    task_manager.start(ArtemisExtractWorker, task_type=task_name)
