"""Implements extract worker for Artemis."""

import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from uuid import UUID

if sys.platform == "win32":
    import mslex as shlex
else:
    import shlex


# ──────────────────────────────────────────────────────────────────────────── #

from artemis_client.workers.base import ArtemisWorker
from falcon_models import CustomSpecChildResponse, ProjectInfoResponse
from falcon_models.api.code_models import (
    GenericConstructFilterRequestResponse,
    PaginatedConstructFilterRequest,
    SnippetFilterParamsRequestResponse,
)
from falcon_models.enums import FilterTypeEnum
from turing_task_manager import WorkingEnv

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.models.build import BuildCommands
from artemisopt.models.code import ConstructMapping
from artemisopt.util.basemodel import ArtemisBaseModel

logger = logging.getLogger(__name__)
inputs_logger = logging.getLogger(__name__ + ".inputs_download")
output_logger = logging.getLogger(__name__ + ".output")

# ---------------------------------- worker ---------------------------------- #


class ArtemisFilterTaskModel(ArtemisBaseModel):
    project_id: UUID
    user_id: str
    filtering_id: UUID
    custom_command: str | None
    run_original: bool = False


class ArtemisFilterWorker(ArtemisWorker):
    """Task-specific behaviors for the extract task"""

    taskType = ArtemisFilterTaskModel
    task: ArtemisFilterTaskModel  # for typing
    project: ProjectInfoResponse
    user_id: str

    def download_inputs(self, env: WorkingEnv):
        """Creates Artemis input config from project ID and language"""
        os.environ["VISION_USER_OVERRIDE"] = self.task.user_id
        self.project = self.falcon_client.get_project(str(self.task.project_id))
        self.filtering = self.falcon_client.get_filtering(str(self.task.filtering_id))

        config = ArtemisTaskConfig(
            git_url=self.project.git_url,
            git_hash=self.project.git_hash,
            build_commands=BuildCommands(
                build=self.project.compile_command,
                unit_test=self.project.unit_test_command,
                perf=self.project.perf_command,
                clean=self.project.clean_command,
                setup=self.project.setup_command,
                custom=self.task.custom_command,
            ),
            project_id=str(self.project.id),
            filtering_id=str(self.task.filtering_id),
            filter_types=self.filtering.types,
            filter_run_original=self.task.run_original,
            llm_type=self.filtering.llm_type,
            project_path=self.init_project(env, str(self.project.id)),
            user_id=self.task.user_id,
        )

        filtering_constructs = self.filtering.constructs or {}
        construct_ids = list(str(id_) for id_ in filtering_constructs.keys())
        if len(construct_ids) > 0:
            construct_list = self.falcon_client.get_constructs(
                project_id=str(self.project.id),
                filters=PaginatedConstructFilterRequest(
                    page=1,
                    per_page=-1,
                    filters=[
                        GenericConstructFilterRequestResponse(
                            type=FilterTypeEnum.snippets,
                            params=SnippetFilterParamsRequestResponse(
                                ids=construct_ids
                            ),
                        )
                    ],
                ),
            ).docs
        else:
            construct_list = []

        # We have a `ConcreteConstruct` but want a `ConcreteConstructResponse`
        for construct in construct_list:
            requested_specs: list[CustomSpecChildResponse] = []
            for spec in construct.custom_specs:
                filtering_specs: list[UUID] = []
                if construct.id in filtering_constructs:
                    filtering_specs = filtering_constructs[construct.id] or []
                if spec.id in filtering_specs:
                    requested_specs.append(
                        CustomSpecChildResponse.model_validate(spec.model_dump())
                    )
            construct.custom_specs = requested_specs

        with open(env.input_dir / "config.json", "w", encoding="utf-8") as f:
            f.write(config.model_dump_json())
        with (env.input_dir / "constructs.json").open("w", encoding="utf-8") as f:
            f.write(
                ConstructMapping({c.id: c for c in construct_list}).model_dump_json()
            )

    def executable_inputs(self, env: WorkingEnv) -> Tuple[Path, str]:
        """Executes Artemis with extract mode"""
        cli = "-i {input} -o {output} -l {log_path} -m filter"
        return "module:artemisopt", cli.format(
            input=shlex.quote(str(env.input_dir)),
            output=shlex.quote(str(env.output_dir)),
            log_path=shlex.quote(str(env.output_dir / ".log")),
        )

    def process_outputs_on_exit(self, paths_list: List[Path]):
        """Uploads results to Vision API"""
        ...


if __name__ == "__main__":
    import turing_task_manager as task_manager

    os.environ["ARTEMIS_OUTPUT_MODE"] = "api"
    task_name = "artemis-filter"
    if os.environ.get("WORKER_SUFFIX"):
        task_name += "-" + os.environ["WORKER_SUFFIX"]
    task_manager.start(ArtemisFilterWorker, task_type=task_name)
