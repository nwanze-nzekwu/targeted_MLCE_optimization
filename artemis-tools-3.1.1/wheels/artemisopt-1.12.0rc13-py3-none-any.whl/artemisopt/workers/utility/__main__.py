"""Implementation of Optimise worker for Artemis"""

import enum
import logging
import os
import sys
from pathlib import Path
from uuid import UUID

if sys.platform == "win32":
    import mslex as shlex
else:
    import shlex

from artemis_client.workers.base import ArtemisWorker
from falcon_models import ChangesetCommandUpdateRequest, ChangesetValidationResponse
from falcon_models.api.code_models import (
    CustomSpecChildResponse,
    GenericConstructFilterRequestResponse,
    PaginatedConstructFilterRequest,
    ProjectInfoResponse,
    SnippetFilterParamsRequestResponse,
    SolutionResultsRequest,
)
from falcon_models.enums import FilterTypeEnum
from falcon_models.enums.general import ExecutionStatusEnum
from turing_task_manager import WorkingEnv
from typing_extensions import override

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.models.build import BuildCommands
from artemisopt.models.code import ConstructMapping
from artemisopt.models.solution import BriefSolutionInfo, SolutionEntry, SolutionStatus
from artemisopt.util.basemodel import ArtemisBaseModel

# ──────────────────────────────────────────────────────────────────────────── #

logger = logging.getLogger(__name__)
inputs_logger = logging.getLogger(__name__ + ".inputs_download")
output_logger = logging.getLogger(__name__ + ".output")

# ---------------------------------- worker ---------------------------------- #


class UtilityMode(enum.StrEnum):
    """Utility mode for the worker"""

    GENERATE = "generate"
    GENERATE_SINGLE = "generate-single"
    EVALUATE = "evaluate"
    TEMPLATE = "template"
    CHANGESET_EVALUATE = "changeset-evaluate"

    @property
    def mode_name(self) -> str:
        if self == UtilityMode.GENERATE_SINGLE:
            return "generate"
        else:
            return self.value


class ArtemisUtilityTaskModel(ArtemisBaseModel):
    mode: UtilityMode
    solution_id: UUID | None = None
    construct_id: UUID | None = None
    file: str | None = None
    evaluation_repetitions: int = 1
    unit_test: bool = False
    custom_command: str | None = None
    project_id: str | None = None
    validation_id: str | None = None


class ArtemisUtilityWorker(ArtemisWorker):
    """Task-specific behaviors for the optimise task"""

    taskType = ArtemisUtilityTaskModel
    project: ProjectInfoResponse
    task: ArtemisUtilityTaskModel

    @override
    def download_inputs(self, env: WorkingEnv):
        """Creates template and Artemis input config from project ID and language"""
        if self.task.mode == UtilityMode.CHANGESET_EVALUATE:
            if not self.task.project_id or not self.task.validation_id:
                raise ValueError(
                    "Project ID and validation ID are required for changeset evaluation"
                )

            # Get project details
            self.project = self.falcon_client.get_project(self.task.project_id)

            # Clone the repository at the specific version
            config = ArtemisTaskConfig(
                validation_id=self.task.validation_id,
                project_id=self.task.project_id,
            )

            with open(env.input_dir / "config.json", "w", encoding="utf-8") as f:
                f.write(config.model_dump_json())

            return

        if not self.task.solution_id:
            return
        self.solution = self.falcon_client.get_solution(str(self.task.solution_id))
        self.project = self.falcon_client.get_project(str(self.solution.project_id))
        config = ArtemisTaskConfig(
            git_url=self.project.git_url,
            git_hash=self.project.git_hash,
            build_commands=BuildCommands(
                build=self.project.compile_command,
                unit_test=self.project.unit_test_command,
                perf=self.task.custom_command or self.project.perf_command,
                clean=self.project.clean_command,
                setup=self.project.setup_command,
            ),
            project_id=str(self.project.id),
            project_path=self.init_project(env, str(self.project.id)),
            user_id="",
            evaluation_repetitions=self.task.evaluation_repetitions,
            evaluation_unit_test=self.task.unit_test,
        )

        with open(env.input_dir / "config.json", "w", encoding="utf-8") as f:
            f.write(config.model_dump_json())

        specs = self.solution.specs or []
        if self.task.mode == UtilityMode.GENERATE_SINGLE and self.task.construct_id:
            sol = BriefSolutionInfo(
                constructs=[
                    SolutionEntry(construct_id=s.construct_id, spec_id=s.spec_id)
                    for s in specs
                    if str(s.construct_id) == str(self.task.construct_id)
                ],
            )
        else:
            sol = BriefSolutionInfo(
                constructs=[
                    SolutionEntry(construct_id=s.construct_id, spec_id=s.spec_id)
                    for s in specs
                ],
            )
        with open(env.input_dir / "solution.json", "w", encoding="utf-8") as f:
            f.write(sol.model_dump_json())

        spec_map: dict[UUID, UUID] = {s.construct_id: s.spec_id for s in specs}

        if len(spec_map) > 0:
            construct_list = self.falcon_client.get_constructs(
                project_id=str(self.project.id),
                filters=PaginatedConstructFilterRequest(
                    page=1,
                    per_page=-1,
                    filters=[
                        GenericConstructFilterRequestResponse(
                            type=FilterTypeEnum.snippets,
                            params=SnippetFilterParamsRequestResponse(
                                ids=[str(c_id) for c_id in spec_map.keys()]
                            ),
                        )
                    ],
                ),
            ).docs
        else:
            construct_list = []

        # We have a `ConcreteConstruct` but want a `ConcreteConstructResponse`
        for construct in construct_list:
            requested_specs: list[CustomSpecChildResponse] = []
            for spec in construct.custom_specs:
                filtering_specs: list[UUID] = []
                if construct.id in spec_map:
                    filtering_specs = [spec_map[construct.id]]
                if spec.id in filtering_specs:
                    requested_specs.append(
                        CustomSpecChildResponse.model_validate(spec.model_dump())
                    )
            construct.custom_specs = requested_specs

        with (env.input_dir / "constructs.json").open("w", encoding="utf-8") as f:
            f.write(
                ConstructMapping({c.id: c for c in construct_list}).model_dump_json()
            )

    @override
    def executable_inputs(self, env: WorkingEnv) -> tuple[Path, str]:
        """Executes Artemis in optimise mode"""
        if self.task.mode in [
            UtilityMode.GENERATE,
            UtilityMode.EVALUATE,
            UtilityMode.GENERATE_SINGLE,
            UtilityMode.CHANGESET_EVALUATE,
        ]:
            cli = "-i {input} -o {output} -l {log_path} -m {mode}"
            return "module:artemisopt", cli.format(
                input=shlex.quote(str(env.input_dir)),
                output=shlex.quote(str(env.output_dir)),
                mode=UtilityMode(self.task.mode).mode_name,
                log_path=shlex.quote(str(env.output_dir / ".log")),
            )
        else:
            return Path("/bin/echo"), "Artemis"

    @override
    def process_outputs(
        self, file_path: Path, processed_paths: set[Path]
    ):  # pylint: disable=unused-argument
        """Handles results after each iteration"""

    @override
    def process_outputs_on_exit(self, paths_list: set[Path]):
        """Handles results at end of optimisation"""
        if self.task.mode == UtilityMode.GENERATE:
            output_logger.info("Finished generation!")
            thor_file = self.thor_client.upload_folder(
                self.env.output_dir / "generated"
            ).id
            self.falcon_client.add_solution_file(str(self.task.solution_id), thor_file)
        elif self.task.mode == UtilityMode.GENERATE_SINGLE:
            assert self.task.file is not None
            self.upload_synchronous_output(
                "artemis-generate-single",
                {
                    "file": (
                        self.env.output_dir / "generated" / self.task.file
                    ).read_text()
                },
            )
        if self.task.mode == UtilityMode.EVALUATE:
            output_logger.info("Finished evaluation!")
            with open(self.env.output_dir / "results.json", "r", encoding="utf-8") as f:
                results = SolutionResultsRequest.model_validate_json(f.read())
            self.falcon_client.add_solution_results(str(self.task.solution_id), results)
            if results.status == SolutionStatus.fail:
                raise Exception("Evaluation failed!")
        elif self.task.mode == UtilityMode.TEMPLATE:
            logger.warning("Deprecated mode, skipping...")
        elif self.task.mode == UtilityMode.CHANGESET_EVALUATE:
            output_logger.info("Finished changeset validation!")


if __name__ == "__main__":
    import turing_task_manager as task_manager

    task_name = "artemis-utility"
    if os.environ.get("WORKER_SUFFIX"):
        task_name += "-" + os.environ["WORKER_SUFFIX"]
    task_manager.start(ArtemisUtilityWorker, task_type=task_name)
