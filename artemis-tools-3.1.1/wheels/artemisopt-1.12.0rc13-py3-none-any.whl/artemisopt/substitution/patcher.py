"""
Contains infrastructure for substitution of data structure on C++
"""

from falcon_models.api import ConcreteConstructResponse, CustomSpecChildResponse


class Patcher:

    @classmethod
    def apply_patch(
        cls,
        code: str,
        construct: ConcreteConstructResponse,
        old_spec: CustomSpecChildResponse | None,
        new_spec: CustomSpecChildResponse | None,
    ) -> tuple[str, set[str]]:
        """Applies a patch to a data structure in Python source"""
        imports: set[str] = set()
        if new_spec and new_spec.id != construct.original_spec_id:
            lines = code.splitlines()
            lines[construct.lineno - 1 : construct.end_lineno] = (
                new_spec.content.splitlines()
            )
            code = "\n".join(lines)
            imports.update(new_spec.imports or [])

        return code, imports
