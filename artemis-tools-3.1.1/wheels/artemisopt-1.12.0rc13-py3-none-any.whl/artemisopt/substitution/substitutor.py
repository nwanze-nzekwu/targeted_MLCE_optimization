import uuid
from pathlib import Path

from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.models.code import ConstructMapping
from artemisopt.models.solution import Solution
from artemisopt.substitution.patcher import Patcher
from artemisopt.util import shutil
from falcon_models.api import ConcreteConstructResponse, CustomSpecChildResponse
from falcon_models.enums import FileOperationEnum


class Substitutor:
    constructs: ConstructMapping
    project_path: Path
    project_output_path: Path

    def __init__(
        self,
        constructs: ConstructMapping,
        project_path: Path,
        project_output_path: Path | None = None,
    ):
        self.constructs = constructs
        self.project_path = project_path
        self.project_output_path = project_output_path or conf_mgr.artemis_settings.output_path / "mutated"

    def substitute(self, solution: Solution, folder_name: str | None = None):
        """Performs substitution for the entire project"""
        folder_name = folder_name or str(uuid.uuid4())
        mutated_project_path = self.project_output_path / folder_name
        shutil.copytree(self.project_path, mutated_project_path, symlinks=True)
        includes: dict[Path, set[str]] = {}
        for entry in sorted(
            solution.constructs,
            key=lambda c: self.constructs.root[c.construct_id].lineno,
            reverse=True,
        ):
            construct = self.constructs.root[entry.construct_id]
            spec = next(
                iter(s for s in construct.custom_specs if s.id == entry.spec_id),
                None,
            )
            if not spec:
                return mutated_project_path

            file_path = (mutated_project_path / construct.file).resolve()

            match spec.file_operation:
                case FileOperationEnum.ADD:
                    # Create parent directories if needed
                    file_path.parent.mkdir(parents=True, exist_ok=True)
                    # Write the spec content directly to the new file
                    file_path.write_text(spec.content or "")
                    # Track imports for consistency (even though currently unused)
                    includes.setdefault(file_path, set())
                    includes[file_path].update(spec.imports or [])
                    continue  # Skip line-based patching
                case FileOperationEnum.DELETE:
                    if file_path.exists():
                        file_path.unlink()
                    continue  # Skip further processing for this file
                case _:
                    code = file_path.read_text()
            code, sub_includes = self.substitute_single(code, spec, construct)
            includes.setdefault(file_path, set())
            includes[file_path].update(sub_includes)
            file_path.write_text(code)

        return mutated_project_path

    @classmethod
    def substitute_single(
        cls,
        code: str,
        spec: CustomSpecChildResponse,
        construct: ConcreteConstructResponse,
        add_imports: bool = False,
    ) -> tuple[str, set[str]]:
        includes: set[str] = set()
        if spec and spec.content:
            if spec:
                code, new_imports = Patcher.apply_patch(
                    code,
                    construct,
                    None,
                    spec,
                )
                includes.update(new_imports)

        return code, includes
