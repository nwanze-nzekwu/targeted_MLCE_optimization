from io import StringIO
from pathlib import Path
from uuid import UUID

from loguru import logger

from artemisopt.compilation.build import BuildSystem
from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.conf.conf_manager import conf_mgr
from artemisopt.models.code import ConstructMapping
from artemisopt.models.executor import EvaluationResults, ExecutionResults
from artemisopt.models.solution import Solution, SolutionEntry
from artemisopt.substitution.substitutor import Substitutor
from artemisopt.util import shutil
from artemisopt.util.general import loguru_file_wrapper
from artemisopt.util.output import OutputManager
from falcon_models.api import CustomSpecChildResponse
from falcon_models.enums import FileOperationEnum, ValidationFilterTypeEnum


def compiler_filtration(constructs: ConstructMapping, config: ArtemisTaskConfig) -> dict[UUID, list[UUID]]:
    """
    Brute force search through the space to eliminate constructs that can't be
    substituted
    """
    logger.info("Compiler validation starting")
    logger.info(f"Tests: {', '.join([t.value for t in config.filter_types])}")
    logger.info(f"Tests: {config.filter_types}")
    assert config.project_path is not None, "Project path must be provided"
    assert conf_mgr.artemis_settings.artemis_task is not None, "Settings must be set"

    # Run Original
    log_og_file_id = {}
    if not constructs.root or conf_mgr.artemis_settings.artemis_task.filter_run_original:
        # only build the original if no constructs were passed in (project level)
        success_og, log_og, evaluation_results = build_original(
            config.project_path, config, conf_mgr.artemis_settings.incremental_build, False
        )
        for filter_type, val in success_og.items():
            cpu_avg = mem_avg = runtime = None
            if evaluation_results and evaluation_results.get(filter_type):
                cpu_avg = evaluation_results.get(filter_type).cpu_avg
                mem_avg = evaluation_results.get(filter_type).mem_avg
                runtime = evaluation_results.get(filter_type).runtime
            log_og_file_id[filter_type] = OutputManager.verify_spec(
                None,
                None,
                filter_type,
                val,
                logs=log_og.get(filter_type),
                cpu=cpu_avg,
                memory=mem_avg,
                runtime=runtime,
            )
        if all(success_og.values()):
            logger.info("Original project built and tested successfully")
        else:
            logger.info("Original project failed to build and test")

    # Config
    backup_made = conf_mgr.artemis_settings.build_backup_dir.exists()
    og_project = (
        conf_mgr.artemis_settings.build_backup_dir
        if backup_made and conf_mgr.artemis_settings.incremental_build
        else config.project_path
    )

    # Substitutor
    sub = Substitutor(
        constructs=constructs,
        project_path=og_project,
        project_output_path=conf_mgr.artemis_settings.output_path,
    )

    # Mapping from construct id to spec id for all passing
    passing_ids: dict[UUID, list[UUID]] = {}

    if constructs.root:
        logger.info("Testing alternatives")
        sorted_construct_ids = sorted(
            constructs.root.keys(),
            key=lambda x: (constructs.root[x].created_at, constructs.root[x].id),
        )
        for i, construct_id in enumerate(sorted_construct_ids):
            construct = constructs.root[construct_id]
            target_id_short = str(construct.id)[:-5]
            passed_specs: list[CustomSpecChildResponse] = []
            failed_specs: list[CustomSpecChildResponse] = []
            logger.info(
                f"[{i + 1}/{len(constructs.root)}] Testing code snippet"
                f" {target_id_short} ({construct.file} {construct.lineno}:{construct.end_lineno}):"
            )
            for spec in sorted(construct.custom_specs, key=lambda c: (c.created_at, c.id)):
                if spec.id != construct.original_spec_id:
                    logger.info(f"[{i + 1}/{len(constructs.root)}] Testing alternative {spec.name}:")
                    shutil.rmtree(conf_mgr.artemis_settings.build_dir, not_exists_ok=True)
                    solution = Solution(constructs=[SolutionEntry(construct_id=construct_id, spec_id=spec.id)])
                    new_path = sub.substitute(solution, "build")
                    viable, logs, evaluation_results = _test_alternative(
                        new_path,
                        config,
                        types=conf_mgr.artemis_settings.artemis_task.filter_types,
                        backup=(not backup_made) and conf_mgr.artemis_settings.incremental_build,
                    )

                    if all(viable.values()):
                        if (
                            not backup_made
                            and conf_mgr.artemis_settings.incremental_build
                            and conf_mgr.artemis_settings.build_backup_dir.exists()
                        ):
                            # clean up project if incremental build was used
                            reset_file(
                                spec.file_operation,
                                construct.file,
                                conf_mgr.artemis_settings.build_backup_dir,
                                config.project_path,
                            )
                            backup_made = True
                            og_project = conf_mgr.artemis_settings.build_backup_dir
                            sub.project_path = og_project
                        passed_specs.append(spec)
                    else:
                        failed_specs.append(spec)
                    for filter_type, val in viable.items():
                        cpu_avg = mem_avg = runtime = None
                        if evaluation_results and evaluation_results.get(filter_type):
                            cpu_avg = evaluation_results.get(filter_type).cpu_avg
                            mem_avg = evaluation_results.get(filter_type).mem_avg
                            runtime = evaluation_results.get(filter_type).runtime
                        OutputManager.verify_spec(
                            construct_id=str(construct_id),
                            spec_id=str(spec.id),
                            type=filter_type,
                            passed=val,
                            logs=logs.get(filter_type),
                            cpu=cpu_avg,
                            memory=mem_avg,
                            runtime=runtime,
                        )

                if passed_specs:
                    logger.info(
                        f"[{i + 1}/{len(constructs.root)}] Code snippet"
                        f" {target_id_short} ({construct.file} {construct.lineno}:{construct.end_lineno})"
                        f" has ({len(passed_specs)}/{len(construct.custom_specs) - 1})"
                        " valid alternatives:"
                    )
                    success_list = ", ".join(str(s.id) for s in passed_specs)
                    logger.info(f"\t✓ Successful: {success_list}")
                    if len(failed_specs) > 0:
                        failed_list = ", ".join(str(s.id) for s in failed_specs)
                        logger.info(f"\t✗ Failed: {failed_list}")
                else:
                    logger.info(
                        f"[{i + 1}/{len(constructs.root)}] Code Snippet"
                        f" {target_id_short} ({construct.file} {construct.lineno}:{construct.end_lineno})"
                        " has no valid alternatives"
                    )

            passing_ids[construct_id] = [s.id for s in passed_specs]

    return passing_ids


def reset_file(operation: FileOperationEnum, file_path: str, target_dir: Path, source_dir: Path) -> None:
    """Reset a file to its original state for incremental builds.

    For ADD operations: removes the file and any empty directories created.
    For EDIT/DELETE operations: restores the original file from source.

    Args:
        operation: The type of file operation that was applied
        file_path: Path to the file relative to project root
        target_dir: Directory containing the modified file to reset
        source_dir: Directory containing the original file state
    """
    if not target_dir:
        return

    target_file = target_dir / file_path

    if operation == FileOperationEnum.ADD:
        # Remove the file to reset to original state
        if target_file.exists():
            target_file.unlink()

        # Clean up directories that were created by the ADD operation
        # Only remove directories that don't exist in the original project
        current_dir = target_file.parent
        while current_dir != target_dir:
            # Check if this directory exists in the original project
            original_dir = source_dir / current_dir.relative_to(target_dir)

            if not original_dir.exists():
                # This directory was created by ADD, safe to remove if empty
                try:
                    current_dir.rmdir()
                    current_dir = current_dir.parent
                except (OSError, FileNotFoundError):
                    # Directory not empty (has other files) or doesn't exist
                    break
            else:
                # This directory exists in original, don't remove
                break
    else:
        # For EDIT/DELETE, copy the original file as before
        if target_file.exists():
            # delete file from original project just in case
            # we've had issues with overwriting files on Windows in the past
            target_file.unlink()
        # Ensure parent directory exists
        target_file.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(
            source_dir / file_path,
            target_file,
        )


def build_original(
    source_path: Path,
    run_conf: ArtemisTaskConfig,
    make_backup: bool = True,
    fail_on_error: bool = False,
) -> tuple[dict[ValidationFilterTypeEnum, bool], dict[str, str], dict[ValidationFilterTypeEnum, EvaluationResults]]:
    logger.info("Running original project")
    shutil.copytree(source_path, conf_mgr.artemis_settings.build_dir, symlinks=True)
    assert conf_mgr.artemis_settings.artemis_task, "No artemis task"
    success, logs, evaluation_results = _test_alternative(
        conf_mgr.artemis_settings.build_dir,
        run_conf,
        clean=False,
        types=conf_mgr.artemis_settings.artemis_task.filter_types,
        backup=make_backup,
    )
    if not all(success.values()) and fail_on_error:
        raise Exception("Original project failed to build")
    return success, logs, evaluation_results


def _test_alternative(
    source_path: Path,
    run_conf: ArtemisTaskConfig,
    types: list[ValidationFilterTypeEnum],
    clean: bool = True,
    name: str | None = None,
    backup: bool = False,
) -> tuple[dict[ValidationFilterTypeEnum, bool], dict[str, str], dict[ValidationFilterTypeEnum, EvaluationResults]]:
    """
    Given a substitution, attempt to compile the project and run unit tests.
    Return True if successful
    """

    def check_output(process_output: ExecutionResults | None) -> bool:
        return process_output is not None and process_output.status_code == 0

    try:
        build_system = BuildSystem(run_conf, source_path)
        comp_status = True
        build_logs = StringIO()
        final_logs: dict[ValidationFilterTypeEnum, str] = {}
        res: dict[ValidationFilterTypeEnum, bool] = {}
        evaluation_res: dict[ValidationFilterTypeEnum, EvaluationResults] = {}
        try:
            res[ValidationFilterTypeEnum.COMPILATION] = True
            with loguru_file_wrapper(build_logs):
                logger.info("Running build")
                out = build_system.build()
            comp_status = check_output(out)
            res[ValidationFilterTypeEnum.COMPILATION] = comp_status
            if out and out.evaluation:
                evaluation_res[ValidationFilterTypeEnum.COMPILATION] = EvaluationResults(
                    runtime=out.evaluation.runtime,
                    cpu_avg=out.evaluation.cpu_avg,
                    mem_avg=out.evaluation.mem_avg,
                )
        finally:
            build_logs.flush()
            final_logs[ValidationFilterTypeEnum.COMPILATION] = f"=====BUILD LOGS=====\n{build_logs.getvalue()}"
        if not comp_status:
            logger.info("Failed building")
        if comp_status and ValidationFilterTypeEnum.UNIT in types:
            unit_test_logs = StringIO()
            try:
                res[ValidationFilterTypeEnum.UNIT] = True
                with loguru_file_wrapper(unit_test_logs):
                    logger.info("Running unit test")
                    out = build_system.unit_test()
                res[ValidationFilterTypeEnum.UNIT] = check_output(out)
                if out and out.evaluation:
                    evaluation_res[ValidationFilterTypeEnum.UNIT] = EvaluationResults(
                        runtime=out.evaluation.runtime,
                        cpu_avg=out.evaluation.cpu_avg,
                        mem_avg=out.evaluation.mem_avg,
                    )
            finally:
                unit_test_logs.flush()
                final_logs[ValidationFilterTypeEnum.UNIT] = f"=====UNIT TEST LOGS=====\n{unit_test_logs.getvalue()}"
            if not res[ValidationFilterTypeEnum.UNIT]:
                logger.info("Failed unit testing")
        if comp_status and ValidationFilterTypeEnum.PERF in types:
            perf_logs = StringIO()
            try:
                res[ValidationFilterTypeEnum.PERF] = True
                with loguru_file_wrapper(perf_logs):
                    logger.info("Running performance tests")
                    out = build_system.perf_test()
                    res[ValidationFilterTypeEnum.PERF] = check_output(out)
                    if out and out.evaluation:
                        evaluation_res[ValidationFilterTypeEnum.PERF] = EvaluationResults(
                            runtime=out.evaluation.runtime,
                            cpu_avg=out.evaluation.cpu_avg,
                            mem_avg=out.evaluation.mem_avg,
                        )
            finally:
                perf_logs.flush()
                final_logs[ValidationFilterTypeEnum.PERF] = f"=====PERF LOGS=====\n{perf_logs.getvalue()}"
            if not res[ValidationFilterTypeEnum.PERF]:
                logger.info("Failed perf testing")
        # custom run doesn't depend on build
        if ValidationFilterTypeEnum.CUSTOM in types:
            custom_logs = StringIO()
            try:
                res[ValidationFilterTypeEnum.CUSTOM] = True
                with loguru_file_wrapper(custom_logs):
                    logger.info("Running custom command")
                    out = build_system.custom()
                    res[ValidationFilterTypeEnum.CUSTOM] = check_output(out)
                    if out and out.evaluation:
                        evaluation_res[ValidationFilterTypeEnum.CUSTOM] = EvaluationResults(
                            runtime=out.evaluation.runtime,
                            cpu_avg=out.evaluation.cpu_avg,
                            mem_avg=out.evaluation.mem_avg,
                        )
            finally:
                custom_logs.flush()
                final_logs[ValidationFilterTypeEnum.CUSTOM] = f"=====CUSTOM LOGS=====\n{custom_logs.getvalue()}"
            if not res[ValidationFilterTypeEnum.CUSTOM]:
                logger.info("Failed custom command")

        if all(res.values()) and backup:
            shutil.move(
                source_path,
                conf_mgr.artemis_settings.build_backup_dir,
            )
    finally:
        if clean:
            shutil.rmtree(source_path, not_exists_ok=True)
    return res, final_logs, evaluation_res
