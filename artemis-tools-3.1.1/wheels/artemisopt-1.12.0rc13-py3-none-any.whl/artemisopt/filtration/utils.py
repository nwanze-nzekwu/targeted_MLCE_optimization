from typing import TypeVar
from uuid import UUID

from falcon_models.api import CustomSpecChildResponse
from falcon_models.enums import ValidationFilterTypeEnum
from loguru import logger

from artemisopt.conf.artemis_input import ArtemisTaskConfig
from artemisopt.filtration.compilation import compiler_filtration
from artemisopt.models.code import ConstructMapping

T = TypeVar("T")


def merge_alt_dicts(
    dict1: dict[UUID, list[T]], dict2: dict[UUID, list[T]]
) -> dict[UUID, list[T]]:
    merged_dict: dict[UUID, list[T]] = {}
    for key in dict1.keys():
        merged_dict[key] = list(set(dict1[key]) & (set(dict2[key])))
    return merged_dict


def run_filtering(
    constructs: ConstructMapping, config: ArtemisTaskConfig
) -> ConstructMapping:
    all_alts: list[dict[UUID, list[UUID]]] = []
    if ValidationFilterTypeEnum.SECURITY in config.filter_types:
        logger.warning("Security validation option is deprecated. Skipping...")
    else:
        all_alts.append(compiler_filtration(constructs, config))

    if len(all_alts) > 0:
        final_alts = all_alts[0]
        for alts in all_alts[1:]:
            final_alts = merge_alt_dicts(final_alts, alts)
    else:
        final_alts = {}

    filtered = constructs.model_copy()
    for construct in filtered.root.values():
        filtered_specs: list[CustomSpecChildResponse] = []
        for spec in construct.custom_specs:
            if spec.id in final_alts.get(construct.id, []):
                filtered_specs.append(spec)
        construct.custom_specs = filtered_specs

    return filtered
