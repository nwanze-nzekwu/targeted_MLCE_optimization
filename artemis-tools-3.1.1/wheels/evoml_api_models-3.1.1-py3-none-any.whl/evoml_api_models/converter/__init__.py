from .highcharts.interface import convert_highcharts_graph as convert_highcharts
from .highcharts.interface import convert_highcharts_graph as convert_graph
